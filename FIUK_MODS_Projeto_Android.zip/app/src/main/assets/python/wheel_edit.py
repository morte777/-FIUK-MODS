"""Edit vehicle wheel configurations; never write to shared game-base assets."""
import copy,math,posixpath,uuid,xml.etree.ElementTree as ET
from core import I3D
from wheel_preview import Assembly,values,node_index
from decals import spans,append_element
from xml_edit import replace,whole_end
from scene_tools import scene_paths,label

def scaled_tire(editor,assembly,target,tire,vehicle,factors,pending):
    """GIANTS does not read tire#scale: bake it into a private I3D root.

    Keep every shape byte and hierarchy index. Shared textures/shaders stay
    native; the external geometry is copied beside the private I3D.
    """
    source=assembly.wheel_definition(target,vehicle)[1]
    resource=assembly.resolve(tire.get('filename'),source)
    if not resource:raise ValueError('Modelo do pneu nao encontrado. Conecte a base correta.')
    doc=I3D(editor.read_resource(resource));left=target.get('isLeft','true') not in ('false','0')
    node=tire.get('node') or tire.get('nodeLeft' if left else 'nodeRight','0|0');index=node_index(doc.nodes,node)
    if index is None:raise ValueError('Indice do pneu nao encontrado no I3D.')
    destination='gabriel_rodas/'+uuid.uuid4().hex[:16]+'/pneu.i3d';folder=posixpath.dirname(destination)
    raw=doc.patch(index,{'scale':[a*b for a,b in zip(doc.nodes[index]['scale'],factors)]})
    current=I3D(raw);_,items=spans(current.text)
    from xml_edit import attributes
    for item in reversed(items):
        attr='externalShapesFile' if item['attrs'].get('externalShapesFile') else 'filename' if item['local']=='File' else None
        if not attr:continue
        ref=item['attrs'].get(attr)
        if not ref:continue
        if attr=='filename' and ref.startswith('$'):continue
        found=editor.resolve_resource(ref,resource)
        if not found:raise ValueError('Recurso do pneu nao encontrado: '+ref)
        if attr=='externalShapesFile':
            logical='pneu.i3d.shapes';pending[folder+'/'+logical]=editor.read_resource(found,256*1024*1024)
        elif found.startswith('base:'):
            path=found.split('/',1)[1];logical='$data/'+path[5:] if path.startswith('data/') else '$'+path
        else:
            logical=posixpath.relpath(found,folder)
            if found.lower().endswith(('.ast','.astc')) and ref.lower().endswith(('.png','.dds')):logical=posixpath.splitext(logical)[0]+'.png'
        if found.lower().endswith(('.ast','.astc')) and ref.lower().endswith(('.png','.dds')):logical=posixpath.splitext(logical)[0]+'.png'
        raw=attributes(current,item,{attr:logical});current=I3D(raw)
    pending[destination]=raw
    return destination

def context(editor,model,configuration):
    scene=editor.scene(model,include_wheels=False);assembly=Assembly(editor,scene,model)
    vehicle,root=assembly.vehicle()
    if not vehicle:raise ValueError('Abra o veiculo com seu XML e suas rodas.')
    wheels=root.find('wheels');configs=assembly.configurations(wheels)
    if type(configuration)!=int or not 0<=configuration<len(configs):raise ValueError('Escolha uma configuracao de rodas.')
    assembly.base_owner=vehicle
    effective=assembly.effective(configs,configuration)
    return vehicle,root,wheels,configs,effective,assembly

def catalog(editor):
    candidates=[n for n in editor.archive_index()[0].values() if n.lower().endswith('.xml') and 'wheel' in n.lower()]
    overrides=editor.meta()['overrides']
    stamp=(editor.project,editor.base.id if editor.base else None,tuple((n,overrides.get(n)) for n in candidates))
    if getattr(editor,'_wheel_catalog_stamp',None)==stamp:return copy.deepcopy(editor._wheel_catalog)
    if editor.base:candidates+=['base:'+editor.base.id+'/'+key for key,_,size in editor.base.entries.values() if key.lower().endswith('.xml') and '/wheels/' in key.lower() and size<1024*1024]
    rows=[]
    for resource in candidates[:6000]:
        try:
            root=ET.fromstring(I3D(editor.read_resource(resource,1024*1024)).text)
            if root.tag not in ('wheel','hub'):continue
            reference=resource
            if reference.startswith('base:'):
                path=reference.split('/',1)[1];reference='$data/'+path[5:] if path.startswith('data/') else '$'+path
            rows.append({'kind':root.tag,'filename':reference,'name':posixpath.basename(resource)[:-4],'configIds':['default']+[c.get('id') for c in root.findall('configurations/configuration') if c.get('id') and c.get('id')!='default']})
        except (ValueError,OSError,KeyError,ET.ParseError):continue
    editor._wheel_catalog_stamp=stamp;editor._wheel_catalog=rows
    return copy.deepcopy(rows)

def options(editor,model,configuration):
    with editor.lock:
        vehicle,root,wheels,configs,effective,assembly=context(editor,model,configuration)
        scene=editor.scene(model,wheel_config=configuration)
        return {'project':editor.project.name,'revision':editor.meta()['revision'],'file':model,'vehicle':vehicle,'configuration':configuration,'wheels':scene.get('wheelInfo',{}).get('wheels',[]),'catalog':[r for r in catalog(editor) if r['kind']=='wheel'],'hubs':[r for r in catalog(editor) if r['kind']=='hub'],'rims':[('$data/'+k[5:] if k.startswith('data/') else '$'+k) for k,_,_ in editor.base.entries.values() if k.lower().endswith('.i3d') and '/wheels/rims/' in k.lower()] if editor.base else [],'configurations':[{'name':c.get('name','Padrao'),'index':i,'price':c.get('price','0')} for i,c in enumerate(configs)]}

def scalar(value,name,lo,hi):
    if type(value) not in (int,float) or not math.isfinite(value) or not lo<=value<=hi:raise ValueError(name+' fora do limite permitido.')
    return float(value)
def fmt(seq):return ' '.join(format(v,'.9g') for v in seq)

def save(editor,body):
    with editor.lock:
        if body.get('project')!=editor.project.name or body.get('revision')!=editor.meta()['revision']:raise ValueError('O projeto mudou. Reabra as rodas.')
        vehicle,root,wheels,configs,config,assembly=context(editor,body['file'],body['configuration'])
        if body.get('vehicle')!=vehicle:raise ValueError('O XML do veiculo mudou. Reabra as rodas.')
        action=body.get('action','adjust');pending={};doc=I3D(editor.read(vehicle));_,items=spans(doc.text)
        section=next(e for e in items if e['local']=='wheels' and e['depth']==1)
        config_group=wheels.find('wheelConfigurations')
        if config_group is None:
            # Normalize old direct-wheel XML without discarding hubs/rimColor.
            config_group=ET.SubElement(wheels,'wheelConfigurations')
            for child in list(wheels):
                if child.tag=='wheel':wheels.remove(child)
            ET.SubElement(config_group,'wheelConfiguration',{'name':'Padrao','saveId':'1'}).append(config.find('wheels'))
            configs=list(config_group)
        if action=='duplicate':
            title=label(body.get('name'),'Rodas novas');config.set('name',title)
            config.find('wheels').attrib.pop('baseConfig',None)
            from shop_options import money
            config.set('price',money(body.get('price',0)))
            ids={c.get('saveId',str(i+1)) for i,c in enumerate(configs)};serial=1
            while 'gabriel'+str(serial) in ids:serial+=1
            config.set('saveId','gabriel'+str(serial));config_group.append(config);selected=len(configs)
        elif action=='adjust':
            wheel_nodes=config.findall('wheels/wheel');index=body.get('wheel')
            if type(index)!=int or not 0<=index<len(wheel_nodes):raise ValueError('Selecione uma roda.')
            indices=[index]
            mappings={m.get('id'):m.get('node','') for m in root.findall('i3dMappings/i3dMapping')}
            assembly.mappings=mappings;assembly.object_changes(config)
            doc_model=I3D(editor.read(body['file']));paths=scene_paths(doc_model)
            def definition(i):return assembly.wheel_definition(wheel_nodes[i],vehicle)[0]
            source=definition(index);physics=source.find('physics')
            if physics is None:raise ValueError('Roda sem configuracao fisica.')
            anchor=node_index(assembly.scene['nodes'],physics.get('repr') or physics.get('driveNode'),mappings)
            if anchor is None:raise ValueError('Ponto de montagem da roda nao encontrado.')
            position=body.get('position')
            if not isinstance(position,list) or len(position)!=3:raise ValueError('Informe X, Y e Z da roda.')
            position=[scalar(v,'Posicao',-100,100) for v in position]
            radius=scalar(body.get('radius'),'Raio do pneu',.05,5);width=scalar(body.get('width'),'Largura do pneu',.02,5)
            if body.get('pair'):
                # Pair by opposite side and longitudinal mounting position;
                # refuse ambiguity instead of adjusting an unrelated axle.
                z=assembly.scene['nodes'][anchor]['translation'][2];others=[]
                for j in range(len(wheel_nodes)):
                    d=definition(j);p=d.find('physics')
                    if j==index or p is None or d.get('isLeft','true')==source.get('isLeft','true'):continue
                    a=node_index(assembly.scene['nodes'],p.get('repr') or p.get('driveNode'),mappings)
                    if a is not None and abs(assembly.scene['nodes'][a]['translation'][2]-z)<.15 and doc_model.nodes[a]['parent']==doc_model.nodes[anchor]['parent']:others.append(j)
                if len(others)!=1:raise ValueError('Par do eixo ambiguo ou ausente. Ajuste cada roda separadamente.')
                indices+=others
            for j in indices:
                current=definition(j);old=current.find('physics');target=wheel_nodes[j]
                a=node_index(assembly.scene['nodes'],old.get('repr') or old.get('driveNode'),mappings)
                filename=body.get('filename',target.get('filename',''));config_id=body.get('configId','default')
                if filename!=target.get('filename','') or config_id!=target.get('configId','default'):
                    if not isinstance(filename,str) or not filename:raise ValueError('Escolha um XML de pneu valido.')
                    probe=ET.Element('wheel',{'filename':filename,'configId':config_id});replacement,_=assembly.wheel_definition(probe,vehicle)
                    if replacement.find('tire') is None:raise ValueError('O XML escolhido nao define um pneu.')
                    target.set('filename',filename);target.set('configId',config_id)
                    for part in list(target):
                        if part.tag in ('tire','outerRim','innerRim','additional'):target.remove(part)
                    current=assembly.wheel_definition(target,vehicle)[0];old=current.find('physics')
                parts=body.get('parts',{})
                if not isinstance(parts,dict) or set(parts)-{'outerRim','innerRim'}:raise ValueError('Selecao de aros invalida.')
                for role,part_values in parts.items():
                    if not isinstance(part_values,dict) or set(part_values)-{'filename','node'}:raise ValueError('Definicao de aro invalida.')
                    part=current.find(role)
                    if part is None:raise ValueError('Este pneu nao define '+role+'.')
                    ref=part_values.get('filename') or part.get('filename');node=part_values.get('node') or part.get('node') or part.get('nodeLeft' if current.get('isLeft','true') not in ('false','0') else 'nodeRight','0|0')
                    resource=assembly.resolve(ref,assembly.wheel_definition(target,vehicle)[1])
                    if not resource or not resource.lower().endswith('.i3d'):raise ValueError('I3D do aro nao encontrado.')
                    asset=editor.scene(resource,include_wheels=False)
                    if node_index(asset['nodes'],node) is None:raise ValueError('Indice do aro nao existe neste I3D.')
                    override=target.find(role)
                    if override is None:override=ET.SubElement(target,role)
                    override.set('filename',ref);override.set('node',node)
                hubref=body.get('hub')
                if hubref:
                    resource=assembly.resolve(hubref,vehicle)
                    if not resource or assembly.xml(resource).tag!='hub':raise ValueError('XML de cubo nao encontrado.')
                    matched_hub=False
                    for hub in wheels.findall('hubs/hub'):
                        link=node_index(doc_model.nodes,hub.get('linkNode'),mappings)
                        if link in (a,node_index(doc_model.nodes,old.get('driveNode') or old.get('repr'),mappings)):hub.set('filename',hubref);matched_hub=True
                    if not matched_hub:raise ValueError('Cubo separado deste ponto de roda. Ajuste o XML de hubs para esta montagem.')
                oldradius=scalar(float(old.get('radius','0')),'Raio original',.001,10);oldwidth=scalar(float(old.get('width','0')),'Largura original',.001,10)
                tire=current.find('tire')
                if tire is None:raise ValueError('Pneu sem definicao visual.')
                scale=values(tire.get('scale'),[1,1,1]);scale=[scale[0]*width/oldwidth,scale[1]*radius/oldradius,scale[2]*radius/oldradius]
                override=target.find('tire')
                if override is None:override=ET.SubElement(target,'tire')
                if any(abs(v-1)>1e-8 for v in scale):
                    override.set('filename',scaled_tire(editor,assembly,target,tire,vehicle,scale,pending))
                override.attrib.pop('scale',None)
                for role in ('outerRim','innerRim'):
                    part=current.find(role)
                    if part is not None and part.get('widthAndDiam'):
                        dims=values(part.get('widthAndDiam'),[0,0]);dims[0]*=width/oldwidth
                        rim=target.find(role)
                        if rim is None:rim=ET.SubElement(target,role)
                        rim.set('widthAndDiam',fmt(dims))
                override=target.find('physics')
                if override is None:override=ET.SubElement(target,'physics')
                override.set('radius',format(radius,'.9g'));override.set('width',format(width,'.9g'))
                dual_mode=body.get('dualMode','keep')
                if dual_mode not in ('keep','single','double','triple'):raise ValueError('Configuracao de rodas duplas invalida.')
                if dual_mode!='keep':
                    for extra in list(target.findall('additionalWheel')):target.remove(extra)
                    if dual_mode!='single':
                        if not target.get('filename'):raise ValueError('Escolha um XML de pneu antes de criar duplas.')
                        gap=scalar(body.get('dualGap',.1),'Distancia entre pneus duplos',0,2)
                        rim=target.find('outerRim');rim=rim if rim is not None and rim.get('widthAndDiam') else current.find('outerRim')
                        rim_width=values(rim.get('widthAndDiam'),[0,0])[0]*.0254 if rim is not None and rim.get('widthAndDiam') else width
                        for serial in range(1 if dual_mode=='double' else 2):
                            attrs={k:v for k,v in target.attrib.items() if k in ('filename','configId','isLeft','color','isInverted')};attrs['offset']=format(gap+serial*(rim_width+gap),'.9g');additional=ET.SubElement(target,'additionalWheel',attrs)
                            for role in ('tire','outerRim','innerRim'):
                                part=target.find(role)
                                if part is not None:additional.append(copy.deepcopy(part))
                            ET.SubElement(additional,'physics',{'radius':format(radius,'.9g'),'width':format(width,'.9g')})
                newposition=position[:] if j==index else [-position[0],position[1],position[2]]
                change=next((c for c in config.findall('objectChange') if node_index(doc_model.nodes,c.get('node'),mappings)==a),None)
                if change is None:change=ET.SubElement(config,'objectChange',{'node':paths[a]})
                change.set('translationActive',fmt(newposition));change.set('translationInactive',fmt(doc_model.nodes[a]['translation']))
            # Materialize inherited wheel attributes to isolate this choice.
            config.find('wheels').attrib.pop('baseConfig',None)
            selected=body['configuration'];oldconfig=list(config_group)[selected];at=list(config_group).index(oldconfig);config_group.remove(oldconfig);config_group.insert(at,config)
        else:raise ValueError('Operacao de roda desconhecida.')
        raw=replace(doc,section,ET.tostring(wheels,encoding='utf-8'))
        pending[vehicle]=raw
        result=editor.change_many(pending,body['revision'])
        return {'project':result,'configuration':selected,'wheel':body.get('wheel',0)}

"""Embedded V1.14 vehicle converter, persistent jobs and streamed ZIP input."""
import copy,json,re,secrets,shutil,threading,time
from pathlib import Path
from urllib.parse import unquote
from core import atomic,jsonbytes

class Cancelled(Exception):pass
_current=None
def current():
    if _current is None:raise ValueError('Conversor disponível no APK do editor.')
    return _current

class ConversionJobs:
    def __init__(self,directory):
        global _current
        _current=self
        self.directory=Path(directory);self.directory.mkdir(parents=True,exist_ok=True)
        self.lock=threading.RLock();self.worker=threading.Lock();self.jobs={};self.cancelled=set()
        for path in self.directory.glob('*/job.json'):
            try:
                row=json.loads(path.read_text())
                if not re.fullmatch('[0-9a-f]{32}',row['id']) or path.parent.name!=row['id']:continue
                if row['status'] in ('convertendo','fila'):
                    row.update(status='interrompido',message='A conversão foi interrompida. O ZIP recebido continua preservado. Selecione-o novamente para repetir.')
                    atomic(path,jsonbytes(row))
                self.jobs[row['id']]=row
            except (OSError,ValueError,KeyError):continue
    def info(self):
        from gm_vehicle_converter.engine.converter import FAST
        return {'version':'1.19','fast':FAST,'sources':['FS19','FS25'],'targets':['FS22','FS23'],'maxBytes':1024**3}
    def list(self):
        with self.lock:return [copy.deepcopy({k:v for k,v in row.items() if k!='report'}) for row in sorted(self.jobs.values(),key=lambda j:j['created'],reverse=True)]
    def get(self,identifier):
        with self.lock:
            if not isinstance(identifier,str) or not re.fullmatch('[0-9a-f]{32}',identifier) or identifier not in self.jobs:raise ValueError('Conversão não encontrada.')
            return copy.deepcopy(self.jobs[identifier])
    def update(self,identifier,**values):
        with self.lock:
            row=self.jobs[identifier];row.update(values)
            atomic(self.directory/identifier/'job.json',jsonbytes(row))
    def upload(self,stream,length,name,target,options=None):
        if type(length)!=int or not 0<length<=1024**3:raise ValueError('Selecione um ZIP de até 1 GB.')
        name=Path(unquote(name).replace('\\','/')).name
        if not name.lower().endswith('.zip') or len(name)>200:raise ValueError('Selecione um arquivo ZIP.')
        if target not in ('FS22','FS23'):raise ValueError('Destino inválido.')
        options=options or {'textures':False,'maxSize':1024,'quality':'fast'}
        if type(options.get('textures'))!=bool or type(options.get('maxSize'))!=int or options['maxSize'] not in (0,256,512,1024,2048,4096) or options.get('quality') not in ('fast','medium'):raise ValueError('Opções de texturas inválidas.')
        if not self.worker.acquire(False):raise ValueError('Aguarde a conversão atual terminar.')
        folder=None
        try:
            if shutil.disk_usage(self.directory).free<length*3+128*1024**2:raise ValueError('Libere espaço para extrair e salvar o mod.')
            identifier=secrets.token_hex(16);folder=self.directory/identifier;folder.mkdir()
            source=folder/'entrada.zip';remaining=length
            with source.open('wb') as f:
                while remaining:
                    data=stream.read(min(1024*1024,remaining))
                    if not data:raise ValueError('Envio interrompido. Selecione o arquivo novamente.')
                    f.write(data);remaining-=len(data)
            stem=re.sub('[^a-zA-Z0-9_]','_',Path(name).stem)[:100] or 'mod'
            stem=re.sub(r'^(?:BASE_FS23_|FS19_|FS22_|FS23_|FS25_)','',stem,flags=re.I) or 'mod'
            if stem[:1].isdigit():stem='MOD_'+stem
            output=('FS22_' if target=='FS22' else 'FS23_' if options['textures'] else 'BASE_FS23_')+stem+'_GabrielMods.zip'
            row={'id':identifier,'name':name,'target':target,'outputName':output,'status':'fila','percent':0,'message':'ZIP recebido','created':time.time(),'textureOptions':dict(options)}
            with self.lock:self.jobs[identifier]=row
            self.update(identifier)
            threading.Thread(target=self.run,args=(identifier,source,folder/'trabalho',target),daemon=True,name='ConverterMod').start()
            return self.get(identifier)
        except Exception:
            if folder:
                with self.lock:self.jobs.pop(folder.name,None)
                shutil.rmtree(folder,ignore_errors=True)
            self.worker.release();raise
    def run(self,identifier,source,work,target):
        last=0;notify_started=False
        def progress(percent,message):
            nonlocal last
            with self.lock:
                if identifier in self.cancelled:raise Cancelled('Conversão cancelada. O ZIP original foi preservado.')
            now=time.monotonic()
            if now-last>=.25 or percent==100:
                self.update(identifier,percent=percent,message=message);last=now
        try:
            from gm_vehicle_converter.engine.converter import convert
            self.update(identifier,status='convertendo',message='Preparando arquivos')
            options=self.get(identifier).get('textureOptions',{'textures':False,'maxSize':1024,'quality':'fast'});with_textures=target=='FS23' and options['textures']
            output,report=convert(source,work,target,(lambda p,m:progress(int(p*.65),m)) if with_textures else progress)
            if with_textures:
                from vehicle_textures import prepare
                notify_started=True;output=prepare(output,work,report,options,progress,identifier)
            progress(100,'Conferindo resultado')
            output.replace(self.directory/identifier/'resultado.zip')
            self.update(identifier,status='concluido',percent=100,message='Concluído. Confira o relatório antes de usar no jogo.',report=report)
        except Cancelled as error:self.update(identifier,status='cancelado',message=str(error))
        except Exception as error:self.update(identifier,status='erro',message=str(error),percent=0)
        finally:
            if notify_started:
                try:
                    from android_notifications import notify
                    row=self.get(identifier);textures=row.get('report',{}).get('texturas_fs23',{});count=textures.get('convertidas',0)
                    notify({'id':identifier,'state':'done' if row['status']=='concluido' else 'cancelled' if row['status']=='cancelado' else 'error','phase':'done' if row['status']=='concluido' else 'error','percent':row['percent'],'done':count,'total':count+len(textures.get('nao_convertidas',[])),'file':'','error':row['message'],'elapsed':0})
                except Exception:pass
            shutil.rmtree(work,ignore_errors=True)
            with self.lock:self.cancelled.discard(identifier)
            self.worker.release()
    def output(self,identifier):
        row=self.get(identifier)
        if row['status']!='concluido':raise ValueError('Resultado ainda não está disponível.')
        path=self.directory/identifier/'resultado.zip'
        if not path.is_file():raise ValueError('ZIP de resultado indisponível.')
        return path,row
    def cancel(self,identifier):
        row=self.get(identifier)
        if row['status'] not in ('fila','convertendo'):return row
        with self.lock:self.cancelled.add(identifier)
        return row
    def delete(self,identifier):
        row=self.get(identifier)
        if row['status'] in ('fila','convertendo'):raise ValueError('Cancele e aguarde a conversão antes de excluir.')
        with self.lock:
            shutil.rmtree(self.directory/identifier);self.jobs.pop(identifier)
        return {'deleted':identifier}

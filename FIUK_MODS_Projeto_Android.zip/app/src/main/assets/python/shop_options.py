"""Create/edit managed design groups; original choices use optional_manager."""
import math,posixpath,re,uuid,xml.etree.ElementTree as ET
from core import I3D,tagname
from xml.parsers.expat import ExpatError
from decals import spans,append_element
from scene_tools import scene_paths,selection,is_anchor
from xml_edit import replace

SLOTS=['design']+['design'+str(i) for i in range(2,9)]

def canonical(path):
    if not isinstance(path,str):return None
    path=path.strip()
    if not re.fullmatch(r'\d+(?:>\d*(?:\|\d+)*)?',path):return None
    if '>' not in path:return str(int(path))
    root,tail=path.split('>')
    return str(int(root))+('>'+'|'.join(str(int(p)) for p in tail.split('|')) if tail else '')

def model(editor,name):
    if not isinstance(name,str) or not name.lower().endswith('.i3d') or name.startswith('base:'):raise ValueError('Abra o I3D principal do mod.')
    return I3D(editor.read(name))

def vehicles(editor,name):
    found=[]
    for entry in editor.summary()['files']:
        filename=entry['name']
        if not filename.lower().endswith('.xml'):continue
        try:
            doc=I3D(editor.read(filename));root=ET.fromstring(doc.text)
            if tagname(root.tag)!='vehicle':continue
            reference=root.findtext('base/filename')
            if not reference or editor.resolve_resource(reference.strip(),filename)!=name:continue
            found.append((filename,doc,root))
        except (ValueError,OSError,ET.ParseError,ExpatError,UnicodeError):continue
    return sorted(found,key=lambda item:(posixpath.splitext(item[0])[0]!=posixpath.splitext(name)[0],item[0]))

def groups(root):
    used=[]
    for slot in SLOTS:
        sections=root.findall(slot+'Configurations')
        if sections:
            used.append({'slot':slot,'title':sections[0].get('title') or slot,'choices':[e.get('name','') for e in sections[0].findall(slot+'Configuration')]})
    # configurationSets can reserve a group even without a section.
    reserved={e.get('name') for e in root.findall('.//configurationSets/configurationSet/configuration')}
    occupied={g['slot'] for g in used}|reserved
    return used,[slot for slot in SLOTS if slot not in occupied]

def inspect(editor,name,vehicle=None):
    with editor.lock:
        model(editor,name);matches=vehicles(editor,name)
        if not matches:raise ValueError('Nenhum XML de veiculo aponta para este I3D em base/filename. Abra o mod completo com o XML do veiculo.')
        chosen=next((item for item in matches if item[0]==vehicle),None) if vehicle is not None else matches[0]
        if chosen is None:raise ValueError('Esse XML nao pertence ao I3D aberto.')
        used,free=groups(chosen[2])
        return {'file':name,'vehicle':chosen[0],'vehicles':[v[0] for v in matches],'used':used,'freeSlots':free,'revision':editor.meta()['revision'],'managed':managed_groups(chosen[2],model(editor,name))}

def text(value,label):
    if not isinstance(value,str) or not value.strip() or len(value.strip())>80 or any(ord(c)<32 for c in value):raise ValueError('Informe '+label+' com 1 a 80 caracteres.')
    if value.strip().startswith('$'):raise ValueError('Use um nome direto em '+label+', sem referencias $l10n.')
    return value.strip()

def money(value):
    if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value) or not 0<=value<=10000000:raise ValueError('Preco invalido: use um valor de 0 a 10.000.000.')
    if abs(value*100-round(value*100))>1e-6:raise ValueError('O preco deve ter no maximo duas casas decimais.')
    return format(value,'.2f')

def managed_groups(root,doc):
    paths={path:i for i,path in scene_paths(doc).items()};managed=[]
    reserved={e.get('name') for e in root.findall('.//configurationSets/configurationSet/configuration')}
    for slot in SLOTS:
        sections=root.findall(slot+'Configurations')
        if len(sections)!=1:continue
        section=sections[0];configs=list(section);tokens=[re.fullmatch(r'(gm_[0-9a-f]{12})_([0-9a-z]+)',e.get('saveId','')) for e in configs]
        if not configs or not all(tokens) or len({m.group(1) for m in tokens})!=1:continue
        info={'slot':slot,'title':section.get('title') or slot,'options':[],'editable':True,'reason':''}
        try:
            if not 2<=len(configs)<=20 or len({c.get('saveId') for c in configs})!=len(configs) or set(section.attrib)!={'title'} or slot in reserved:raise ValueError('Grupo referenciado por configurationSets ou alterado manualmente.')
            all_paths=None
            for config in configs:
                if config.tag!=slot+'Configuration' or set(config.attrib)!={'name','price','saveId'}:raise ValueError('A configuracao possui atributos adicionais.')
                indices=[];references=set()
                for change in config:
                    if change.tag!='objectChange' or set(change.attrib)!={'node','visibilityActive','visibilityInactive'}:raise ValueError('A configuracao possui controles adicionais.')
                    path=canonical(change.get('node'));active=change.get('visibilityActive');inactive=change.get('visibilityInactive')
                    if path not in paths or path in references or active not in ('true','false') or inactive!=str(active=='false').lower():raise ValueError('Referencias ou controles de visibilidade foram alterados.')
                    references.add(path)
                    if active=='true':indices.append(paths[path])
                if not references or (all_paths is not None and references!=all_paths):raise ValueError('As escolhas controlam conjuntos de nos diferentes.')
                all_paths=references;price=float(config.get('price'));money(price)
                info['options'].append({'name':config.get('name'),'price':price,'saveId':config.get('saveId'),'indices':indices})
            selection(doc,[paths[p] for p in all_paths])
        except (ValueError,TypeError):info['editable']=False;info['reason']='Grupo protegido: XML ou referencias alterados. Confira pelo editor XML.'
        managed.append(info)
    return managed

def _association(editor,name,vehicle):
    matches=vehicles(editor,name);match=next((v for v in matches if v[0]==vehicle),None)
    if match is None:raise ValueError('Esse XML nao pertence ao I3D aberto.')
    return match[1],match[2]

def save(editor,name,vehicle,title,options,revision,slot=None):
    with editor.lock:
        if revision!=editor.meta()['revision']:raise ValueError('O projeto mudou. Reabra o painel de opcionais.')
        doc=model(editor,name);xml_doc,root=_association(editor,name,vehicle);used,free=groups(root)
        editing=slot is not None and slot not in free
        existing=None;current=None
        if editing:
            from optional_manager import protected_slots
            if slot in protected_slots(xml_doc):raise ValueError('Use Gerenciar opcionais para este grupo; ha escolhas desativadas ou removidas.')
            current=next((g for g in managed_groups(root,doc) if g['slot']==slot and g['editable']),None)
            if current is None:raise ValueError('Grupo ocupado ou protegido. Somente opcionais criados pelo editor podem ser editados.')
            existing=root.find(slot+'Configurations')
        if slot is None:slot=next(iter(free),None)
        if slot not in SLOTS or (not editing and slot not in free):raise ValueError('Grupo ocupado ou indisponivel. Este jogo usa design a design8.')
        title=text(title,'o titulo')
        if not isinstance(options,list) or not 2<=len(options)<=20:raise ValueError('Crie de 2 a 20 escolhas no grupo.')
        normalized=[];all_indices=set();names=set();old_ids={o['saveId'] for o in current['options']} if current else set();seen_ids=set()
        token=next(iter(old_ids)).rsplit('_',1)[0] if old_ids else 'gm_'+uuid.uuid4().hex[:12]
        for option in options:
            if not isinstance(option,dict):raise ValueError('Escolha invalida.')
            option_name=text(option.get('name'),'o nome da escolha');price=money(option.get('price'));indices=option.get('indices')
            if not isinstance(indices,list) or len(indices)>50 or any(type(i)!=int for i in indices) or len(indices)!=len(set(indices)):raise ValueError('Selecao de pecas invalida.')
            if option_name.casefold() in names:raise ValueError('Use nomes diferentes nas escolhas.')
            names.add(option_name.casefold());all_indices.update(indices)
            save_id=option.get('saveId')
            if save_id is not None and (save_id not in old_ids or save_id in seen_ids):raise ValueError('Identificador da escolha nao pertence a este grupo.')
            save_id=save_id or token+'_'+uuid.uuid4().hex[:8];seen_ids.add(save_id)
            normalized.append((option_name,set(indices),price,save_id))
        indices=selection(doc,sorted(all_indices))
        if len({tuple(sorted(option[1])) for option in normalized})<2:raise ValueError('As escolhas precisam mostrar conjuntos de pecas diferentes.')
        for i in indices:
            n=doc.nodes[i]
            if n['tag'] not in ('Shape','TransformGroup') or n['nonRenderable'] or is_anchor(n):raise ValueError('Escolha uma peca visual ou grupo do I3D principal.')
        paths=scene_paths(doc);path_nodes={path:i for i,path in paths.items()};mappings={e.get('id'):e.get('node') for e in root.findall('i3dMappings/i3dMapping')}
        def related(a,b):
            for child,parent in ((a,b),(b,a)):
                while child is not None:
                    if child==parent:return True
                    child=doc.nodes[child]['parent']
            return False
        for section in root:
            if section is existing:continue
            for change in section.iter('objectChange'):
                if change.get('visibilityActive') is None and change.get('visibilityInactive') is None:continue
                reference=change.get('node');target=path_nodes.get(canonical(mappings.get(reference,reference)))
                if target is not None and any(related(i,target) for i in indices):raise ValueError('Uma peca, pai ou filho ja tem visibilidade controlada neste XML. Use uma copia visual para criar outro opcional.')
        section=ET.Element(slot+'Configurations',{'title':title})
        for option_name,chosen,price,save_id in normalized:
            config=ET.SubElement(section,slot+'Configuration',{'name':option_name,'price':price,'saveId':save_id})
            for i in indices:
                active=i in chosen;ET.SubElement(config,'objectChange',{'node':paths[i],'visibilityActive':str(active).lower(),'visibilityInactive':str(not active).lower()})
        _,elements=spans(xml_doc.text);data=ET.tostring(section,encoding='utf-8')
        if editing:
            item=next(e for e in elements if e['depth']==1 and e['local']==slot+'Configurations');raw=replace(xml_doc,item,data)
        else:raw=append_element(xml_doc.utf8,elements[0],data).decode().encode(xml_doc.encoding,errors='xmlcharrefreplace')
        I3D(raw);project=editor.change(vehicle,raw,revision)
        return {'project':project,'file':name,'vehicle':vehicle,'slot':slot,'title':title,'choices':[o[0] for o in normalized],'indices':indices}

def remove(editor,name,vehicle,slot,revision):
    with editor.lock:
        if revision!=editor.meta()['revision']:raise ValueError('O projeto mudou. Reabra o painel de opcionais.')
        doc=model(editor,name);xml_doc,root=_association(editor,name,vehicle)
        from optional_manager import protected_slots
        if slot in protected_slots(xml_doc):raise ValueError('Use Gerenciar opcionais para remover este grupo.')
        if not any(g['slot']==slot and g['editable'] for g in managed_groups(root,doc)):raise ValueError('Grupo protegido. Somente opcionais criados pelo editor podem ser excluidos.')
        _,elements=spans(xml_doc.text);item=next(e for e in elements if e['depth']==1 and e['local']==slot+'Configurations');raw=replace(xml_doc,item,b'')
        return {'project':editor.change(vehicle,raw,revision),'vehicle':vehicle,'slot':slot}

def create(editor,name,vehicle,off_indices,on_indices,title,off_name,on_name,off_price,on_price,revision,slot=None):
    # Backward-compatible v15 two-choice API; an occupied group is never replaced.
    with editor.lock:
        if revision!=editor.meta()['revision']:raise ValueError('O projeto mudou. Reabra o painel de opcionais.')
        info=inspect(editor,name,vehicle)
        if slot is not None and slot not in info['freeSlots']:raise ValueError('Grupo ocupado ou indisponivel.')
        if not isinstance(off_indices,list) or not isinstance(on_indices,list) or not on_indices:raise ValueError('Escolha pelo menos uma peca para a opcao Com.')
        selection(model(editor,name),off_indices+on_indices)
        return save(editor,name,vehicle,title,[{'name':off_name,'price':off_price,'indices':off_indices},{'name':on_name,'price':on_price,'indices':on_indices}],revision,slot)

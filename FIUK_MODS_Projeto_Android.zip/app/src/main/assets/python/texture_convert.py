"""Explicit, undoable DDS -> FS23 AST conversion; preserve original DDS bytes."""
import base64,hashlib,json,posixpath,re
from xml.sax.saxutils import quoteattr,escape
from core import I3D
from decals import spans
from dds_texture import convert
from texture_v18 import header

MAX_BYTES=128*1024*1024

def catalog(editor,replace_existing=False,progress=None):
 with editor.lock:
  if not editor.project:raise ValueError('Abra um mod primeiro.')
  rows=[];names=editor.archive_index()[0]
  for path in sorted(names.values()):
   if not path.lower().endswith('.dds'):continue
   if progress:progress(phase='scan',file=path)
   row=dict(file=path,eligible=True,reason='',ast=posixpath.splitext(path)[0]+'.ast')
   try:
    info=header(editor.read_resource(path,148,head=True),False);row.update({k:info[k] for k in ('width','height','format','mipmaps')});row['layers']=info.get('layers',1)
    if info.get('layers'):row['note']='Array RGBA16F experimental: a DDS sera preservada.' if info.get('effect') else 'Array V18: exporta o mip principal de cada camada.'
    existing=next((names[posixpath.splitext(path)[0].casefold()+ext] for ext in ('.ast','.astc','.png') if posixpath.splitext(path)[0].casefold()+ext in names),None)
    if existing and not replace_existing:raise ValueError('Ja existe AST ou PNG com esse nome. A conversao nao sobrescreve texturas existentes.')
    if existing:
     row['existing']=existing
     if existing.lower().endswith('.ast'):row['ast']=existing
    if not info.get('layers') and (info['width']&(info['width']-1) or info['height']&(info['height']-1)):raise ValueError('Largura e altura precisam ser potencias de 2 para gerar os mipmaps AST.')
   except (ValueError,KeyError,OSError) as error:row.update(eligible=False,reason=str(error))
   rows.append(row)
  return dict(project=editor.project.name,revision=editor.meta()['revision'],textures=rows,asyncJobs=True,encoding='V18: ASTC 6x6 com compressao e mipmaps por classe FS23; funciona offline. Arrays 4/6 camadas: GS2D RGBA8. RGBA16F 2 camadas: experimental, mantem DDS. Alternativa: RGBA8 sem compressao ASTC.')

def rewrite(editor,raw,owner,selected):
 doc=I3D(raw);_,items=spans(doc.text);edits=[];count=0
 def replacement(value):
  if not value.strip().lower().endswith('.dds'):return None
  resolved=editor.resolve_resource(value.strip(),owner)
  if resolved not in selected:return None
  # FS23 uses PNG resource names backed by same-stem .ast files.
  stripped=value.strip();result=posixpath.splitext(stripped)[0]+'.png'
  return value[:len(value)-len(value.lstrip())]+result+value[len(value.rstrip()):]
 for item in items:
  tag=doc.utf8[item['start']:item['openEnd']].decode();changed=False
  tokens=list(re.finditer(r'([\w:.-]+)(\s*=\s*)([\"\'])(.*?)\3',tag,re.S))
  for match in reversed(tokens):
   key=match.group(1);value=item['attrs'].get(key,'');new=replacement(value)
   if new is not None:tag=tag[:match.start()]+key+match.group(2)+quoteattr(new)+tag[match.end():];count+=1;changed=True
  if changed:edits.append((item['start'],item['openEnd'],tag.encode()))
  if not item['empty']:
   content=doc.utf8[item['openEnd']:item['close']].decode()
   if '<' not in content:
    import xml.etree.ElementTree as ET
    try:value=ET.fromstring(doc.utf8[item['start']:doc.utf8.index(b'>',item['close'])+1]).text or ''
    except ET.ParseError:continue
    new=replacement(value)
    if new is not None:edits.append((item['openEnd'],item['close'],escape(new).encode()));count+=1
 result=doc.utf8
 for start,end,new in sorted(edits,reverse=True):result=result[:start]+new+result[end:]
 # Keep disabled-choice backups consistent with the live section (Alpha 9).
 from optional_manager import backups,MARK,MAX_BACKUP
 from xml_edit import fragment
 stored=backups(doc)
 if stored:
  updated=I3D(result);_,updated_items=spans(updated.text);updated_backups=backups(updated);comment_edits=[]
  for slot,(state,_,_)in stored.items():
   template,extra=rewrite(editor,state['template'].encode(),owner,selected)
   old_item=next(e for e in items if e['depth']==1 and e['local']==slot+'Configurations');new_item=next(e for e in updated_items if e['depth']==1 and e['local']==slot+'Configurations')
   old_group=fragment(doc,old_item);new_group=fragment(updated,new_item)
   if extra or old_group!=new_group:
    if hashlib.sha256(old_group).hexdigest()!=state['hash']:raise ValueError('Backup de opcionais alterado. Resolva o grupo '+slot+' antes de converter suas texturas.')
    state['template']=template.decode();state['hash']=hashlib.sha256(new_group).hexdigest();encoded=base64.b64encode(json.dumps(state,separators=(',',':'),ensure_ascii=False).encode())
    if len(encoded)>MAX_BACKUP:raise ValueError('Backup de opcionais excede o limite apos atualizar as texturas.')
    _,a,b=updated_backups[slot];comment_edits.append((a,b,b'<!--'+MARK.encode()+b' '+slot.encode()+b' '+encoded+b'-->'));count+=extra
  for a,b,data in sorted(comment_edits,reverse=True):result=result[:a]+data+result[b:]
 return result.decode().encode(doc.encoding,errors='xmlcharrefreplace'),count

def apply(editor,body,progress=None):
 with editor.lock:
  from game_compat import profile
  if profile(editor)['game']=='FS19':raise ValueError('Este projeto esta em modo FS19 e usa DDS. A conversao de texturas para AST e destinada ao FS23; mantenha o formato original para editar no FS19.')
  if not editor.project or body.get('project')!=editor.project.name or body.get('revision')!=editor.meta()['revision']:raise ValueError('O projeto mudou. Reabra o conversor de texturas.')
  bulk=body.get('all',False);delete_dds=body.get('deleteDDS',False);resolution=body.get('maxSize',0);encoding=body.get('encoding','rgba8');replace_existing=body.get('replaceExisting',False);force_delete=body.get('forceDelete',False);quality=body.get('quality','medium');preserve_profiles=body.get('preserveProfiles',True)
  if any(type(v)!=bool for v in (replace_existing,force_delete,preserve_profiles)) or quality not in ('fast','medium'):raise ValueError('Opcoes do conversor invalidas.')
  if encoding not in ('rgba8','astc-v18'):raise ValueError('Codificacao de textura invalida.')
  if type(bulk)!=bool or type(delete_dds)!=bool:raise ValueError('Opcoes de conversao invalidas.')
  if type(resolution)!=int or resolution not in (0,256,512,1024,2048,4096):raise ValueError('Resolucao invalida.')
  if progress:progress(phase='scan',percent=0,file='',done=0,total=0)
  all_rows=catalog(editor,replace_existing,progress)['textures'];rows={r['file']:r for r in all_rows};skipped=[]
  if bulk:
   selected=[r['file'] for r in all_rows if r['eligible']];skipped=[dict(file=r['file'],reason=r['reason']) for r in all_rows if not r['eligible']]
  else:
   selected=body.get('files')
   if not isinstance(selected,list) or not 1<=len(selected)<=32 or any(not isinstance(p,str) for p in selected) or len(set(selected))!=len(selected):raise ValueError('Selecione de 1 a 32 texturas DDS diferentes por conversao.')
  total=0
  for path in selected:
   row=rows.get(path)
   if not row or not row['eligible']:raise ValueError(row['reason'] if row else 'DDS nao pertence ao projeto.')
   w,h=row['width'],row['height']
   if resolution:
    while max(w,h)>resolution:w=max(1,w//2);h=max(1,h//2)
   total+=w*h*4*4//3
  if not bulk and total>MAX_BYTES:raise ValueError('Selecao grande demais. Use Converter ZIP todo para processar as texturas uma por vez.')
  staged={};converted=[];roles=None
  if encoding=='astc-v18':
   from texture_v18 import terrain_roles
   roles=terrain_roles(editor)
  from ast_texture import decode
  for number,path in enumerate(selected):
   if progress:progress(phase='encode',percent=int(85*number/max(1,len(selected))),file=path,done=number,total=len(selected),mip=0,mips=0)
   try:
    raw=editor.read(path,128*1024*1024)
    if encoding=='astc-v18':
     from texture_v18 import convert as convert_v18
     def mip_progress(mip,mips):
      if progress:progress(phase='encode',percent=int(85*(number+mip/max(1,mips))/max(1,len(selected))),file=path,done=number,total=len(selected),mip=mip,mips=mips)
     ast,info=convert_v18(raw,path,resolution,roles,quality,preserve_profiles,mip_progress)
    else:ast,info=convert(raw,resolution)
    if not info.get('layers'):
     validation=decode(ast)
     if validation['width']!=info['width'] or validation['height']!=info['height']:raise ValueError('AST gerado com dimensoes incorretas.')
     del validation
    target=rows[path]['ast'];staged[target]=editor.blob(ast);converted.append(dict(source=path,ast=target,sourceBytes=len(raw),astBytes=len(ast),**info));del raw,ast
   except (ValueError,OSError,MemoryError,RuntimeError) as error:
    if not bulk:raise
    skipped.append(dict(file=path,reason=str(error) or 'Memoria insuficiente para esta textura.'))
  # Resolve every reference before publishing any new files or removing a DDS.
  # Bulk mode can keep a DDS whose XML is malformed while converting the rest.
  names=list(editor.archive_index()[0].values());ignored=[];xml_staged={};references=0
  if progress:progress(phase='references',percent=86,done=len(selected),total=len(selected),file='',mip=0,mips=0)
  while converted:
   selected_set={r['source'] for r in converted};blocked=set();xml_staged={};references=0;ignored=[]
   for reference_number,name in enumerate(names):
    if progress:progress(phase='references',percent=86+int(5*reference_number/max(1,len(names))),file=name)
    if not name.lower().endswith(('.xml','.i3d')):continue
    raw=editor.read(name)
    try:rewritten,count=rewrite(editor,raw,name,selected_set)
    except Exception as error:
     affected={p for p in selected_set if posixpath.basename(p).encode().lower() in raw.lower()}
     if b'GABRIEL_OPTIONALS_V1' in raw:affected=selected_set
     if affected:
      if not bulk:raise ValueError('XML nao pode ser atualizado: '+name+' · '+str(error))
      blocked.update(affected)
      for path in affected:skipped.append(dict(file=path,reason='Referencia em XML invalido: '+name))
     else:ignored.append(name)
     continue
    if count:xml_staged[name]=editor.blob(rewritten);references+=count
   if not blocked:break
   for row in converted:
    if row['source'] in blocked:staged.pop(row['ast'],None)
   converted=[row for row in converted if row['source'] not in blocked]
  if not converted:xml_staged={};references=0
  staged.update(xml_staged)
  deleted=[];kept=[]
  if delete_dds:
   successful={r['source'] for r in converted};protected={}
   for name in ([] if force_delete else names):
    if not name.lower().endswith(('.lua','.json','.txt','.glsl','.hlsl','.material')):continue
    try:raw=editor.read(name).lower()
    except (ValueError,OSError,KeyError):
     for path in successful:protected.setdefault(path,name)
     continue
    matches={path for path in successful if posixpath.basename(path).encode().lower() in raw}
    if b'.dds' in raw and (not matches or b"'.dds'" in raw or b'".dds"' in raw):matches=successful
    for path in matches:protected.setdefault(path,name)
   mandatory={r['source']:r for r in converted if r.get('preserveDDS')}
   for path in sorted(successful):
    if path in mandatory:kept.append(dict(file=path,reason=mandatory[path]['note']))
    elif path in protected:kept.append(dict(file=path,reason='Referencia em '+protected[path]+'; DDS mantida.'))
    else:deleted.append(path)
  else:kept=[dict(file=r['source'],reason='Manter DDS originais selecionado.') for r in converted]
  if progress:progress(phase='commit',percent=92,file='')
  project=editor.commit_blobs(staged,body['revision'],deleted)
  return dict(project=project,converted=converted,references=references,ignoredXml=ignored,originalsKept=not bool(deleted),deletedDDS=deleted,keptDDS=kept,skipped=skipped,bulk=bulk)

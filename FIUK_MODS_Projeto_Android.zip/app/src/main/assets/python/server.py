#!/usr/bin/env python3
"""Loopback transport for Termux; editor logic lives in core.py."""
import argparse
import base64
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import shutil
import subprocess
import tempfile
from urllib.parse import parse_qs, quote, unquote, urlparse
from core import Editor, I3D, jsonbytes

ROOT = Path(__file__).resolve().parent

def handler_for(editor, port):
    from texture_jobs import TextureJobs
    texture_jobs = TextureJobs(editor)
    class Handler(BaseHTTPRequestHandler):
        def send(self, data, code=200, kind='application/json; charset=utf-8'):
            if not isinstance(data, bytes): data = jsonbytes(data)
            self.send_response(code)
            self.send_header('Content-Type', kind)
            self.send_header('Content-Length', str(len(data)))
            self.send_header('Cache-Control', 'no-store')
            self.end_headers()
            self.wfile.write(data)

        def do_GET(self):
            try:
                u = urlparse(self.path)
                q = parse_qs(u.query)
                name = q.get('file', [''])[0]
                if u.path == '/api/texture-jobs/status':return self.send(texture_jobs.get(q.get('id',[None])[0]))
                if u.path == '/api/texture-jobs/output':
                    path,filename=texture_jobs.output(q.get('id',[''])[0])
                    self.send_response(200);self.send_header('Content-Type','application/zip');self.send_header('Content-Length',str(path.stat().st_size));self.send_header('Content-Disposition',"attachment; filename*=UTF-8''"+quote(filename));self.end_headers()
                    with path.open('rb') as f:shutil.copyfileobj(f,self.wfile,1024*1024)
                    return
                with editor.lock:
                    if u.path in ('/api/texture','/api/texture-image'):
                        project=q.get('project',[''])[0]
                        if not editor.project or project!=editor.project.name:
                            raise ValueError('O projeto mudou. Reabra o modelo para carregar as texturas.')
                        limit=int(q.get('size',['2048'])[0])
                        if u.path=='/api/texture':return self.send(editor.texture(name,limit))
                        data,mime=editor.texture_image(name,min(limit,1024))
                        return self.send(data,kind=mime)
                    if u.path in ('/api/projects','/api/piece-library','/api/check'):
                        import workbench
                        return self.send(workbench.projects(editor) if u.path=='/api/projects' else workbench.library(editor) if u.path=='/api/piece-library' else workbench.check(editor))
                    if u.path == '/api/texture-paint':
                        from texture_paint import options
                        return self.send(options(editor,name,int(q.get('index',['-1'])[0])))
                    if u.path == '/api/selection-state':
                        from selection_tools import view_state
                        return self.send(view_state(editor,name))
                    if u.path == '/api/animations':
                        from animation_preview import options
                        return self.send(options(editor,name))
                    if u.path == '/api/material-surface':
                        from material_surface import info
                        return self.send(info(editor,name,int(q.get('index',['-1'])[0])))
                    if u.path == '/api/wheel-edit':
                        from wheel_edit import options
                        return self.send(options(editor,name,int(q.get('configuration',['0'])[0])))
                    if u.path == '/api/new-mod':return self.send(editor.new_mod_options(name))
                    if u.path == '/api/base-vehicles':return self.send(editor.base_vehicles(q.get('refresh',['0'])[0]=='1'))
                    if u.path == '/api/base-vehicle-info':return self.send(editor.base_vehicle_info(name,q.get('baseId',[''])[0]))
                    if u.path == '/api/base':return self.send(editor.base_status(include_candidates=True))
                    if u.path == '/api/texture-convert':
                        from texture_convert import catalog
                        return self.send(catalog(editor,q.get('replaceExisting',['0'])[0]=='1'))
                    if u.path == '/api/optional-manager':
                        from optional_manager import inspect
                        return self.send(inspect(editor,name,q.get('vehicle',[None])[0]))
                    if u.path == '/api/shop-options':return self.send(editor.shop_options(name,q.get('vehicle',[None])[0]))
                    if u.path == '/api/paint':return self.send(editor.paint_options(name,int(q.get('index',['-1'])[0])))
                    if u.path == '/api/accessory-source':return self.send(editor.accessory_source(name or None))
                    if u.path == '/api/project': return self.send(editor.summary())
                    if u.path == '/api/scene': return self.send(editor.scene(name,wheel_config=int(q.get('wheelConfig',['0'])[0])))
                    if u.path == '/api/text': return self.send({'text': I3D(editor.read(name)).text})
                    if u.path == '/api/export':
                        if q.get('project') and (not editor.project or q['project'][0]!=editor.project.name or q.get('revision',[''])[0]!=str(editor.meta()['revision'])):raise ValueError('Projeto mudou. Baixe novamente o ZIP do projeto atual.')
                        path = editor.export()
                        filename = Path(editor.meta()['name']).stem + '_editado.zip'
                        self.send_response(200)
                        self.send_header('Content-Type', 'application/zip')
                        self.send_header('Content-Length', str(path.stat().st_size))
                        self.send_header('Content-Disposition', "attachment; filename*=UTF-8''" + quote(filename))
                        self.end_headers()
                        with open(path, 'rb') as f: shutil.copyfileobj(f, self.wfile, 1024 * 1024)
                        return
                assets = {'/': ('index.html', 'text/html; charset=utf-8'),
                          '/android-ui.js': ('android-ui.js', 'text/javascript; charset=utf-8'),
                          '/app.js': ('app.js', 'text/javascript; charset=utf-8'),
                          '/texture-convert-ui.js': ('texture-convert-ui.js', 'text/javascript; charset=utf-8'),
                          '/optional-manager-ui.js': ('optional-manager-ui.js', 'text/javascript; charset=utf-8'),
                          '/creation-ui.js': ('creation-ui.js', 'text/javascript; charset=utf-8'),
                          '/texture-paint-ui.js': ('texture-paint-ui.js', 'text/javascript; charset=utf-8'),
                          '/canvas-paint.js': ('canvas-paint.js', 'text/javascript; charset=utf-8'),
                          '/selection-ui.js': ('selection-ui.js', 'text/javascript; charset=utf-8'),
                          '/animation-ui.js': ('animation-ui.js', 'text/javascript; charset=utf-8'),
                          '/workbench-ui.js': ('workbench-ui.js', 'text/javascript; charset=utf-8'),
                          '/wheels-ui.js': ('wheels-ui.js', 'text/javascript; charset=utf-8'),
                          '/editing.js': ('editing.js', 'text/javascript; charset=utf-8'),
                          '/viewer.js': ('viewer.js', 'text/javascript; charset=utf-8'),
                          '/textures.js': ('textures.js', 'text/javascript; charset=utf-8'),
                          '/style.css': ('style.css', 'text/css; charset=utf-8')}
                if u.path in assets:
                    file, mime = assets[u.path]
                    return self.send((ROOT / 'web' / file).read_bytes(), kind=mime)
                self.send({'error': 'Endereco nao encontrado.'}, 404)
            except (ValueError, KeyError, OSError, Exception) as error:
                self.send({'error': str(error)}, 400)

        def do_POST(self):
            temporary = None
            try:
                if self.headers.get('X-Gabriel-Editor') != '1':
                    return self.send({'error': 'Requisicao invalida.'}, 403)
                origin = self.headers.get('Origin')
                if origin and origin not in (f'http://127.0.0.1:{port}', f'http://localhost:{port}'):
                    return self.send({'error': 'Origem invalida.'}, 403)
                length = int(self.headers.get('Content-Length', '0'))
                route = urlparse(self.path).path
                if route == '/api/vehicle-convert/upload':
                    from conversion_jobs import current
                    options={'textures':self.headers.get('X-Textures','1')=='1','maxSize':int(self.headers.get('X-Resolution','1024')),'quality':self.headers.get('X-Quality','fast')}
                    return self.send(current().upload(self.rfile,length,self.headers.get('X-Filename','mod.zip'),self.headers.get('X-Target','FS23'),options),202)
                if route == '/api/dds-preview':
                    if not 0<length<=64*1024*1024:raise ValueError('Escolha um DDS de ate 64 MB.')
                    from dds_texture import preview_png
                    return self.send(preview_png(self.rfile.read(length),2048),kind='image/png')
                if route in ('/api/import','/api/accessory-source'):
                    if length <= 0 or length > 2 * 1024**3: raise ValueError('Limite inicial: ZIP de ate 2 GB.')
                    with tempfile.NamedTemporaryFile(dir=editor.directory, delete=False) as f:
                        temporary = Path(f.name)
                        remaining = length
                        while remaining:
                            chunk = self.rfile.read(min(1024 * 1024, remaining))
                            if not chunk: raise ValueError('Upload interrompido.')
                            f.write(chunk); remaining -= len(chunk)
                    name = unquote(self.headers.get('X-Filename', 'mod.zip'))
                    return self.send(editor.import_zip(temporary,name,consume_source=True) if route=='/api/import' else editor.load_accessory_source(temporary,name,consume_source=True))
                if length > 40 * 1024 * 1024: raise ValueError('Requisicao grande demais.')
                body = json.loads(self.rfile.read(length) or b'{}')
                if route == '/api/vehicle-convert/project':
                    from conversion_jobs import current
                    from game_compat import profile
                    with editor.lock:
                        if not editor.project or body.get('project')!=editor.project.name or body.get('revision')!=editor.meta()['revision']:raise ValueError('O projeto mudou. Reabra o conversor.')
                        if profile(editor)['game']!='FS19':raise ValueError('Esta opção usa o projeto FS19 aberto.')
                        source=editor.export();options={'textures':body.get('textures',True),'maxSize':body.get('maxSize',1024),'quality':body.get('quality','fast')}
                        with source.open('rb') as stream:return self.send(current().upload(stream,source.stat().st_size,editor.meta()['name'],'FS23',options),202)
                if route == '/api/texture-jobs/start':return self.send(texture_jobs.start(body),202)
                if route == '/api/texture-jobs/cancel':return self.send(texture_jobs.cancel(body.get('id')))
                if route == '/api/project-delete':
                    import workbench
                    return self.send(workbench.delete_project(editor,body))
                if route in ('/api/project-open','/api/piece-library-save','/api/piece-library-open','/api/precision'):
                    import workbench
                    return self.send(workbench.open_project(editor,body['id']) if route=='/api/project-open' else workbench.save_piece(editor,body) if route=='/api/piece-library-save' else workbench.load_piece(editor,body['id']) if route=='/api/piece-library-open' else workbench.precision(editor,body))
                if route == '/api/empty-project':
                    from primitives import new_project
                    return self.send(new_project(editor,body.get('name')))
                if route == '/api/primitive':
                    from primitives import create
                    return self.send(create(editor,body))
                if route == '/api/texture-paint':
                    from texture_paint import save
                    return self.send(save(editor,body))
                if route == '/api/accessory-export':
                    if not editor.project or body.get('project')!=editor.project.name:raise ValueError('O projeto mudou. Reabra a exportacao.')
                    raw=editor.export_prefab(body['file'],body['index'],body.get('title','Meu acessorio'),body['revision'],allow_functional=True)
                    return self.send(raw,kind='application/zip')
                if route in ('/api/selection-state','/api/selection-action'):
                    from selection_tools import save_view,apply
                    return self.send(save_view(editor,body) if route=='/api/selection-state' else apply(editor,body))
                if route == '/api/material-surface':
                    from material_surface import save
                    return self.send(save(editor,body))
                if route == '/api/wheel-edit':
                    from wheel_edit import save
                    return self.send(save(editor,body))
                if route == '/api/new-mod-export':
                    temporary,report=editor.export_new_mod(body)
                    self.send_response(200)
                    self.send_header('Content-Type','application/zip')
                    self.send_header('Content-Length',str(temporary.stat().st_size))
                    self.send_header('Content-Disposition',"attachment; filename*=UTF-8''"+quote(report['name']))
                    self.send_header('X-Gabriel-Icon',report['iconSource'])
                    self.end_headers()
                    with temporary.open('rb') as stream:shutil.copyfileobj(stream,self.wfile,1024*1024)
                    return
                elif route == '/api/base-vehicle-open':result=editor.open_base_vehicle(body['file'],body['baseId'])
                elif route == '/api/base-vehicle-export':
                    temporary,report=editor.export_base_vehicle(body['file'],body['baseId'])
                    self.send_response(200)
                    self.send_header('Content-Type','application/zip')
                    self.send_header('Content-Length',str(temporary.stat().st_size))
                    self.send_header('Content-Disposition',"attachment; filename*=UTF-8''"+quote(report['name']))
                    self.end_headers()
                    with temporary.open('rb') as stream:shutil.copyfileobj(stream,self.wfile,1024*1024)
                    return
                elif route == '/api/base':result=editor.set_base(body.get('path'))
                elif route == '/api/decal':
                    try:png=base64.b64decode(body['png'],validate=True)
                    except (ValueError,TypeError):raise ValueError('PNG invalido.')
                    result=editor.add_decal(body['file'],body['parent'],png,body['width'],body['translation'],body['rotation'],body['revision'],body.get('label','Adesivo'),body.get('projection'))
                elif route == '/api/decal-project':
                    result=editor.project_decal(body['file'],body['index'],body['revision'],body.get('depth',.2),body.get('maxAngle',75),body.get('offset',.001))
                elif route == '/api/paint':
                    result=editor.paint_material(body['file'],body['index'],body['materialId'],body['channel'],body['color'],body.get('shared',False),body['revision'])
                elif route == '/api/accessory-import':
                    result=editor.import_accessory(body['file'],body['parent'],body['sourceFile'],body['sourceIndex'],body['revision'],body.get('translation'),body.get('sourceId'),allow_functional=bool(body.get('allowFunctional')))
                elif route == '/api/texture-convert':
                    from texture_convert import apply
                    result=apply(editor,body)
                elif route == '/api/optional-manager':
                    from optional_manager import apply
                    result=apply(editor,body)
                elif route == '/api/shop-options':
                    if 'options' in body:result=editor.save_shop_options(body['file'],body['vehicle'],body['title'],body['options'],body['revision'],body.get('slot'))
                    else:result=editor.create_shop_option(body['file'],body['vehicle'],body['offIndices'],body['onIndices'],body['title'],body['offName'],body['onName'],body['offPrice'],body['onPrice'],body['revision'],body.get('slot'))
                elif route == '/api/shop-options-delete':
                    result=editor.remove_shop_options(body['file'],body['vehicle'],body['slot'],body['revision'])
                elif route == '/api/mirror':
                    result=editor.mirror_piece(body['file'],body['index'],body['axis'],body['revision'])
                elif route == '/api/align':
                    result=editor.align_piece(body['file'],body['index'],body['target'],body['point'],body['normal'],body.get('axis',1),body.get('offset',.001),body.get('orient',True),body['revision'])
                elif route == '/api/prefab':
                    raw=editor.export_prefab(body['file'],body['index'],body.get('title','Meu conjunto'),body['revision'],allow_functional=True)
                    return self.send(raw,kind='application/zip')
                elif route == '/api/scene-tool':
                    result=editor.scene_tool(body['file'],body['action'],body['indices'],body['revision'],body.get('name'),body.get('offset'))
                elif route == '/api/transforms':
                    result = editor.transform_many(body)
                elif route == '/api/transform':
                    result = editor.transform(body['file'], int(body['index']), body['changes'], body['revision'])
                elif route == '/api/xml':
                    result = editor.save_xml(body['file'], body['text'], body['revision'])
                elif route == '/api/undo': result = editor.history()
                elif route == '/api/redo': result = editor.history(True)
                elif route == '/api/example':
                    result = editor.import_zip(ROOT / 'examples' / 'mod_exemplo.zip', 'Gabriel_Exemplo.zip')
                else: raise ValueError('Operacao desconhecida.')
                self.send(result)
            except Exception as error:
                self.send({'error': str(error)}, 400)
            finally:
                if temporary: temporary.unlink(missing_ok=True)

        def log_message(self, format, *args): pass
    return Handler

def main():
    p = argparse.ArgumentParser(description='Gabriel Mods Editor - Android/Termux')
    p.add_argument('--port', type=int, default=8766)
    p.add_argument('--data', type=Path, default=ROOT / 'projetos')
    p.add_argument('--open', action='store_true')
    args = p.parse_args()
    editor = Editor(args.data)
    server = ThreadingHTTPServer(('127.0.0.1', args.port), handler_for(editor, args.port))
    url = f'http://127.0.0.1:{args.port}'
    print(f'Gabriel Mods Editor v0.26\nAbra no navegador: {url}\nProjetos: {args.data}\nCTRL+C encerra o servidor.', flush=True)
    if args.open and shutil.which('termux-open-url'):
        subprocess.Popen(['termux-open-url', url], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally: server.server_close()

if __name__ == '__main__': main()


def start_embedded(data_dir):
    """Start the editor HTTP server on loopback for the Android WebView."""
    import threading
    editor = Editor(Path(data_dir))
    server = ThreadingHTTPServer(('127.0.0.1', 8766), handler_for(editor, 8766))
    thread = threading.Thread(target=server.serve_forever, name='FiukModsServer', daemon=True)
    thread.start()
    return server

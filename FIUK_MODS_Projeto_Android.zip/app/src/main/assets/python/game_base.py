"""Read-only game assets from a local APK/ZIP or an extracted data directory.

Only the ZIP directory is indexed and assets are read on demand. Normal mod
exports keep external references. Explicit vehicle copies can include selected
vehicle folders; the source APK/directory is never modified and GAR is not read.
"""
from pathlib import Path,PurePosixPath
import os,stat,uuid,zipfile

MAX_ENTRIES=250000

def clean(name):
    name=name.replace('\\','/')
    path=PurePosixPath(name)
    if path.is_absolute() or '..' in path.parts or '\0' in name:return None
    return '/'.join(p for p in path.parts if p!='.')

def variants(path):
    root,ext=os.path.splitext(path)
    if ext.lower() in ('.dds','.png','.ast','.astc','.jpg','.jpeg'):
        return list(dict.fromkeys([root+'.ast',root+'.astc',path,root+'.png',root+'.dds']))
    return [path]

class GameBase:
    def __init__(self,source):
        self.path=Path(source).expanduser().resolve(strict=True)
        self.id=uuid.uuid4().hex[:16]
        self.archive=None;self.entries={};self.bytes=0;self.gar=False
        self.stamp=self._stamp()
        try:
            if self.path.is_file():
                if not zipfile.is_zipfile(self.path):raise ValueError('Escolha um APK/ZIP ou uma pasta data extraida. GAR ainda nao e lido nesta versao.')
                self.archive=zipfile.ZipFile(self.path)
                infos=self.archive.infolist()
                if len(infos)>MAX_ENTRIES:raise ValueError('Base com arquivos demais.')
                names=[i.filename for i in infos if not i.is_dir()]
                # Accept assets/data from an APK, data from a ZIP, or one wrapper.
                has_root=any(n.replace('\\','/').lower().startswith(('assets/data/','data/')) for n in names)
                wrapper=None
                if not has_root:
                    roots={clean(n).split('/')[0] for n in names if clean(n)}
                    if len(roots)==1:
                        first=next(iter(roots))
                        if any(n.lower().startswith(first.lower()+'/data/') for n in names):wrapper=first+'/'
                raw_data=not has_root and not wrapper and any(n.lower().startswith(('vehicles/','maps/','shared/')) for n in names)
                for info in infos:
                    if info.is_dir():continue
                    name=clean(info.filename)
                    if not name:continue
                    relative=name[len(wrapper):] if wrapper and name.startswith(wrapper) else name
                    key=self._canonical(relative,raw_data)
                    if name.lower() in ('assets/datas.gar','datas.gar'):self.gar=True
                    if key:
                        if info.flag_bits&1:continue
                        if (info.external_attr>>16)&0o170000==stat.S_IFLNK:continue
                        self._add(key,info.filename,info.file_size)
                self.kind='APK/ZIP'
            elif self.path.is_dir():
                self.kind='PASTA'
                if self.path.name.casefold()=='data':roots=[('data',self.path)]
                elif (self.path/'assets'/'data').is_dir():roots=[('data',self.path/'assets'/'data'),('shared',self.path/'assets'/'shared')]
                elif (self.path/'data').is_dir():roots=[('data',self.path/'data'),('shared',self.path/'shared')]
                elif any((self.path/n).is_dir() for n in ('vehicles','maps','shared')):roots=[('data',self.path)]
                else:raise ValueError('Pasta sem data/vehicles/shared. Selecione a pasta data ou a pasta que contem data.')
                for prefix,root in roots:
                    if not root.is_dir() or root.is_symlink():continue
                    for parent,dirs,files in os.walk(root,followlinks=False):
                        dirs[:]=[d for d in dirs if not (Path(parent)/d).is_symlink()]
                        for name in files:
                            p=Path(parent)/name
                            if p.is_symlink() or not p.is_file():continue
                            self._add(prefix+'/'+p.relative_to(root).as_posix(),p,p.stat().st_size)
                self.gar=(self.path/'dataS.gar').is_file()
            else:raise ValueError('A base precisa ser um arquivo APK/ZIP ou uma pasta.')
            if not self.entries:
                message='O APK/ZIP nao tem arquivos acessiveis em assets/data ou data.'
                if self.gar:message+=' Somente o GAR nao serve como pasta de recursos nesta versao.'
                raise ValueError(message)
        except Exception:
            self.close();raise

    def _stamp(self):
        s=self.path.stat();return (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns)

    def _canonical(self,name,raw=False):
        lower=name.casefold()
        for prefix in ('assets/',''):
            part=lower[len(prefix):] if lower.startswith(prefix) else ''
            if part.startswith(('data/','shared/')):return name[len(prefix):]
        if raw:return 'data/'+name
        return None

    def _add(self,key,value,size):
        folded=key.casefold()
        if folded in self.entries:raise ValueError('Base com caminhos de recursos duplicados: '+key)
        self.entries[folded]=(key,value,size);self.bytes+=size
        if len(self.entries)>MAX_ENTRIES:raise ValueError('Base com arquivos demais.')

    def close(self):
        if self.archive:self.archive.close();self.archive=None

    def check(self):
        if not self.path.exists():raise ValueError('A base foi movida ou removida. Selecione o APK novamente em BASE DO JOGO.')
        if self.archive and self._stamp()!=self.stamp:raise ValueError('O APK da base mudou. Selecione novamente em BASE DO JOGO.')

    def status(self):
        try:self.check();error=None
        except (OSError,ValueError) as e:error=str(e)
        return {'active':error is None,'path':str(self.path),'name':self.path.name,'id':self.id,'kind':self.kind,
                'files':len(self.entries),'size':self.bytes,'error':error,'hasGar':self.gar}

    def resolve(self,reference):
        ref=reference.replace('\\','/')
        low=ref.casefold()
        if low.startswith('$data/'):ref='data/'+ref[6:]
        elif low.startswith('$shared/'):ref='shared/'+ref[8:]
        elif low.startswith('assets/'):ref=ref[7:]
        elif not low.startswith(('data/','shared/')):return None
        ref=clean(ref)
        if not ref:return None
        paths=variants(ref)
        # Some mobile bases expose shared at assets/shared instead of data/shared.
        if ref.casefold().startswith('data/shared/'):paths+=variants(ref[5:])
        for p in paths:
            item=self.entries.get(p.casefold())
            if item:return 'base:'+self.id+'/'+item[0]
        return None

    def read(self,reference,limit,head=False):
        self.check();prefix='base:'+self.id+'/'
        if not reference.startswith(prefix):raise ValueError('A base mudou. Reabra a cena para atualizar as texturas.')
        key=reference[len(prefix):]
        item=self.entries.get(key.casefold())
        if not item:raise ValueError('Recurso nao encontrado na base: '+key)
        _,source,size=item
        if size>limit and not head:raise ValueError('Recurso da base acima do limite de leitura.')
        if self.archive:
            with self.archive.open(source) as f:return f.read(limit if head else limit+1)
        source=Path(source).resolve(strict=True)
        # Refuse paths/symlinks moved outside the selected tree after indexing.
        if not source.is_relative_to(self.path):raise ValueError('Recurso fora da pasta da base.')
        if source.stat().st_size>limit and not head:raise ValueError('Recurso da base acima do limite de leitura.')
        with source.open('rb') as f:return f.read(limit if head else limit+1)

    def copy_to(self,reference,sink,limit):
        """Stream one indexed asset to a ZIP entry without allocating the whole file."""
        self.check();prefix='base:'+self.id+'/'
        if not reference.startswith(prefix):raise ValueError('A base mudou. Atualize a lista de veiculos.')
        item=self.entries.get(reference[len(prefix):].casefold())
        if not item:raise ValueError('Recurso nao encontrado na base.')
        _,source,size=item
        if size>limit:raise ValueError('Recurso da base acima do limite de copia.')
        if self.archive:stream=self.archive.open(source)
        else:
            source=Path(source).resolve(strict=True)
            if not source.is_relative_to(self.path):raise ValueError('Recurso fora da pasta da base.')
            if source.stat().st_size!=size:raise ValueError('Arquivo da base mudou. Conecte a base novamente.')
            stream=source.open('rb')
        with stream as f:
            copied=0
            while True:
                chunk=f.read(min(1024*1024,limit-copied+1))
                if not chunk:break
                copied+=len(chunk)
                if copied>limit or copied>size:raise ValueError('Recurso da base mudou ou excede o limite de copia.')
                sink.write(chunk)
            if copied!=size:raise ValueError('A leitura do recurso foi interrompida.')


def candidates():
    roots=[Path.home()/'storage'/'downloads',Path('/storage/emulated/0/Download'),Path('/sdcard/Download')]
    seen=set();found=[]
    for root in roots:
        try:
            real=root.resolve()
            if real in seen or not root.is_dir():continue
            seen.add(real)
            for p in root.iterdir():
                if p.is_file() and p.suffix.casefold() in ('.apk','.zip','.obb'):
                    s=p.stat();found.append({'path':str(p),'name':p.name,'size':s.st_size,'modified':s.st_mtime})
                elif p.is_dir() and p.name.casefold() in ('data','assets'):
                    found.append({'path':str(p),'name':p.name+' (pasta)','size':0,'modified':p.stat().st_mtime})
        except (OSError,PermissionError):continue
    return sorted(found,key=lambda p:p['modified'],reverse=True)[:200]

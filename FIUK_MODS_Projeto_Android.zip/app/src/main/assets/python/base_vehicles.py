"""Editable vehicle-folder copies from the selected read-only game base."""
import copy,os,posixpath,re,tempfile,zipfile,xml.etree.ElementTree as ET
from pathlib import Path
from xml.sax.saxutils import quoteattr,escape,unescape
from xml.parsers.expat import ExpatError
from core import I3D,tagname,MAX_XML
from decals import spans

MAX_PACKAGE=1024*1024*1024
MAX_FILE=256*1024*1024
MAX_FILES=20000
ATTR=re.compile(r'([\w:.-]+)(\s*=\s*)([\"\'])(.*?)\3',re.S)

def selected_base(editor,base_id=None):
    base=editor.base
    if base is None:raise ValueError('Conecte o APK ou a pasta data em BASE DO JOGO primeiro.')
    base.check()
    if base_id is not None and base.id!=base_id:raise ValueError('A base mudou. Atualize a lista de veiculos.')
    return base

def resource(base,value,owner):
    if not isinstance(value,str) or not value.strip():return None
    ref=value.strip().replace('\\','/')
    if ref.startswith('$') or ref.casefold().startswith(('data/','shared/','assets/')):return base.resolve(ref)
    if ref.startswith('/') or ':' in ref:return None
    path=posixpath.normpath(posixpath.join(posixpath.dirname(owner),ref))
    return base.resolve(path)

def key_of(reference):return reference.split('/',1)[1]

def inventory(editor,refresh=False):
    with editor.lock:
        base=selected_base(editor)
        if not refresh and hasattr(base,'_vehicle_inventory'):return copy.deepcopy(base._vehicle_inventory)
        rows=[];linked=set();skipped=0
        for key,_,size in sorted(base.entries.values()):
            if not key.casefold().startswith('data/vehicles/') or not key.casefold().endswith('.xml'):continue
            try:
                doc=I3D(base.read('base:'+base.id+'/'+key,MAX_XML));root=ET.fromstring(doc.text)
                if tagname(root.tag)!='vehicle':continue
                filename=root.findtext('base/filename');model=resource(base,filename,key) if filename else None
                model_key=key_of(model) if model and key_of(model).casefold().endswith('.i3d') else None
                if model_key:linked.add(model_key.casefold())
                element=root.find('storeData/name');name=''
                if element is not None:
                    for language in ('pt','br','en'):
                        name=element.findtext(language) or ''
                        if name.strip():break
                    name=name or element.text or ''
                name=' '.join(name.split());name=name if name and not name.startswith('$') else Path(key).stem
                brand=(root.findtext('storeData/brand') or '').strip();brand=brand if not brand.startswith('$') else ''
                rows.append({'file':key,'model':model_key,'kind':'vehicle','name':name[:120],'brand':brand[:80],
                             'folder':posixpath.dirname(key),'available':bool(model_key),'error':'' if model_key else 'I3D do veiculo nao encontrado nesta base.'})
            except (ValueError,ET.ParseError,ExpatError,UnicodeError,OSError,LookupError):skipped+=1
        for key,_,size in sorted(base.entries.values()):
            if key.casefold().startswith('data/vehicles/') and key.casefold().endswith('.i3d') and key.casefold() not in linked:
                rows.append({'file':key,'model':key,'kind':'model','name':Path(key).stem,'brand':'','folder':posixpath.dirname(key),'available':True,'error':''})
        result={'baseId':base.id,'baseName':base.path.name,'items':rows,'skipped':skipped,'hasGar':base.gar}
        base._vehicle_inventory=result
        return copy.deepcopy(result)

def choose(editor,filename,base_id):
    if not isinstance(base_id,str) or not base_id:raise ValueError('Atualize a lista de veiculos da base.')
    base=selected_base(editor,base_id)
    row=next((r for r in inventory(editor)['items'] if r['file']==filename),None)
    if row is None:raise ValueError('Escolha um veiculo da lista desta base.')
    if not row['available']:raise ValueError(row['error'])
    return base,row

def package_files(base,row):
    folder=row['folder'];prefix=folder.casefold()+'/'
    # Never collect the whole vehicles directory for an XML saved directly there.
    files={key for key,_,_ in base.entries.values() if len(folder.split('/'))>=3 and key.casefold().startswith(prefix)}
    files.update([row['file'],row['model']]);main=row['model'];doc=I3D(base.read('base:'+base.id+'/'+main,MAX_XML));_,elements=spans(doc.text)
    for item in elements:
        ref=item['attrs'].get('externalShapesFile')
        if not ref:continue
        resolved=resource(base,ref,main)
        if not resolved:raise ValueError('Malha externa do veiculo nao encontrada: '+ref)
        files.add(key_of(resolved))
    if len(files)>MAX_FILES:raise ValueError('A pasta tem arquivos demais. Limite: 20.000 arquivos por copia.')
    total=0
    for key in files:
        size=base.entries[key.casefold()][2];total+=size
        if size>MAX_FILE:raise ValueError('Arquivo maior que 256 MB: '+key)
    if total>MAX_PACKAGE:raise ValueError('A pasta do veiculo excede 1 GB. Escolha um modelo/pasta menor.')
    return files,total

def describe(editor,filename,base_id):
    with editor.lock:
        base,row=choose(editor,filename,base_id);files,total=package_files(base,row)
        return {**row,'baseId':base.id,'files':len(files),'size':total,
                'note':'Copia a pasta do veiculo. Recursos compartilhados continuam referenciando a base do jogo.'}

def rewrite(raw,owner,base,files,external,missing):
    doc=I3D(raw);data,elements=spans(doc.text);patches=[];folded={k.casefold():k for k in files}
    def link(value):
        ref=resource(base,value,owner)
        if not ref:
            if value.strip().casefold().startswith(('$data/','$shared/')):missing.add(value.strip())
            return value
        actual=key_of(ref);logical=actual;ext=posixpath.splitext(value.strip())[1].lower();actual_ext=posixpath.splitext(actual)[1].lower()
        if actual_ext in ('.ast','.astc') and ext in ('.dds','.png'):logical=posixpath.splitext(actual)[0]+'.png'
        if actual.casefold() in folded:return posixpath.relpath(logical,posixpath.dirname(owner))
        external.add(actual)
        if logical.casefold().startswith('data/'):return '$data/'+logical[5:]
        if logical.casefold().startswith('shared/'):return '$shared/'+logical[7:]
        return value
    for item in elements:
        tag=data[item['start']:item['openEnd']].decode();parts=[];start=0
        for match in ATTR.finditer(tag):
            value=item['attrs'].get(match.group(1));new=link(value) if value is not None else value
            if new is not None and new!=value:
                parts.extend([tag[start:match.start()],match.group(1)+match.group(2)+quoteattr(new)]);start=match.end()
        if parts:
            parts.append(tag[start:]);patches.append((item['start'],item['openEnd'],''.join(parts).encode()))
        if not item['empty']:
            segment=data[item['openEnd']:item['close']].decode()
            if '<' not in segment and segment.strip():
                value=unescape(segment.strip());new=link(value)
                if new!=value:
                    left=segment[:len(segment)-len(segment.lstrip())];right=segment[len(segment.rstrip()):];patches.append((item['openEnd'],item['close'],(left+escape(new)+right).encode()))
    if not patches:return raw
    for a,b,replacement in sorted(patches,reverse=True):data=data[:a]+replacement+data[b:]
    result=data.decode().encode(doc.encoding,errors='xmlcharrefreplace');I3D(result);return result

def build(editor,filename,base_id):
    """Return a temporary ZIP path; caller must unlink it after import/download."""
    with editor.lock:
        base,row=choose(editor,filename,base_id);files,total=package_files(base,row);external=set();missing=set();unparsed=[]
        fd,path=tempfile.mkstemp(prefix='veiculo_base_',suffix='.zip',dir=editor.directory);os.close(fd);path=Path(path)
        try:
            # Main model first: opening the copy selects the right I3D even if its
            # folder contains other models for accessories and configurations.
            ordered=list(dict.fromkeys([row['model'],row['file']]+sorted(files)))
            with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=3) as archive:
                for key in ordered:
                    ref='base:'+base.id+'/'+key;size=base.entries[key.casefold()][2]
                    if key.casefold().endswith(('.xml','.i3d')):
                        raw=base.read(ref,MAX_XML)
                        try:raw=rewrite(raw,key,base,files,external,missing)
                        except Exception:
                            if key in (row['model'],row['file']):raise
                            unparsed.append(key)
                        archive.writestr(key,raw)
                    else:
                        with archive.open(key,'w') as sink:base.copy_to(ref,sink,MAX_FILE)
                report=['GABRIEL MODS EDITOR - COPIA DA BASE','Selecionado: '+row['file'],'Modelo: '+row['model'],f'Arquivos da base copiados: {len(files)}',f'Tamanho original: {total} bytes',
                        'O APK/pasta original foi preservado.','Esta e uma copia para edicao; nao instala um veiculo extra automaticamente.','Referencias locais foram ajustadas; recursos compartilhados continuam externos.',
                        'Recursos externos: '+str(len(external)),*sorted(external),'Referencias nao encontradas: '+str(len(missing)),*sorted(missing),'XMLs auxiliares preservados sem reescrita: '+str(len(unparsed)),*unparsed]
                archive.writestr('GABRIEL_BASE.txt','\n'.join(report).encode())
            return path,{'vehicle':row['file'],'file':row['model'],'name':'FS23_Base_'+re.sub(r'[^A-Za-z0-9_-]','_',Path(row['file']).stem)+'.zip',
                         'files':len(files),'size':total,'externalCount':len(external),'missingCount':len(missing),'unparsed':unparsed,'kind':row['kind']}
        except Exception:path.unlink(missing_ok=True);raise

def open_copy(editor,filename,base_id):
    with editor.lock:
        path,result=build(editor,filename,base_id)
        try:return {**result,'project':editor.import_zip(path,result['name'])}
        finally:path.unlink(missing_ok=True)

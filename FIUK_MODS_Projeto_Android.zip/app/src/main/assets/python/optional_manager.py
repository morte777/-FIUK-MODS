"""Manage original and editor design choices without changing unrelated XML.
Disabled choices are retained in a bounded XML comment for offline reactivation.
"""
import base64, hashlib, json, re, xml.etree.ElementTree as ET
from xml.parsers import expat
from core import I3D
from decals import spans
from xml_edit import fragment, whole_end, attributes
from shop_options import SLOTS, _association, canonical, model
from scene_tools import scene_paths

MARK='GABRIEL_OPTIONALS_V1'
MAX_BACKUP=4*1024*1024

def digest(raw):return hashlib.sha256(raw).hexdigest()

def backups(doc):
 result={};depth=0;p=expat.ParserCreate('UTF-8')
 def start(*args):
  nonlocal depth
  depth+=1
 def end(*args):
  nonlocal depth
  depth-=1
 def comment(text):
  if depth!=1 or not text.startswith(MARK+' '):return
  try:
   _,slot,encoded=text.split(' ',2)
   if slot not in SLOTS or slot in result or len(encoded)>MAX_BACKUP:raise ValueError()
   state=json.loads(base64.b64decode(encoded,validate=True))
   if state.get('version')!=1 or not isinstance(state.get('template'),str) or not isinstance(state.get('entries'),list) or not isinstance(state.get('hash'),str):raise ValueError()
   offset=p.CurrentByteIndex;result[slot]=(state,offset,doc.utf8.index(b'-->',offset)+3)
  except (ValueError,TypeError,KeyError):raise ValueError('Backup de opcionais invalido. Use Desfazer ou restaure uma copia do projeto.')
 p.StartElementHandler=start;p.EndElementHandler=end;p.CommentHandler=comment;p.Parse(doc.utf8,True)
 return result

def protected_slots(doc):return set(backups(doc))

def data(editor,name,vehicle):
 doc=model(editor,name);xml,root=_association(editor,name,vehicle);_,items=spans(xml.text);stored=backups(xml);groups=[]
 reserved={e.get('name') for e in root.findall('.//configurationSets/configurationSet/configuration')}
 paths={path:i for i,path in scene_paths(doc).items()};mappings={e.get('id'):e.get('node') for e in root.findall('i3dMappings/i3dMapping')}
 for slot in SLOTS:
  sections=[e for e in items if e['depth']==1 and e['local']==slot+'Configurations']
  if not sections:continue
  current=fragment(xml,sections[0]);reason=''
  state=stored[slot][0] if slot in stored else None
  if len(sections)!=1:reason='Ha mais de uma secao com este grupo. Confira o XML.'
  if state:
   if state['hash']!=digest(current):reason='Este grupo mudou fora do gerenciador. Desfaca a alteracao ou restaure uma copia.'
   template=I3D(state['template'].encode());entries=state['entries']
  else:
   template=I3D(current);entries=None
  _,parts=spans(template.text);configs=[e for e in parts if e['depth']==1 and e['local']==slot+'Configuration'];section=ET.fromstring(template.text)
  if section.tag!=slot+'Configurations' or len(configs)>1000:raise ValueError('Estrutura de opcionais invalida.')
  if entries is None:entries=[dict(key=str(i),enabled=True,deleted=False) for i in range(len(configs))]
  if len(entries)!=len(configs) or any(e.get('key')!=str(i) or type(e.get('enabled'))!=bool or type(e.get('deleted'))!=bool or type(e.get('visible',True))!=bool for i,e in enumerate(entries)):raise ValueError('Backup de escolhas invalido.')
  if slot in reserved:reason='Grupo usado em conjuntos da loja (configurationSets). Remova essa ligacao no XML antes de editar as escolhas.'
  if any('default' in key.lower() and value.isdigit() for key,value in section.attrib.items()):reason='Este grupo possui um indice padrao explicito no XML.'
  options=[];pure=all(c.tag==slot+'Configuration' for c in section);all_indices=set()
  for i,item in enumerate(configs):
   config=ET.fromstring(fragment(template,item));changes={};partial=bool(set(config.attrib)-{'name','price','saveId','isDefault'})
   for change in config:
    if change.tag!='objectChange':partial=True;continue
    reference=change.get('node');index=paths.get(canonical(mappings.get(reference,reference)))
    visual=set(change.attrib)<={'node','visibilityActive','visibilityInactive'} and index is not None
    if not visual:partial=True
    if index is not None:
     for key in ('visibilityActive','visibilityInactive'):
      value=change.get(key)
      if value in ('true','false'):changes.setdefault(index,{})[key]=value=='true';all_indices.add(index)
      elif value is not None:partial=True
   pure=pure and not partial
   can_hide=not partial and any(c.get('visibilityActive') is True for c in changes.values())
   if not entries[i].get('visible',True):
    for c in changes.values():
     if c.get('visibilityActive') is True:c['visibilityActive']=False
   if not entries[i]['deleted']:options.append(dict(key=str(i),name=config.get('name') or 'Escolha '+str(i+1),enabled=entries[i]['enabled'],visible=entries[i].get('visible',True),canHide=can_hide,changes=[dict(index=k,**v) for k,v in changes.items()],partial=partial))
  groups.append(dict(slot=slot,title=section.get('title') or slot,origin='editor' if all(c.get('saveId','').startswith('gm_') for c in section) and len(section) else 'mod',options=options,reason=reason,editable=not reason,removable=not reason and pure and bool(options),indices=sorted(all_indices),_state=dict(version=1,template=template.text,entries=entries,hash=digest(current)),_item=sections[0],_template=template,_configs=configs))
 return doc,xml,groups,stored

def inspect(editor,name,vehicle=None):
 from shop_options import inspect as shop_info
 with editor.lock:
  info=shop_info(editor,name,vehicle);_,_,groups,_=data(editor,name,info['vehicle'])
  return dict(project=editor.project.name,file=name,vehicle=info['vehicle'],vehicles=info['vehicles'],revision=editor.meta()['revision'],groups=[{k:v for k,v in g.items() if not k.startswith('_')} for g in groups])

def apply(editor,body):
 with editor.lock:
  if not editor.project or body.get('project')!=editor.project.name or body.get('revision')!=editor.meta()['revision']:raise ValueError('O projeto mudou. Reabra o gerenciador de opcionais.')
  name=body.get('file');vehicle=body.get('vehicle');doc,xml,groups,stored=data(editor,name,vehicle)
  group=next((g for g in groups if g['slot']==body.get('slot')),None)
  if not group:raise ValueError('Grupo de opcionais nao encontrado.')
  if group['reason']:raise ValueError(group['reason'])
  action=body.get('action');key=body.get('key');choice=next((c for c in group['options'] if c['key']==key),None)
  if action not in ('toggle','choice-visibility','remove-choice','remove-group') or not choice:raise ValueError('Acao ou escolha invalida.')
  state=group['_state'];entries=state['entries'];index=int(key)
  if action=='remove-group':
   if not group['removable']:raise ValueError('Este grupo controla materiais, funcoes ou referencias sem previa. A remocao completa exige revisar o XML; nenhuma alteracao foi feita.')
   if not choice['enabled']:raise ValueError('Selecione uma escolha ativa para manter sua aparencia.')
   values={}
   for c in group['options']:
    if c['enabled']:
     for change in c['changes']:
      if 'visibilityInactive' in change:values[change['index']]=change['visibilityInactive']
   for change in choice['changes']:
    if 'visibilityActive' in change:values[change['index']]=change['visibilityActive']
   # The resulting visual state must not hide mechanical nodes or override another group.
   from selection_tools import node_keys,view_state
   keys=node_keys(doc.nodes);locked=set(view_state(editor,name)['locked'])
   for i in values:
    if doc.nodes[i]['parent'] is None:raise ValueError('O grupo controla a raiz do veiculo. Confira o XML.')
    for j in range(len(doc.nodes)):
     if keys[j] not in locked:continue
     a=i
     while a is not None:
      if a==j:raise ValueError('O opcional contem pecas travadas.')
      a=doc.nodes[a]['parent']
     a=j
     while a is not None:
      if a==i:raise ValueError('O opcional contem pecas travadas.')
      a=doc.nodes[a]['parent']
   paths={i:path for i,path in scene_paths(doc).items()};root=ET.fromstring(xml.text);mappings={e.get('id'):e.get('node') for e in root.findall('i3dMappings/i3dMapping')}
   targets={canonical(mappings.get(c.get('node'),c.get('node'))) for section in root if section.tag!=group['slot']+'Configurations' for c in section.iter('objectChange') if c.get('visibilityActive') is not None or c.get('visibilityInactive') is not None}
   def related(a,b):return a==b or a.startswith(b+'|') or b.startswith(a+'|') or a.startswith(b+'>') or b.startswith(a+'>')
   if any(related(paths[i],target) for i in values for target in targets if target):raise ValueError('Outro grupo controla estas pecas. Confira o XML antes de remover o grupo inteiro.')
   model_raw=editor.read(name)
   for i,visible in values.items():model_raw=I3D(model_raw).patch(i,{'visibility':visible})
   replacement=b''
  else:
   entry=entries[index]
   if action=='toggle':
    if type(body.get('enabled'))!=bool:raise ValueError('Estado de escolha invalido.')
    entry['enabled']=body['enabled']
   elif action=='choice-visibility':
    if not choice['canHide'] or type(body.get('visible'))!=bool:raise ValueError('Esta escolha nao possui pecas visuais que possam ser ocultadas automaticamente.')
    entry['visible']=body['visible']
   else:entry['deleted']=True
   active=[e for e in entries if e['enabled'] and not e['deleted']]
   if not active:raise ValueError('Mantenha pelo menos uma escolha ativa. Para tirar o grupo da loja, use Remover grupo.')
   template=group['_template'];replacement=template.utf8
   for i,item in reversed(list(enumerate(group['_configs']))):
    content=fragment(template,item)
    if entries[i]['deleted'] or not entries[i]['enabled']:content=b''
    elif not entries[i].get('visible',True):
     config_doc=I3D(content);_,children=spans(config_doc.text)
     for child in reversed(children):
      if child['depth']==1 and child['local']=='objectChange' and child['attrs'].get('visibilityActive')=='true':config_doc=I3D(attributes(config_doc,child,{'visibilityActive':'false'}))
     content=config_doc.utf8
    replacement=replacement[:item['start']]+content+replacement[whole_end(template,item):]
   state['hash']=digest(replacement)
  edits=[(group['_item']['start'],whole_end(xml,group['_item']),replacement)]
  if group['slot'] in stored:_,start,end=stored[group['slot']];edits.append((start,end,b''))
  if action!='remove-group' and any(e['deleted'] or not e['enabled'] or not e.get('visible',True) for e in entries):
   encoded=base64.b64encode(json.dumps(state,separators=(',',':'),ensure_ascii=False).encode())
   if len(encoded)>MAX_BACKUP:raise ValueError('Grupo muito grande para manter a reativacao offline.')
   # Put the comment alongside its section; the game ignores it.
   edits[0]=(edits[0][0],edits[0][1],replacement+b'\n<!--'+MARK.encode()+b' '+group['slot'].encode()+b' '+encoded+b'-->')
  raw=xml.utf8
  for start,end,replacement in sorted(edits,reverse=True):raw=raw[:start]+replacement+raw[end:]
  raw=raw.decode().encode(xml.encoding,errors='xmlcharrefreplace');I3D(raw)
  files={vehicle:raw}
  if action=='remove-group':files[name]=model_raw
  result=editor.change_many(files,body['revision'])
  return dict(project=result,file=name,vehicle=vehicle,slot=group['slot'],action=action)

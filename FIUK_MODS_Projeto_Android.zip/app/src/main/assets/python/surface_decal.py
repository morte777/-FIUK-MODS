"""Clip a connected patch of receiver triangles into a decal projection box."""
import base64,json,math,struct,xml.etree.ElementTree as ET
from collections import deque

INFO='gabrielPlotagem'
def dot(a,b):return sum(x*y for x,y in zip(a,b))
def sub(a,b):return [x-y for x,y in zip(a,b)]
def cross(a,b):return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]
def unit(v):
    length=math.sqrt(dot(v,v))
    return [x/length for x in v] if length>1e-15 else [0,0,1]
def rotation(r):
    x,y,z=[v*math.pi/180 for v in r];cx,sx,cy,sy,cz,sz=math.cos(x),math.sin(x),math.cos(y),math.sin(y),math.cos(z),math.sin(z)
    return [[cz*cy,cz*sy*sx-sz*cx,cz*sy*cx+sz*sx],[sz*cy,sz*sy*sx+cz*cx,sz*sy*cx-cz*sx],[-sy,cy*sx,cy*cx]]
def matrix_vector(m,p):return [dot(row,p) for row in m]
def arrays(mesh):
    if 'positionsBase64' in mesh:
        unpack=lambda s,code:list(struct.unpack('<'+code*(len(base64.b64decode(s))//struct.calcsize(code)),base64.b64decode(s)))
        values=unpack(mesh['positionsBase64'],'f');positions=[values[i:i+3] for i in range(0,len(values),3)]
        indices=unpack(mesh['indicesBase64'],'I' if mesh['indexType']=='u32' else 'H')
        values=unpack(mesh['normalsBase64'],'f') if mesh.get('normalsBase64') else []
        normals=[values[i:i+3] for i in range(0,len(values),3)]
    else:positions=mesh['positions'];indices=mesh['indices'];normals=[]
    return positions,indices,normals

def flat_mesh(width,height):
    return {'positions':[[-width/2,-height/2,0],[width/2,-height/2,0],[width/2,height/2,0],[-width/2,height/2,0]],'normals':[[0,0,1]]*4,'uvs':[[0,0],[1,0],[1,1],[0,1]],'indices':[0,1,2,0,2,3]}

def distance_triangle(a,b,c):
    # Squared distance from the projector origin to a triangle (not its centroid).
    ab,ac=sub(b,a),sub(c,a);n=cross(ab,ac);nn=dot(n,n)
    if nn>1e-24:
        q=[x*dot(n,a)/nn for x in n];aq=sub(q,a)
        d00,d01,d11,d20,d21=dot(ab,ab),dot(ab,ac),dot(ac,ac),dot(aq,ab),dot(aq,ac);den=d00*d11-d01*d01
        if abs(den)>1e-24:
            u=(d11*d20-d01*d21)/den;v=(d00*d21-d01*d20)/den
            if u>=-1e-9 and v>=-1e-9 and u+v<=1+1e-9:return dot(q,q)
    result=math.inf
    for p,q in ((a,b),(b,c),(c,a)):
        edge=sub(q,p);ee=dot(edge,edge);t=max(0,min(1,-dot(p,edge)/ee)) if ee else 0
        closest=[x+t*y for x,y in zip(p,edge)];result=min(result,dot(closest,closest))
    return result

def clipped(poly,axis,limit,sign):
    out=[]
    for current,previous in zip(poly,poly[-1:]+poly[:-1]):
        dc=limit-sign*current[0][axis];dp=limit-sign*previous[0][axis];inside=dc>=-1e-10;before=dp>=-1e-10
        if inside!=before:
            t=dp/(dp-dc)
            out.append(([a+(b-a)*t for a,b in zip(previous[0],current[0])],[a+(b-a)*t for a,b in zip(previous[1],current[1])]))
        if inside:out.append(current)
    return out

def project(mesh,width,height,translation,angles,scale=(1,1,1),depth=.2,max_angle=75,offset=.001):
    for value,lo,hi,label in [(width,.001,100,'largura'),(height,.001,100,'altura'),(depth,.001,2,'profundidade'),(max_angle,5,85,'inclinacao'),(offset,0,.01,'afastamento')]:
        if not isinstance(value,(int,float)) or isinstance(value,bool) or not math.isfinite(value) or not lo<=value<=hi:raise ValueError('Valor invalido de '+label+'.')
    if len(scale)!=3 or any(not math.isfinite(v) or abs(v)<1e-6 or abs(v)>1e5 for v in scale):raise ValueError('A escala da plotagem precisa ser diferente de zero e estar dentro do limite.')
    source,indices,normals=arrays(mesh)
    if len(indices)>1800000:raise ValueError('Peca muito grande para esta projecao. Escolha uma parte menor.')
    r=rotation(angles);rt=list(zip(*r));bounds=[width/2,height/2,depth/(2*abs(scale[2]))]
    to_local=lambda p:[v/s for v,s in zip(matrix_vector(rt,sub(p,translation)),scale)]
    # Normals transform by M^T when positions transform by M^-1.
    normal_local=lambda n:unit([v*s for v,s in zip(matrix_vector(rt,n),scale)])
    positions=[to_local(p) for p in source];candidates=[]
    for start in range(0,len(indices),3):
        ids=indices[start:start+3];tri=[positions[i] for i in ids]
        if any(min(p[k] for p in tri)>bounds[k] or max(p[k] for p in tri)<-bounds[k] for k in range(3)):continue
        face=cross(sub(tri[1],tri[0]),sub(tri[2],tri[0]));area=math.sqrt(dot(face,face))
        if area<1e-14:continue
        receiver_face=unit(cross(sub(source[ids[1]],source[ids[0]]),sub(source[ids[2]],source[ids[0]])))
        if abs(matrix_vector(rt,receiver_face)[2])<math.cos(math.radians(max_angle)):continue
        poly=[(p,list(normals[i]) if normals else receiver_face[:]) for p,i in zip(tri,ids)]
        for axis in range(3):
            for sign in (-1,1):
                poly=clipped(poly,axis,bounds[axis],sign)
                if len(poly)<3:break
            if len(poly)<3:break
        if len(poly)<3:continue
        valid=[i for i in range(1,len(poly)-1) if dot(cross(sub(poly[i][0],poly[0][0]),sub(poly[i+1][0],poly[0][0])),cross(sub(poly[i][0],poly[0][0]),sub(poly[i+1][0],poly[0][0])))>1e-24]
        if not valid:continue
        physical=lambda p:[v*s for v,s in zip(p,scale)]
        nearest=min(distance_triangle(physical(poly[0][0]),physical(poly[i][0]),physical(poly[i+1][0])) for i in valid)
        candidates.append({'poly':poly,'fan':valid,'sign':1 if face[2]>0 else -1,'distance':nearest})
        if len(candidates)>30000:raise ValueError('Projecao detalhada demais. Reduza o tamanho ou a profundidade.')
    if not candidates:raise ValueError('Nenhuma superficie encontrada na projecao. Aproxime a plotagem da peca ou aumente um pouco a profundidade.')
    seed=min(range(len(candidates)),key=lambda i:candidates[i]['distance']);side=candidates[seed]['sign']
    # Geometric position keys bridge duplicated vertices at UV/normal seams.
    links={}
    for i,candidate in enumerate(candidates):
        if candidate['sign']!=side:continue
        keys={tuple(round(v,6) for v in p) for p,n in candidate['poly']};candidate['keys']=keys
        for key in keys:links.setdefault(key,[]).append(i)
    queue=deque([seed]);connected={seed}
    while queue:
        i=queue.popleft()
        for key in candidates[i]['keys']:
            for other in links.pop(key,[]):
                if other not in connected:connected.add(other);queue.append(other)
    front=1 if scale[0]*scale[1]>0 else -1
    output={'positions':[],'normals':[],'uvs':[],'indices':[]}
    for i in sorted(connected):
        candidate=candidates[i];poly=candidate['poly'];base=len(output['positions'])
        for p,n in poly:
            n=unit(n)
            if matrix_vector(rt,n)[2]<0:n=[-v for v in n]
            nl=normal_local(n)
            shift=[v/s for v,s in zip(matrix_vector(rt,[x*offset for x in n]),scale)]
            output['positions'].append([a+b for a,b in zip(p,shift)]);output['normals'].append(nl)
            output['uvs'].append([max(0,min(1,p[0]/width+.5)),max(0,min(1,p[1]/height+.5))])
        for j in candidate['fan']:output['indices'].extend([base,base+j,base+j+1] if side==front else [base,base+j+1,base+j])
        if len(output['positions'])>60000 or len(output['indices'])>120000:raise ValueError('Malha projetada grande demais. Reduza a area da plotagem.')
    return output,{'triangles':len(output['indices'])//3,'sourceTriangles':len(connected),'discardedTriangles':len(candidates)-len(connected),'depth':depth,'maxAngle':max_angle,'offset':offset}

def info_map(document):
    from core import tagname
    result={}
    for e in ET.fromstring(document.text).iter():
        if tagname(e.tag)!='UserAttribute':continue
        for child in e:
            if tagname(child.tag)=='Attribute' and child.get('name')==INFO:
                try:
                    data=json.loads(child.get('value',''))
                    if isinstance(data,dict) and all(isinstance(data.get(k),(float,int)) and math.isfinite(data[k]) and 0<data[k]<=100 for k in ('width','height')):result[e.get('nodeId')]=data
                except (ValueError,TypeError):pass
    return result

def annotate(scene,document):
    stored=info_map(document)
    for node in scene['nodes']:
        material=scene['materialDetails'].get(node.get('materialIds'),{})
        texture=material.get('maps',{}).get('diffuse','') or ''
        if node.get('nodeId') not in stored and not (node['name'].startswith('Plotagem ') and 'gabriel_plotagens/adesivo_' in texture.replace('\\','/')):continue
        info=stored.get(node.get('nodeId'))
        if not info:
            mesh=scene['meshes'].get(node.get('shapeId'))
            if not mesh:continue
            p,_,_=arrays(mesh)
            if not p:continue
            width=max(v[0] for v in p)-min(v[0] for v in p);height=max(v[1] for v in p)-min(v[1] for v in p)
            if width<=0 or height<=0:continue
            info={'width':width,'height':height,'mode':'flat'}
        node['decalInfo']=info

def store_info(document,node_id,info):
    from decals import spans,append_element
    from xml.sax.saxutils import quoteattr
    raw,elements=spans(document.text);value=json.dumps(info,separators=(',',':'),allow_nan=False)
    existing=next((e for e in elements if e['local']=='UserAttribute' and e['attrs'].get('nodeId')==node_id),None)
    if existing:
        attr=next((e for e in elements if e['local']=='Attribute' and e['attrs'].get('name')==INFO and existing['start']<e['start']<existing['close']),None)
        if attr:return patch_attribute(document,attr,'value',value)
        raw=append_element(raw,existing,f'<Attribute name="{INFO}" type="string" value={quoteattr(value)}/>'.encode())
    else:
        child=f'<UserAttribute nodeId={quoteattr(node_id)}><Attribute name="{INFO}" type="string" value={quoteattr(value)}/></UserAttribute>'.encode()
        section=next((e for e in elements if e['depth']==1 and e['local']=='UserAttributes'),None)
        if section:raw=append_element(raw,section,child)
        else:raw=raw[:elements[0]['close']]+b'<UserAttributes>'+child+b'</UserAttributes>'+raw[elements[0]['close']:]
    return raw.decode().encode(document.encoding,errors='xmlcharrefreplace')

def patch_attribute(document,element,key,value):
    import re
    from xml.sax.saxutils import quoteattr
    raw=document.utf8;tag=raw[element['start']:element['openEnd']].decode()
    match=next((m for m in re.finditer(r'([\w:.-]+)(\s*=\s*)([\"\'])(.*?)\3',tag,re.S) if m.group(1)==key),None)
    if not match:raise ValueError('Atributo da plotagem nao encontrado.')
    tag=tag[:match.start()]+key+match.group(2)+quoteattr(str(value))+tag[match.end():]
    return (raw[:element['start']]+tag.encode()+raw[element['openEnd']:]).decode().encode(document.encoding,errors='xmlcharrefreplace')

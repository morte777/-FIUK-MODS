"""Read transform/visibility animation tracks without running game scripts."""
import math
from core import I3D
from shop_options import vehicles
from wheel_preview import node_index

def vector(value):
    try:
        result=[float(v) for v in value.split()]
        return result if len(result)==3 and all(math.isfinite(v) and abs(v)<1e6 for v in result) else None
    except (ValueError,AttributeError):return None

def options(editor,model):
    with editor.lock:
        nodes=I3D(editor.read(model)).nodes;rows=[];warnings=[]
        for filename,doc,root in vehicles(editor,model):
            mappings={e.get('id'):e.get('node','') for e in root.findall('i3dMappings/i3dMapping')}
            for a in root.findall('animations/animation')[:300]:
                parts=[];unsupported=0;duration=0
                for p in a.findall('part')[:3000]:
                    try:
                        start=float(p.get('startTime','0'));end=float(p.get('endTime',str(start+float(p.get('duration','0')))))
                        if not all(math.isfinite(v) for v in (start,end)) or not 0<=start<=end<=3600:raise ValueError()
                    except ValueError:unsupported+=1;continue
                    index=node_index(nodes,p.get('node'),mappings)
                    if index is None:unsupported+=1;continue
                    tracks={};bad=False
                    for key,suffix in (('translation','Trans'),('rotation','Rot'),('scale','Scale')):
                        first=p.get('start'+suffix);last=p.get('end'+suffix)
                        if first is None and last is None:continue
                        v0=vector(first) if first is not None else None;v1=vector(last) if last is not None else v0
                        if (first is not None and v0 is None) or v1 is None:bad=True;continue
                        tracks[key]={'start':v0,'end':v1}
                    if p.get('visibility') is not None:tracks['visibility']=p.get('visibility') in ('true','1')
                    if p.get('shaderParameter') or p.get('componentJointIndex') or bad:unsupported+=1
                    if p.get('interpolation','linear').lower() not in ('linear',''):unsupported+=1
                    if tracks:parts.append({'index':index,'start':start,'end':end,'tracks':tracks});duration=max(duration,end)
                    elif not p.get('shaderParameter'):unsupported+=1
                rows.append({'name':a.get('name','Animacao'),'vehicle':filename,'duration':duration,'parts':parts,'unsupported':unsupported,'supported':bool(parts)})
        return {'file':model,'project':editor.project.name,'revision':editor.meta()['revision'],'animations':rows,'note':'Prévia de posição, rotação, escala e visibilidade do XML. Interpolação linear; sons, shaders, ossos, física e scripts não são executados.'}

"""Import one static donor subtree with isolated IDs, geometry and resources."""
import copy,hashlib,json,math,posixpath,re,uuid,xml.etree.ElementTree as ET
from core import Editor,I3D,tagname,vector
from decals import spans,append_element,replace_external
from xml_edit import section,attributes,next_id,whole_end
from game_compat import profile
from native_assets import append_meshes,empty_shapes,inline_mesh,extract_records
from surface_decal import arrays,rotation,matrix_vector

VISUAL={'name','translation','rotation','scale','visibility','nodeId','shapeId','materialIds','nonRenderable','clipDistance','castsShadows','receiveShadows','distanceBlending'}

def source_editor(editor):
    if not editor.project:raise ValueError('Abra o mod de destino primeiro.')
    donor=Editor(editor.project/'accessory_source');donor.base=editor.base;donor.base_path=editor.base_path
    if not donor.project:raise ValueError('Carregue o ZIP que contem o acessorio.')
    return donor

def load_source(editor,path,name,*,consume_source=False):
    with editor.lock:
        if not editor.project:raise ValueError('Abra o mod de destino primeiro.')
        donor=Editor(editor.project/'accessory_source');donor.import_zip(path,name,consume_source=consume_source)
        return inspect(editor)

def inspect(editor,name=None):
    donor=source_editor(editor);summary=donor.summary();name=name or summary['i3ds'][0]
    if name not in summary['i3ds']:raise ValueError('Selecione um I3D da origem.')
    doc=I3D(donor.read(name));nodes=[{k:n[k] for k in ('index','parent','name','tag','shapeId')} for n in doc.nodes]
    return {'source':{'name':summary['name'],'i3ds':summary['i3ds'],'id':donor.project.name},'file':name,'nodes':nodes}

def element_nodes(doc):
    root=ET.fromstring(doc.text);scene=next((e for e in root if tagname(e.tag)=='Scene'),None)
    if scene is None:raise ValueError('Origem sem Scene.')
    return root,list(scene.iter())[1:]

def import_part(editor,target,parent,source,index,revision,translation=None,source_id=None,*,allow_functional=False):
    with editor.lock:
        if revision!=editor.meta()['revision']:raise ValueError('Projeto mudou. Reabra a importacao.')
        donor=source_editor(editor)
        if source_id!=donor.project.name:raise ValueError('A origem do acessorio mudou. Selecione a peca novamente.')
        destination=I3D(editor.read(target));donor_doc=I3D(donor.read(source));source_root,node_elements=element_nodes(donor_doc)
        if not isinstance(index,int) or not 0<=index<len(donor_doc.nodes):raise ValueError('Selecione uma peca da origem.')
        if not isinstance(parent,int) or not 0<=parent<len(destination.nodes):raise ValueError('Selecione onde ligar o acessorio no destino.')
        translation=[0,0,0] if translation is None else translation;destination.patch(parent,{'translation':translation})
        selected=copy.deepcopy(node_elements[index]);subtree=list(selected.iter())
        if len(subtree)>3000:raise ValueError('Subarvore grande demais. Selecione uma parte menor.')
        if not allow_functional and any(tagname(e.tag) not in ('TransformGroup','Shape') for e in subtree):raise ValueError('Escolha uma subarvore estatica com Shape/TransformGroup, sem cameras, dinamicos ou luzes funcionais.')
        source_scene=donor.scene(source,include_wheels=False);target_scene=editor.scene(target,include_wheels=False)
        used_shapes=list(dict.fromkeys(e.get('shapeId') for e in subtree if e.get('shapeId')))
        if not used_shapes and not allow_functional:raise ValueError('A selecao nao possui nenhuma malha.')
        for sid in used_shapes:
            mesh=source_scene['meshes'].get(sid)
            if not mesh:raise ValueError('Malha ausente no acessorio: '+sid)
            if mesh.get('skin') or any(e.get('skinBindNodeIds') for e in subtree if e.get('shapeId')==sid):raise ValueError('Selecione uma peca estatica, sem deformacao por ossos.')
        if sum(source_scene['meshes'][sid].get('vertexCount',len(source_scene['meshes'][sid].get('positions',[]))) for sid in used_shapes)>1000000:raise ValueError('Acessorio grande demais. Escolha menos pecas.')
        sid_start=max([next_id(destination,'shapeId')-1]+[int(k) for k in target_scene['meshes'] if k.isdigit()])+1
        shape_ids={sid:str(sid_start+i) for i,sid in enumerate(used_shapes)}
        material_ids=list(dict.fromkeys(mid for e in subtree for mid in e.get('materialIds','').split()))
        mid_start=next_id(destination,'materialId');materials={mid:str(mid_start+i) for i,mid in enumerate(material_ids)}
        material_elements={e.get('materialId'):e for e in source_root.iter() if tagname(e.tag)=='Material'}
        file_elements={e.get('fileId'):e for e in source_root.iter() if tagname(e.tag)=='File'}
        token=uuid.uuid4().hex[:12];namespace='gabriel_acessorios/'+token;prefix=posixpath.dirname(target);pending={};file_ids={};file_start=next_id(destination,'fileId');new_files=[];new_materials=[]
        total=0;warnings=[];copied=set()
        def copy_resource(resource):
            nonlocal total
            if resource in copied:return
            if profile(editor)['game']=='FS19' and resource.lower().endswith(('.ast','.astc')):raise ValueError('O projeto FS19 precisa de texturas DDS. Este acessorio usa AST; escolha uma origem com DDS. A conversao entre jogos sera uma opcao separada.')
            copied.add(resource)
            if resource.startswith('base:'):relative='base/'+resource.split('/',1)[1]
            else:relative=resource
            relative=relative.replace('\\','/')
            if relative.startswith('/') or '..' in relative.split('/'):raise ValueError('Caminho de recurso invalido.')
            data=donor.read_resource(resource,128*1024*1024);total+=len(data)
            if total>256*1024*1024:raise ValueError('Recursos do acessorio excedem 256 MB. Escolha uma parte menor.')
            dest=posixpath.join(prefix,namespace,'recursos',relative);pending[dest]=data
            # Retain the editable PNG alongside native AST resources when supplied.
            if resource.lower().endswith(('.ast','.astc')) and not resource.startswith('base:'):
                png=posixpath.splitext(resource)[0]+'.png';companion=donor.archive_index()[0].get(png.casefold())
                if companion:copy_resource(companion)
            # Preserve sibling files in a local shader directory for relative includes/archives.
            if resource.lower().endswith('.xml') and 'shader' in posixpath.basename(resource).lower() and not resource.startswith('base:'):
                directory=posixpath.dirname(resource)
                if directory and 'shader' in directory.lower():
                    for other in donor.archive_index()[0].values():
                        if other.startswith(directory+'/') and not other.lower().endswith(('.i3d','.shapes','.zip')):copy_resource(other)
        def map_file(fid):
            if fid in file_ids:return file_ids[fid]
            original=file_elements.get(fid)
            if original is None:raise ValueError('FileId ausente na origem: '+str(fid))
            clone=copy.deepcopy(original);reference=clone.get('filename','');new_id=str(file_start+len(file_ids));file_ids[fid]=new_id;clone.set('fileId',new_id)
            if reference.startswith('$'):
                # Native game references remain external; no APK data is bundled for these.
                pass
            else:
                resource=donor.resolve_resource(reference,source,basename_fallback=True)
                if not resource:raise ValueError('Recurso ausente na origem: '+reference)
                copy_resource(resource)
                relative='base/'+resource.split('/',1)[1] if resource.startswith('base:') else resource
                path=namespace+'/recursos/'+relative
                ref_ext=posixpath.splitext(reference)[1].lower();actual_ext=posixpath.splitext(path)[1].lower()
                if actual_ext in ('.ast','.astc') and ref_ext in ('.png','.dds'):
                    path=posixpath.splitext(path)[0]+('.png' if ref_ext=='.dds' else ref_ext)
                clone.set('filename',path);clone.set('relativePath','true')
            new_files.append(clone);return new_id
        for mid in material_ids:
            if mid not in material_elements:raise ValueError('Material ausente na origem: '+mid)
            clone=copy.deepcopy(material_elements[mid]);clone.set('materialId',materials[mid])
            for element in clone.iter():
                for key in ('fileId','customShaderId'):
                    if element.get(key):element.set(key,map_file(element.get(key)))
            new_materials.append(clone)
        node_start=next_id(destination,'nodeId');wrapper_id=str(node_start)
        idmap={e.get('nodeId'):str(node_start+i+1) for i,e in enumerate(subtree) if e.get('nodeId')}
        for i,element in enumerate(subtree):
            attrs=dict(element.attrib) if allow_functional else {k:v for k,v in element.attrib.items() if k in VISUAL};element.attrib.clear();element.attrib.update(attrs);element.set('nodeId',str(node_start+i+1))
            if allow_functional:
                # Referencias a outros nos so sobrevivem se o alvo esta dentro do ramo exportado.
                for key in ('skinBindNodeIds','transformId','rootNode','jointNode'):
                    if element.get(key):
                        values=element.get(key).split()
                        if all(v in idmap for v in values):element.set(key,' '.join(idmap[v] for v in values))
                        else:
                            del element.attrib[key];warnings.append('Referencia '+key+' fora do ramo removida em '+(element.get('name') or '?'))
                # Arquivos usados diretamente por luzes/cameras etc. (ex.: *FileId).
                for key in [k for k in element.attrib if k.lower().endswith('fileid') and k!='fileId']:
                    if element.get(key) in file_elements:element.set(key,map_file(element.get(key)))
            if element.get('shapeId'):element.set('shapeId',shape_ids[element.get('shapeId')])
            if element.get('materialIds'):element.set('materialIds',' '.join(materials[mid] for mid in element.get('materialIds').split()))
        # Keep the selected part's orientation/scale, remove donor placement, recenter its bounds.
        selected.set('translation','0 0 0');selected.set('visibility','true');bounds=[]
        def apply(element,chain):
            if element.get('visibility') in ('false','0'):return
            chain=chain+[(vector(element.get('translation'),[0,0,0]),rotation(vector(element.get('rotation'),[0,0,0])),vector(element.get('scale'),[1,1,1]))]
            sid=element.get('shapeId');old=next((s for s,new in shape_ids.items() if new==sid),None)
            if old and element.get('nonRenderable') not in ('true','1'):
                mesh=source_scene['meshes'][old];p,_,_=arrays(mesh)
                if not p:raise ValueError('Malha visual sem vertices.')
                lo=[min(v[k] for v in p) for k in range(3)];hi=[max(v[k] for v in p) for k in range(3)]
                for x in (lo[0],hi[0]):
                    for y in (lo[1],hi[1]):
                        for z in (lo[2],hi[2]):
                            value=[x,y,z]
                            for t,r,s in reversed(chain):value=[a+b for a,b in zip(matrix_vector(r,[v*k for v,k in zip(value,s)]),t)]
                            bounds.append(value)
            for child in element:apply(child,chain)
        apply(selected,[])
        if not bounds and not allow_functional:raise ValueError('A selecao nao contem geometria visual.')
        center=[(min(p[k] for p in bounds)+max(p[k] for p in bounds))/2 for k in range(3)] if bounds else [0,0,0]
        if any(not math.isfinite(v) or abs(v)>1e9 for v in center):raise ValueError('Dimensoes do acessorio fora do limite.')
        selected.set('translation',' '.join(format(-v,'.9g') for v in center))
        label=donor_doc.nodes[index]['name'];wrapper=ET.Element('TransformGroup',{'name':'Acessorio '+label[:60],'nodeId':wrapper_id,'translation':' '.join(format(v,'.9g') for v in translation)})
        wrapper.append(selected)
        raw=editor.read(target);user_attributes=[]
        if allow_functional:
            for ua in source_root.iter():
                if tagname(ua.tag)=='UserAttribute' and ua.get('nodeId') in idmap:
                    clone=copy.deepcopy(ua);clone.set('nodeId',idmap[ua.get('nodeId')]);user_attributes.append(ET.tostring(clone,encoding='utf-8'))
        for section_name,items in (('Files',new_files),('Materials',new_materials)):
            if items:raw=section(I3D(raw),section_name,b''.join(ET.tostring(e,encoding='utf-8') for e in items))
        doc=I3D(raw);_,elements=spans(doc.text);parent_item=next(e for e in elements if e['start']==doc.spans[parent][0]);raw=append_element(doc.utf8,parent_item,ET.tostring(wrapper,encoding='utf-8')).decode().encode(doc.encoding,errors='xmlcharrefreplace')
        if user_attributes:raw=section(I3D(raw),'UserAttributes',b''.join(user_attributes))
        references=target_scene['externalShapes']
        if len(references)>1:raise ValueError('Destino com varias fontes .shapes ainda nao e suportado.')
        binary_path=editor.resolve_resource(references[0],target) if references else None
        entries=[(shape_ids[sid],source_scene['meshes'][sid]) for sid in used_shapes]
        original_records={}
        for reference in source_scene['externalShapes']:
            resource=donor.resolve_resource(reference,source)
            if resource:original_records.update(extract_records(donor.read_resource(resource,256*1024*1024),used_shapes))
        native_records={shape_ids[sid]:record for sid,record in original_records.items()}
        if references and not binary_path:raise ValueError('O .shapes de destino precisa estar disponivel.')
        if not binary_path:
            target_root=ET.fromstring(destination.text);inline=[e for e in target_root.iter() if tagname(e.tag)=='IndexedTriangleSet']
            entries=[(e.get('shapeId'),inline_mesh(e)) for e in inline]+entries
            doc=I3D(raw);_,elements=spans(doc.text)
            for item in sorted([e for e in elements if e['local']=='IndexedTriangleSet'],key=lambda e:e['start'],reverse=True):
                data=doc.utf8;data=data[:item['start']]+data[whole_end(doc,item):];doc=I3D(data.decode().encode(doc.encoding,errors='xmlcharrefreplace'))
            raw=doc.text.encode(doc.encoding);binary=append_meshes(empty_shapes(profile(editor)['shapeVersion']),entries,native_records)
        else:binary=append_meshes(editor.read_resource(binary_path,256*1024*1024),entries,native_records)
        if not binary_path or binary_path.startswith('base:'):
            relative=namespace+'/malhas.i3d.shapes';doc=I3D(raw);_,elements=spans(doc.text);shape_section=next((e for e in elements if e['depth']==1 and e['local']=='Shapes'),None)
            if shape_section:raw=attributes(doc,shape_section,{'externalShapesFile':relative})
            else:raw=section(doc,'Shapes',b'');doc=I3D(raw);_,elements=spans(doc.text);shape_section=next(e for e in elements if e['depth']==1 and e['local']=='Shapes');raw=attributes(doc,shape_section,{'externalShapesFile':relative})
            pending[posixpath.join(prefix,relative)]=binary
        else:pending[binary_path]=binary
        pending[target]=raw
        parsed=I3D(raw);imported_index=next(n['index'] for n in parsed.nodes if n['nodeId']==wrapper_id)
        result=editor.change_many(pending,revision)
        return {'project':result,'index':imported_index,'meshes':len(used_shapes),'resources':len(copied),'warnings':warnings}

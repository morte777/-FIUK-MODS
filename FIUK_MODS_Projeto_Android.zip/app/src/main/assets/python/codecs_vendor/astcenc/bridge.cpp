// Gabriel Mods memory bridge for Arm astc-encoder 5.3.0 (Apache-2.0).
// No subprocess, filesystem, executable extraction or Termux dependency.
#include "astcenc.h"
#include <cstddef>
#include <new>
#include <thread>
extern "C" __attribute__((visibility("default")))
int gm_astc(int decode, int srgb, float quality, unsigned w, unsigned h,
            unsigned char* rgba, unsigned char* blocks, size_t length) noexcept {
    if (!rgba || !blocks || !w || !h || w > 4096 || h > 4096 ||
        length != size_t((w+5)/6)*((h+5)/6)*16) return -1;
    astcenc_context* context = nullptr;
    try {
        astcenc_config config;
        unsigned threads = !decode && w*h >= 256*256 ? 2 : 1;
        auto error = astcenc_config_init(srgb ? ASTCENC_PRF_LDR_SRGB : ASTCENC_PRF_LDR,
            6, 6, 1, quality, decode ? ASTCENC_FLG_DECOMPRESS_ONLY : 0, &config);
        if (error) return error;
        error = astcenc_context_alloc(&config, threads, &context);
        if (error) return error;
        void* slice = rgba;
        astcenc_image image {w, h, 1, ASTCENC_TYPE_U8, &slice};
        astcenc_swizzle swizzle {ASTCENC_SWZ_R, ASTCENC_SWZ_G, ASTCENC_SWZ_B, ASTCENC_SWZ_A};
        if (decode) error = astcenc_decompress_image(context, blocks, length, &image, &swizzle, 0);
        else if (threads == 2) {
            astcenc_error other = ASTCENC_SUCCESS;
            std::thread worker([&] { other = astcenc_compress_image(context, &image, &swizzle, blocks, length, 1); });
            error = astcenc_compress_image(context, &image, &swizzle, blocks, length, 0);
            worker.join();
            if (!error) error = other;
        } else error = astcenc_compress_image(context, &image, &swizzle, blocks, length, 0);
        astcenc_context_free(context);
        return error;
    } catch (...) {
        astcenc_context_free(context);
        return -2;
    }
}

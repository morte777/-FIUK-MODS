Arm astc-encoder 5.3.0, Apache-2.0. See LICENSE.txt and SOURCE.json.
The unmodified upstream memory API sources are in upstream/Source.
Rebuild from project root: python gabriel_android/tools/build_astcenc.py --source gabriel_editor/codecs_vendor/astcenc/upstream --ndk /path/android-ndk-r27c
Host validation: use --host, then set GABRIEL_ASTC_TEST_LIBRARY to the host libgabriel_astc.so for Python tests. Host ELF and upstream sources are excluded from assets/editor.zip.
App uses ASTC 6x6, fast (default) or medium, two workers for images >=256x256 / one for smaller mips, LDR/sRGB per V18, bottom-up rows. Lossy compression. No external tool or runtime download.
V18 array profiles: 4/6 layers RGBA8 mip0; 2-layer RGBA16F experimental and DDS always kept. Unknown arrays/cubemaps rejected.

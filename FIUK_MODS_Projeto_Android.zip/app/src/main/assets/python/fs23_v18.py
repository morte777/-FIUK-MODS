#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
FS23 Mobile DDS -> AST (GS2D v6 / ASTC 6x6) - V14 MEDIUM MIP FIX
Conversor FS22 -> FS23 orientado pelo padrão medido em texturas nativas do FS23.

Principais correções desta versão:
- preserva a resolução em classes genéricas, mas redimensiona classes FS23 de tamanho fixo
  (Terrain, Ground Type, FillPlanes e distance) para o padrão nativo medido;
- gera a cadeia de mipmaps conforme a classe nativa FS23;
- perfil 4 + 1 mip para ícones/mapIcons/overview/store images;
- perfil 6 para texturas 2D normais;
- ASTC 6x6 e chunks GS2D no mesmo arranjo dos AST nativos;
- mipmaps sempre refeitos a partir do mip 0, sem perda acumulada;
- nitidez moderada nos mipmaps de texturas de cor;
- preservação de cobertura alpha para recortes (folhagem, letras, logos),
  reduzindo "sumir/pular" nas bordas quando muda de mip;
- detecção de canais baseada no conteúdo decodificado, não só no FourCC;
- suporte mais amplo aos DDS que o Pillow consegue decodificar;
- verificação estrutural do AST antes de gravar;
- V10: catálogo interno com 256 perfis 2D exatos medidos no data do FS23;
- V10: reconhece automaticamente por caminho e, quando não há ambiguidade, por nome;
- V10: corrige terrainNoise para 512x512 / 8 mips / 1 canal / perfil 6;
- V10: reconhece ground mesmo fora de uma pasta chamada terrain;
- V10: fallback inteligente para foliage LOD, alpha e distance de culturas não catalogadas;
- V10: mantém a saída otimizada da V9, até 8 workers e astcenc -j 1;
- V11: corrige a ordem nativa do grupo de mipmaps 3..N dentro do chunk0;
- V11: adiciona os 703 perfis medidos na pasta textures nativa do mapa FS23;
- V11: impede distância de terreno preta e restaura as 19 cores nativas conhecidas
  quando o decodificador DDS devolver RGB completamente zerado;
- V7: PNG temporário sem compressão pesada (compress_level=0);
- V7: DDS original é apagado SOMENTE depois do AST ser validado e gravado;
- V7: --keep-dds preserva os DDS para testes;
- V7: qualquer DDS sob a raiz é classificado pelo caminho/nome, inclusive mapUS/mapFR/mapAlpine,
  maps/.../fillPlanes, terrain, foliage e pastas soltas no Download.

Dependências no Termux:
    pkg install python -y
    pip install pillow
    astcenc precisa estar instalado e acessível como astcenc-neon,
    astcenc ou astcenc-native.

Uso:
    python ~/fs23_dds2ast/dds2ast.py /storage/emulated/0/Download --overwrite

Por padrão a V11 APAGA cada DDS somente após o AST correspondente ser validado.
Para teste sem apagar DDS:
    python ~/fs23_dds2ast/dds2ast.py /storage/emulated/0/Download --overwrite --keep-dds

O caminho pode ser omitido porque /storage/emulated/0/Download já é o padrão:
    python ~/fs23_dds2ast/dds2ast.py --overwrite
"""

import os
import sys
import struct
import zlib
import base64
import hashlib
import shutil
import tempfile
import subprocess
import io
import math
import argparse
import xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from PIL import Image, ImageFilter

try:
    import numpy as np
except Exception:
    np = None

ROOT_DEFAULT = "/storage/emulated/0/Download"
ASTC_BLOCK = 6
QUALITY = "-medium"
DEFAULT_WORKERS = max(1, min(8, (os.cpu_count() or 4)))
ASTCENC_HAS_J = False

DDS_MAGIC = b"DDS "
ASTC_MAGIC = b"\x13\xAB\xA1\x5C"

ALPHA_CUTOFF = 128
ALPHA_EDGE_LOW = 24
ALPHA_EDGE_HIGH = 232

LINEAR_WORDS = (
    "normal", "specular", "vmask", "mask", "height",
    "rough", "metal", "metallic", "ao", "ambientocclusion",
    "displacement", "gloss", "smoothness", "terrainnoise"
)

ONE_CHANNEL_WORDS = ("height", "displacement")


def u32(data, offset):
    return struct.unpack_from("<I", data, offset)[0]


def read_24(buf):
    return buf[0] | (buf[1] << 8) | (buf[2] << 16)


def is_power_of_two(v):
    return v > 0 and (v & (v - 1)) == 0


def find_astcenc():
    for name in ("astcenc-neon", "astcenc", "astcenc-native"):
        p = shutil.which(name)
        if p:
            return p
    raise RuntimeError(
        "astcenc não encontrado. Teste: astcenc-neon -help "
        "ou astcenc -help"
    )


def detect_astcenc_features(astcenc):
    global ASTCENC_HAS_J
    try:
        r = subprocess.run(
            [astcenc, "-help"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=10,
        )
        text = r.stdout or ""
        ASTCENC_HAS_J = ("-j " in text) or ("-j<" in text) or ("-j <" in text)
    except Exception:
        ASTCENC_HAS_J = False
    return ASTCENC_HAS_J


def read_dds_header(path):
    data = Path(path).read_bytes()
    if len(data) < 128 or data[:4] != DDS_MAGIC:
        raise ValueError("Não é DDS válido")

    width = u32(data, 16)
    height = u32(data, 12)
    mip_count = u32(data, 28) or 1
    pf_flags = u32(data, 80)
    fourcc = data[84:88]
    caps2 = u32(data, 112)

    if width <= 0 or height <= 0:
        raise ValueError(f"Dimensão DDS inválida: {width}x{height}")

    header_size = 128
    dxgi = None
    resource_dimension = None
    misc_flag = 0
    array_size = 1

    if fourcc == b"DX10":
        if len(data) < 148:
            raise ValueError("DDS DX10 incompleto")
        header_size = 148
        dxgi = u32(data, 128)
        resource_dimension = u32(data, 132)
        misc_flag = u32(data, 136)
        array_size = u32(data, 140) or 1

    # Cubemap/HDR do FS23 usa outra estrutura (perfil 5, seis faces).
    if (caps2 & 0x200) or (misc_flag & 0x4):
        raise ValueError(
            "DDS cubemap detectado. Classe GS2D perfil 5/HDR ainda é separada; "
            "arquivo não foi alterado."
        )

    return {
        "data": data,
        "width": width,
        "height": height,
        "mips": mip_count,
        "pf_flags": pf_flags,
        "fourcc": fourcc,
        "caps2": caps2,
        "dxgi": dxgi,
        "resource_dimension": resource_dimension,
        "misc_flag": misc_flag,
        "array_size": array_size,
        "header_size": header_size,
    }

def decode_base(path, info):
    """
    Decodifica somente o mip 0 com Pillow. Isso evita depender do formato
    interno de cada DDS para calcular offsets dos mipmaps menores.
    """
    try:
        with Image.open(path) as img:
            img.load()

            if img.size != (info["width"], info["height"]):
                raise RuntimeError(
                    f"Pillow decodificou {img.size[0]}x{img.size[1]}, "
                    f"mas o header DDS diz {info['width']}x{info['height']}"
                )

            bands = img.getbands()

            if "A" in bands:
                out = img.convert("RGBA")
            elif img.mode in ("1", "L", "I", "F", "I;16"):
                out = img.convert("L")
            else:
                out = img.convert("RGB")

            return out.copy()
    except Exception as e:
        raise RuntimeError(f"Pillow não conseguiu decodificar o DDS: {e}")


def full_fs23_mip_count(width, height):
    """
    Padrão 2D observado no FS23:
    1024x1024 -> 9 mips ... até 4x4
    512x256   -> 7 mips ... até 8x4
    32x64     -> 4 mips ... até 4x8
    """
    count = 1
    w, h = width, height
    while min(w, h) > 4:
        w = max(1, w // 2)
        h = max(1, h // 2)
        count += 1
    return count


def semantic_kind(path):
    s = str(path).replace("\\", "/").lower()
    name = Path(path).name.lower()
    stem = Path(path).stem.lower()

    if any(k in name for k in ONE_CHANNEL_WORDS):
        return "height"

    if stem.endswith("_alpha") or "_alpha." in name:
        return "alpha_map"

    if "normal" in name:
        return "normal"

    if any(k in name for k in ("vmask", "_fmask", "_mask", "mask_", "mask.")):
        return "mask"

    if any(k in name for k in (
        "specular", "rough", "metal", "metallic", "ao",
        "ambientocclusion", "gloss", "smoothness"
    )):
        return "material"

    if (
        "/mapicons/" in s
        or stem.startswith("mapicon_")
        or stem == "icon"
        or stem.startswith("icon_")
        or stem == "store"
        or stem.startswith("store_")
        or stem == "overview"
    ):
        return "ui_nomip"

    if stem == "preview":
        return "preview"

    return "color"

# Regras exatas medidas da cultura barley no pacote nativo FS23
FOLIAGE_NATIVE_EXACT = {'barleystage01_alpha.dds': (256, 128, 1, 6, 6), 'barleystage01_diffuse.dds': (256, 128, 3, 6, 6), 'barleystage01_fmask.dds': (128, 64, 3, 5, 6), 'barleystage01_normal.dds': (256, 128, 3, 6, 6), 'barleystage01lod1_alpha.dds': (512, 32, 1, 2, 6), 'barleystage01lod1_diffuse.dds': (1024, 64, 3, 2, 6), 'barleystage01lod1_normal.dds': (1024, 64, 3, 2, 6), 'barleystage02_alpha.dds': (512, 256, 1, 6, 6), 'barleystage02_diffuse.dds': (512, 256, 3, 7, 6), 'barleystage02_fmask.dds': (256, 128, 3, 6, 6), 'barleystage02_normal.dds': (512, 256, 3, 7, 6), 'barleystage02lod1_alpha.dds': (512, 32, 1, 2, 6), 'barleystage02lod1_diffuse.dds': (1024, 64, 3, 2, 6), 'barleystage02lod1_normal.dds': (1024, 64, 3, 2, 6), 'barleystage03_alpha.dds': (2048, 1024, 1, 6, 6), 'barleystage03_diffuse.dds': (1024, 512, 3, 8, 6), 'barleystage03_fmask.dds': (512, 256, 3, 7, 6), 'barleystage03_normal.dds': (1024, 512, 3, 8, 6), 'barleystage03lod1_alpha.dds': (512, 64, 1, 2, 6), 'barleystage03lod1_diffuse.dds': (1024, 128, 3, 2, 6), 'barleystage03lod1_normal.dds': (1024, 128, 3, 2, 6), 'barleystage04_alpha.dds': (2048, 1024, 1, 2, 6), 'barleystage04_diffuse.dds': (1024, 512, 3, 8, 6), 'barleystage04_fmask.dds': (512, 256, 3, 7, 6), 'barleystage04_normal.dds': (1024, 512, 3, 8, 6), 'barleystage04lod1_alpha.dds': (512, 64, 1, 2, 6), 'barleystage04lod1_diffuse.dds': (1024, 128, 3, 2, 6), 'barleystage04lod1_normal.dds': (1024, 128, 3, 2, 6), 'barleystage05_alpha.dds': (1024, 512, 1, 6, 6), 'barleystage05_diffuse.dds': (1024, 512, 3, 8, 6), 'barleystage05_fmask.dds': (512, 256, 3, 7, 6), 'barleystage05_normal.dds': (1024, 512, 3, 8, 6), 'barleystage05lod1_alpha.dds': (512, 64, 1, 2, 6), 'barleystage05lod1_diffuse.dds': (1024, 128, 3, 2, 6), 'barleystage05lod1_normal.dds': (1024, 128, 3, 2, 6), 'barleystage06_alpha.dds': (256, 256, 1, 6, 6), 'barleystage06_diffuse.dds': (256, 256, 3, 7, 6), 'barleystage06_fmask.dds': (128, 128, 3, 6, 6), 'barleystage06_normal.dds': (256, 256, 3, 7, 6), 'barleystage06lod1_alpha.dds': (512, 16, 1, 2, 6), 'barleystage06lod1_diffuse.dds': (1024, 32, 3, 2, 6), 'barleystage06lod1_normal.dds': (1024, 32, 3, 2, 6), 'foliage_barley_distance2_diffuse.dds': (128, 128, 4, 6, 6), 'foliage_barley_distance3_diffuse.dds': (128, 128, 4, 6, 6), 'foliage_barley_distance4_diffuse.dds': (128, 128, 4, 6, 6), 'foliage_barley_distance5_diffuse.dds': (128, 128, 4, 6, 6), 'foliage_barley_distance6_diffuse.dds': (128, 128, 4, 6, 6)}

# Catálogo exato extraído do pacote FS23 analisado em 06/09/2026.
# Tupla: (largura, altura, componentes/formato_raw, quantidade_de_mips, perfil).
# Apenas AST 2D comuns entram aqui; arrays DX10 continuam no caminho dedicado.
NATIVE_PROFILE_CATALOG = {'effects/smoke/industrial/smoke6x6_diffuse.dds': (512, 512, 4, 8, 6),
 'effects/smoke/industrial/smoke6x6_lightmap.dds': (512, 512, 4, 8, 6),
 'effects/smoke/smoke6x6_diffuse.dds': (512, 512, 4, 8, 6),
 'effects/smoke/smoke6x6_normal.dds': (512, 512, 3, 8, 6),
 'fillplanes/distance/soybeandistance_diffuse.dds': (128, 128, 4, 6, 6),
 'fillplanes/soybean_diffuse.dds': (256, 256, 4, 7, 6),
 'fillplanes/soybean_normal.dds': (256, 256, 3, 7, 6),
 'fillplanes/soybean_specular.dds': (256, 256, 3, 7, 6),
 'foliage/soybean/distance/foliage_soybean_distance2_diffuse.dds': (128, 128, 4, 6, 6),
 'foliage/soybean/distance/foliage_soybean_distance3_diffuse.dds': (128, 128, 4, 6, 6),
 'foliage/soybean/distance/foliage_soybean_distance4_diffuse.dds': (128, 128, 4, 6, 6),
 'foliage/soybean/distance/foliage_soybean_distance5_diffuse.dds': (128, 128, 4, 6, 6),
 'foliage/soybean/distance/foliage_soybean_distance6_diffuse.dds': (128, 128, 4, 6, 6),
 'foliage/soybean/soybean_alpha.dds': (2048, 1024, 1, 6, 6),
 'foliage/soybean/soybean_diffuse.dds': (2048, 1024, 3, 9, 6),
 'foliage/soybean/soybean_normal.dds': (1024, 512, 3, 8, 6),
 'foliage/soybean/soybeanstage01_alpha.dds': (512, 256, 1, 6, 6),
 'foliage/soybean/soybeanstage01_diffuse.dds': (512, 256, 3, 7, 6),
 'foliage/soybean/soybeanstage01_fmask.dds': (256, 128, 3, 6, 6),
 'foliage/soybean/soybeanstage01_normal.dds': (512, 256, 3, 7, 6),
 'foliage/soybean/soybeanstage01lod1_alpha.dds': (512, 32, 1, 2, 6),
 'foliage/soybean/soybeanstage01lod1_diffuse.dds': (1024, 64, 3, 2, 6),
 'foliage/soybean/soybeanstage01lod1_normal.dds': (1024, 64, 3, 2, 6),
 'foliage/soybean/soybeanstage02_alpha.dds': (1024, 512, 1, 6, 6),
 'foliage/soybean/soybeanstage02_diffuse.dds': (1024, 512, 3, 8, 6),
 'foliage/soybean/soybeanstage02_fmask.dds': (512, 256, 3, 7, 6),
 'foliage/soybean/soybeanstage02_normal.dds': (1024, 512, 3, 8, 6),
 'foliage/soybean/soybeanstage02lod1_alpha.dds': (512, 32, 1, 2, 6),
 'foliage/soybean/soybeanstage02lod1_diffuse.dds': (1024, 64, 3, 2, 6),
 'foliage/soybean/soybeanstage02lod1_normal.dds': (1024, 64, 3, 2, 6),
 'foliage/soybean/soybeanstage03_alpha.dds': (1024, 512, 1, 6, 6),
 'foliage/soybean/soybeanstage03_diffuse.dds': (1024, 512, 3, 8, 6),
 'foliage/soybean/soybeanstage03_fmask.dds': (512, 256, 3, 7, 6),
 'foliage/soybean/soybeanstage03_normal.dds': (1024, 512, 3, 8, 6),
 'foliage/soybean/soybeanstage03lod1_alpha.dds': (512, 64, 1, 2, 6),
 'foliage/soybean/soybeanstage03lod1_diffuse.dds': (1024, 128, 3, 2, 6),
 'foliage/soybean/soybeanstage03lod1_normal.dds': (1024, 128, 3, 2, 6),
 'foliage/soybean/soybeanstage04_alpha.dds': (1024, 512, 1, 6, 6),
 'foliage/soybean/soybeanstage04_diffuse.dds': (1024, 512, 3, 8, 6),
 'foliage/soybean/soybeanstage04_fmask.dds': (512, 256, 3, 7, 6),
 'foliage/soybean/soybeanstage04_normal.dds': (1024, 512, 3, 8, 6),
 'foliage/soybean/soybeanstage04lod1_alpha.dds': (512, 64, 1, 2, 6),
 'foliage/soybean/soybeanstage04lod1_diffuse.dds': (1024, 128, 3, 2, 6),
 'foliage/soybean/soybeanstage04lod1_normal.dds': (1024, 128, 3, 2, 6),
 'foliage/soybean/soybeanstage05_alpha.dds': (1024, 512, 1, 6, 6),
 'foliage/soybean/soybeanstage05_diffuse.dds': (1024, 512, 3, 8, 6),
 'foliage/soybean/soybeanstage05_fmask.dds': (512, 256, 3, 7, 6),
 'foliage/soybean/soybeanstage05_normal.dds': (1024, 512, 3, 8, 6),
 'foliage/soybean/soybeanstage05lod1_alpha.dds': (512, 64, 1, 2, 6),
 'foliage/soybean/soybeanstage05lod1_diffuse.dds': (1024, 128, 3, 2, 6),
 'foliage/soybean/soybeanstage05lod1_normal.dds': (1024, 128, 3, 2, 6),
 'foliage/soybean/soybeanstage06lod1_alpha.dds': (512, 8, 1, 2, 6),
 'foliage/soybean/soybeanstage06lod1_diffuse.dds': (1024, 16, 3, 2, 6),
 'foliage/soybean/soybeanstage06lod1_normal.dds': (1024, 16, 3, 2, 6),
 'maps/map/textures/animaltrader_diffuse.dds': (256, 1024, 3, 7, 6),
 'maps/map/textures/animaltrader_height.dds': (256, 1024, 1, 7, 6),
 'maps/map/textures/props/airconditionusa_a_diffuse.dds': (256, 256, 3, 7, 6),
 'maps/map/textures/props/airconditionusa_a_normal.dds': (256, 256, 3, 7, 6),
 'maps/map/textures/props/airconditionusa_a_specular.dds': (256, 256, 3, 7, 6),
 'maps/map/textures/props/airconditionusa_alpha_diffuse.dds': (32, 64, 4, 4, 6),
 'maps/map/textures/props/airconditionusa_alpha_normal.dds': (32, 64, 3, 4, 6),
 'maps/map/textures/props/airconditionusa_alpha_specular.dds': (32, 64, 3, 4, 6),
 'maps/map/textures/props/airconditionusa_b_diffuse.dds': (256, 256, 3, 7, 6),
 'maps/map/textures/props/airconditionusa_b_normal.dds': (256, 256, 3, 7, 6),
 'maps/map/textures/props/airconditionusa_b_specular.dds': (256, 256, 3, 7, 6),
 'maps/map/textures/props/airconditionusa_c_diffuse.dds': (256, 256, 3, 7, 6),
 'maps/map/textures/props/airconditionusa_c_normal.dds': (256, 256, 3, 7, 6),
 'maps/map/textures/props/airconditionusa_c_specular.dds': (256, 256, 3, 7, 6),
 'maps/map/textures/props/airpump01_diffuse.dds': (128, 64, 3, 5, 6),
 'maps/map/textures/props/airpump01_normal.dds': (128, 64, 3, 5, 6),
 'maps/map/textures/props/airpump01_specular.dds': (128, 64, 3, 5, 6),
 'maps/map/textures/props/alpsfence02_diffuse.dds': (256, 64, 3, 5, 6),
 'maps/map/textures/props/alpsfence02_normal.dds': (256, 64, 3, 5, 6),
 'maps/map/textures/props/alpsfence02_specular.dds': (256, 64, 3, 5, 6),
 'maps/map/textures/props/alpsfence05_diffuse.dds': (128, 128, 4, 6, 6),
 'maps/map/textures/props/alpsfence05_normal.dds': (128, 128, 3, 6, 6),
 'maps/map/textures/props/alpsfence05_specular.dds': (128, 128, 3, 6, 6),
 'maps/map/textures/props/alpsroadfence01_diffuse.dds': (512, 256, 3, 7, 6),
 'maps/map/textures/props/alpsroadfence01_normal.dds': (512, 256, 3, 7, 6),
 'maps/map/textures/props/alpsroadfence01_specular.dds': (512, 256, 3, 7, 6),
 'maps/map/textures/props/alpsroadfence02_diffuse.dds': (256, 64, 3, 5, 6),
 'maps/map/textures/props/alpsroadfence02_normal.dds': (256, 64, 3, 5, 6),
 'maps/map/textures/props/alpsroadfence02_specular.dds': (256, 64, 3, 5, 6),
 'maps/map/textures/props/auxialiaryset_diffuse.dds': (1024, 512, 3, 8, 6),
 'maps/map/textures/props/auxialiaryset_normal.dds': (1024, 512, 3, 8, 6),
 'maps/map/textures/props/auxialiaryset_specular.dds': (1024, 512, 3, 8, 6),
 'maps/map/textures/props/auxiliarydecals01_diffuse.dds': (256, 256, 4, 7, 6),
 'maps/map/textures/props/barrelsset_diffuse.dds': (512, 256, 3, 7, 6),
 'maps/map/textures/props/barrelsset_normal.dds': (512, 256, 3, 7, 6),
 'maps/map/textures/props/barrelsset_specular.dds': (512, 256, 3, 7, 6),
 'maps/map/textures/props/barricadebig_diffuse.dds': (256, 256, 3, 7, 6),
 'maps/map/textures/props/barricadebig_normal.dds': (256, 256, 3, 7, 6),
 'maps/map/textures/props/barricadebig_specular.dds': (256, 256, 3, 7, 6),
 'maps/map/textures/props/barricadelight_diffuse.dds': (128, 128, 3, 6, 6),
 'maps/map/textures/props/barricadelight_normal.dds': (128, 128, 3, 6, 6),
 'maps/map/textures/props/barricadelight_specular.dds': (128, 128, 3, 6, 6),
 'maps/map/textures/props/basketballstand_diffuse.dds': (256, 256, 3, 7, 6),
 'maps/map/textures/props/basketballstand_normal.dds': (256, 256, 3, 7, 6),
 'maps/map/textures/props/basketballstand_specular.dds': (256, 256, 3, 7, 6),
 'maps/map/textures/props/basketballstandnet_diffuse.dds': (16, 64, 4, 3, 6),
 'maps/map/textures/props/basketballstandnet_normal.dds': (16, 64, 3, 3, 6),
 'maps/map/textures/props/basketballstandnet_specular.dds': (16, 64, 3, 3, 6),
 'maps/map/textures/props/beachandelectricitydecals_diffuse.dds': (128, 128, 4, 6, 6),
 'maps/map/textures/props/birdhouse_diffuse.dds': (64, 64, 3, 5, 6),
 'maps/map/textures/props/birdhouse_normal.dds': (64, 64, 3, 5, 6),
 'maps/map/textures/props/birdhouse_specular.dds': (64, 64, 3, 5, 6),
 'maps/map/textures/props/cablestraightventilator_diffuse.dds': (256, 128, 3, 6, 6),
 'maps/map/textures/props/cablestraightventilator_normal.dds': (256, 128, 3, 6, 6),
 'maps/map/textures/props/cablestraightventilator_specular.dds': (256, 128, 3, 6, 6),
 'maps/map/textures/props/cablestraightventilatorgrid_diffuse.dds': (32, 32, 4, 4, 6),
 'maps/map/textures/props/cablestraightventilatorgrid_specular.dds': (32, 32, 3, 4, 6),
 'maps/map/textures/props/ceilinglamp02_diffuse.dds': (64, 128, 3, 5, 6),
 'maps/map/textures/props/ceilinglamp02_normal.dds': (64, 128, 3, 5, 6),
 'maps/map/textures/props/ceilinglamp02_specular.dds': (64, 128, 3, 5, 6),
 'maps/map/textures/props/cellularantenna_diffuse.dds': (256, 512, 3, 7, 6),
 'maps/map/textures/props/cellularantenna_normal.dds': (256, 512, 3, 7, 6),
 'maps/map/textures/props/cellularantenna_specular.dds': (256, 512, 3, 7, 6),
 'maps/map/textures/props/chimney01_diffuse.dds': (128, 128, 3, 6, 6),
 'maps/map/textures/props/chimney01_normal.dds': (128, 128, 3, 6, 6),
 'maps/map/textures/props/chimney01_specular.dds': (128, 128, 3, 6, 6),
 'maps/map/textures/props/chimney01grid_diffuse.dds': (32, 16, 4, 3, 6),
 'maps/map/textures/props/chimney01grid_normal.dds': (32, 16, 3, 3, 6),
 'maps/map/textures/props/chimney01grid_specular.dds': (32, 16, 3, 3, 6),
 'maps/map/textures/props/chimney04_diffuse.dds': (256, 256, 3, 7, 6),
 'maps/map/textures/props/chimney04_normal.dds': (256, 256, 3, 7, 6),
 'maps/map/textures/props/chimney04_specular.dds': (256, 256, 3, 7, 6),
 'maps/map/textures/props/chimneypipe01_diffuse.dds': (64, 64, 3, 5, 6),
 'maps/map/textures/props/chimneypipe01_normal.dds': (64, 64, 3, 5, 6),
 'maps/map/textures/props/chimneypipe01_specular.dds': (64, 64, 3, 5, 6),
 'maps/map/textures/props/chimneypipe02_diffuse.dds': (32, 128, 3, 4, 6),
 'maps/map/textures/props/chimneypipe02_normal.dds': (32, 128, 3, 4, 6),
 'maps/map/textures/props/chimneypipe02_specular.dds': (32, 128, 3, 4, 6),
 'maps/map/textures/props/chimneypipe03_diffuse.dds': (64, 256, 3, 5, 6),
 'maps/map/textures/props/chimneypipe03_normal.dds': (64, 256, 3, 5, 6),
 'maps/map/textures/props/chimneypipe03_specular.dds': (64, 256, 3, 5, 6),
 'maps/map/textures/props/clock_diffuse.dds': (256, 128, 3, 6, 6),
 'maps/map/textures/props/clock_normal.dds': (256, 128, 3, 6, 6),
 'maps/map/textures/props/clock_specular.dds': (256, 128, 3, 6, 6),
 'maps/map/textures/props/clockglass_diffuse.dds': (64, 64, 4, 5, 6),
 'maps/map/textures/props/clockglass_specular.dds': (64, 64, 3, 5, 6),
 'maps/map/textures/props/doublebenchtable_diffuse.dds': (256, 256, 3, 7, 6),
 'maps/map/textures/props/doublebenchtable_normal.dds': (256, 256, 3, 7, 6),
 'maps/map/textures/props/doublebenchtable_specular.dds': (256, 256, 3, 7, 6),
 'maps/map/textures/props/electricalmeter_diffuse.dds': (256, 128, 3, 6, 6),
 'maps/map/textures/props/electricalmeter_normal.dds': (256, 128, 3, 6, 6),
 'maps/map/textures/props/electricalmeter_specular.dds': (256, 128, 3, 6, 6),
 'maps/map/textures/props/electricbox_diffuse.dds': (256, 128, 3, 6, 6),
 'maps/map/textures/props/electricbox_normal.dds': (256, 128, 3, 6, 6),
 'maps/map/textures/props/electricbox_specular.dds': (256, 128, 3, 6, 6),
 'maps/map/textures/props/electricitybox03_diffuse.dds': (512, 512, 3, 8, 6),
 'maps/map/textures/props/electricitybox03_normal.dds': (512, 512, 3, 8, 6),
 'maps/map/textures/props/electricitybox03_specular.dds': (512, 512, 3, 8, 6),
 'maps/map/textures/props/electricityshed_diffuse.dds': (512, 512, 3, 8, 6),
 'maps/map/textures/props/electricityshed_normal.dds': (512, 512, 3, 8, 6),
 'maps/map/textures/props/electricityshed_specular.dds': (512, 512, 3, 8, 6),
 'maps/map/textures/props/emptyroom_diffuse.dds': (128, 128, 3, 6, 6),
 'maps/map/textures/props/emptyroom_mask.dds': (256, 256, 3, 7, 6),
 'maps/map/textures/props/emptyroom_normal.dds': (256, 256, 3, 7, 6),
 'maps/map/textures/props/emptyroom_specular.dds': (128, 128, 3, 6, 6),
 'maps/map/textures/props/faucet_diffuse.dds': (128, 64, 3, 5, 6),
 'maps/map/textures/props/faucet_normal.dds': (128, 64, 3, 5, 6),
 'maps/map/textures/props/faucet_specular.dds': (128, 64, 3, 5, 6),
 'maps/map/textures/props/flagpoleshort_diffuse.dds': (256, 256, 3, 7, 6),
 'maps/map/textures/props/flagpoleshort_normal.dds': (256, 256, 3, 7, 6),
 'maps/map/textures/props/flagpoleshort_specular.dds': (256, 256, 3, 7, 6),
 'maps/map/textures/props/garbagecartblack_diffuse.dds': (1024, 512, 3, 8, 6),
 'maps/map/textures/props/garbagecartblack_normal.dds': (512, 256, 3, 7, 6),
 'maps/map/textures/props/garbagecartblack_specular.dds': (512, 256, 3, 7, 6),
 'maps/map/textures/props/garbagecartblackdecal_diffuse.dds': (128, 128, 4, 6, 6),
 'maps/map/textures/props/garbagecartgreen_diffuse.dds': (512, 256, 3, 7, 6),
 'maps/map/textures/props/garbagecartgreen_normal.dds': (256, 128, 3, 6, 6),
 'maps/map/textures/props/garbagecartgreen_specular.dds': (256, 128, 3, 6, 6),
 'maps/map/textures/props/garbagecartgreendecal_diffuse.dds': (64, 64, 4, 5, 6),
 'maps/map/textures/props/gasbox01_diffuse.dds': (64, 128, 3, 5, 6),
 'maps/map/textures/props/gasbox01_normal.dds': (64, 128, 3, 5, 6),
 'maps/map/textures/props/gasbox01_specular.dds': (64, 128, 3, 5, 6),
 'maps/map/textures/props/gasmeterus_diffuse.dds': (256, 256, 3, 7, 6),
 'maps/map/textures/props/gasmeterus_normal.dds': (256, 256, 3, 7, 6),
 'maps/map/textures/props/gasmeterus_specular.dds': (256, 256, 3, 7, 6),
 'maps/map/textures/props/hangingflowerpots_diffuse.dds': (64, 64, 4, 5, 6),
 'maps/map/textures/props/hangingflowerpots_normal.dds': (64, 64, 3, 5, 6),
 'maps/map/textures/props/hangingflowerpots_specular.dds': (64, 64, 3, 5, 6),
 'maps/map/textures/props/industrialwalllight_diffuse.dds': (128, 256, 3, 6, 6),
 'maps/map/textures/props/industrialwalllight_normal.dds': (128, 256, 3, 6, 6),
 'maps/map/textures/props/industrialwalllight_specular.dds': (128, 256, 3, 6, 6),
 'maps/map/textures/props/lightwarm_emissive.dds': (16, 16, 3, 3, 6),
 'maps/map/textures/props/plasticbarrier2m_diffuse.dds': (512, 256, 3, 7, 6),
 'maps/map/textures/props/plasticbarrier2m_normal.dds': (512, 256, 3, 7, 6),
 'maps/map/textures/props/plasticbarrier2m_specular.dds': (512, 256, 3, 7, 6),
 'maps/map/textures/props/propsdecals_diffuse.dds': (512, 512, 4, 8, 6),
 'maps/map/textures/props/propsdecals_specular.dds': (32, 32, 3, 4, 6),
 'maps/map/textures/props/propsdecalsus_diffuse.dds': (128, 128, 4, 6, 6),
 'maps/map/textures/props/signgrocerymart01_normal.dds': (512, 256, 3, 7, 6),
 'maps/map/textures/props/signgrocerymart01_specular.dds': (512, 256, 3, 7, 6),
 'maps/map/textures/props/stormlamps_diffuse.dds': (128, 128, 3, 6, 6),
 'maps/map/textures/props/stormlamps_normal.dds': (128, 128, 3, 6, 6),
 'maps/map/textures/props/stormlamps_specular.dds': (128, 128, 3, 6, 6),
 'maps/map/textures/props/stormlampsglass_diffuse.dds': (32, 32, 4, 4, 6),
 'maps/map/textures/props/stormlampsglass_normal.dds': (32, 32, 3, 4, 6),
 'maps/map/textures/props/stormlampsglass_specular.dds': (32, 32, 4, 4, 6),
 'maps/map/textures/props/streetlanternset_diffuse.dds': (128, 256, 3, 6, 6),
 'maps/map/textures/props/streetlanternset_normal.dds': (128, 256, 3, 6, 6),
 'maps/map/textures/props/streetlanternset_specular.dds': (128, 256, 4, 6, 6),
 'maps/map/textures/props/teardropbanner01_normal.dds': (64, 256, 3, 5, 6),
 'maps/map/textures/props/teardropbanner01_specular.dds': (64, 256, 3, 5, 6),
 'maps/map/textures/props/teardropbanner_diffuse.dds': (64, 256, 3, 5, 6),
 'maps/map/textures/props/ventilationpipe01_diffuse.dds': (512, 256, 3, 7, 6),
 'maps/map/textures/props/ventilationpipe01_normal.dds': (512, 256, 3, 7, 6),
 'maps/map/textures/props/ventilationpipe01_specular.dds': (512, 256, 3, 7, 6),
 'maps/map/textures/props/waterbarrelrack_diffuse.dds': (256, 256, 3, 7, 6),
 'maps/map/textures/props/waterbarrelrack_normal.dds': (256, 256, 3, 7, 6),
 'maps/map/textures/props/waterbarrelrack_specular.dds': (128, 128, 3, 6, 6),
 'maps/map/textures/props/watercontainer_diffuse.dds': (128, 128, 3, 6, 6),
 'maps/map/textures/props/watercontainer_normal.dds': (128, 128, 3, 6, 6),
 'maps/map/textures/props/watercontainer_specular.dds': (128, 128, 3, 6, 6),
 'maps/map/textures/props/watertank01_diffuse.dds': (512, 128, 3, 6, 6),
 'maps/map/textures/props/watertank01_normal.dds': (512, 128, 3, 6, 6),
 'maps/map/textures/props/watertank01_specular.dds': (512, 128, 3, 6, 6),
 'maps/map/textures/props/watertank02_diffuse.dds': (512, 256, 3, 7, 6),
 'maps/map/textures/props/watertank02_normal.dds': (512, 256, 3, 7, 6),
 'maps/map/textures/props/watertank02_specular.dds': (512, 256, 3, 7, 6),
 'maps/map/textures/terrain/animalmud01_diffuse.dds': (256, 256, 4, 7, 6),
 'maps/map/textures/terrain/animalmud01_height.dds': (128, 128, 1, 6, 6),
 'maps/map/textures/terrain/ground/distance/cultivated_distance_diffuse.dds': (128, 128, 4, 6, 6),
 'maps/map/textures/terrain/ground/distance/directsown_distance_diffuse.dds': (128, 128, 4, 6, 6),
 'maps/map/textures/terrain/ground/groundtype_cultivated_diffuse.dds': (256, 256, 4, 7, 6),
 'maps/map/textures/terrain/ground/groundtype_cultivated_height.dds': (128, 128, 1, 6, 6),
 'maps/textures/terrain/terrainnoise.dds': (512, 512, 1, 8, 6),
 'maps/trees/americanelm/americanelm_diffuse.dds': (512, 1024, 3, 8, 6),
 'maps/trees/americanelm/americanelm_mask.dds': (256, 512, 3, 3, 6),
 'maps/trees/americanelm/americanelm_normal.dds': (256, 512, 3, 7, 6),
 'maps/trees/americanelm/americanelm_specular.dds': (256, 512, 3, 7, 6),
 'maps/trees/americanelm/americanelmstage04lod_diffuse.dds': (1024, 128, 3, 1, 6),
 'maps/trees/americanelm/americanelmstage04lod_mask.dds': (2048, 256, 3, 1, 4),
 'maps/trees/americanelm/americanelmstage04lod_normal.dds': (1024, 128, 3, 1, 6),
 'maps/trees/americanelm/americanelmtrunk_diffuse.dds': (64, 1024, 3, 5, 6),
 'maps/trees/americanelm/americanelmtrunk_normal.dds': (64, 1024, 3, 5, 6),
 'maps/trees/mud_diffuse.dds': (128, 128, 3, 6, 6),
 'maps/trees/mud_normal.dds': (128, 128, 3, 6, 6),
 'maps/trees/mud_specular.dds': (128, 128, 3, 6, 6),
 'maps/trees/pine/pine1lod_diffuse.dds': (256, 64, 4, 4, 6),
 'maps/trees/pine/pine1lod_normal.dds': (256, 64, 3, 2, 6),
 'maps/trees/pine/pine2lod_diffuse.dds': (1024, 128, 4, 5, 6),
 'maps/trees/pine/pine2lod_normal.dds': (1024, 128, 3, 2, 6),
 'maps/trees/pine/pine3lod_diffuse.dds': (1024, 128, 4, 5, 6),
 'maps/trees/pine/pine3lod_normal.dds': (1024, 128, 3, 2, 6),
 'maps/trees/pine/pine4lod_diffuse.dds': (1024, 128, 4, 4, 6),
 'maps/trees/pine/pine4lod_normal.dds': (1024, 128, 3, 2, 6),
 'maps/trees/pine/pine5lod_diffuse.dds': (1024, 256, 4, 4, 6),
 'maps/trees/pine/pine5lod_normal.dds': (1024, 256, 3, 2, 6),
 'maps/trees/pine/pine6lod_diffuse.dds': (1024, 256, 4, 4, 6),
 'maps/trees/pine/pine6lod_normal.dds': (1024, 256, 3, 2, 6),
 'maps/trees/pine/pinebranch_diffuse.dds': (512, 512, 4, 5, 6),
 'maps/trees/pine/pinebranch_normal.dds': (512, 512, 3, 8, 6),
 'maps/trees/pine/pinetrunk_diffuse.dds': (128, 2048, 3, 6, 6),
 'maps/trees/pine/pinetrunk_normal.dds': (128, 2048, 3, 6, 6)}

NATIVE_CATALOG_TOPS = ("effects", "fillplanes", "foliage", "maps")

# Catálogo complementar V11, extraído dos 703 AST GS2D v6 da pasta textures
# nativa fornecida em 07/09/2026. O conteúdo é armazenado de forma compacta
# para manter este conversor em um único arquivo. Cada entrada é:
# caminho relativo sob textures -> (largura, altura, componentes, mips, perfil).
MAP_TEXTURE_NATIVE_CATALOG_B85 = b"c-pm{+j6AH5r*GouN9tc=+;Vp6^BDn4W({EG~fcHksW?_7sswck_TG8(9G<{_d{lpm32zcfBsNaaZ_byRIbfiUcA5et^Qk{w}1ToAIa(Y>F{TAd`h4GdV2onlh0mtak+LOdVtWIYCmT1bV#0tpY-V^=BnD*|6tv{ZFJU`%5Y%SXI)WOS5=l04_z7GSy#pM+m-N}z*R|F<E%_2X@-&K`#<7L$48d$@rX-Y&2^?q1v#6%JRP5&VZj*?3_t4~+U7b4YL&MEI<?AV&g%%DRrc{-)?a<w>W;Xu&qnRCjRI}r!CGZkRpq+WS!ar@=)OlsBkOIexGi%oYWpDDrvB2VDOJ_|d7uIZlHjoeDUk4ia6Ez_1r<cGCXsudh&@kao+o0@6WVhdA0J;fr$o<siH>xM4u|v{UBCkXdImq+KpXCSim<@S0PKr0FRIHF!(dDfKgY$R5XU=KNK<{w<1ePKE?Q*JED;zrD@2BwzU@S2jRJvDBQG-PtFCjANuxku(#R7gW$Ik&)+YZUem`~96{YHGvoT~Wp}(byyCXvc^+;NFF-6#Vsm&FMZM!3>3vM|H(^Yu0lMAr>JDqT)JfF9q;D!-q@?5J@o1y!+#U-4d`2BytN17gvTog~nE{P;z7sHdUOHxVq&L(`161GPP&!dFxQNs5KoM;U9cl-HDU+k0yR1Ea<5ZXZq0Ku|cd^JTErOgSYx;0Vr+DlG-?F69VShY>Y!<EmLD@*k%4@J9{M-u((THGrA9eE#)=yxu<GmHVZ1wlGld8BvuAUSy;p2ueN$n^Ti^ZLm3`oz5NiFe-<_rA~6;I(r2aJ6F805yS4(da0=gT(ET$W+h=(aE5TCUJ~Sh8_Vl46<!9j<PK_joqIz(Fs69|F_Aw0X(*>vkxMzj0l=eMuJEq17kBz+v0usj^X{Yt}>%L-M8SV=cRBLjYhpOAR!X(S1w6)t-2nP?YaI<^{qRIcdk1}^)6Glt+lnXOLvR+EtORw9&d#RCz>L!YqPPHG0iIe^0BBHKniFCms>V2RC%*cjGCQ?H2Ne$n0OouPKSa^vMgW(gR_CtUUd#keB7B`NPAXLa9~M<-<s~*)b))B$2*6H;T<Ew?_HVOunkC0lpPYECp#cAO?D`Jmh6DkB>9dOm5sfkHhia61=pHYz_#khw&uucxg*!sBg;lR`M)Xip}VGz_BNof@p&{HW1JC|7iH8%<IBf^yVllDE|yYQTa-1u4t7YoGt40G#`GhdLCzx`(S+?x!gVHLIg@am;q>f2i^j-dDs`X!%t$y3jEQ*m=Q4%S`gdpN5`AIwwu#53U=jxju!$kW<I_Yy0ZkeY&(owa#YN%0o+s~TRaw`0tE)E3oKXjLNWAMiAkpb<hd<jMpDELwOBKz*!+nSdM`r~QO-v0!e%wU?S7XZ_ileyL#;^G1PdL~7iRPO>@_h5_s#8U!P2Vyda0Jneh~R-qk*{dab=Q^JMsWE~%nt*YXibkL+tQ_hy_c{dBOF<p12nomANk+V#(=v;wo=%h+X~^^Z5A7+@_kFJDjg6#Rd6`sG{KThKkf*sdNXM(2x;8RQMSz(&otg$S@&e#(e|IVF7-IWr@KU?p!!85pgYGP;pCSQw2P8=GO^rABBR_vI+e7Y8tXgyj=sOcQWiKU+lKa9H^gEyfbof00HX`jfF;(YK3xt*Fw#IQp*ldUpn8L`gNU76^yXFohwIS{GUACA4RK_`8?pGbH^QmOZy-p7t|kK86PfLa)b><pdn&L!mD!#OZQrbY+Kx)F`e~lsFKO|rs*9ba54A_yG<DRw{3IIF$kZZ+(V4}yHm$bFw4pk<1ESs9;fT&$RC(WarcmX$gGr>ukVey82ow44j!)YUTlT=#yBc)dfF;EEaTg88`eT~JXMvCan-D@gJ~wm}_Mi0^6*@7GMo^5Cf%I;aRrFcc8+}v8b^vOJAJ(9YT3A9XZ*P6s6-}wWwV8H4E)~^Wb(!-vXYU|9ti>FXSMLy>Q12X-NgHK8;(1rtKnsO7{Q?n<J*J&ssxWpgn-{~>qHon3mA<!BXpnA+h)~^-mCaSf$ARMza3po%8SI$dX<2-%ND9xpTJpT7CC~d>GTUWgw#UMZZQ;1KBx+Vd7~4$@S$rpPrpu;%*Hxy$w1VPM+n_YiC<uQdil<{9&l3^O%NSNL6rxX}12OW$8g%4`CB(=NiP#U%mGB;*t6)9E{<j^X3uV6JgY0n}a7PzN;y+1_B7B(Jno+_mZJtziP&2v&4&~v;;^2%Y@6fD=KJZ1Ra(yl?tc>Of7|G1zS$S+#KvPh-TLltE&kYo;&U?0V8r_|Tn%7QMIkUNZ4Xed`3A52WQ5AQTxgayeMSj!GosrPQXFjoN=PNC<x-j{8zKWKsg)Fjk4N-LAI>GxY&v7lfS&B=EZBtZCmUq%>v{G!A^Xqsa0k)8YczhwbD9UnRRMqLKQbbJ@tU(K;U<pwzHH+r@%>ygp-DyUyyThzBx8iV|9G-(L;`33R=5vq=d>km&+!7pF33sDBn1WeJmR~vx@nk*{l+nflqL>yEU?sH>j~CX)3ZlFg5@1EP5RaGI&I+L5b|YWLb+;JE%fVY!xc<&-1T!9gUiUUbpY2Tg+6}py)juK;qnkt;R&SA2fx;Tbvk+E<`Xah6H0A|1F=|A8ft?o(XXYufMZF<Hcd9ou#D;aGVidB%8kupNqSjf&ENu;GXNPhle&JeJ3TBP5V8I!<odVUJVIXIV=Dk#xrXFfSYSXc@hOc0>hc95|3!*-2V-1d%X~BzLs#uGsf@%`r^^34{YeU4yJJK>PSVb3GEILlDP{7jjdS>0w3iGOmBAgM#{7RyUmmRilX~=n^@Zfb4(WiSu<4!(36S^oF@nk@1iiIQkrOfS3--@;^KAjDWXlc;csZwW$*<mwBo8-poSdoa4F(M5sV~l@pzEL~;9KBrT@{AR>gZI3Rl;KeDV(Ltr@0;!Iyv^iT#B#pv?4^grdCMA@9h|YGb!gUjd*|sF;$Q{xk}E6#A7FS7n{K<|OCQ=)t>$&eNW|!kk!GVS`q9#9Wpewkv#P524SH~`6-hV?G+)G7G%mYQMO}f5aX2Dl6(jm%5i9z?R5yMA$>`E3aQR7V7$a0DVReR4wAM+pdS@VE^w2=TH>^|D2lzm7K6;cm4m?Cmkgx*G<r$&n;+&vjrh21_a{SnpO-R!lPIUPqsKHAZK?z>b0ZORi4nUOba3_(wlgQmk_PCSoa3__!lgiym<?euWjA3_&RcGS(G*Hbis^P`68=7Q?CdD<k#+#@vd*nua4hgW%J~j@oz0c42bbM}&z|fJkk6TajVKh_a@=hZacd>$qx>$g<SxgfV8Vkty3?+%!=|t*uB62#BI-SU!PQ^~AQm0dq)2Y<yRPOXq?DSFU^ikyWQR?(j?(|9Q^hxUUN#yiN>hwwO^o!W(7pc=PBBx)ZPQS>Veib|YDs}o*<n*i5=~uDShd-rGTZPPND-bwsX_?bjKss%w9%obJ7dUUb%K{I@%yv0+S?Q6)rl-Rm`Gy8bb}{u3n|frrbY#0kp7Xcri+&+%ff5dsG9b>Eu3Z!lIhUkjZDt!)>5};FvWKE)5i>bYpP7y=G|RUICfyshF4wpJ;0dp5c!=X}hBR^567bX;#SxAMc|=oz?(->r6dBRjabyJJN0L6?-r~Lxt{x!;x+4V%hz+ShQh!yzM@uo1v|<4ncb{HKQu!w%Xzwf;v3HaV*RsA>{cYAZ-vcVZiEs^QGF*M0EMWu%$R0k(qh~O_V%QsoE4saW4{FfL2v|Z?MzlqB`O;-p-!yeR>!aA|tWV;Hv+Tnk?y(R5z(;b_BRJ#{9q+V#qs{a=s<Tnm@QrICGDK%B!c!K>`AVnF@Q(4X>9;K0`kZ{J0aBpfmxlysvWNwV*rr5kQzEq~72A|bZAzIoO~3Gh|KwJlXU~d@tVx8{Br<CfnKh}<np9>D^GW4};XkGsX4x^bEF&()<}<bx3(YcPfdzIXB0Ca^9f`z_RAfggu_G1OVgLBlrR?df8oo`dgln15D49KSQxcgeiO7^hWJ)SCB^8;%4xPHMa+?K)ceFD7D;vHI@Tt17ba(oH#3Az5m26_sS=ZWi%+FovT^l>SE&lzub?cSPqgNVx#gAMh8$V3&BiH%4h8nN<bC<g+^EtdKrd9s^lh^wHSXg)0#{(p~;Lq7w7B~I)HU8BX`At>5dH7m4WxdL-b<;fFY(Hbs@K)m2;}_}A=Th5;R!-ZLKX|o=gJJrs`)>4`m%Mo+3vvnOXoFlqG6FeQ@J5b(ZaA0N>4tNKoo*}x!#)ot^-kj_@gsI;efOB@!v!9(KI^-^4g_P&J}113>~zGt#t%5N3`dW9G+pTj+?p=5)3@<g7e0`z7X3~?7Wr=L>#v85ALYAkAJsceAI~^<TRy3G8a|2l+Fh5WHf2%i{fX7R#$F$sOYHQd)jB^v5Iu{2rw5CCul0|N&5w-AkBrCBEN-Xy{$=($;$KDLQrj5y{pKxT1)fA|i35>XZuh)o5nDX!<hG8oJyv>)q8-*c`aM=Va=G=vGE8i}r<Ysr$@f^lx7ByI_wJTnmX~5vC!yTZNyjquW@W=WHAC4qdj~cUu?!3}a^sRc#w9z9OLiES?lCUiVH|VEcK*Ani^!ydkG|>O9eJ31C-J-6<*=cD70QaCFEy<c@h+2%_4b;nil_`&F|;mVrHHD4Pkk-2@pA;t@GE1ex85QgH6o(<#+3E>{7rm_D#FokP(?KH`KhTOXe?@oYn{edSq}57EIt{2Db9I0d;Xeo)|;Ul&}WM=k49~b6V*erV8h2?BQAi^2OqG+W1s2aD<R8ocWZO?O>|~RRROQ>hp&_mzfQfWO?D*;x9%L?=qrXc_J98eP~e&W"


def _load_map_texture_native_catalog():
    raw = zlib.decompress(base64.b85decode(MAP_TEXTURE_NATIVE_CATALOG_B85))
    import json
    decoded = json.loads(raw.decode("utf-8"))
    return {key: tuple(value) for key, value in decoded.items()}


MAP_TEXTURE_NATIVE_CATALOG = _load_map_texture_native_catalog()


def _build_native_basename_indexes():
    index = {}
    for catalog in (NATIVE_PROFILE_CATALOG, MAP_TEXTURE_NATIVE_CATALOG):
        for key, profile in catalog.items():
            name = key.rsplit("/", 1)[-1]
            index.setdefault(name, set()).add(profile)
    unique = {name: next(iter(profiles)) for name, profiles in index.items()
              if len(profiles) == 1}
    ambiguous = {name for name, profiles in index.items() if len(profiles) > 1}
    return unique, ambiguous


NATIVE_UNIQUE_BASENAME_PROFILES, NATIVE_AMBIGUOUS_BASENAMES = _build_native_basename_indexes()


def native_profile_match(path):
    """
    Primeiro tenta o caminho relativo nativo (mais seguro). Se o DDS estiver
    solto em Download, usa o nome somente quando esse nome possui um único
    perfil no catálogo. Nomes ambíguos, como soybean_diffuse.dds, não são
    forçados sem a pasta de origem.
    """
    parts = normalized_path_parts(path)
    for i, part in enumerate(parts):
        if part in NATIVE_CATALOG_TOPS:
            key = "/".join(parts[i:])
            profile = NATIVE_PROFILE_CATALOG.get(key)
            if profile is not None:
                return profile, "FS23_NATIVE_PATH"

    # O nome da pasta do mapa varia (map, mapUS, mapFR, mapa convertido etc.).
    # A porção depois de /textures/ é estável e identifica sem ambiguidade os
    # 703 arquivos medidos na referência nativa.
    for i, part in enumerate(parts):
        if part == "textures" and i + 1 < len(parts):
            key = "/".join(parts[i + 1:])
            profile = MAP_TEXTURE_NATIVE_CATALOG.get(key)
            if profile is not None:
                return profile, "FS23_MAP_TEXTURE_PATH"

    name = Path(path).name.lower()
    profile = NATIVE_UNIQUE_BASENAME_PROFILES.get(name)
    if profile is not None:
        return profile, "FS23_NATIVE_UNIQUE_NAME"
    return None, None


def alpha_stats(img):
    if "A" not in img.getbands():
        return {
            "has_alpha": False,
            "meaningful_alpha": False,
            "cutout": False,
            "coverage": 1.0,
            "transparent": 0.0,
            "opaque": 1.0,
        }

    a = img.getchannel("A")
    hist = a.histogram()
    total = max(1, sum(hist))

    transparent = sum(hist[:ALPHA_EDGE_LOW]) / total
    opaque = sum(hist[ALPHA_EDGE_HIGH:]) / total
    middle = max(0.0, 1.0 - transparent - opaque)
    coverage = sum(hist[ALPHA_CUTOFF:]) / total

    meaningful = (sum(hist[:255]) > 0)

    # Alpha-test/cutout: boa parte dos pixels está muito transparente
    # ou muito opaca, típico de folhas, recortes, letras e logos.
    cutout = (
        meaningful
        and transparent > 0.01
        and opaque > 0.01
        and (transparent + opaque) >= 0.65
        and middle <= 0.35
    )

    return {
        "has_alpha": True,
        "meaningful_alpha": meaningful,
        "cutout": cutout,
        "coverage": coverage,
        "transparent": transparent,
        "opaque": opaque,
    }


def normalized_path_parts(path):
    """Partes normalizadas do caminho; classificação não depende da pasta raiz."""
    s = str(path).replace("\\", "/").lower()
    return [p for p in s.split("/") if p]


def path_has_family(parts, family):
    """Aceita variações de nome de pasta, ex. fillPlanes/fillPlane."""
    family = family.lower()
    return any(family in p for p in parts)


def path_has_distance(parts, name):
    return any("distance" in p for p in parts) or "distance" in name.lower()


# Overrides descobertos diretamente dos <Layer> do I3D do mapa.
# Chave: caminho absoluto normalizado do DDS; valor: "detail" ou "normal".
I3D_TERRAIN_LAYER_TEXTURES = {}


def scan_i3d_terrain_layers(root):
    """Descobre pinturas do terrain pelos IDs usados em <Layer> do I3D.

    Nao depende do nome do arquivo/pasta. Resolve detailMapId e normalMapId
    contra <Files><File fileId=... filename=...>. Referencias .png tambem sao
    aceitas: antes da conversao procuramos o DDS irmao com o mesmo stem.
    """
    found = {}
    root = Path(root).resolve()
    for i3d in root.rglob("*.i3d"):
        try:
            tree = ET.parse(i3d)
            doc = tree.getroot()
        except Exception as e:
            print(f"AVISO I3D: nao foi possivel ler {i3d}: {e}")
            continue

        files = {}
        for node in doc.iter("File"):
            fid = node.get("fileId")
            fn = node.get("filename")
            if fid and fn:
                files[fid] = fn

        for layer in doc.iter("Layer"):
            for attr, role in (("detailMapId", "detail"), ("normalMapId", "normal")):
                fid = layer.get(attr)
                fn = files.get(fid)
                if not fn or fn.startswith("$data"):
                    continue
                # URI simples usado por I3D; remove query/fragment se houver.
                fn = fn.split("?", 1)[0].split("#", 1)[0].replace("\\", "/")
                ref = (i3d.parent / fn).resolve()
                candidates = [ref]
                if ref.suffix.lower() == ".png":
                    candidates.insert(0, ref.with_suffix(".dds"))
                elif ref.suffix.lower() == ".dds":
                    candidates.append(ref.with_suffix(".png"))
                for c in candidates:
                    if c.suffix.lower() == ".dds" and c.exists():
                        found[str(c)] = role
                        break

    I3D_TERRAIN_LAYER_TEXTURES.clear()
    I3D_TERRAIN_LAYER_TEXTURES.update(found)
    return found


def choose_settings(path, base, info=None):
    kind = semantic_kind(path)
    astats = alpha_stats(base)
    name = Path(path).name.lower()
    stem = Path(path).stem.lower()
    parts = normalized_path_parts(path)
    in_terrain = path_has_family(parts, "terrain")
    in_ground = path_has_family(parts, "ground")
    in_fillplanes = path_has_family(parts, "fillplane")
    in_foliage = path_has_family(parts, "foliage")
    is_distance = path_has_distance(parts, name)
    terrain_like = in_terrain or in_ground or stem.startswith("groundtype")

    # Valores padrão: texturas de veículos/placeables preservam a resolução.
    target_w, target_h = base.size
    profile = 6
    mip_count = full_fs23_mip_count(target_w, target_h)
    class_name = (
        "GENERIC_2D_AMBIGUOUS_NAME"
        if name in NATIVE_AMBIGUOUS_BASENAMES
        else "GENERIC_2D"
    )
    force_components = None

    # Maior prioridade para pinturas do terrain explicitamente ligadas por <Layer> no I3D.
    # Isso corrige nomes customizados (roughDirt*, concrete*, etc.) que nao possuem
    # "groundType" no nome e antes acabavam preservados em 1024x1024.
    i3d_role = I3D_TERRAIN_LAYER_TEXTURES.get(str(Path(path).resolve()))
    if i3d_role == "detail":
        target_w = target_h = 256
        force_components = 4
        mip_count = 7
        profile = 6
        class_name = "I3D_TERRAIN_LAYER_DIFFUSE"
    elif i3d_role == "normal":
        target_w = target_h = 256
        force_components = 3
        mip_count = 7
        profile = 6
        class_name = "I3D_TERRAIN_LAYER_NORMAL"

    # Maior prioridade seguinte: correspondência exata com o catálogo do data FS23.
    # O caminho é usado primeiro. Nome solto só é aceito quando possui um
    # único perfil no catálogo, evitando confundir arquivos homônimos.
    exact, exact_source = native_profile_match(path)
    if i3d_role is None and exact is not None:
        target_w, target_h, force_components, mip_count, profile = exact
        class_name = exact_source

    # Perfis de interface são independentes da resolução original.
    elif i3d_role is None and kind == "ui_nomip":
        class_name = "UI_STORE_ICON"
        profile = 4
        mip_count = 1
        force_components = 4
    elif i3d_role is None and kind == "preview":
        class_name = "MAP_PREVIEW"
        profile = 6
        mip_count = min(2, full_fs23_mip_count(target_w, target_h))

    # FillPlanes do FS23. Diffuse, normal e specular precisam manter a mesma
    # resolução e quantidade de níveis; distance usa o perfil reduzido.
    elif i3d_role is None and in_fillplanes and is_distance:
        class_name = "FILLPLANE_DISTANCE"
        target_w = target_h = 128
        force_components = 4
        mip_count = 6
    elif i3d_role is None and in_fillplanes:
        target_w = target_h = 256
        mip_count = 7
        if kind == "color":
            class_name = "FILLPLANE_DIFFUSE"
            force_components = 4
        elif kind == "normal":
            class_name = "FILLPLANE_NORMAL"
            force_components = 3
        elif kind == "material":
            class_name = "FILLPLANE_SPECULAR"
            force_components = 3
        else:
            class_name = "FILLPLANE_OTHER"

    # Terrain/ground nativo do FS23. A ordem é importante: terrainNoise não
    # pode cair antes na regra genérica de diffuse.
    elif i3d_role is None and terrain_like and "terrainnoise" in stem:
        class_name = "TERRAIN_NOISE"
        target_w = target_h = 512
        force_components = 1
        mip_count = 8
    elif i3d_role is None and terrain_like and is_distance:
        class_name = "TERRAIN_GROUND_DISTANCE"
        target_w = target_h = 128
        force_components = 4
        mip_count = 6
    elif i3d_role is None and terrain_like and kind == "height":
        class_name = "TERRAIN_HEIGHT"
        target_w = target_h = 128
        force_components = 1
        mip_count = 6
    elif i3d_role is None and terrain_like and kind == "normal":
        class_name = "TERRAIN_NORMAL"
        target_w = target_h = 256
        force_components = 3
        mip_count = 7
    elif i3d_role is None and terrain_like and kind == "color":
        class_name = "TERRAIN_DIFFUSE"
        target_w = target_h = 256
        force_components = 4
        mip_count = 7

    # Texture-array de ground do FS22: os diffuse precisam ter o mesmo layout
    # RGBA usado pelas demais camadas do array no FS23. Alguns DDS BC7 abrem
    # no Pillow como RGB quando o alpha e totalmente opaco; nesse caso a V12
    # antiga gravava 3 canais e o engine rejeitava o array (channels 3 vs 4).
    elif i3d_role is None and in_ground and kind == "color":
        class_name = "GROUND_ARRAY_DIFFUSE_RGBA"
        force_components = 4

    # Foliage conhecido pelo pacote anterior (barley) e fallbacks para outras
    # culturas. LOD usa dois níveis; alpha principal é limitado a seis níveis;
    # distance usa 128x128 com seis níveis.
    elif i3d_role is None and in_foliage and name in FOLIAGE_NATIVE_EXACT:
        target_w, target_h, force_components, mip_count, profile = FOLIAGE_NATIVE_EXACT[name]
        class_name = "FOLIAGE_BARLEY_EXACT"
    elif i3d_role is None and in_foliage and is_distance:
        class_name = "FOLIAGE_DISTANCE"
        target_w = target_h = 128
        force_components = 4
        mip_count = 6
    elif i3d_role is None and in_foliage and "lod" in stem:
        class_name = "FOLIAGE_LOD"
        mip_count = min(2, full_fs23_mip_count(target_w, target_h))
    elif i3d_role is None and in_foliage and kind == "alpha_map":
        class_name = "FOLIAGE_ALPHA"
        force_components = 1
        mip_count = min(6, full_fs23_mip_count(target_w, target_h))
    elif i3d_role is None and in_foliage:
        class_name = "FOLIAGE_GENERIC"

    if force_components is not None:
        components = force_components
    elif kind in ("height", "alpha_map"):
        components = 1
    elif kind in ("normal", "mask"):
        components = 3
    elif base.mode == "L":
        components = 1
    elif astats["meaningful_alpha"]:
        components = 4
    else:
        components = 3

    linear = any(word in name for word in LINEAR_WORDS)
    if kind in ("height", "alpha_map", "normal", "mask", "material"):
        linear = True
    srgb = not linear

    return {
        "kind": kind,
        "class": class_name,
        "profile": profile,
        "mip_count": mip_count,
        "components": components,
        "srgb": srgb,
        "alpha": astats,
        "target_width": target_w,
        "target_height": target_h,
        "i3d_terrain_role": i3d_role,
        "catalog_match": exact_source,
    }

def alpha_coverage(alpha, cutoff=ALPHA_CUTOFF):
    hist = alpha.histogram()
    total = max(1, sum(hist))
    return sum(hist[cutoff:]) / total


def preserve_alpha_coverage(alpha, target, cutoff=ALPHA_CUTOFF):
    """
    Ajusta ganho do alpha para manter aproximadamente a mesma área visível
    após o downsample. Isso reduz popping/flicker em alpha-test.
    """
    if target <= 0.0 or target >= 1.0:
        return alpha, 1.0

    lo, hi = 0.25, 4.0

    def apply_gain(g):
        lut = [min(255, max(0, int(round(i * g)))) for i in range(256)]
        return alpha.point(lut)

    # Se mesmo no limite não conseguimos melhorar, ainda devolvemos
    # o melhor limite em vez de criar valores absurdos.
    for _ in range(18):
        mid = (lo + hi) * 0.5
        test = apply_gain(mid)
        cov = alpha_coverage(test, cutoff)
        if cov < target:
            lo = mid
        else:
            hi = mid

    gain = (lo + hi) * 0.5
    return apply_gain(gain), gain


def sharpen_color_mip(img, cutout=False):
    """
    Nitidez leve: suficiente para letras/logos resistirem melhor aos mips,
    sem transformar a textura em serrilhado.
    """
    if min(img.size) < 16:
        return img

    percent = 85 if cutout else 55

    if img.mode == "RGBA":
        rgb = img.convert("RGB")
        a = img.getchannel("A")
        rgb = rgb.filter(
            ImageFilter.UnsharpMask(radius=0.65, percent=percent, threshold=2)
        )
        out = rgb.convert("RGBA")
        out.putalpha(a)
        return out

    if img.mode == "RGB":
        return img.filter(
            ImageFilter.UnsharpMask(radius=0.65, percent=percent, threshold=2)
        )

    return img


def _lanczos():
    try:
        return Image.Resampling.LANCZOS
    except AttributeError:
        return Image.LANCZOS



def resize_preserve_rgba_rgb(img, size, resample=None):
    """Redimensiona RGB e alpha separadamente para não apagar RGB oculto sob alpha=0."""
    if resample is None:
        resample = _lanczos()
    if img.mode != "RGBA":
        return img.resize(size, resample=resample)
    rgb = img.convert("RGB").resize(size, resample=resample)
    alpha = img.getchannel("A").resize(size, resample=resample)
    out = rgb.convert("RGBA")
    out.putalpha(alpha)
    return out


def renormalize_normal_map(img):
    """Renormaliza RGB normal map. Usa NumPy quando disponível; fallback sem dependência."""
    rgb = img.convert("RGB")

    if np is not None:
        arr = np.asarray(rgb, dtype=np.float32) / 127.5 - 1.0
        length = np.sqrt(np.sum(arr * arr, axis=2, keepdims=True))
        safe = np.maximum(length, 1e-8)
        arr = arr / safe
        bad = (length[..., 0] < 1e-8)
        if np.any(bad):
            arr[bad, 0] = 0.0
            arr[bad, 1] = 0.0
            arr[bad, 2] = 1.0
        out_arr = np.clip(np.rint((arr + 1.0) * 127.5), 0, 255).astype(np.uint8)
        return Image.fromarray(out_arr, mode="RGB")

    data = []
    for r, g, b in rgb.getdata():
        x = r / 127.5 - 1.0
        y = g / 127.5 - 1.0
        z = b / 127.5 - 1.0
        length = math.sqrt(x*x + y*y + z*z)
        if length < 1e-8:
            x, y, z = 0.0, 0.0, 1.0
        else:
            x, y, z = x/length, y/length, z/length
        data.append((
            max(0, min(255, int(round((x+1.0)*127.5)))),
            max(0, min(255, int(round((y+1.0)*127.5)))),
            max(0, min(255, int(round((z+1.0)*127.5)))),
        ))
    out = Image.new("RGB", rgb.size)
    out.putdata(data)
    return out


def prepare_target_base(base, settings):
    tw, th = settings["target_width"], settings["target_height"]
    kind = settings["kind"]
    comp = settings["components"]

    if kind in ("height", "alpha_map") or comp == 1:
        img = base.convert("L")
    elif comp == 4:
        img = base.convert("RGBA")
    else:
        img = base.convert("RGB")

    if img.size != (tw, th):
        img = resize_preserve_rgba_rgb(img, (tw, th), resample=_lanczos())

    if kind == "normal":
        img = renormalize_normal_map(img)

    return img


# As imagens nativas de distance do ground usam RGB escuro e alpha zero. Em
# alguns DDS do FS22 o Pillow abre o arquivo sem erro, porém entrega todos os
# canais zerados. As cores abaixo foram medidas nos 19 AST originais do FS23 e
# só são usadas quando o RGB decodificado está comprovadamente preto.
TERRAIN_DISTANCE_FALLBACK_RGB = {
    "cultivated_distance_diffuse": (54, 47, 40),
    "directsownfertilized_distance_diffuse": (62, 50, 31),
    "directsown_distance_diffuse": (79, 62, 39),
    "fertilizer_distance_diffuse": (40, 35, 30),
    "grasscutfertilized_distance_diffuse": (68, 69, 41),
    "grasscut_distance_diffuse": (85, 86, 52),
    "grassfertilized_distance_diffuse": (51, 55, 32),
    "grass_distance_diffuse": (64, 69, 40),
    "harvestreadyfertilized_distance_diffuse": (86, 72, 42),
    "harvestreadyotherfertilized_distance_diffuse": (55, 49, 36),
    "harvestreadyother_distance_diffuse": (79, 70, 52),
    "harvestready_distance_diffuse": (124, 103, 61),
    "lime_distance_diffuse": (174, 174, 174),
    "liquidmanure_distance_diffuse": (42, 36, 28),
    "maizechopper_distance_diffuse": (154, 126, 66),
    "manure_distance_diffuse": (113, 86, 45),
    "straw_distance_diffuse": (191, 146, 87),
    "stubbletillagefertilized_distance_diffuse": (79, 61, 39),
    "stubbletillage_distance_diffuse": (98, 76, 47),
}


def repair_terrain_distance_base(path, base, settings):
    """Corrige somente ground/distance; demais classes permanecem intactas."""
    parts = normalized_path_parts(path)
    key = Path(path).stem.lower()
    excluded_family = (
        path_has_family(parts, "fillplane")
        or path_has_family(parts, "foliage")
    )
    known_native_distance = (
        key in TERRAIN_DISTANCE_FALLBACK_RGB and not excluded_family
    )
    is_ground_distance = (
        path_has_distance(parts, Path(path).name)
        and (path_has_family(parts, "terrain") or path_has_family(parts, "ground"))
        and not excluded_family
    )

    # Uma correspondência exata do catálogo troca o nome da classe por
    # FS23_MAP_TEXTURE_PATH. Por isso a decisão usa caminho/nome, não apenas
    # settings["class"]. Os 19 nomes conhecidos também funcionam soltos.
    if not (known_native_distance or is_ground_distance):
        return base, None

    rgba = base.convert("RGBA")
    extrema = rgba.convert("RGB").getextrema()
    rgb_max = max(channel_max for _channel_min, channel_max in extrema)
    note = "DISTANCE_ALPHA0"

    if rgb_max <= 2:
        color = TERRAIN_DISTANCE_FALLBACK_RGB.get(key)
        if color is None:
            raise RuntimeError(
                "DDS de distance foi decodificado com RGB preto e não existe "
                "cor nativa segura para este nome; DDS foi preservado"
            )
        rgba = Image.new("RGBA", rgba.size, color + (0,))
        note = "DISTANCE_RGB_NATIVE_FALLBACK+ALPHA0"
    else:
        rgba.putalpha(0)

    return rgba, note


def gray_coverage(gray, cutoff=ALPHA_CUTOFF):
    hist = gray.histogram()
    total = max(1, sum(hist))
    return sum(hist[cutoff:]) / total


def preserve_gray_coverage(gray, target, cutoff=ALPHA_CUTOFF):
    if target <= 0.0 or target >= 1.0:
        return gray, 1.0
    lo, hi = 0.25, 4.0
    def apply_gain(g):
        lut = [min(255, max(0, int(round(i*g)))) for i in range(256)]
        return gray.point(lut)
    for _ in range(18):
        mid=(lo+hi)*0.5
        cov=gray_coverage(apply_gain(mid),cutoff)
        if cov < target: lo=mid
        else: hi=mid
    gain=(lo+hi)*0.5
    return apply_gain(gain),gain

def build_fs23_mips(base, settings):
    wanted = settings["mip_count"]
    result = []
    base = prepare_target_base(base, settings)
    w, h = base.size
    lanczos = _lanczos()

    cutout = settings["alpha"]["cutout"]
    base_coverage = settings["alpha"]["coverage"]
    gray_cutout = settings["kind"] == "alpha_map"
    gray_base_coverage = gray_coverage(base) if gray_cutout else 1.0

    for level in range(wanted):
        if level == 0:
            img = base.copy()
            alpha_gain = 1.0
        else:
            # Terrain painting is sampled aggressively by the mobile Medium/Low
            # profiles. Keep its derived mips neutral: no UnsharpMask and no
            # accumulated resampling. Every mip is rebuilt directly from mip0.
            terrain_role = settings.get("i3d_terrain_role")
            if terrain_role == "normal":
                try:
                    mip_filter = Image.Resampling.BOX
                except AttributeError:
                    mip_filter = Image.BOX
            else:
                mip_filter = lanczos

            img = resize_preserve_rgba_rgb(base, (w, h), resample=mip_filter)

            if settings["kind"] == "normal":
                img = renormalize_normal_map(img)
            elif settings["kind"] in ("color", "preview", "ui_nomip") and terrain_role is None:
                img = sharpen_color_mip(img, cutout=cutout)

            alpha_gain = 1.0
            if cutout and "A" in img.getbands():
                a = img.getchannel("A")
                a, alpha_gain = preserve_alpha_coverage(a, base_coverage)
                img.putalpha(a)
            elif gray_cutout and img.mode == "L":
                img, alpha_gain = preserve_gray_coverage(img, gray_base_coverage)

        # Guard específico para terrain painting: um mip derivado não pode
        # virar branco/preto quase uniforme se o mip0 não é assim. Isso evita
        # gerar AST que só quebra quando o perfil gráfico troca de mip.
        if settings.get("i3d_terrain_role") == "detail" and level > 0:
            probe = img.convert("RGB").resize((1, 1), resample=Image.Resampling.BOX if hasattr(Image, "Resampling") else Image.BOX)
            pr, pg, pb = probe.getpixel((0, 0))
            base_probe = base.convert("RGB").resize((1, 1), resample=Image.Resampling.BOX if hasattr(Image, "Resampling") else Image.BOX)
            br, bg, bb = base_probe.getpixel((0, 0))
            avg = (pr + pg + pb) / 3.0
            bavg = (br + bg + bb) / 3.0
            if (avg >= 252.0 and bavg < 245.0) or (avg <= 3.0 and bavg > 10.0):
                raise RuntimeError(
                    f"Terrain mip {level} degenerou (media RGB={avg:.1f}; mip0={bavg:.1f})"
                )

        result.append({
            "level": level,
            "width": w,
            "height": h,
            "image": img,
            "alpha_gain": alpha_gain,
        })

        w = max(1, w // 2)
        h = max(1, h // 2)

    return result

def encode_astc_image(astcenc, img, width, height, srgb, tmpdir, index):
    png_file = os.path.join(tmpdir, f"mip_{index}.png")
    out_file = os.path.join(tmpdir, f"mip_{index}.astc")

    if img.size != (width, height):
        raise RuntimeError(
            f"Mip {index}: imagem {img.size[0]}x{img.size[1]}, "
            f"esperado {width}x{height}"
        )

    img.save(png_file, format="PNG", optimize=False, compress_level=0)

    mode = "-cs" if srgb else "-cl"
    cmd = [
        astcenc, mode, png_file, out_file,
        f"{ASTC_BLOCK}x{ASTC_BLOCK}",
        QUALITY,
        "-yflip",
        "-silent",
    ]
    if ASTCENC_HAS_J:
        cmd.extend(["-j", "1"])

    r = subprocess.run(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
    )

    if r.returncode != 0:
        raise RuntimeError("astcenc falhou:\n" + r.stdout[-2000:])

    astc = Path(out_file).read_bytes()

    if len(astc) < 16 or astc[:4] != ASTC_MAGIC:
        raise RuntimeError("ASTC gerado inválido")

    bx, by, bz = astc[4], astc[5], astc[6]
    aw = read_24(astc[7:10])
    ah = read_24(astc[10:13])
    az = read_24(astc[13:16])

    if (bx, by, bz) != (ASTC_BLOCK, ASTC_BLOCK, 1):
        raise RuntimeError(f"ASTC inesperado: {bx}x{by}x{bz}")

    if (aw, ah, az) != (width, height, 1):
        raise RuntimeError(
            f"Dimensão ASTC errada: {aw}x{ah}x{az}; "
            f"esperado {width}x{height}x1"
        )

    blocks = astc[16:]
    expected = (
        ((width + ASTC_BLOCK - 1) // ASTC_BLOCK)
        * ((height + ASTC_BLOCK - 1) // ASTC_BLOCK)
        * 16
    )

    if len(blocks) != expected:
        raise RuntimeError(
            f"Payload ASTC mip {index}: {len(blocks)}, esperado {expected}"
        )

    return blocks


def dds_array_format(info):
    """Retorna (kind, bytes_per_block_or_pixel) para DX10 arrays suportados."""
    dxgi = info.get("dxgi")
    if dxgi in (71, 72):
        return "BC1", 8
    if dxgi in (77, 78):
        return "BC3", 16
    if dxgi in (98, 99):
        return "BC7", 16
    if dxgi in (28, 29):
        return "RGBA8", 4
    raise ValueError(f"DDS array DXGI {dxgi} ainda não suportado")


def dds_level_size(w, h, fmt, unit):
    if fmt in ("BC1", "BC3", "BC7"):
        return max(1, (w+3)//4) * max(1, (h+3)//4) * unit
    return w*h*unit


def decode_dds_array_layers(path, info, experimental=False):
    layers = info.get("array_size", 1)
    if layers <= 1:
        raise ValueError("DDS não é array")
    if layers not in (4, 6) and not experimental:
        raise ValueError(
            f"DDS array com {layers} layers: layout GS2D não validado. "
            "Use --experimental-arrays --keep-dds para gerar candidato sem apagar o original."
        )
    if info.get("fourcc") != b"DX10":
        raise ValueError("DDS array sem header DX10 não suportado")

    fmt, unit = dds_array_format(info)
    w, h = info["width"], info["height"]
    mip_count = info["mips"]
    sizes=[]; ww=w; hh=h
    for _ in range(mip_count):
        sizes.append(dds_level_size(ww, hh, fmt, unit))
        ww=max(1,ww//2); hh=max(1,hh//2)
    layer_stride=sum(sizes)
    base_size=sizes[0]
    payload_off=info["header_size"]
    expected=payload_off + layer_stride*layers
    if len(info["data"]) < expected:
        raise ValueError(
            f"DDS array truncado: {len(info['data'])} bytes, esperado >= {expected}"
        )

    out=[]
    for layer in range(layers):
        off=payload_off + layer*layer_stride
        raw=info["data"][off:off+base_size]
        if fmt == "RGBA8":
            img=Image.frombytes("RGBA", (w,h), raw)
        else:
            hdr=bytearray(info["data"][:148])
            struct.pack_into("<I", hdr, 28, 1)   # um mip
            struct.pack_into("<I", hdr, 140, 1)  # uma layer
            one=bytes(hdr)+raw
            try:
                with Image.open(io.BytesIO(one)) as im:
                    im.load()
                    img=im.convert("RGBA")
            except Exception as e:
                raise RuntimeError(f"Falha decodificando layer {layer} do DDS array: {e}")

        # Mesmo sentido vertical usado no caminho ASTC (-yflip).
        try:
            img=img.transpose(Image.Transpose.FLIP_TOP_BOTTOM)
        except AttributeError:
            img=img.transpose(Image.FLIP_TOP_BOTTOM)
        out.append(img)
    return out


def make_gs2d_array(source_dds, layers_images, experimental=False):
    layers=len(layers_images)
    if layers not in (4,6) and not experimental:
        raise ValueError("GS2D array não validado para esta quantidade de layers")
    w,h=layers_images[0].size
    for i,img in enumerate(layers_images):
        if img.size != (w,h):
            raise ValueError(f"Layer {i} tem tamanho diferente")
    raw=b"".join(img.convert("RGBA").tobytes() for img in layers_images)
    encoded=compress_chunk(raw)
    payload=pad16(encoded)
    # No conjunto nativo fornecido: field7=2 para 4 layers; 3 para 6 layers.
    field7=layers//2
    ident=hashlib.md5(source_dds+b"FS23_GS2D_V6_2DARRAY_RGBA_V6").digest()
    header=struct.pack(
        "<4s12I16s3I",
        b"GS2D",6,len(payload),w,h,1,
        4,field7,4,
        len(encoded),0,0,0,
        ident,5,1,6,
    )
    return header+payload


def verify_gs2d_array(data, w, h, layers):
    if len(data)<80 or data[:4]!=b"GS2D":
        raise RuntimeError("Array AST sem GS2D")
    v=struct.unpack("<4s12I16s3I",data[:80])
    if v[1]!=6 or (v[3],v[4],v[5])!=(w,h,1):
        raise RuntimeError("Header array inválido")
    if (v[6]&0xffff)!=4 or ((v[6]>>16)+1)!=1:
        raise RuntimeError("Array deve ser RGBA / 1 mip")
    if v[7] != layers//2 or v[8]!=4 or v[-3:]!=(5,1,6):
        raise RuntimeError("Assinatura GS2D array não bate com referência FS23")
    s=v[9]; chunk=data[80:80+s]
    try: raw=zlib.decompress(chunk)
    except Exception: raw=chunk
    if len(raw)!=w*h*4*layers:
        raise RuntimeError(
            f"Payload array {len(raw)}, esperado {w*h*4*layers}"
        )

def make_chunks(mips):
    """
    Padrão GS2D 2D do FS23:
    <=4 mips: chunks em ordem inversa;
    >4 mips : chunk0 agrupa mip3..mip final,
              chunk1=mip2, chunk2=mip1, chunk3=mip0.
    """
    count = len(mips)
    if count <= 4:
        return list(reversed(mips))

    # Dentro do chunk agregado a ordem nativa é crescente (mip3, mip4...).
    # A V10 invertia esta sequência; texturas uniformes mascaravam a falha,
    # enquanto atlas de estruturas/estradas liam blocos do mip errado.
    tail = b"".join(mips[3:])
    return [tail, mips[2], mips[1], mips[0]]


def compress_chunk(raw):
    comp = zlib.compress(raw, 9)
    return comp if len(comp) < len(raw) else raw


def pad16(data):
    pad = (-len(data)) & 15
    if pad:
        return data + (b"\x00" * pad)
    return data


def make_gs2d(source_dds, width, height, components, profile, astc_mips):
    raw_chunks = make_chunks(astc_mips)
    encoded_chunks = [compress_chunk(x) for x in raw_chunks]

    while len(encoded_chunks) < 4:
        encoded_chunks.append(b"")

    chunk_sizes = [len(x) for x in encoded_chunks]
    payload_parts = []
    for chunk in encoded_chunks:
        if chunk:
            payload_parts.append(pad16(chunk))
    payload = b"".join(payload_parts)

    mip_index = len(astc_mips) - 1
    component_mip_field = (mip_index << 16) | components

    identifier = hashlib.md5(
        source_dds + b"FS23_GS2D_V6_ASTC_6X6_NATIVE_MIPS_ALPHA_V4"
    ).digest()

    header = struct.pack(
        "<4s12I16s3I",
        b"GS2D",
        6,
        len(payload),
        width,
        height,
        1,
        component_mip_field,
        1,
        profile,
        chunk_sizes[0],
        chunk_sizes[1],
        chunk_sizes[2],
        chunk_sizes[3],
        identifier,
        34,
        1,
        1,
    )

    if len(header) != 80:
        raise RuntimeError("Header GS2D não ficou com 80 bytes")

    return header + payload


def verify_gs2d_2d(data, expected_w, expected_h, expected_mips,
                   expected_components, expected_profile):
    if len(data) < 80 or data[:4] != b"GS2D":
        raise RuntimeError("AST final sem header GS2D")

    values = struct.unpack("<4s12I16s3I", data[:80])

    version = values[1]
    payload_size = values[2]
    width = values[3]
    height = values[4]
    depth = values[5]
    component_mip_field = values[6]
    profile = values[8]
    chunk_sizes = values[9:13]

    components = component_mip_field & 0xFFFF
    mip_count = ((component_mip_field >> 16) & 0xFFFF) + 1

    if version != 6:
        raise RuntimeError(f"GS2D versão {version}, esperado 6")
    if (width, height, depth) != (expected_w, expected_h, 1):
        raise RuntimeError(
            f"GS2D dimensão {width}x{height}x{depth}, "
            f"esperado {expected_w}x{expected_h}x1"
        )
    if mip_count != expected_mips:
        raise RuntimeError(
            f"GS2D {mip_count} mips, esperado {expected_mips}"
        )
    if components != expected_components:
        raise RuntimeError(
            f"GS2D {components} canais, esperado {expected_components}"
        )
    if profile != expected_profile:
        raise RuntimeError(
            f"GS2D perfil {profile}, esperado {expected_profile}"
        )

    padded_sum = sum(((s + 15) // 16) * 16 for s in chunk_sizes if s)
    if payload_size != padded_sum:
        raise RuntimeError(
            f"GS2D payload={payload_size}, soma chunks alinhados={padded_sum}"
        )
    if len(data) != 80 + payload_size:
        raise RuntimeError(
            f"AST tamanho={len(data)}, esperado {80 + payload_size}"
        )



# GS2D v6 format 5 template from the user's original FS23 fertilizer effect.
# Only used for DX10 RGBA16F 2-layer effect arrays. Unknown metadata is preserved.
import base64 as _effect_base64
import zlib as _effect_zlib
import struct as _effect_struct
_EFFECT_NATIVE_HEADER = _effect_base64.b64decode("R1MyRAYAAAAwFAAAIAAAABAAAAABAAAABAAAAAIAAAAEAAAAKxQAAAAAAAAAAAAAAAAAAGWmQjZIjogEH3fqpxE9hdQFAAAAAQAAAAYAAAA=")

def convert_fs23_effect_array_dds(dds_data):
    """Lossless DX10 R16G16B16A16_FLOAT (2 layers, mip0) -> GS2D v6 format 5."""
    if len(dds_data) < 148 or dds_data[:4] != b"DDS " or dds_data[84:88] != b"DX10":
        raise ValueError("DDS DX10 inválido")
    w, h = _effect_struct.unpack_from("<II", dds_data, 16)[0], _effect_struct.unpack_from("<II", dds_data, 12)[0]
    dxgi, dim, misc, layers, misc2 = _effect_struct.unpack_from("<5I", dds_data, 128)
    mips = _effect_struct.unpack_from("<I", dds_data, 28)[0]
    if (dxgi, dim, layers) != (10, 3, 2) or mips not in (0, 1):
        raise ValueError(f"Array não é RGBA16F 2 layers/mip0: DXGI={dxgi} dim={dim} layers={layers} mips={mips}")
    payload = dds_data[148:]
    if len(payload) != w * h * 2 * 8:
        raise ValueError(f"RGBA16F truncado/inconsistente: {len(payload)} bytes")
    hdr = bytearray(_EFFECT_NATIVE_HEADER)
    if hdr[:4] != b"GS2D" or _effect_struct.unpack_from("<I", hdr, 68)[0] != 5:
        raise ValueError("Template GS2D inválido")
    compressed = _effect_zlib.compress(payload, 9)
    _effect_struct.pack_into("<I", hdr, 8, len(compressed))
    _effect_struct.pack_into("<II", hdr, 12, w, h)
    result = bytes(hdr) + compressed
    if _effect_zlib.decompress(result[80:]) != payload:
        raise RuntimeError("Falha na validação lossless do array")
    return result

def convert_file(path, astcenc, overwrite=False, delete_dds=True, experimental_arrays=False):
    src = Path(path)
    dst = src.with_suffix(".ast")

    if dst.exists() and not overwrite:
        return "SKIP", "AST já existe"

    info = read_dds_header(src)

    # Detecção por estrutura, sem depender do nome do arquivo.
    # DXGI 10 = R16G16B16A16_FLOAT, 2D array com 2 layers e um mip.
    # O tratamento lossless é experimental até validação no FS23.
    if (info.get("array_size") == 2 and info.get("dxgi") == 10
            and info.get("resource_dimension") == 3 and info.get("mips") == 1):
        gs2d = convert_fs23_effect_array_dds(info["data"])
        tmp = dst.with_suffix(".ast.tmp")
        tmp.write_bytes(gs2d)
        os.replace(tmp, dst)
        removed = False
        if delete_dds:
            # O arquivo .ast já foi gerado e seu payload foi validado acima.
            # A validação binária não substitui um teste no jogo.
            src.unlink()
            removed = True
        return ("OK", f"RGBA16F_2L_AUTO {info['width']}x{info['height']} "
                      "GS2D_FMT5 | EXPERIMENTAL" +
                      (" | DDS_REMOVIDO" if removed else " | DDS_PRESERVADO"))

    # DDS DX10 2DARRAY: crawler/other. Não passa pelo encoder ASTC 2D.
    if info.get("array_size", 1) > 1:
        layers = decode_dds_array_layers(src, info, experimental=experimental_arrays)
        gs2d = make_gs2d_array(info["data"], layers, experimental=experimental_arrays)
        verify_gs2d_array(gs2d, info["width"], info["height"], len(layers))
        tmp = dst.with_suffix(".ast.tmp")
        tmp.write_bytes(gs2d)
        os.replace(tmp, dst)
        removed = False
        if delete_dds and len(layers) in (4, 6):
            src.unlink()
            removed = True
        return (
            "OK",
            f"{'EXPERIMENTAL' if len(layers) not in (4,6) else 'PREBUILT'}_2DARRAY {info['width']}x{info['height']} "
            f"layers={len(layers)} RGBA perfil=4 mips=1" +
            (" | DDS_REMOVIDO" if removed else "")
        )

    base = decode_base(src, info)
    settings = choose_settings(src, base, info)
    base, distance_note = repair_terrain_distance_base(src, base, settings)
    source_size = base.size

    encoded_mips = []
    with tempfile.TemporaryDirectory() as td:
        mips = build_fs23_mips(base, settings)
        for mip in mips:
            encoded_mips.append(
                encode_astc_image(
                    astcenc,
                    mip["image"],
                    mip["width"],
                    mip["height"],
                    settings["srgb"],
                    td,
                    mip["level"],
                )
            )

    tw, th = settings["target_width"], settings["target_height"]
    gs2d = make_gs2d(
        info["data"], tw, th,
        settings["components"], settings["profile"], encoded_mips,
    )
    verify_gs2d_2d(
        gs2d, tw, th, len(encoded_mips),
        settings["components"], settings["profile"],
    )

    tmp = dst.with_suffix(".ast.tmp")
    tmp.write_bytes(gs2d)
    os.replace(tmp, dst)

    removed = False
    if delete_dds:
        src.unlink()
        removed = True

    resize_desc = ""
    if source_size != (tw, th):
        resize_desc = f" {source_size[0]}x{source_size[1]}->{tw}x{th}"

    return (
        "OK",
        f"{settings['class']}{resize_desc} "
        f"canais={settings['components']} mips={len(encoded_mips)} "
        f"perfil={settings['profile']} {'sRGB' if settings['srgb'] else 'linear'}" +
        (f" {distance_note}" if distance_note else "") +
        (" | DDS_REMOVIDO" if removed else "")
    )

def find_roots(root):
    """
    NATIVE V6.1 FS22->FS23: sempre usa exatamente a pasta informada como raiz.

    A varredura recursiva acontece depois com os.walk(), portanto qualquer
    DDS dentro de subpastas e convertido, mesmo que nao exista modDesc.xml.
    Exemplos:
      /Download/Terrain/*.dds
      /Download/meuMapa/maps/.../*.dds
      /Download/meuMod/.../*.dds

    Isso evita o bug da V4 em que a existencia de um modDesc.xml em qualquer
    lugar de Download fazia pastas soltas serem ignoradas.
    """
    return [Path(root)]

def parse_args():
    parser = argparse.ArgumentParser(
        description="FS22 DDS -> FS23 AST V18 ARRAY AUTO RGBA16F (I3D terrain + mip seguro)"
    )
    parser.add_argument(
        "root", nargs="?", default=ROOT_DEFAULT,
        help="Pasta raiz. Padrão: /storage/emulated/0/Download"
    )
    parser.add_argument(
        "--overwrite", action="store_true",
        help="Sobrescreve AST existente"
    )
    parser.add_argument(
        "--keep-dds", action="store_true",
        help="Não apaga o DDS após conversão bem-sucedida"
    )
    parser.add_argument(
        "--workers", type=int, default=None,
        help="Quantidade de arquivos convertidos em paralelo (padrão automático)"
    )
    parser.add_argument(
        "--experimental-arrays", action="store_true",
        help="Gera candidatos GS2D para arrays 2/50 layers. Não apaga DDS; layout não validado no jogo."
    )
    parser.add_argument(
        "--verbose", action="store_true",
        help="Mostra uma linha para cada arquivo. Por padrão a V11 mostra só progresso e erros."
    )
    return parser.parse_args()


def main():
    args = parse_args()
    root = Path(args.root)
    overwrite = args.overwrite
    delete_dds = not args.keep_dds
    if args.experimental_arrays and not args.keep_dds:
        raise SystemExit("Segurança: --experimental-arrays exige --keep-dds (preserva originais).")

    if not root.exists():
        raise SystemExit(f"Raiz não existe: {root}")

    astcenc = find_astcenc()
    has_j = detect_astcenc_features(astcenc)

    workers = args.workers
    if workers is None:
        # Se conseguimos limitar cada astcenc a 1 thread, usamos paralelismo real.
        # Se não, ficamos conservadores para não abrir vários astcenc multithread ao mesmo tempo.
        workers = DEFAULT_WORKERS if has_j else 1
    workers = max(1, min(8, workers))

    print("====================================================")
    print(" FS23 DDS -> AST | GS2D v6 | ASTC 6x6 + RGBA16F | V18 ARRAY AUTO RGBA16F")
    print("====================================================")
    print("ASTC encoder   :", astcenc)
    print("Raiz           :", root)
    print("Qualidade      :", QUALITY)
    print("Mipmaps        : por classe nativa FS23 + terrain painting seguro para Medium/Low")
    print("Classes        : catálogo exato/terrain/ground/fillPlanes/foliage/UI/2DARRAY")
    print(
        "Catálogo FS23  :",
        len(NATIVE_PROFILE_CATALOG), "gerais +",
        len(MAP_TEXTURE_NATIVE_CATALOG), "texturas de mapa",
    )
    print("Mapas shared   : mapUS/mapFR/mapAlpine e qualquer outro caminho terrain")
    print("Varredura      : recursiva TOTAL")
    print("Workers        :", workers)
    print("astcenc -j 1   :", "sim" if has_j else "não detectado")
    print("DDS pós-sucesso:", "APAGAR" if delete_dds else "MANTER (--keep-dds)")
    print("NumPy normalmap:", "ativo" if np is not None else "fallback Python")
    print("Saída terminal :", "DETALHADA (--verbose)" if args.verbose else "OTIMIZADA")
    print("====================================================")

    i3d_layers = scan_i3d_terrain_layers(root)
    if i3d_layers:
        nd = sum(1 for v in i3d_layers.values() if v == "detail")
        nn = sum(1 for v in i3d_layers.values() if v == "normal")
        print(f"I3D terrain    : {len(i3d_layers)} DDS detectados (detail={nd}, normal={nn})")
    else:
        print("I3D terrain    : nenhuma layer DDS local detectada")

    dds_files = []
    for base, dirs, files in os.walk(root):
        # Evita reprocessar diretórios temporários acidentais.
        dirs[:] = [d for d in dirs if not d.startswith(".dds2ast_tmp")]
        for name in files:
            if name.lower().endswith(".dds"):
                dds_files.append(Path(base) / name)

    dds_files.sort()
    total = len(dds_files)
    if total == 0:
        print("Nenhum DDS encontrado.")
        return

    print(f"DDS encontrados : {total}")
    print("====================================================")

    ok = skip = errors = removed = 0
    class_counts = {}

    def job(dds):
        try:
            rel = dds.relative_to(root)
        except Exception:
            rel = dds
        status, text = convert_file(
            dds, astcenc, overwrite=overwrite, delete_dds=delete_dds,
            experimental_arrays=args.experimental_arrays
        )
        return dds, rel, status, text

    completed = 0
    progress_every = 25

    with ThreadPoolExecutor(max_workers=workers) as pool:
        future_map = {pool.submit(job, dds): dds for dds in dds_files}
        for fut in as_completed(future_map):
            dds = future_map[fut]
            completed += 1
            try:
                _dds, rel, status, text = fut.result()
                if status == "OK":
                    ok += 1
                    detected_class = text.split(" ", 1)[0]
                    class_counts[detected_class] = class_counts.get(detected_class, 0) + 1
                    if "DDS_REMOVIDO" in text:
                        removed += 1
                else:
                    skip += 1

                if args.verbose:
                    print(f"[{status}] {rel} | {text}")
                elif completed % progress_every == 0 or completed == total:
                    print(
                        f"[PROGRESSO] {completed}/{total} | "
                        f"OK={ok} PULADOS={skip} ERROS={errors}"
                    )
            except Exception as e:
                errors += 1
                try:
                    rel = dds.relative_to(root)
                except Exception:
                    rel = dds
                print(f"[ERRO] {rel} | {e}")

    print()
    print("====================================================")
    print("RESUMO V18 ARRAY AUTO RGBA16F")
    print("DDS encontrados        :", total)
    print("AST gerados            :", ok)
    print("DDS removidos          :", removed)
    print("Pulados                 :", skip)
    print("Erros / DDS preservados:", errors)
    if class_counts:
        print("Classes detectadas      :")
        for name, count in sorted(class_counts.items(), key=lambda item: (-item[1], item[0])):
            print(f"  {name}: {count}")
    print("====================================================")

    if errors:
        print("AVISO: arquivos com erro foram preservados; não assumir compatibilidade do pacote.")
        sys.exit(2)


if __name__ == "__main__":
    main()

"""Optional Android notification sink; inert on Termux/desktop."""
import json,time
_native=None
_checked=False
_last=0
_state=None
def notify(row):
 global _native,_checked,_last,_state
 if not _checked:
  _checked=True
  try:
   from java import jclass
   _native=jclass('br.com.gabrielmods.editor.ProgressActivity')
  except (ImportError,Exception):return
 if _native is None:return
 now=time.monotonic();state=(row['id'],row['state'],row['phase'])
 if state==_state and now-_last<.8:return
 _last=now;_state=state
 _native.textureProgress(json.dumps({k:row.get(k) for k in ('id','state','phase','percent','done','total','file','elapsed','error')},ensure_ascii=False))

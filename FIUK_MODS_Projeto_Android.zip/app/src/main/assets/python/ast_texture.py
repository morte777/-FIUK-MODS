"""Read-only GS2D v6 (ASTC/RGBA8) / standard ASTC textures. Originals never rewritten."""
import base64
import struct
import zlib

MAGIC=b'\x13\xab\xa1\x5c'
BLOCKS={(4,4),(5,4),(5,5),(6,5),(6,6),(8,5),(8,6),(8,8),(10,5),(10,6),(10,8),(10,10),(12,10),(12,12)}
def size(w,h,bx=6,by=6):return ((w+bx-1)//bx)*((h+by-1)//by)*16
def astc_file(w,h,bx,by,payload):
    return MAGIC+bytes([bx,by,1])+w.to_bytes(3,'little')+h.to_bytes(3,'little')+b'\x01\0\0'+payload

def _inflate(chunk,expected):
    # Uncompressed chunks are legal. Never inflate beyond the known size.
    try:
        d=zlib.decompressobj();raw=d.decompress(chunk,expected+1)
        if len(raw)==expected and d.eof and not d.unused_data:return raw
    except zlib.error:pass
    if len(chunk)==expected:return chunk
    raise ValueError('Chunk AST comprimido invalido ou tamanho inesperado.')

def decode(raw):
    if raw[:4]==MAGIC:
        if len(raw)<16:raise ValueError('ASTC truncado.')
        bx,by,bz=raw[4:7];w=int.from_bytes(raw[7:10],'little');h=int.from_bytes(raw[10:13],'little');depth=int.from_bytes(raw[13:16],'little')
        if (bx,by) not in BLOCKS or bz!=1 or depth!=1 or not 0<w<=16384 or not 0<h<=16384:
            raise ValueError('ASTC 2D nao suportado.')
        if len(raw)!=16+size(w,h,bx,by):raise ValueError('Payload ASTC truncado.')
        return {'width':w,'height':h,'blockX':bx,'blockY':by,'components':4,'levels':[(w,h,raw[16:])],'container':'ASTC','encoding':'astc'}
    if len(raw)<80 or raw[:4]!=b'GS2D':raise ValueError('Formato AST desconhecido: esperado GS2D ou ASTC.')
    v=struct.unpack('<4s12I16s3I',raw[:80])
    _,version,total,w,h,depth,cm,layers,profile,*_=v
    count=(cm>>16)+1;components=cm&65535
    format_id=v[-3]
    if version!=6 or depth!=1 or layers!=1 or v[-2:]!=(1,1) or format_id not in (5,34):
        raise ValueError(f'AST GS2D nao suportado: versao={version}, formato={format_id}, profundidade={depth}, camadas={layers}.')
    if format_id==5 and components!=4:raise ValueError('GS2D RGBA8 exige quatro componentes.')
    if not 0<w<=16384 or not 0<h<=16384 or not 1<=count<=15 or components not in (1,2,3,4):
        raise ValueError('Dimensoes ou mipmaps AST invalidos.')
    if len(raw)!=80+total:raise ValueError('Tamanho do arquivo AST incorreto.')
    sizes=v[9:13];chunks=[];offset=80
    for n in sizes:
        if not n:continue
        if offset+n>len(raw):raise ValueError('Chunk AST fora do arquivo.')
        chunks.append(raw[offset:offset+n]);offset+=(n+15)//16*16
    if offset!=len(raw) or len(chunks)!=min(count,4):raise ValueError('Tabela de chunks AST invalida.')
    dims=[(max(1,w>>i),max(1,h>>i)) for i in range(count)]
    lengths=[a*b*4 if format_id==5 else size(a,b) for a,b in dims]
    if format_id==5 and sum(lengths)>128*1024*1024:raise ValueError('GS2D RGBA8 acima do limite de pixels da previa.')
    decoded=[None]*count
    if count<=4:
        for i,c in enumerate(chunks):
            mip=count-1-i;decoded[mip]=_inflate(c,lengths[mip])
    else:
        tail=_inflate(chunks[0],sum(lengths[3:]));p=0
        for mip in range(3,count):decoded[mip]=tail[p:p+lengths[mip]];p+=lengths[mip]
        for c,mip in zip(chunks[1:],[2,1,0]):decoded[mip]=_inflate(c,lengths[mip])
    return {'width':w,'height':h,'blockX':6 if format_id==34 else 0,'blockY':6 if format_id==34 else 0,'components':components,'encoding':'astc' if format_id==34 else 'rgba8',
            'levels':[(a,b,c) for (a,b),c in zip(dims,decoded)],'container':'GS2D'}

def preview(raw,max_size=2048):
    texture=decode(raw);levels=texture.pop('levels');max_size=max(32,min(4096,int(max_size)))
    first=next((i for i,(w,h,data) in enumerate(levels) if max(w,h)<=max_size),len(levels)-1)
    selected=levels[first:]
    # WebGL1 NPOT compressed textures must clamp and omit mip filtering.
    w,h=selected[0][:2]
    pot=lambda x:x>0 and (x&(x-1))==0
    if not (pot(w) and pot(h)):selected=selected[:1]
    return {**texture,'width':w,'height':h,'sourceMip':first,'flipY':False,
        'levels':[{'width':a,'height':b,'data':base64.b64encode(c).decode('ascii')} for a,b,c in selected]}

def png_rgba(w,h,rgba):
    """Lossless local preview, with the original row and channel order."""
    if len(rgba)!=w*h*4:raise ValueError('Pixels RGBA8 com tamanho incorreto.')
    def chunk(kind,content):return struct.pack('>I',len(content))+kind+content+struct.pack('>I',zlib.crc32(kind+content)&0xffffffff)
    rows=b''.join(b'\0'+rgba[y*w*4:(y+1)*w*4] for y in range(h))
    return b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>2I5B',w,h,8,6,0,0,0))+chunk(b'IDAT',zlib.compress(rows,3))+chunk(b'IEND',b'')

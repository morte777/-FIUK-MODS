"""Read-only static assembly of FS22-style vehicle wheels from XML resources."""
import base64,copy,hashlib,math,posixpath,struct
import xml.etree.ElementTree as ET

PARTS=('tire','outerRim','innerRim','additional')

def number(value,default=0):
    try:
        v=float(value)
        return v if math.isfinite(v) and abs(v)<1e6 else default
    except (ValueError,TypeError):return default

def values(value,default):
    try:
        out=[float(x) for x in value.split()]
        return out if len(out)==len(default) and all(math.isfinite(v) and abs(v)<1e6 for v in out) else list(default)
    except (ValueError,AttributeError):return list(default)

def merge(base,override):
    result=copy.deepcopy(base);result.attrib.update(override.attrib)
    if override.text and override.text.strip():result.text=override.text
    seen={}
    for child in override:
        index=seen.get(child.tag,0);seen[child.tag]=index+1
        matching=[c for c in result if c.tag==child.tag]
        if child.get('id') is not None:
            matching=[c for c in matching if c.get('id')==child.get('id')];index=0
        if index<len(matching):
            old=matching[index];at=list(result).index(old);result.remove(old);result.insert(at,merge(old,child))
        else:result.append(copy.deepcopy(child))
    return result

def node_index(nodes,path,mappings=None):
    mappings=mappings or {};path=str(path or '')
    visited=set()
    while path in mappings:
        if path in visited:return None
        visited.add(path);path=mappings[path]
    children={None:[]}
    for node in nodes:children.setdefault(node['parent'],[]).append(node['index'])
    try:
        if '>' in path:
            first,rest=path.split('>',1);parts=[int(first)]+[int(p) for p in rest.split('|') if p!='']
        else:parts=[int(p) for p in path.split('|') if p!='']
        if not parts:return None
        parent=None
        for part in parts:
            if part<0:return None
            parent=children.get(parent,[])[part]
        return parent
    except (ValueError,IndexError):
        names=[n['index'] for n in nodes if n['name']==path]
        return names[0] if len(names)==1 else None

def rotated(v,rotation):
    x,y,z=v;rx,ry,rz=[a*math.pi/180 for a in rotation]
    y,z=y*math.cos(rx)-z*math.sin(rx),y*math.sin(rx)+z*math.cos(rx)
    x,z=x*math.cos(ry)+z*math.sin(ry),-x*math.sin(ry)+z*math.cos(ry)
    return [x*math.cos(rz)-y*math.sin(rz),x*math.sin(rz)+y*math.cos(rz),z]

def rim_geometry(mesh,material,width_diameter,vertex_range=None):
    """Bake the supplied vehicleShader's static RIM width/diameter deformation."""
    variation=material.get('variation','').lower()
    if not variation.startswith('rim') or 'dual' in variation:return mesh,False
    width,diam=[x*.0254 for x in width_diameter]
    if not mesh.get('positionsBase64'):return mesh,False
    positions=list(struct.unpack('<'+'f'*(len(base64.b64decode(mesh['positionsBase64']))//4),base64.b64decode(mesh['positionsBase64'])))
    color_raw=mesh.get('colorsBase64')
    colors=struct.unpack('<'+'f'*(len(base64.b64decode(color_raw))//4),base64.b64decode(color_raw)) if color_raw else None
    if not colors:return mesh,False
    statics=max(1,number(material.get('customParameters',{}).get('numberOfStatics',['4'])[0],4))
    discrete='numberofstatics' in variation
    for i in (vertex_range if vertex_range is not None else range(len(positions)//3)):
        x,y,z=positions[i*3:i*3+3];r,g,_,alpha=colors[i*4:i*4+4];length=math.hypot(y,z)
        if discrete and alpha<.5:
            step=2*math.pi/statics;angle=math.floor(math.atan2(y,z)/step+.5)*step
            dy,dz=math.sin(angle),math.cos(angle)
        else:dy,dz=(y/length,z/length) if length>1e-9 else (0,0)
        positions[i*3:i*3+3]=[x+(r-g)*(width*.5-.5),y+dy*(diam-1)*.5,z+dz*(diam-1)*.5]
    result=dict(mesh);result['positionsBase64']=base64.b64encode(struct.pack('<'+'f'*len(positions),*positions)).decode()
    result['bounds']=[[min(positions[a::3]) for a in range(3)],[max(positions[a::3]) for a in range(3)]]
    return result,True

class Assembly:
    def __init__(self,editor,scene,owner):
        self.editor=editor;self.scene=scene;self.owner=owner;self.base_owner=owner;self.assets={};self.errors=[];self.serial=0;self.main_count=len(scene['nodes']);self.mappings={}
        self.info={'configurations':[],'selected':0,'requested':0,'tiresLoaded':0,'rimsLoaded':0,'hubsLoaded':0,'parts':[],'missing':[],'wheels':[]}
    def resolve(self,reference,owner=None):
        return self.editor.resolve_resource(reference,self.base_owner) or (self.editor.resolve_resource(reference,owner) if owner else None)
    def xml(self,resource):
        from core import I3D
        return ET.fromstring(I3D(self.editor.read_resource(resource)).text)
    def vehicle(self):
        preferred=posixpath.splitext(self.owner)[0]+'.xml'
        candidates=[preferred]+[n for n in self.editor.archive_index()[0].values() if n.lower().endswith('.xml') and n!=preferred][:128]
        for name in candidates:
            try:
                root=self.xml(name)
                if root.tag!='vehicle':continue
                file=root.findtext('./base/filename')
                if file and self.editor.resolve_resource(file,name)!=self.owner:continue
                if not file and name!=preferred:continue
                if root.find('wheels') is not None:return name,root
            except (ValueError,OSError,KeyError,ET.ParseError):continue
        return None,None
    def configurations(self,wheels):
        configs=wheels.findall('./wheelConfigurations/wheelConfiguration')
        if not configs:
            default=ET.Element('wheelConfiguration',{'name':'Padrao'});default.append(copy.deepcopy(wheels));configs=[default]
        return configs
    def effective(self,configs,index,visited=None):
        visited=set() if visited is None else set(visited)
        if index in visited or len(visited)>16:raise ValueError('Ciclo na heranca das configuracoes de rodas.')
        visited.add(index);current=configs[index];w=current.find('wheels')
        base_id=w.get('baseConfig') if w is not None else None
        if base_id:
            parent=next((i for i,c in enumerate(configs) if c.get('saveId',str(i+1))==base_id),None)
            if parent is None:raise ValueError('Configuracao base das rodas nao encontrada: '+base_id)
            return merge(self.effective(configs,parent,visited),current)
        return copy.deepcopy(current)
    def paint(self,material,colors):
        rgba=copy.deepcopy(material.get('paletteRGBA',[[*c,0] for c in material.get('palette',[[.5,.5,.5]]*8)]))
        for index,value in colors.items():
            if value is None:continue
            rgba[index][:3]=value[:3]
            if len(value)>3:rgba[index][3]=value[3]
            material.setdefault('customParameters',{})['colorMat'+str(index)]=[str(x) for x in rgba[index]]
        material['paletteRGBA']=rgba;material['palette']=[c[:3] for c in rgba]
    def add_part(self,filename,index,parent,label,role,owner=None,offset=None,scale=None,rotation=None,width_diameter=None,colors=None):
        if not filename or filename=='-':return False
        resource=self.resolve(filename,owner)
        if not resource:self.errors.append(filename);return False
        try:
            if resource not in self.assets:self.assets[resource]=self.editor.scene(resource,include_wheels=False)
            asset=self.assets[resource];root=node_index(asset['nodes'],index)
            if root is None:raise ValueError('Indice '+str(index)+' nao encontrado em '+filename)
            keep=set();selected=[]
            for n in asset['nodes']:
                if n['index']==root or n['parent'] in keep:keep.add(n['index']);selected.append(n)
            if len(self.scene['nodes'])+len(selected)>50000:raise ValueError('Limite de nos da previa de rodas atingido.')
            self.serial+=1;prefix='wp'+str(self.serial)+':'
            mesh_prefix='wm'+hashlib.sha256(resource.encode()).hexdigest()[:12]+':'
            map_nodes={};map_materials={};drawable=0
            for original in selected:
                node=copy.deepcopy(original);node['index']=len(self.scene['nodes']);map_nodes[original['index']]=node['index']
                node['parent']=parent if original['index']==root else map_nodes[original['parent']]
                if original['index']==root:
                    node['name']=label+' · '+original['name']
                    if offset is not None:node['translation']=[offset,0,0]
                    if scale is not None:node['scale']=scale[:]
                    if rotation is not None:node['rotation']=rotation[:]
                node.update({'previewOnly':True,'sourceResource':resource,'sourceNode':original['index'],'wheelRole':role})
                ids=original.get('materialIds','').split();newids=[]
                for mid in ids:
                    newid=prefix+mid;newids.append(newid)
                    if newid not in map_materials:
                        material=copy.deepcopy(asset['materialDetails'].get(mid,{}))
                        if colors:self.paint(material,colors)
                        if width_diameter:material.setdefault('customParameters',{})['widthAndDiam']=[str(x) for x in width_diameter]+['0','0']
                        self.scene['materialDetails'][newid]=material;self.scene['materials'][newid]=asset['materials'].get(mid,[.5,.5,.5]);map_materials[newid]=material
                node['materialIds']=' '.join(newids)
                sid=original.get('shapeId');mesh=asset['meshes'].get(sid)
                if mesh:
                    key=mesh_prefix+sid
                    if width_diameter:
                        changed=False
                        # Smart-rim geometry uses its original vertex-color control points.
                        for subset_index,mid in enumerate(newids):
                            material=map_materials[mid]
                            if material.get('variation','').lower().startswith('rim'):
                                subset=mesh.get('subsets',[])[subset_index] if subset_index<len(mesh.get('subsets',[])) else None
                                vertices=range(subset['firstVertex'],subset['firstVertex']+subset['numVertices']) if subset else None
                                mesh,baked=rim_geometry(mesh,material,width_diameter,vertices);changed=changed or baked
                        if changed:key+=':'+str(width_diameter)
                        elif any(m.get('variation','').lower().startswith('rim') for m in map_materials.values()):
                            raise ValueError('Deformacao de aro nao suportada ou sem cores de vertices: '+filename)
                        else:
                            # Legacy normalized 1m rims without the smart-rim shader.
                            node['scale']=[width_diameter[0]*.0254,width_diameter[1]*.0254,width_diameter[1]*.0254]
                    node['shapeId']=key;self.scene['meshes'][key]=mesh
                    if not node.get('nonRenderable'):drawable+=1
                self.scene['nodes'].append(node)
            if not drawable:self.errors.append('Sem malha disponivel: '+filename)
            self.info['parts'].append({'role':role,'resource':resource,'node':index,'parent':parent,'nodes':len(selected),'meshes':drawable})
            return drawable>0
        except (ValueError,KeyError,OSError,ET.ParseError) as error:
            self.errors.append(str(error));return False
    def object_changes(self,config):
        for change in config.findall('objectChange'):
            index=node_index(self.scene['nodes'][:self.main_count],change.get('node'),self.mappings)
            if index is None:continue
            node=self.scene['nodes'][index]
            for attr,property in (('translationActive','translation'),('rotationActive','rotation'),('scaleActive','scale')):
                if change.get(attr) is not None:node[property]=values(change.get(attr),node[property]);node['previewDriven']=True
            if change.get('visibilityActive') is not None:node['visibility']=change.get('visibilityActive') not in ('false','0');node['previewDriven']=True
    def wheel_root(self,resource,visited=None):
        visited=set() if visited is None else set(visited)
        if resource in visited or len(visited)>16:raise ValueError('Ciclo em parentFile da roda.')
        visited.add(resource);root=self.xml(resource);parent=root.find('parentFile')
        if parent is not None and parent.get('xmlFilename'):
            ref=parent.get('xmlFilename');source=self.editor.resolve_resource(ref,resource) or self.resolve(ref,resource)
            if not source:raise ValueError('parentFile da roda nao encontrado: '+ref)
            root=merge(self.wheel_root(source,visited),root)
        return root
    def wheel_definition(self,wheel,vehicle_file):
        combined=ET.Element('default');filename=wheel.get('filename');source=vehicle_file
        if filename:
            source=self.resolve(filename,vehicle_file)
            if not source:raise ValueError('XML de roda ausente: '+filename)
            root=self.wheel_root(source);default=root.find('default')
            if default is not None:combined=copy.deepcopy(default)
            config_id=wheel.get('configId','default')
            if config_id!='default':
                config=next((c for c in root.findall('./configurations/configuration') if c.get('id')==config_id),None)
                if config is None:raise ValueError('configId '+config_id+' ausente em '+filename)
                combined=merge(combined,config)
        return merge(combined,wheel),source
    def hubs(self,wheels,vehicle_file):
        hubs=wheels.find('hubs')
        if hubs is None:return
        global_colors={i:self.color(hubs.findtext('color'+str(i))) for i in range(8)}
        for j,hub in enumerate(hubs.findall('hub')[:32]):
            parent=node_index(self.scene['nodes'][:self.main_count],hub.get('linkNode'),self.mappings)
            if parent is None:self.errors.append('Ponto de montagem do cubo nao encontrado: '+str(hub.get('linkNode')));continue
            try:
                resource=self.resolve(hub.get('filename'),vehicle_file)
                if not resource:raise ValueError('XML do cubo ausente: '+str(hub.get('filename')))
                xml=self.xml(resource);nodes=xml.find('nodes');left=hub.get('isLeft','true') not in ('false','0')
                index=nodes.get('left' if left else 'right','0|0') if nodes is not None else '0|0'
                colors={i:global_colors[i] or self.color(xml.findtext('color'+str(i))) for i in range(8)}
                scale=values(hub.get('scale') or xml.findtext('scale'),[1,1,1])
                offset=number(hub.get('offset'))*(1 if left else -1) if hub.get('offset') is not None else None
                if self.add_part(xml.findtext('filename'),index,parent,'Cubo '+str(j+1),'hub',resource,offset,scale,colors=colors):self.info['hubsLoaded']+=1
            except (ValueError,OSError,KeyError,ET.ParseError) as error:self.errors.append(str(error))
    @staticmethod
    def color(text):
        if not text:return None
        raw=text.split()
        if len(raw) not in (3,4):return None
        try:
            result=[float(v) for v in raw]
            return result if all(math.isfinite(v) for v in result) else None
        except ValueError:return None
    def run(self,index):
        vehicle_file,vehicle=self.vehicle()
        if vehicle is None:return
        self.base_owner=vehicle_file
        wheels=vehicle.find('wheels');configs=self.configurations(wheels)
        self.info['configurations']=[{'index':i,'name':({'$l10n_configuration_valueDefault':'Padrao','$l10n_configuration_valueWheelBroad':'Largos'}.get(c.get('name'),c.get('name','Padrao'))),'brand':c.get('brand',''),'saveId':c.get('saveId',str(i+1))} for i,c in enumerate(configs)]
        index=max(-1,min(len(configs)-1,int(index)));self.info['selected']=index;self.info['vehicleXml']=vehicle_file
        self.scene['wheelInfo']=self.info
        if index<0:return
        self.mappings={m.get('id'):m.get('node','') for m in vehicle.findall('./i3dMappings/i3dMapping')}
        try:config=self.effective(configs,index)
        except ValueError as error:self.errors.append(str(error));self.finish();return
        self.object_changes(config)
        wheel_list=config.findall('./wheels/wheel')[:32];self.info['requested']=len(wheel_list)
        rim_color=self.color(wheels.findtext('rimColor'))
        for i,wheel in enumerate(wheel_list):
            try:
                definition,source=self.wheel_definition(wheel,vehicle_file);physics=definition.find('physics')
                if physics is None:raise ValueError('Roda sem physics: '+str(i+1))
                anchor=node_index(self.scene['nodes'][:self.main_count],physics.get('driveNode') or physics.get('repr'),self.mappings)
                if anchor is None:raise ValueError('Ponto da roda nao encontrado: '+str(physics.get('repr')))
                repr_index=node_index(self.scene['nodes'][:self.main_count],physics.get('repr'),self.mappings)
                edit_anchor=repr_index if repr_index is not None else anchor
                self.info['wheels'].append({'index':i,'left':definition.get('isLeft','true') not in ('false','0'),'anchor':edit_anchor,'driveAnchor':anchor,'position':self.scene['nodes'][edit_anchor]['translation'][:],'radius':number(physics.get('radius'),.5),'width':number(physics.get('width'),.3),'filename':wheel.get('filename',''),'configId':wheel.get('configId','default'),'dualCount':len(definition.findall('additionalWheel')),'parts':{role:dict(definition.find(role).attrib) for role in PARTS if definition.find(role) is not None}})
                start_nodes=len(self.scene['nodes'])
                node=self.scene['nodes'][anchor];yoffset=number(physics.get('yOffset'))
                if yoffset:
                    delta=rotated([0,yoffset*node['scale'][1],0],node['rotation']);node['translation']=[a+b for a,b in zip(node['translation'],delta)];node['previewDriven']=True
                parent=node_index(self.scene['nodes'][:self.main_count],physics.get('linkNode'),self.mappings) if physics.get('linkNode') else anchor
                if parent is None:parent=anchor
                left=definition.get('isLeft','true') not in ('false','0');side=1 if left else -1
                for role in PARTS:
                    part=definition.find(role)
                    if part is None:continue
                    index_str=part.get('node') or part.get('nodeLeft' if left else 'nodeRight','0|0')
                    offset=number(part.get('offset'))*side if part.get('offset') is not None else None
                    scale=values(part.get('scale'),[1,1,1]) if part.get('scale') is not None else None
                    dim=values(part.get('widthAndDiam'),[0,0]) if part.get('widthAndDiam') else None
                    if dim and not all(v>0 for v in dim):raise ValueError('Dimensoes invalidas de aro.')
                    rotation=[number(definition.get('xRotOffset')),0,180 if part.get('isInverted',definition.get('isInverted')) in ('true','1') else 0] if role=='tire' else None
                    color=self.color(definition.get('color')) or rim_color
                    colors={0:color} if role!='tire' and color else None
                    if self.add_part(part.get('filename'),index_str,parent,'Roda '+str(i+1)+' '+role,role,source,offset,scale,rotation,dim,colors):
                        if role=='tire':self.info['tiresLoaded']+=1
                        elif role in ('outerRim','innerRim'):self.info['rimsLoaded']+=1
                for added in self.scene['nodes'][start_nodes:]:added['wheelIndex']=i
                if definition.findall('additionalWheel'):self.duals(definition,parent,vehicle_file,i,self.color(definition.get('color')) or rim_color)
            except (ValueError,KeyError,OSError,ET.ParseError) as error:self.errors.append(str(error))
        self.hubs(wheels,vehicle_file)
        for added in self.scene['nodes'][self.main_count:]:
            if added.get('wheelRole')=='hub':
                row=next((r for r in self.info['wheels'] if added['parent'] in (r['anchor'],r['driveAnchor'])),None)
                if row:added['wheelIndex']=row['index']
        self.finish()
    def duals(self,definition,parent,vehicle_file,wheel_index,default_color):
        base_rim=definition.find('outerRim');base_physics=definition.find('physics')
        base_width=values(base_rim.get('widthAndDiam'),[0,0])[0]*.0254 if base_rim is not None and base_rim.get('widthAndDiam') else number(base_physics.get('width'),.5)
        for j,additional in enumerate(definition.findall('additionalWheel')[:4]):
            try:
                element=copy.deepcopy(additional);element.tag='wheel'
                if element.get('isLeft') is None:element.set('isLeft',definition.get('isLeft','true'))
                dual,source=self.wheel_definition(element,vehicle_file);left=dual.get('isLeft','true') not in ('false','0');side=1 if left else -1
                rim=dual.find('outerRim');physics=dual.find('physics');width=values(rim.get('widthAndDiam'),[0,0])[0]*.0254 if rim is not None and rim.get('widthAndDiam') else number(physics.get('width'),.5)
                shift=(base_width*.5+number(additional.get('offset'))+width*.5)*side
                start=len(self.scene['nodes'])
                for role in PARTS:
                    part=dual.find(role)
                    if part is None:continue
                    node=part.get('node') or part.get('nodeLeft' if left else 'nodeRight','0|0');offset=shift+number(part.get('offset'))*side
                    scale=values(part.get('scale'),[1,1,1]) if part.get('scale') else None;dim=values(part.get('widthAndDiam'),[0,0]) if part.get('widthAndDiam') else None
                    rotation=[number(dual.get('xRotOffset')),0,180 if dual.get('isInverted') in ('true','1') else 0] if role=='tire' else None
                    color=self.color(dual.get('color')) or default_color
                    self.add_part(part.get('filename'),node,parent,'Roda '+str(wheel_index+1)+' dupla '+str(j+1)+' '+role,role,source,offset,scale,rotation,dim,{0:color} if role!='tire' and color else None)
                for n in self.scene['nodes'][start:]:n.update({'wheelIndex':wheel_index,'additionalWheel':j})
                self.info['additionalTires']=self.info.get('additionalTires',0)+1
                if additional.find('connector') is not None:self.errors.append('Conector especial de roda dupla ainda sem previa; XML preservado.')
            except (ValueError,KeyError,OSError,ET.ParseError) as error:self.errors.append(str(error))
    def finish(self):
        self.info['missing']=sorted(set(self.errors));self.info['generatedNodes']=len(self.scene['nodes'])-self.main_count
        resources=set();missing=set(self.scene['textureInfo']['missing']);formats=dict(self.scene['textureInfo'].get('formats',{}))
        for material in self.scene['materialDetails'].values():
            for role,path in material.get('maps',{}).items():
                if path:resources.add(path)
                elif material.get('sourceMaps',{}).get(role):missing.add(material['sourceMaps'][role])
        for asset in self.assets.values():formats.update(asset['textureInfo'].get('formats',{}))
        self.scene['textureInfo'].update({'resources':sorted(resources),'missing':sorted(missing),'formats':formats,'fromBase':sum(p.startswith('base:') for p in resources)})
        self.scene['warnings']=[w for w in self.scene['warnings'] if not (w.split(' ',1)[0].isdigit() and 'texturas referenciadas' in w)]
        if missing:self.scene['warnings'].append(str(len(missing))+' texturas referenciadas nao foram encontradas no mod nem na base selecionada.')
        if self.errors:self.scene['warnings'].append('Previa de rodas: '+str(len(set(self.errors)))+' recursos/etapas indisponiveis. Veja RODAS para os detalhes.')

def assemble(editor,scene,owner,index=0):
    Assembly(editor,scene,owner).run(index)

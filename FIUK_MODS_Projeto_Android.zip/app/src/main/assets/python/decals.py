"""Decal geometry and lossless GS2D RGBA8 textures; existing mesh records preserved."""
import hashlib,math,posixpath,re,struct,zlib
from xml.parsers import expat
from xml.sax.saxutils import quoteattr

MAX_PNG=8*1024*1024

def png_pixels(raw):
    if not raw.startswith(b'\x89PNG\r\n\x1a\n') or len(raw)>MAX_PNG:raise ValueError('Escolha um PNG de ate 8 MB.')
    offset=8;payload=[];header=None;ended=False
    while offset+12<=len(raw):
        n=struct.unpack('>I',raw[offset:offset+4])[0];kind=raw[offset+4:offset+8];end=offset+12+n
        if end>len(raw):raise ValueError('PNG truncado.')
        data=raw[offset+8:offset+8+n]
        if zlib.crc32(kind+data)&0xffffffff!=struct.unpack('>I',raw[end-4:end])[0]:raise ValueError('PNG com CRC invalido.')
        if kind==b'IHDR':
            if header is not None or n!=13:raise ValueError('Cabecalho PNG invalido.')
            header=struct.unpack('>2I5B',data)
        elif kind==b'IDAT':payload.append(data)
        elif kind==b'IEND':ended=True;break
        offset=end
    if not header or not ended:raise ValueError('PNG incompleto.')
    w,h,depth,color,compression,filtering,interlace=header
    if not (0<w<=1024 and 0<h<=1024) or depth!=8 or color not in (2,6) or compression or filtering or interlace:
        raise ValueError('PNG deve ser RGB/RGBA 8 bits, sem entrelacamento, ate 1024 px. Importe pelo painel Plotagem.')
    channels=4 if color==6 else 3;stride=w*channels;expected=(stride+1)*h
    d=zlib.decompressobj();scan=d.decompress(b''.join(payload),expected+1)
    if len(scan)!=expected or not d.eof or d.unused_data:raise ValueError('Pixels PNG invalidos.')
    rows=[];previous=bytearray(stride)
    def paeth(a,b,c):
        p=a+b-c;pa,pb,pc=abs(p-a),abs(p-b),abs(p-c)
        return a if pa<=pb and pa<=pc else b if pb<=pc else c
    for y in range(h):
        start=y*(stride+1);f=scan[start];row=bytearray(scan[start+1:start+1+stride])
        if f>4:raise ValueError('Filtro PNG invalido.')
        for i in range(stride):
            a=row[i-channels] if i>=channels else 0;b=previous[i];c=previous[i-channels] if i>=channels else 0
            predictor=(0,a,b,(a+b)//2,paeth(a,b,c))[f];row[i]=(row[i]+predictor)&255
        rows.append(bytes(row) if channels==4 else b''.join(row[i:i+3]+b'\xff' for i in range(0,stride,3)));previous=row
    return w,h,b''.join(rows)

def power_of_two_rgba(w,h,pixels):
    """Resample the complete UV image, without padding or changing geometry.

    Each axis rounds up independently: the bitmap aspect can change, but the
    complete image still maps to the same UV rectangle on the unchanged mesh.
    Premultiplied-alpha interpolation avoids fringes around transparent logos.
    """
    if type(w)!=int or type(h)!=int or not 0<w<=1024 or not 0<h<=1024 or len(pixels)!=w*h*4:
        raise ValueError('Pixels RGBA8 invalidos ou acima de 1024 px.')
    nw,nh=1<<(w-1).bit_length(),1<<(h-1).bit_length()
    if (nw,nh)==(w,h):return w,h,pixels
    def axis(old,new):
        result=[]
        for i in range(new):
            at=max(0,min(old-1,(i+.5)*old/new-.5));lo=int(at)
            result.append((lo,min(old-1,lo+1),at-lo))
        return result
    xs,ys=axis(w,nw),axis(h,nh);out=bytearray(nw*nh*4)
    for y,(y0,y1,fy) in enumerate(ys):
        for x,(x0,x1,fx) in enumerate(xs):
            samples=((4*(y0*w+x0),(1-fx)*(1-fy)),(4*(y0*w+x1),fx*(1-fy)),
                     (4*(y1*w+x0),(1-fx)*fy),(4*(y1*w+x1),fx*fy))
            weights=[(i,weight*pixels[i+3]) for i,weight in samples]
            alpha=sum(weight for _,weight in weights);j=4*(y*nw+x)
            for c in range(3):out[j+c]=max(0,min(255,round(sum(pixels[i+c]*weight for i,weight in weights)/alpha))) if alpha else 0
            out[j+3]=max(0,min(255,round(alpha)))
    return nw,nh,bytes(out)

def gs2d_rgba(w,h,pixels):
    w,h,pixels=power_of_two_rgba(w,h,pixels)
    # Engine textures use bottom-up rows; standard PNG uses top-down rows.
    pixels=b''.join(pixels[y*w*4:(y+1)*w*4] for y in range(h-1,-1,-1));levels=[pixels];width,height=w,h
    while width>1 or height>1:
        nw,nh=max(1,width//2),max(1,height//2);out=bytearray(nw*nh*4)
        for y in range(nh):
            for x in range(nw):
                samples=[(yy*width+xx)*4 for yy in range(y*height//nh,(y+1)*height//nh) for xx in range(x*width//nw,(x+1)*width//nw)]
                alpha=sum(pixels[i+3] for i in samples);j=(y*nw+x)*4
                for c in range(3):out[j+c]=round(sum(pixels[i+c]*pixels[i+3] for i in samples)/alpha) if alpha else 0
                out[j+3]=round(alpha/len(samples))
        pixels=bytes(out);levels.append(pixels);width,height=nw,nh
    chunks=list(reversed(levels)) if len(levels)<=4 else [b''.join(levels[3:]),levels[2],levels[1],levels[0]]
    chunks=[min((c,zlib.compress(c,6)),key=len) for c in chunks];sizes=[len(c) for c in chunks]+[0]*(4-len(chunks))
    data=b''.join(c+b'\0'*((-len(c))%16) for c in chunks)
    return struct.pack('<4s12I16s3I',b'GS2D',6,len(data),w,h,1,((len(levels)-1)<<16)|4,1,4,*sizes,hashlib.md5(data).digest(),5,1,1)+data

def generated_texture(name):
    parts=name.replace('\\','/').lower().split('/')
    return bool(parts and parts[-1].endswith('.ast') and (
        ('gabriel_plotagens' in parts[:-1] and parts[-1].startswith('adesivo_')) or
        ('gabriel_texturas' in parts[:-1] and parts[-1]=='pintura.ast')))

def repair_generated_texture(raw):
    """Upgrade legacy editor RGBA8 ASTs only; leave unknown formats untouched."""
    if len(raw)<80 or len(raw)>8*1024*1024 or raw[:4]!=b'GS2D':return raw
    w,h=struct.unpack_from('<2I',raw,12)
    if not 0<w<=1024 or not 0<h<=1024 or (w&(w-1)==0 and h&(h-1)==0):return raw
    from ast_texture import decode
    try:texture=decode(raw)
    except ValueError:return raw
    if texture['encoding']!='rgba8':return raw
    pixels=texture['levels'][0][2]
    pixels=b''.join(pixels[y*w*4:(y+1)*w*4] for y in range(h-1,-1,-1))
    return gs2d_rgba(w,h,pixels)

def spans(text):
    """Capture whole element bounds without serializing/reformatting the XML."""
    raw=text.encode('utf-8');stack=[];elements=[];parser=expat.ParserCreate('UTF-8')
    def start(tag,attrs):
        at=parser.CurrentByteIndex;end=at;quote=None
        while end<len(raw):
            c=raw[end]
            if quote:
                if c==quote:quote=None
            elif c in (34,39):quote=c
            elif c==62:break
            end+=1
        item={'tag':tag,'local':tag.rsplit(':',1)[-1],'attrs':attrs,'start':at,'openEnd':end+1,'empty':raw[at:end].rstrip().endswith(b'/'),'depth':len(stack)}
        stack.append(item);elements.append(item)
    def end(tag):
        item=stack.pop();item['close']=item['openEnd'] if item['empty'] else parser.CurrentByteIndex
    parser.StartElementHandler=start;parser.EndElementHandler=end;parser.Parse(raw,True)
    return raw,elements

def append_element(raw,item,child):
    if item['empty']:
        prefix=raw[item['start']:item['openEnd']];prefix=re.sub(br'/\s*>$',b'>',prefix)
        return raw[:item['start']]+prefix+child+b'</'+item['tag'].encode()+b'>'+raw[item['openEnd']:]
    return raw[:item['close']]+child+raw[item['close']:]

def add_xml(document,parent,texture,width,height,translation,rotation,label,used_shapes=(),binary=False,mesh=None):
    raw,elements=spans(document.text)
    def next_id(attr):return str(max([int(e['attrs'][attr]) for e in elements if e['attrs'].get(attr,'').isdigit()]+[0])+1)
    sid,mid,fid,nid=(next_id(a) for a in ('shapeId','materialId','fileId','nodeId'))
    sid=str(max([int(sid)-1]+list(used_shapes))+1)
    # IDs include scene references as well as binary shape declarations.
    q=lambda s:quoteattr(str(s));nums=lambda v:' '.join(format(x,'.8g') for x in v)
    label='Plotagem '+label[:60]
    node=(f'<Shape name={q(label)} shapeId={q(sid)} materialIds={q(mid)} nodeId={q(nid)} translation={q(nums(translation))} rotation={q(nums(rotation))} castsShadows="false" receiveShadows="true"/>').encode()
    parent_span=document.spans[parent];target=next(e for e in elements if e['start']==parent_span[0]);raw=append_element(raw,target,node)
    from surface_decal import flat_mesh
    mesh=mesh or flat_mesh(width,height)
    center,radius=mesh_bounds(mesh)
    shape=f'<IndexedTriangleSet name={q(label)} shapeId={q(sid)} bvCenter={q(nums(center))} bvRadius={q(radius)}><Vertices count={q(len(mesh["positions"]))} normal="true" uv0="true">'
    shape+=''.join(f'<v p={q(nums(p))} n={q(nums(n))} t0={q(" ".join(format(x,".8g") for x in uv))}/>' for p,n,uv in zip(mesh['positions'],mesh['normals'],mesh['uvs']))
    shape+=f'</Vertices><Triangles count={q(len(mesh["indices"])//3)}>'
    shape+=''.join(f'<t vi={q(" ".join(str(x) for x in mesh["indices"][i:i+3]))}/>' for i in range(0,len(mesh['indices']),3))
    shape+=f'</Triangles><Subsets count="1"><Subset firstVertex="0" numVertices={q(len(mesh["positions"]))} firstIndex="0" numIndices={q(len(mesh["indices"]))}/></Subsets></IndexedTriangleSet>'
    if binary:shape=''
    children={'Files':f'<File fileId={q(fid)} filename={q(texture)} relativePath="true"/>',
              'Materials':f'<Material name={q(label)} materialId={q(mid)} diffuseColor="1 1 1 1" specularColor="0 0 0" alphaBlending="true" alphaTesting="true" doubleSided="true"><Texture fileId={q(fid)}/></Material>',
              'Shapes':shape}
    for section,child in children.items():
        _,updated=spans(raw.decode('utf-8'));item=next((e for e in updated if e['depth']==1 and e['local']==section),None)
        if item:raw=append_element(raw,item,child.encode())
        else:
            order=['Files','Materials','Shapes','Dynamics','Scene','Animation','UserAttributes']
            following=next((e for e in updated if e['depth']==1 and e['local'] in order and order.index(e['local'])>order.index(section)),None)
            at=following['start'] if following else updated[0]['close']
            raw=raw[:at]+f'<{section}>{child}</{section}>'.encode()+raw[at:]
    return raw.decode('utf-8').encode(document.encoding,errors='xmlcharrefreplace'),nid

def append_binary_mesh(raw,shape_id,mesh):
    """Append one native entity; retain all existing encrypted entity bytes verbatim."""
    from codecs_vendor import shapes_cipher as cipher
    if len(raw)<8:raise ValueError('Arquivo de malhas incompleto.')
    version,seed,offset=cipher.read_header(raw)
    if version not in (4,5,6,7):raise ValueError('Plotagem binaria suporta .shapes de versao 4 a 7.')
    count=struct.unpack('<i',cipher.process(raw[offset:offset+4],seed,0))[0]
    if not 0<=count<100000:raise ValueError('Contagem de malhas invalida.')
    pos=offset+4;block=1
    for _ in range(count):
        if pos+8>len(raw):raise ValueError('Arquivo de malhas truncado.')
        # Kind occupies one cipher block. Payload size occupies the next block.
        length=struct.unpack('<i',cipher.process(raw[pos+4:pos+8],seed,block+1))[0]
        if length<0 or pos+8+length>len(raw):raise ValueError('Entidade de malha invalida.')
        pos+=8+length;block+=2+(length+63)//64
    if pos!=len(raw):raise ValueError('Dados adicionais fora das entidades de malha.')
    name=b'GabrielDecal';blob=struct.pack('<i',len(name))+name;blob+=b'\0'*((-len(blob))%4)
    center,radius=mesh_bounds(mesh);vertices=len(mesh['positions']);corners=len(mesh['indices'])
    blob+=struct.pack('<I4f4I',int(shape_id),*center,radius,corners,1,vertices,3)
    blob+=struct.pack('<4I',0,vertices,0,corners)
    if version>=6:blob+=struct.pack('<f',1)
    blob+=struct.pack('<'+('I' if vertices>65536 else 'H')*corners,*mesh['indices']);blob+=b'\0'*((-len(blob))%4)
    for key in ('positions','normals','uvs'):
        values=[v for row in mesh[key] for v in row];blob+=struct.pack('<'+'f'*len(values),*values)
    blob+=struct.pack('<I',0)
    tail=cipher.process(struct.pack('<i',1),seed,block)+cipher.process(struct.pack('<i',len(blob)),seed,block+1)+cipher.process(blob,seed,block+2)
    return raw[:offset]+cipher.process(struct.pack('<i',count+1),seed,0)+raw[offset+4:]+tail

def replace_external(document,reference):
    raw,elements=spans(document.text)
    item=next(e for e in elements if e['depth']==1 and e['local']=='Shapes')
    tag=raw[item['start']:item['openEnd']].decode('utf-8')
    attrs=re.finditer(r'([\w:.-]+)(\s*=\s*)([\"\'])(.*?)\3',tag,re.S)
    match=next(m for m in attrs if m.group(1)=='externalShapesFile')
    tag=tag[:match.start()]+match.group(1)+match.group(2)+quoteattr(reference)+tag[match.end():]
    text=(raw[:item['start']]+tag.encode()+raw[item['openEnd']:]).decode('utf-8')
    return text.encode(document.encoding,errors='xmlcharrefreplace')


def mesh_bounds(mesh):
    p=mesh['positions'];lo=[min(v[k] for v in p) for k in range(3)];hi=[max(v[k] for v in p) for k in range(3)]
    center=[(a+b)/2 for a,b in zip(lo,hi)]
    return center,max(math.sqrt(sum((x-c)**2 for x,c in zip(v,center))) for v in p)

def append_binary_quad(raw,shape_id,width,height):
    from surface_decal import flat_mesh
    return append_binary_mesh(raw,shape_id,flat_mesh(width,height))

def append_inline_mesh(document,shape_id,mesh):
    raw,elements=spans(document.text);section=next(e for e in elements if e['depth']==1 and e['local']=='Shapes')
    q=lambda v:quoteattr(str(v));nums=lambda v:' '.join(format(x,'.8g') for x in v)
    center,radius=mesh_bounds(mesh)
    child=f'<IndexedTriangleSet name="GabrielDecal" shapeId={q(shape_id)} bvCenter={q(nums(center))} bvRadius={q(radius)}><Vertices count={q(len(mesh["positions"]))} normal="true" uv0="true">'
    child+=''.join(f'<v p={q(nums(p))} n={q(nums(n))} t0={q(nums(uv))}/>' for p,n,uv in zip(mesh['positions'],mesh['normals'],mesh['uvs']))
    child+=f'</Vertices><Triangles count={q(len(mesh["indices"])//3)}>'
    child+=''.join(f'<t vi={q(" ".join(str(x) for x in mesh["indices"][i:i+3]))}/>' for i in range(0,len(mesh['indices']),3))
    child+=f'</Triangles><Subsets count="1"><Subset firstVertex="0" numVertices={q(len(mesh["positions"]))} firstIndex="0" numIndices={q(len(mesh["indices"]))}/></Subsets></IndexedTriangleSet>'
    return append_element(raw,section,child.encode()).decode().encode(document.encoding,errors='xmlcharrefreplace')

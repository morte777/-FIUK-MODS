"""Portable project backups, including history; never overwrite existing projects."""
import hashlib,json,re,shutil,tempfile,uuid,zipfile
from pathlib import Path,PurePosixPath

ID=re.compile(r'[0-9a-f]{32}')

def backup(editor,destination):
    with editor.lock,zipfile.ZipFile(destination,'w',zipfile.ZIP_DEFLATED,allowZip64=True) as z:
        z.writestr('gabriel_backup.json',json.dumps({'format':1,'editor':26}))
        for folder in sorted(editor.directory.iterdir()):
            if not folder.is_dir() or not (ID.fullmatch(folder.name) or folder.name=='pecas_salvas'):continue
            for path in sorted(folder.rglob('*')):
                if path.is_file() and not path.is_symlink() and path.name not in ('export.zip',) and not path.name.endswith('.tmp'):
                    z.write(path,path.relative_to(editor.directory).as_posix())
        if (editor.directory/'last.json').is_file():z.write(editor.directory/'last.json','last.json')
    return str(destination)

def restore(editor,source):
    from core import atomic,jsonbytes
    with editor.lock,tempfile.TemporaryDirectory(prefix='restaurar_',dir=editor.directory) as tmp:
        temp=Path(tmp);count=0;first=None;prepared=[]
        with zipfile.ZipFile(source) as z:
            infos=z.infolist()
            if len(infos)>250000 or sum(i.file_size for i in infos)>16*1024**3:raise ValueError('Backup acima do limite de 16 GB ou arquivos demais.')
            seen=set()
            for info in infos:
                p=PurePosixPath(info.filename)
                if p.is_absolute() or '..' in p.parts or '\\' in info.filename or '\0' in info.filename:raise ValueError('Caminho invalido no backup.')
                if info.filename in seen:raise ValueError('Arquivo duplicado no backup.')
                seen.add(info.filename)
                if not p.parts or not (ID.fullmatch(p.parts[0]) or p.parts[0]=='pecas_salvas'):continue
                if info.is_dir():continue
                if len(p.parts)<2 or p.name=='export.zip' or p.name.endswith('.tmp'):continue
                target=temp.joinpath(*p.parts);target.parent.mkdir(parents=True,exist_ok=True)
                with z.open(info) as src,target.open('wb') as dst:shutil.copyfileobj(src,dst,1024*1024)
            for folder in temp.iterdir():
                if not folder.is_dir() or not ID.fullmatch(folder.name):continue
                meta=json.loads((folder/'project.json').read_text())
                if not isinstance(meta.get('name'),str) or not isinstance(meta.get('overrides'),dict):raise ValueError('Projeto invalido no backup.')
                with zipfile.ZipFile(folder/'original.zip') as original:
                    if len(original.infolist())>100000:raise ValueError('Mod com arquivos demais.')
                    for name in list(meta['overrides'])+original.namelist():
                        p=PurePosixPath(name)
                        if p.is_absolute() or '..' in p.parts or '\\' in name:raise ValueError('Caminho invalido no projeto.')
                removed_lists=[meta.get('deleted',[])]+[op.get(key,[]) for op in meta.get('undo',[])+meta.get('redo',[]) for key in ('deletedBefore','deletedAfter')]
                for removed in removed_lists:
                    if not isinstance(removed,list) or len(removed)>100000:raise ValueError('Lista de exclusao invalida no backup.')
                    for name in removed:
                        if not isinstance(name,str) or not name:raise ValueError('Arquivo excluido invalido no backup.')
                        p=PurePosixPath(name)
                        if p.is_absolute() or '..' in p.parts or '\\' in name:raise ValueError('Caminho excluido invalido no backup.')
                hashes=set(meta['overrides'].values())
                for op in meta.get('undo',[])+meta.get('redo',[]):
                    for change in op.get('files',[op]):
                        name=change.get('file');p=PurePosixPath(name or '')
                        if not name or p.is_absolute() or '..' in p.parts or '\\' in name:raise ValueError('Caminho invalido no historico.')
                        hashes.update(v for v in (change.get('before'),change.get('after')) if v)
                for digest in hashes:
                    if not isinstance(digest,str) or not re.fullmatch('[0-9a-f]{64}',digest):raise ValueError('Historico invalido.')
                    path=folder/'blobs'/digest
                    h=hashlib.sha256()
                    with path.open('rb') as f:
                        for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
                    if h.hexdigest()!=digest:raise ValueError('Arquivo do historico corrompido.')
                identifier=folder.name if not (editor.directory/folder.name).exists() else uuid.uuid4().hex
                prepared.append((folder,editor.directory/identifier));first=first or identifier
            library=temp/'pecas_salvas'
            if library.is_dir():
                for meta_path in library.glob('*.json'):
                    identifier=meta_path.stem
                    if not ID.fullmatch(identifier):continue
                    item=json.loads(meta_path.read_text());piece=library/(identifier+'.zip')
                    if item.get('id')!=identifier or not piece.is_file():raise ValueError('Conjunto salvo invalido no backup.')
                    with zipfile.ZipFile(piece) as check:
                        if len(check.infolist())>100000:raise ValueError('Conjunto com arquivos demais.')
                    target=editor.directory/'pecas_salvas';new_id=identifier
                    if (target/(new_id+'.json')).exists() or (target/(new_id+'.zip')).exists():new_id=uuid.uuid4().hex
                    item['id']=new_id;meta_path.write_bytes(jsonbytes(item));target.mkdir(exist_ok=True)
                    prepared.extend(((meta_path,target/(new_id+'.json')),(piece,target/(new_id+'.zip'))))
        if not prepared:raise ValueError('Nenhum projeto encontrado. Escolha um backup ou a pasta projetos do editor.')
        moved=[]
        try:
            for folder,target in prepared:
                folder.rename(target);moved.append(target)
                if target.is_dir():count+=1
        except Exception:
            for target in moved:
                if target.is_dir():shutil.rmtree(target,ignore_errors=True)
                else:target.unlink(missing_ok=True)
            raise
        if not editor.project and first:
            editor.project=editor.directory/first;atomic(editor.directory/'last.json',jsonbytes({'project':first}))
        return count

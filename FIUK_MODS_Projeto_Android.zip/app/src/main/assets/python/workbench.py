"""Persistent projects/accessories, resource checks and precise alignment."""
import itertools,json,math,posixpath,re,shutil,time,uuid,xml.etree.ElementTree as ET
from pathlib import Path
from core import I3D,atomic,jsonbytes
from scene_tools import label

def projects(editor):
    rows=[]
    for path in editor.directory.glob('*/project.json'):
        if not re.fullmatch('[0-9a-f]{32}',path.parent.name):continue
        try:
            m=json.loads(path.read_text());rows.append({'id':path.parent.name,'name':m['name'],'revision':m['revision'],'modified':path.stat().st_mtime,'current':path.parent==editor.project})
        except (ValueError,KeyError,OSError):continue
    return sorted(rows,key=lambda r:r['modified'],reverse=True)
def open_project(editor,identifier):
    with editor.lock:
        if not isinstance(identifier,str) or not re.fullmatch('[0-9a-f]{32}',identifier):raise ValueError('Projeto invalido.')
        path=editor.directory/identifier
        if not (path/'project.json').is_file() or not (path/'original.zip').is_file():raise ValueError('Projeto nao encontrado.')
        json.loads((path/'project.json').read_text())
        atomic(editor.directory/'last.json',jsonbytes({'project':identifier}));editor.project=path
        return editor.summary()

def delete_project(editor,body):
    """Remove exactly one stored project, leaving sources and piece library alone."""
    with editor.lock:
        identifier=body.get('id')
        if body.get('confirm') is not True:raise ValueError('Confirme a exclusao do projeto.')
        if not isinstance(identifier,str) or not re.fullmatch('[0-9a-f]{32}',identifier):raise ValueError('Projeto invalido.')
        path=editor.directory/identifier
        if path.is_symlink() or not path.is_dir() or path.resolve().parent!=editor.directory.resolve():raise ValueError('Projeto nao encontrado ou caminho invalido.')
        if (path/'project.json').is_symlink() or not (path/'project.json').is_file():raise ValueError('Projeto invalido.')
        meta=json.loads((path/'project.json').read_text())
        if type(body.get('revision'))!=int or body['revision']!=meta.get('revision'):raise ValueError('O projeto mudou. Atualize a lista antes de excluir.')
        active=editor.project==path;last=editor.directory/'last.json';last_points_here=False
        try:
            last_state=json.loads(last.read_text());last_points_here=isinstance(last_state,dict) and last_state.get('project')==identifier
        except (ValueError,OSError):pass
        tomb=editor.directory/('.delete_'+uuid.uuid4().hex);path.rename(tomb)
        try:
            if active or last_points_here:last.unlink(missing_ok=True)
        except OSError:
            tomb.rename(path);raise
        if active:editor.project=None
        cleanup_pending=False
        try:shutil.rmtree(tomb)
        except OSError:cleanup_pending=True
        return {'deleted':identifier,'name':meta['name'],'activeDeleted':active,'cleanupPending':cleanup_pending,'project':editor.summary()}

def library(editor):
    folder=editor.directory/'pecas_salvas';rows=[]
    if folder.exists():
        for path in folder.glob('*.json'):
            try:
                row=json.loads(path.read_text())
                if re.fullmatch('[0-9a-f]{32}',row['id']) and (folder/(row['id']+'.zip')).is_file():rows.append(row)
            except (OSError,ValueError,KeyError):continue
    return sorted(rows,key=lambda r:r.get('created',0),reverse=True)
def save_piece(editor,body):
    from prefabs import export
    with editor.lock:
        if body.get('project')!=editor.project.name:raise ValueError('O projeto mudou.')
        title=label(body.get('title'),'Meu conjunto');raw=export(editor,body['file'],body['index'],title,body['revision'])
        folder=editor.directory/'pecas_salvas';folder.mkdir(exist_ok=True);identifier=uuid.uuid4().hex
        atomic(folder/(identifier+'.zip'),raw);row={'id':identifier,'name':title,'created':time.time(),'bytes':len(raw)};atomic(folder/(identifier+'.json'),jsonbytes(row));return row
def load_piece(editor,identifier):
    with editor.lock:
        row=next((r for r in library(editor) if r['id']==identifier),None)
        if row is None:raise ValueError('Peca salva nao encontrada.')
        return editor.load_accessory_source(editor.directory/'pecas_salvas'/(identifier+'.zip'),row['name']+'.zip')

def check(editor):
    """Report missing resources without executing scripts or changing any files."""
    with editor.lock:
        if not editor.project:raise ValueError('Abra um projeto primeiro.')
        missing=[];external=set();invalid=[];checked=0
        lookup=editor.archive_index()[0];has_descriptor='moddesc.xml' in lookup
        for name in editor.archive_index()[0].values():
            if not name.lower().endswith(('.i3d','.xml')):continue
            try:doc=I3D(editor.read(name));root=ET.fromstring(doc.text)
            except Exception as error:invalid.append({'file':name,'error':str(error)});continue
            for element in root.iter():
                refs=[v for k,v in element.attrib.items() if k in ('filename','xmlFilename','externalShapesFile') or (k=='file' and v.lower().endswith(('.gls','.ogg','.wav')))]
                if element.tag in ('filename','image','iconFilename') and element.text:refs.append(element.text.strip())
                for reference in refs:
                    if not reference or reference=='-' or reference.startswith('$l10n'):continue
                    checked+=1;resolved=editor.resolve_resource(reference,name)
                    if reference.startswith('$'):
                        if not resolved:external.add(reference)
                    elif not resolved:missing.append({'file':name,'resource':reference})
                    elif has_descriptor and root.tag in ('vehicle','sounds'):
                        from game_base import variants
                        path=posixpath.normpath(reference.replace('\\','/'))
                        if not any(c.casefold() in lookup for c in variants(path)):missing.append({'file':name,'resource':reference+' · caminho fora da raiz do mod'})
        return {'project':editor.project.name,'revision':editor.meta()['revision'],'checked':checked,'missing':missing,'external':sorted(external),'invalid':invalid,'note':'A conferência verifica arquivos e XML; não executa scripts nem simula o carregador do jogo.'}

def precision(editor,body):
    from pose_tools import _static,world,mv,inverse
    with editor.lock:
        if body.get('project')!=editor.project.name or body['revision']!=editor.meta()['revision']:raise ValueError('O projeto mudou. Reabra a ferramenta.')
        doc,node=_static(editor,body['file'],body['index']);target=body['target']
        if type(target)!=int or not 0<=target<len(doc.nodes) or target==body['index']:raise ValueError('Escolha outra peca como referencia.')
        cursor=target
        while cursor is not None:
            if cursor==body['index']:raise ValueError('A referencia nao pode ser filha da peca movida.')
            cursor=doc.nodes[cursor]['parent']
        axis=body['axis'];mode=body['mode'];gap=body.get('gap',0)
        if type(axis)!=int or axis not in (0,1,2) or mode not in ('center','min','max'):raise ValueError('Alinhamento invalido.')
        if type(gap) not in (int,float) or not math.isfinite(gap) or abs(gap)>10:raise ValueError('Afastamento entre -10 e 10 metros.')
        scene=editor.scene(body['file'],include_wheels=False);matrices=world(doc.nodes)
        def bounds(index):
            points=[];included=set()
            for n in scene['nodes']:
                if n['index']!=index and n['parent'] not in included:continue
                included.add(n['index']);mesh=scene['meshes'].get(n['shapeId'])
                if not mesh or n['nonRenderable'] or not n['visibility']:continue
                box=mesh.get('bounds')
                if not box:
                    positions=mesh.get('positions',[])
                    if not positions:continue
                    box=[[min(p[k] for p in positions) for k in range(3)],[max(p[k] for p in positions) for k in range(3)]]
                a,t=matrices[n['index']]
                for corner in itertools.product(*zip(*box)):points.append([v+b for v,b in zip(mv(a,corner),t)])
            if not points:raise ValueError('Selecione pecas com geometria visual.')
            lo=min(p[axis] for p in points);hi=max(p[axis] for p in points)
            return (lo+hi)/2 if mode=='center' else lo if mode=='min' else hi
        delta=[0,0,0];delta[axis]=bounds(target)-bounds(body['index'])+gap;parent=matrices[node['parent']][0];local=mv(inverse(parent),delta);translation=[v+d for v,d in zip(node['translation'],local)]
        return {'project':editor.change(body['file'],doc.patch(body['index'],{'translation':translation}),body['revision']),'index':body['index']}

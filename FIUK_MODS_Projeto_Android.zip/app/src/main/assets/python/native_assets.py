"""Serialize static meshes while preserving existing encrypted records verbatim."""
import base64,math,struct
from codecs_vendor import shapes_cipher as cipher
from core import tagname,vector
from shapes_reader import parse_shape,decrypt

def packed(values,kind='f'):return struct.pack('<'+kind*len(values),*values)
def encode_mesh(shape_id,mesh,version):
    if mesh.get('skin'):raise ValueError('Acessorio com deformacao por ossos: selecione uma peca estatica.')
    if mesh.get('nativeOptions',0)&~(1|2|4|8|16|32|128) or mesh.get('nativeAttachments',0):raise ValueError('Malha com dados nativos adicionais: importe para um destino da mesma versao de .shapes para preservar esses dados.')
    if 'positionsBase64' in mesh:
        positions=base64.b64decode(mesh['positionsBase64']);vertices=mesh['vertexCount'];indices=base64.b64decode(mesh['indicesBase64']);corners=mesh['triangleCount']*3
        normal=base64.b64decode(mesh['normalsBase64']) if mesh.get('normalsBase64') else None
        uvs=[base64.b64decode(v) if v else None for v in mesh.get('uvSetsBase64',[])[:4]]
        tangent=base64.b64decode(mesh['tangentsBase64']) if mesh.get('tangentsBase64') else None
        colors=base64.b64decode(mesh['colorsBase64']) if mesh.get('colorsBase64') else None
        values=struct.unpack('<'+'f'*(len(positions)//4),positions);rows=[values[i:i+3] for i in range(0,len(values),3)]
    else:
        rows=mesh['positions'];vertices=len(rows);corners=len(mesh['indices']);positions=packed([v for row in rows for v in row]);indices=packed(mesh['indices'],'I' if vertices>65536 else 'H')
        normal=packed([v for row in mesh['normals'] for v in row]) if mesh.get('normals') else None
        uvs=[packed([v for row in mesh['uvs'] for v in row])] if mesh.get('uvs') else []
        tangent=None;colors=None
    if tangent and version<5:raise ValueError('A malha de destino e antiga demais para as tangentes do acessorio.')
    options=(1 if normal else 0)|(128 if tangent else 0)|(32 if colors else 0)
    for uv,bit in zip(uvs,[2,4,8,16]):
        if uv:options|=bit
    sphere=mesh.get('boundingSphere')
    if sphere and len(sphere)==4 and all(math.isfinite(v) for v in sphere):center=sphere[:3];radius=sphere[3]
    else:center=[(min(p[k] for p in rows)+max(p[k] for p in rows))/2 for k in range(3)];radius=max(math.dist(p,center) for p in rows)
    name=b'GabrielAccessory';blob=struct.pack('<i',len(name))+name;blob+=b'\0'*((-len(blob))%4)
    subsets=mesh.get('subsets') or [{'firstVertex':0,'numVertices':vertices,'firstIndex':0,'numIndices':corners}]
    blob+=struct.pack('<I4f4I',int(shape_id),*center,radius,corners,len(subsets),vertices,options)
    for subset_index,subset in enumerate(subsets):
        blob+=struct.pack('<4I',*[subset[k] for k in ('firstVertex','numVertices','firstIndex','numIndices')])
        if version>=6:
            rows_density=mesh.get('uvDensities') or []
            densities=rows_density[subset_index] if subset_index<len(rows_density) else [None]*4
            values=[densities[i] if i<len(densities) and densities[i] is not None else 0.0 for i,uv in enumerate(uvs) if uv]
            if not all(math.isfinite(v) for v in values):raise ValueError('Densidade UV invalida no acessorio.')
            # A zero density is retained; it must never silently become 1.
            blob+=packed(values)
    blob+=indices;blob+=b'\0'*((-len(blob))%4);blob+=positions
    if normal:blob+=normal
    if tangent:blob+=tangent
    for uv in uvs:
        if uv:blob+=uv
    if colors:blob+=colors
    blob+=struct.pack('<I',0)
    parse_shape(blob,version) # Refuse malformed data before staging any project mutation.
    return blob

def append_meshes(raw,meshes,native_records=None):
    if len(raw)<8:raise ValueError('Arquivo de malhas de destino incompleto.')
    version,seed,offset=cipher.read_header(raw)
    if version not in (4,5,6,7):raise ValueError('Destino deve usar malhas v4 a v7.')
    count=struct.unpack('<i',cipher.process(raw[offset:offset+4],seed,0))[0]
    if not 0<=count<=100000:raise ValueError('Contagem de malhas invalida.')
    pos=offset+4;block=1
    for _ in range(count):
        if pos+8>len(raw):raise ValueError('Malhas de destino truncadas.')
        length=struct.unpack('<i',cipher.process(raw[pos+4:pos+8],seed,block+1))[0]
        if length<0 or pos+8+length>len(raw):raise ValueError('Entidade de destino invalida.')
        pos+=8+length;block+=2+(length+63)//64
    if pos!=len(raw):raise ValueError('Dados adicionais no arquivo de malhas.')
    tail=[]
    for shape_id,mesh in meshes:
        source=(native_records or {}).get(str(shape_id))
        if source and source['version']==version:
            blob=bytearray(source['data']);at=shape_header_offset(blob);struct.pack_into('<I',blob,at,int(shape_id));blob=bytes(blob)
            sid,_=parse_shape(blob,version)
            if sid!=str(shape_id):raise ValueError('shapeId nativo invalido.')
        else:blob=encode_mesh(shape_id,mesh,version)
        tail.extend([cipher.process(struct.pack('<i',1),seed,block),cipher.process(struct.pack('<i',len(blob)),seed,block+1),decrypt(blob,seed,block+2)])
        block+=2+(len(blob)+63)//64
    return raw[:offset]+cipher.process(struct.pack('<i',count+len(meshes)),seed,0)+raw[offset+4:]+b''.join(tail)

def empty_shapes(version=7):
    if version not in (4,5,6,7):raise ValueError('Versao de malha de destino invalida.')
    return cipher.write_header(version,42)+cipher.process(struct.pack('<i',0),42,0)

def inline_mesh(element):
    vertices=next(e for e in element if tagname(e.tag)=='Vertices');triangles=next(e for e in element if tagname(e.tag)=='Triangles')
    positions=[vector(v.get('p'),[0,0,0]) for v in vertices];indices=[int(i) for t in triangles for i in t.get('vi','').split()]
    mesh={'positions':positions,'indices':indices,'uvs':[[float(x) for x in v.get('t0','0 0').split()] for v in vertices]}
    if any(v.get('n') for v in vertices):mesh['normals']=[vector(v.get('n'),[0,0,1]) for v in vertices]
    unsupported=any(any(k not in ('p','n','t0') for k in v.attrib) for v in vertices)
    if unsupported:raise ValueError('Malha inline avancada: salve o destino com .shapes antes de importar.')
    return mesh


def shape_header_offset(blob):
    if len(blob)<4:raise ValueError('Entidade de malha incompleta.')
    length=struct.unpack_from('<i',blob)[0]
    if not 0<=length<=16384:raise ValueError('Nome da malha invalido.')
    at=(4+length+3)//4*4
    if at+36>len(blob):raise ValueError('Cabecalho da malha incompleto.')
    return at

def entity_records(raw):
    """Yield encrypted-record locations, without retaining decoded blobs for every mesh."""
    version,seed,offset=cipher.read_header(raw)
    if version not in (4,5,6,7) or len(raw)<offset+4:raise ValueError('Arquivo nativo de malhas invalido.')
    count=struct.unpack('<i',decrypt(raw[offset:offset+4],seed,0))[0]
    if not 0<=count<=100000:raise ValueError('Contagem de entidades invalida.')
    pos=offset+4;block=1
    for _ in range(count):
        if pos+8>len(raw):raise ValueError('Entidade truncada.')
        kind=struct.unpack('<i',decrypt(raw[pos:pos+4],seed,block))[0]
        length=struct.unpack('<i',decrypt(raw[pos+4:pos+8],seed,block+1))[0]
        if length<0 or pos+8+length>len(raw):raise ValueError('Entidade truncada.')
        yield version,seed,kind,pos+8,length,block+2
        pos+=8+length;block+=2+(length+63)//64
    if pos!=len(raw):raise ValueError('Bytes adicionais nas malhas.')

def extract_records(raw,shape_ids):
    """Retain the selected native payloads, including streaming metadata and attachments."""
    wanted={str(s) for s in shape_ids};records={}
    for version,seed,kind,start,size,block in entity_records(raw):
        if kind!=1:continue
        prefix=decrypt(raw[start:start+min(64,size)],seed,block)
        if len(prefix)<4:raise ValueError('Malha truncada.')
        length=struct.unpack_from('<i',prefix)[0]
        if not 0<=length<=16384:raise ValueError('Nome de malha invalido.')
        at=(4+length+3)//4*4
        if at+4>len(prefix):prefix=decrypt(raw[start:start+min(at+4,size)],seed,block)
        if at+4>len(prefix):raise ValueError('Cabecalho de malha truncado.')
        sid=str(struct.unpack_from('<I',prefix,at)[0])
        if sid in wanted:
            blob=decrypt(raw[start:start+size],seed,block);parse_shape(blob,version)
            records[sid]={'version':version,'data':blob}
    return records

def patch_uv_densities(raw,changes):
    """Repair known subset UV densities, retaining sizes/counters and every other byte."""
    remaining={str(sid):rows for sid,rows in changes.items()};out=bytearray(raw)
    for version,seed,kind,start,size,block in entity_records(raw):
        if kind!=1 or version<6:continue
        prefix=decrypt(raw[start:start+min(16424,size)],seed,block);at=shape_header_offset(prefix)
        sid=str(struct.unpack_from('<I',prefix,at)[0])
        if sid not in remaining:continue
        blob=bytearray(decrypt(raw[start:start+size],seed,block));_,mesh=parse_shape(blob,version)
        rows=remaining.pop(sid);count=len(mesh['subsets']);bits=[i for i,uv in enumerate(mesh['uvSetsBase64']) if uv]
        if len(rows)!=count:raise ValueError('Quantidade de subsets diferente da origem.')
        cursor=at+36
        for row in rows:
            cursor+=16
            if len(row)!=4:raise ValueError('Densidade UV precisa de quatro canais.')
            for i in bits:
                value=row[i]
                if value is None or not math.isfinite(value):raise ValueError('Densidade UV ausente ou invalida.')
                struct.pack_into('<f',blob,cursor,value);cursor+=4
        parse_shape(blob,version)
        out[start:start+size]=cipher.process(bytes(blob),seed,block)
    if remaining:raise ValueError('shapeIds nao encontrados para reparo: '+', '.join(remaining))
    return bytes(out)

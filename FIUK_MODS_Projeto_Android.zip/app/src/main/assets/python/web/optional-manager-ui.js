export function installOptionalManager({$,state,api,busy,status,viewer,projectChanged,openScene,canOpen,onClosed}){
 let info=null,original=null,previews=new Map();
 function restore(){if(original){for(const [index,value]of original)if(state.scene?.nodes[index])state.scene.nodes[index].visibility=value;viewer?.updateMatrices();viewer?.draw();}original=null;previews.clear();$('#optionalManagerPreview').textContent='';$('#optionalManagerDialog').classList.remove('previewing');$('#optionalManagerBack').hidden=true;}
 function close(){restore();info=null;$('#optionalManagerDialog').close();onClosed();}
 function preview(group,choice=null){
  if(!original)original=new Map(state.scene.nodes.map(n=>[n.index,n.visibility]));
  previews.delete(group.slot);previews.set(group.slot,{group,choice});
  for(const [i,value]of original)state.scene.nodes[i].visibility=value;
  for(const {group,choice}of previews.values()){
   for(const c of group.options)for(const change of c.changes||[])if('visibilityInactive'in change)state.scene.nodes[change.index].visibility=change.visibilityInactive;
   if(choice){for(const change of choice.changes||[])if('visibilityActive'in change)state.scene.nodes[change.index].visibility=change.visibilityActive;}
   else{for(const i of group.indices)state.scene.nodes[i].visibility=false;}
  }
  viewer?.updateMatrices();viewer?.draw();$('#optionalManagerDialog').classList.add('previewing');$('#optionalManagerBack').hidden=false;$('#optionalManagerPreview').textContent='Prévia temporária: '+group.title+' · '+(choice?choice.name:'peças ocultas')+(choice?.partial?' · materiais/funções não simulados':'');
 }
 async function load(vehicle){info=await api('/api/optional-manager?file='+encodeURIComponent(state.file)+(vehicle?'&vehicle='+encodeURIComponent(vehicle):''));render();}
 function button(text,fn,disabled=false){const b=document.createElement('button');b.type='button';b.textContent=text;b.disabled=disabled;b.onclick=fn;return b;}
 async function change(group,choice,action,enabled,visible){
  if(state.busy)return;
  const message=action==='remove-group'?'Remover o grupo “'+group.title+'” da loja e manter no modelo a aparência de “'+choice.name+'”? As malhas não serão apagadas. Desfazer recupera o grupo.':action==='remove-choice'?'Remover a escolha “'+choice.name+'” da loja? As peças continuam no mod. Desfazer recupera a escolha.':null;
  if(message&&!window.confirm(message))return;
  await busy('Atualizando os opcionais…',async()=>{
   restore();const response=await api('/api/optional-manager',{project:info.project,file:info.file,vehicle:info.vehicle,revision:info.revision,slot:group.slot,key:choice.key,action,...(action==='toggle'?{enabled}: {}),...(action==='choice-visibility'?{visible}: {})});
   const vehicle=info.vehicle;projectChanged(response.project);await openScene(state.file);await load(vehicle);status('Opcionais atualizados no projeto. Exporte o ZIP para aplicar no jogo.');
  });
  render();
 }
 function render(){
  const list=$('#optionalManagerGroups');list.replaceChildren();if(!info)return;
  const select=$('#optionalManagerVehicle');select.replaceChildren();for(const file of info.vehicles){const o=document.createElement('option');o.value=file;o.textContent=file;select.append(o);}select.value=info.vehicle;
  if(!info.groups.length){const p=document.createElement('p');p.textContent='Nenhum grupo design a design8 encontrado neste veículo.';list.append(p);}
  for(const group of info.groups){
   const card=document.createElement('section');card.className='optional-manager-group';
   const heading=document.createElement('h3');heading.textContent=group.title+' · '+(group.origin==='editor'?'adicionado no editor':'original do mod');card.append(heading);
   if(group.reason){const p=document.createElement('p');p.className='hint';p.textContent=group.reason;card.append(p);}
   for(const choice of group.options){
    const row=document.createElement('div');row.className='optional-manager-choice';row.dataset.choiceKey=choice.key;
    const label=document.createElement('label'),check=document.createElement('input');check.type='checkbox';check.checked=choice.enabled;check.disabled=!group.editable;check.setAttribute('aria-label','Ativar na loja: '+choice.name);check.onchange=async()=>{const enabled=check.checked;check.checked=choice.enabled;await change(group,choice,'toggle',enabled);};
    const text=document.createElement('span');text.textContent=choice.name+' · '+(choice.enabled?'ativa na loja':'desativada na loja');label.append(check,text);row.append(label,button('Ver',()=>preview(group,choice)),button('Remover',()=>change(group,choice,'remove-choice'),!group.editable));if(choice.canHide)row.append(button(choice.visible===false?'Mostrar peças no mod':'Ocultar peças no mod',()=>change(group,choice,'choice-visibility',undefined,choice.visible===false),!group.editable));card.append(row);
   }
   const actions=document.createElement('div');actions.className='optional-manager-actions';
   const keep=document.createElement('select');keep.setAttribute('aria-label','Aparência para manter ao remover '+group.title);for(const c of group.options.filter(c=>c.enabled)){const o=document.createElement('option');o.value=c.key;o.textContent='Manter: '+c.name;keep.append(o);}keep.value=group.options.find(c=>c.enabled)?.key||'';
   actions.append(button('Ocultar peças (prévia)',()=>preview(group)),keep,button('Remover grupo',()=>change(group,group.options.find(c=>c.key===keep.value),'remove-group'),!group.removable));card.append(actions);
   if(!group.removable&&!group.reason){const p=document.createElement('p');p.className='hint';p.textContent='Este grupo também controla materiais, funções ou referências sem prévia. As escolhas podem ser gerenciadas; a remoção completa exige revisar o XML.';card.append(p);}list.append(card);
  }
 }
 async function open(){if(state.busy||!canOpen())return;await busy('Lendo os opcionais originais e adicionados…',async()=>{await load();$('#left').classList.remove('open');$('#optionalManagerDialog').showModal();});}
 $('#manageOptionals').onclick=open;$('#closeOptionalManager').onclick=()=>{if(!state.busy)close();};$('#optionalManagerRestore').onclick=restore;
 $('#optionalManagerBack').onclick=()=>{$('#optionalManagerDialog').classList.remove('previewing');$('#optionalManagerBack').hidden=true;};
 $('#optionalManagerVehicle').onchange=e=>{const vehicle=e.target.value;busy('Lendo o veículo…',async()=>{restore();await load(vehicle);});};
 $('#optionalManagerDialog').addEventListener('cancel',e=>{if(state.busy)e.preventDefault();});$('#optionalManagerDialog').addEventListener('close',()=>{if(!$('#optionalManagerDialog').open&&info)close();});
 return {open,close,isOpen:()=>!!info,restore};
}

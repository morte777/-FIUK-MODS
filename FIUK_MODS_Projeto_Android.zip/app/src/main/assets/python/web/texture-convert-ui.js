export function installTextureConvert({$,state,api,busy,status,projectChanged,openScene,canOpen}){
 let info=null,selected=new Set(),activeJob=null,downloadJob=null;
 function eligible(row){return row.eligible&&(!(row.layers>1)||($('#textureConvertMode').value||'astc-v18')==='astc-v18');}
 function close(){if(!activeJob){info=null;selected.clear();downloadJob=null;}$('#textureConvertDialog').close();}
 function buttonState(){const count=selected.size;$('#textureConvertWhole').disabled=state.busy||!info?.textures?.length;$('#textureConvertApply').disabled=!count||state.busy;$('#textureConvertCount').textContent=count+' textura(s) selecionada(s) · seleção manual: até 32; ZIP todo processa a lista completa';}
 function render(){
  const list=$('#textureConvertList'),query=$('#textureConvertSearch').value.toLowerCase();list.replaceChildren();
  if(!info)return;
  for(const row of info.textures){if(!row.file.toLowerCase().includes(query))continue;
   const item=document.createElement('div');item.className='texture-convert-row';const label=document.createElement('label'),check=document.createElement('input');check.type='checkbox';check.checked=selected.has(row.file);check.disabled=!eligible(row);check.setAttribute('aria-label','Converter '+row.file);check.onchange=()=>{if(check.checked&&selected.size>=32){check.checked=false;status('Selecione até 32 por conversão.');return;}if(check.checked)selected.add(row.file);else selected.delete(row.file);buttonState();};
   const text=document.createElement('span');text.textContent=row.file+(row.width?' · '+row.width+' × '+row.height+' · '+row.format+' · '+row.mipmaps+' mip(s)':'');label.append(check,text);item.append(label);
   if(row.reason||row.note){const p=document.createElement('p');p.className='hint';p.textContent=row.reason||row.note;item.append(p);}
   if(row.width&&!(row.layers>1)){const show=document.createElement('button');show.type='button';show.textContent='Ver DDS';show.onclick=()=>{const image=$('#textureConvertImage');image.src='/api/texture-image?project='+encodeURIComponent(info.project)+'&file='+encodeURIComponent(row.file)+'&size=512';image.hidden=false;image.alt=row.file;};item.append(show);}
   list.append(item);
  }
  if(!info.textures.length){const p=document.createElement('p');p.textContent='Nenhuma textura DDS encontrada neste mod.';list.append(p);}buttonState();
 }
 async function load(){info=await api('/api/texture-convert?replaceExisting=1');selected.clear();$('#textureConvertEncoding').textContent=info.encoding;render();}
 async function open(){if(activeJob){if(!$('#textureConvertDialog').open)$('#textureConvertDialog').showModal();return;}if(state.busy||!canOpen())return;let resume=null;await busy('Lendo as texturas DDS do mod…',async()=>{try{const row=await api('/api/texture-jobs/status');if(row?.state==='running')resume=row;}catch(e){}if(resume)info={asyncJobs:true,textures:[]};else await load();$('#textureConvertReport').textContent='';$('#textureConvertProgress').hidden=!resume;$('#textureConvertDownload').hidden=true;$('#textureConvertImage').hidden=true;$('#left').classList.remove('open');$('#textureConvertDialog').showModal();});buttonState();if(resume)runAsync(false,resume);}
 $('#showTextureConvert').onclick=open;$('#textureConvertClose').onclick=()=>{if(!state.busy||activeJob)close();};$('#textureConvertSearch').oninput=render;
 $('#textureConvertAll').onclick=()=>{selected=new Set((info?.textures||[]).filter(r=>eligible(r)&&r.file.toLowerCase().includes($('#textureConvertSearch').value.toLowerCase())).slice(0,32).map(r=>r.file));render();};$('#textureConvertNone').onclick=()=>{selected.clear();render();};
 $('#textureConvertMode').onchange=()=>{selected=new Set([...selected].filter(path=>eligible(info.textures.find(r=>r.file===path))));render();};
 function download(){
  const a=document.createElement('a');a.href=downloadJob?'/api/texture-jobs/output?id='+encodeURIComponent(downloadJob.id):'/api/export?project='+encodeURIComponent(state.project.project)+'&revision='+state.project.revision;a.download=downloadJob?.outputName||(state.project.name||'mod').replace(/\.zip$/i,'')+'_FS23_AST.zip';document.body.append(a);a.click();a.remove();
 }
 const phases={scan:'Lendo DDS',encode:'Convertendo texturas',references:'Atualizando XML / I3D',commit:'Salvando alterações',export:'Preparando ZIP',done:'ZIP pronto',cancelled:'Cancelado',error:'Falha'};
 function showProgress(row){const percent=Math.round(row.percent||0),time=Math.round(row.elapsed||0);$('#textureConvertProgress').hidden=false;$('#textureConvertPercent').textContent=percent+'%';$('#textureConvertProgressBar').value=percent;$('#textureConvertDetails').textContent=(phases[row.phase]||row.phase)+' · '+(row.done||0)+' / '+(row.total||0)+' DDS · '+Math.floor(time/60)+'min '+time%60+'s'+(row.mips?' · mip '+row.mip+'/'+row.mips:'');$('#textureConvertCurrent').textContent=row.file||row.error||'';$('#textureConvertCancel').disabled=row.state!=='running'||row.canCancel===false||['commit','export'].includes(row.phase);$('#textureJobReopen').hidden=row.state!=='running';$('#textureJobReopen').textContent='Texturas · '+percent+'% · ver progresso';}
 function lockControls(active){for(const id of ['textureConvertSize','textureConvertMode','textureConvertQuality','textureConvertProfiles','textureConvertDelete','textureConvertAll','textureConvertNone','textureConvertSearch'])$('#'+id).disabled=active;for(const el of $('#textureConvertList').querySelectorAll('input,button'))el.disabled=active;buttonState();}
 function body(all){return {project:info.project,revision:info.revision,...(all?{all:true}:{files:[...selected]}),deleteDDS:!!$('#textureConvertDelete').checked,maxSize:Number($('#textureConvertSize').value),encoding:$('#textureConvertMode').value||'astc-v18',quality:$('#textureConvertQuality').value||'fast',preserveProfiles:!!$('#textureConvertProfiles').checked,replaceExisting:true,forceDelete:true};}
 function report(result){const skipped=result.skipped||[];$('#textureConvertReport').textContent=result.converted.length+' textura(s) convertida(s) · '+result.references+' referência(s) atualizada(s). DDS removidas do ZIP: '+(result.deletedDDS?.length||0)+'. DDS sem conversão: '+skipped.length+'.'+(skipped.length?'\n'+skipped.map(r=>r.file+': '+r.reason).join('\n'):'')+(result.keptDDS?.length?'\n'+result.keptDDS.map(r=>r.file+': '+r.reason).join('\n'):'')+(result.converted.some(r=>r.note)?'\n'+result.converted.filter(r=>r.note).map(r=>r.source+': '+r.note).join('\n'):'');}
 async function runAsync(all,resume=null){
  if(activeJob||state.busy)return;state.busy=true;window.GabrielTextureConversionActive=true;window.GabrielAndroid?.conversionRunning?.(true);lockControls(true);$('#textureConvertDownload').hidden=true;downloadJob=null;
  try{
   activeJob=resume||await api('/api/texture-jobs/start',body(all));showProgress(activeJob);$('#textureConvertDialog').scrollTop=0;$('#textureConvertProgress').scrollIntoView?.({block:'start'});
   while(activeJob.state==='running'){
    await new Promise(resolve=>setTimeout(resolve,650));
    try{activeJob=await api('/api/texture-jobs/status?id='+encodeURIComponent(activeJob.id));showProgress(activeJob);}catch(e){$('#textureConvertCurrent').textContent='Retomando progresso… '+e.message;}
   }
   if(activeJob.result){projectChanged(activeJob.result.project);report(activeJob.result);}
   if(activeJob.state==='done'){downloadJob=activeJob;$('#textureConvertDownload').hidden=false;status('Conversão pronta. ZIP preparado; Desfazer recupera as alterações.');if(all&&activeJob.result.converted.length)download();}
   else{status(activeJob.error);$('#textureConvertReport').textContent=activeJob.error;}
  }catch(e){status(e.message);$('#textureConvertReport').textContent=e.message;}
  finally{activeJob=null;state.busy=false;window.GabrielTextureConversionActive=false;window.GabrielAndroid?.conversionRunning?.(!!window.GabrielVehicleConversionActive);$('#textureJobReopen').hidden=true;lockControls(false);if(info&&$('#textureConvertDialog').open)await load();}
 }
 $('#textureConvertCancel').onclick=async()=>{if(activeJob)try{const reply=await api('/api/texture-jobs/cancel',{id:activeJob.id});$('#textureConvertCancel').disabled=true;$('#textureConvertCurrent').textContent=reply.canCancel===false?'Finalizando o ZIP; alterações já salvas.':'Cancelando ao terminar o mip atual…';}catch(e){status(e.message);}};
 $('#textureJobReopen').onclick=()=>{if(activeJob&&!$('#textureConvertDialog').open)$('#textureConvertDialog').showModal();};
 async function run(all=false){
  if(!info||state.busy||!all&&!selected.size)return;
  if(info.asyncJobs)return runAsync(all);
  await busy(all?'Convertendo o ZIP inteiro… As texturas são processadas uma por vez.':'Convertendo DDS para AST com mipmaps…',async()=>{
   window.GabrielTextureConversionActive=true;window.GabrielAndroid?.conversionRunning?.(true);
   try{
    const result=await api('/api/texture-convert',{project:info.project,revision:info.revision,...(all?{all:true}:{files:[...selected]}),deleteDDS:!!$('#textureConvertDelete').checked,maxSize:Number($('#textureConvertSize').value),encoding:$('#textureConvertMode').value||'astc-v18'});
    projectChanged(result.project);if(state.file)await openScene(state.file);await load();const bytes=result.converted.reduce((n,r)=>n+r.astBytes,0),removed=result.deletedDDS?.length||0,kept=result.keptDDS?.length||0,skipped=result.skipped||[];
    $('#textureConvertReport').textContent=result.converted.length+' textura(s) convertida(s) · '+result.references+' referência(s) atualizada(s) · '+(bytes/1024/1024).toFixed(2)+' MB em AST.\nDDS removidas do ZIP: '+removed+'. DDS convertidas mantidas: '+kept+(result.originalsKept?' · DDS originais mantidos':'')+'. DDS sem conversão: '+skipped.length+'.'+(result.converted.some(r=>r.note)?'\n'+result.converted.filter(r=>r.note).map(r=>r.source+': '+r.note).join('\n'):'')+(skipped.length?'\n'+skipped.map(r=>r.file+': '+r.reason).join('\n'):'')+(kept?'\n'+result.keptDDS.map(r=>r.file+': '+r.reason).join('\n'):'');
    $('#textureConvertDownload').hidden=false;status('Conversão salva. Desfazer recupera as DDS e as referências anteriores.');
    if(all&&result.converted.length)download();
   }finally{window.GabrielTextureConversionActive=false;window.GabrielAndroid?.conversionRunning?.(!!window.GabrielVehicleConversionActive);}
  });buttonState();
 }
 $('#textureConvertForm').onsubmit=e=>{e.preventDefault();return run(false);};$('#textureConvertWhole').onclick=()=>run(true);$('#textureConvertDownload').onclick=()=>{if(!state.busy)download();};
 $('#textureConvertDialog').addEventListener('cancel',e=>{if(state.busy&&!activeJob)e.preventDefault();});$('#textureConvertDialog').addEventListener('close',()=>{if(!$('#textureConvertDialog').open&&!activeJob){info=null;selected.clear();}});
 return {close,isOpen:()=>!!info,resume:row=>{info={asyncJobs:true,textures:[]};$('#textureConvertDialog').showModal();return runAsync(false,row);}};
}

// Pure linear track sampling. Every pose starts from the untouched scene snapshot.
export function animationPose(base,parts,time){
 const result=new Map(),tracks=new Map();
 for(const part of parts)for(const [property,value] of Object.entries(part.tracks)){const key=part.index+':'+property;if(!tracks.has(key))tracks.set(key,[]);tracks.get(key).push({...part,property,value});}
 for(const sequence of tracks.values()){
  sequence.sort((a,b)=>a.start-b.start);const first=sequence[0],node=base[first.index];if(!node)continue;let value;
  if(first.property==='visibility'){value=node.visibility;for(const p of sequence)if(time>=p.start)value=p.value;}
  else{let p=sequence[0];for(const candidate of sequence)if(candidate.start<=time)p=candidate;const a=p.value.start??node[p.property],b=p.value.end,t=p.end===p.start?(time>=p.start?1:0):Math.max(0,Math.min(1,(time-p.start)/(p.end-p.start)));value=a.map((v,i)=>v+(b[i]-v)*t);}
  if(!result.has(first.index))result.set(first.index,{});result.get(first.index)[first.property]=value;
 }return result;
}

export function installAnimations({$,state,api,busy,status,viewer,dirtyGuard,onClose}){
 $('#animationPanel').hidden=true;
 let data=null,base=null,current=0,playing=false,last=null,token=0;
 const selected=()=>data?.animations[Number($('#animationChoice').value)];
 function stop(){playing=false;token++;last=null;$('#animationPlay').textContent='Reproduzir';}
 function restore(draw=true){if(base&&state.scene){for(let i=0;i<base.length;i++){const n=state.scene.nodes[i],b=base[i];if(n)Object.assign(n,{translation:[...b.translation],rotation:[...b.rotation],scale:[...b.scale],visibility:b.visibility});}if(draw){viewer?.updateMatrices();viewer?.draw();}}}
 function close(){stop();restore();data=null;base=null;$('#animationPanel').hidden=true;onClose?.();}
 function seek(time){const a=selected();if(!a||!base)return;current=Math.max(0,Math.min(a.duration,time));restore(false);for(const [index,pose] of animationPose(base,a.parts,current))Object.assign(state.scene.nodes[index],pose);viewer?.updateMatrices();viewer?.draw();$('#animationTime').value=a.duration?current/a.duration*1000:0;$('#animationTimeLabel').textContent=current.toFixed(2)+' / '+a.duration.toFixed(2)+' s';}
 function change(){stop();restore();const a=selected();$('#animationPlay').disabled=!a?.supported;$('#animationTime').disabled=!a?.supported;$('#animationNote').textContent=(data?.note||'')+(a?.unsupported?' '+a.unsupported+' trecho(s) fora do suporte da prévia.':'');seek(0);}
 async function open(){if(state.busy||!dirtyGuard())return;await busy('Lendo animações do XML…',async()=>{data=await api('/api/animations?file='+encodeURIComponent(state.file));base=state.scene.nodes.map(n=>({translation:[...n.translation],rotation:[...n.rotation],scale:[...n.scale],visibility:n.visibility}));const select=$('#animationChoice');select.replaceChildren();for(let i=0;i<data.animations.length;i++){const a=data.animations[i],o=document.createElement('option');o.value=i;o.textContent=a.name+(a.supported?'':' · sem movimentos suportados');select.append(o);}const i=data.animations.findIndex(a=>a.supported);select.value=String(Math.max(0,i));$('#animationPanel').hidden=false;$('#touchEditor').hidden=true;$('#selectionPanel').hidden=true;$('#left').classList.remove('open');$('#inspector').classList.remove('open');viewer?.setGizmo?.(null);change();if(!data.animations.length){$('#animationNote').textContent='Nenhuma animação foi encontrada no XML associado a este modelo.';status('O veículo precisa ter animações definidas no XML para a prévia.');}});}
 function play(){if(!selected()?.supported)return;if(playing){stop();return;}if(current>=selected().duration)seek(0);playing=true;last=null;const id=++token;$('#animationPlay').textContent='Pausar';function frame(now){if(!playing||id!==token||!data)return;if(last!==null){const duration=selected().duration;let next=current+(now-last)/1000*Number($('#animationSpeed').value||1);if(next>=duration){if($('#animationLoop').checked&&duration>0)next%=duration;else{seek(duration);stop();return;}}seek(next);}last=now;requestAnimationFrame(frame);}requestAnimationFrame(frame);}
 $('#showAnimations').onclick=open;$('#animationClose').onclick=close;$('#animationChoice').onchange=change;$('#animationPlay').onclick=play;$('#animationTime').oninput=()=>{stop();seek(Number($('#animationTime').value)/1000*(selected()?.duration||0));};$('#animationStart').onclick=()=>{stop();seek(0);};$('#animationEnd').onclick=()=>{stop();seek(selected()?.duration||0);};
 window.addEventListener('blur',stop);
 return {open,close,isActive:()=>!!data,seek};
}

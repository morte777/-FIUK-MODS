export function floodFill(image,x,y,color,tolerance=12){
 const {width:w,height:h,data}=image;x=Math.max(0,Math.min(w-1,Math.floor(x)));y=Math.max(0,Math.min(h-1,Math.floor(y)));const first=(y*w+x)*4,target=[...data.slice(first,first+4)];if(target.every((v,i)=>v===color[i]))return false;
 const seen=new Uint8Array(w*h),queue=new Int32Array(w*h);let head=0,tail=1;queue[0]=y*w+x;seen[queue[0]]=1;
 const match=i=>target.every((v,k)=>Math.abs(data[i*4+k]-v)<=tolerance);
 while(head<tail){const p=queue[head++];if(!match(p))continue;data.set(color,p*4);const px=p%w,py=Math.floor(p/w);for(const n of [px?p-1:-1,px<w-1?p+1:-1,py?p-w:-1,py<h-1?p+w:-1])if(n>=0&&!seen[n]){seen[n]=1;queue[tail++]=n;}}
 return true;
}

export class CanvasPainter{
 constructor(canvas,settings,onchange){this.canvas=canvas;this.ctx=canvas.getContext('2d',{willReadFrequently:true});if(!this.ctx)throw Error('O navegador não disponibilizou o desenho 2D.');this.settings=settings;this.onchange=onchange;this.undo=[];this.redo=[];this.pointer=null;this.stamp=null;this.handlers=[];this.bind();}
 snapshot(){return {width:this.canvas.width,height:this.canvas.height,image:this.ctx.getImageData(0,0,this.canvas.width,this.canvas.height)};}
 restore(s){this.canvas.width=s.width;this.canvas.height=s.height;this.ctx.putImageData(s.image,0,0);}
 push(){this.undo.push(this.snapshot());if(this.undo.length>8)this.undo.shift();this.redo=[];}
 changed(){this.onchange?.();}
 initialize(size=512,color='#ffffff',transparent=false){this.canvas.width=this.canvas.height=size;this.ctx.clearRect(0,0,size,size);if(!transparent){this.ctx.fillStyle=color;this.ctx.fillRect(0,0,size,size);}this.undo=[];this.redo=[];}
 load(image,limit=1024,flip=false,record=false){if(record)this.push();const scale=Math.min(1,limit/Math.max(image.width,image.height));this.canvas.width=Math.max(1,Math.round(image.width*scale));this.canvas.height=Math.max(1,Math.round(image.height*scale));this.ctx.save();if(flip){this.ctx.translate(0,this.canvas.height);this.ctx.scale(1,-1);}this.ctx.drawImage(image,0,0,this.canvas.width,this.canvas.height);this.ctx.restore();if(!record){this.undo=[];this.redo=[];}else this.changed();}
 resize(limit){this.push();const copy=document.createElement('canvas');copy.width=this.canvas.width;copy.height=this.canvas.height;copy.getContext('2d').drawImage(this.canvas,0,0);const ratio=this.canvas.width/this.canvas.height;this.canvas.width=ratio>=1?limit:Math.max(1,Math.round(limit*ratio));this.canvas.height=ratio>=1?Math.max(1,Math.round(limit/ratio)):limit;this.ctx.drawImage(copy,0,0,this.canvas.width,this.canvas.height);this.changed();}
 history(forward=false){const from=forward?this.redo:this.undo,to=forward?this.undo:this.redo;if(!from.length)return;to.push(this.snapshot());this.restore(from.pop());this.changed();}
 background(color,clear=false){this.push();this.ctx.save();this.ctx.globalAlpha=1;this.ctx.globalCompositeOperation='source-over';this.ctx.clearRect(0,0,this.canvas.width,this.canvas.height);if(!clear){this.ctx.fillStyle=color;this.ctx.fillRect(0,0,this.canvas.width,this.canvas.height);}this.ctx.restore();this.changed();}
 position(e){const r=this.canvas.getBoundingClientRect();return [(e.clientX-r.left)/r.width*this.canvas.width,(e.clientY-r.top)/r.height*this.canvas.height].map((v,i)=>Math.max(0,Math.min((i?this.canvas.height:this.canvas.width)-.001,v)));}
 stroke(a,b,s,dot=false){const c=this.ctx;c.save();c.globalCompositeOperation=s.tool==='erase'?'destination-out':'source-over';c.globalAlpha=s.opacity;c.strokeStyle=c.fillStyle=s.color;c.lineWidth=s.size;c.lineCap=c.lineJoin='round';c.beginPath();if(dot){c.arc(a[0],a[1],s.size/2,0,Math.PI*2);c.fill();}else{c.moveTo(...a);c.lineTo(...b);c.stroke();}c.restore();}
 place(p,s){const c=this.ctx;c.save();c.globalAlpha=s.opacity;c.globalCompositeOperation='source-over';c.translate(...p);c.rotate((s.rotation||0)*Math.PI/180);
  if(s.tool==='text'){c.fillStyle=s.color;c.font='bold '+s.fontSize+'px Arial, sans-serif';c.textAlign='center';c.textBaseline='middle';c.fillText(s.text||'',0,0);}
  if(s.tool==='image'&&this.stamp){const width=this.canvas.width*s.imageSize/100,height=width*this.stamp.height/this.stamp.width;c.drawImage(this.stamp,-width/2,-height/2,width,height);}c.restore();
 }
 bind(){const canvas=this.canvas,listen=(type,fn)=>{canvas.addEventListener(type,fn);this.handlers.push([type,fn]);};listen('pointerdown',e=>{if(this.pointer!==null)return;e.preventDefault();const s=this.settings(),p=this.position(e);if(s.tool==='image'&&!this.stamp)return;if(s.tool==='text'&&!s.text.trim())return;this.previousRedo=this.redo;this.push();this.before=this.undo.at(-1);canvas.setPointerCapture?.(e.pointerId);
  if(s.tool==='fill'){const image=this.ctx.getImageData(0,0,canvas.width,canvas.height),rgb=[1,3,5].map(i=>parseInt(s.color.slice(i,i+2),16));floodFill(image,...p,[...rgb,Math.round(s.opacity*255)]);this.ctx.putImageData(image,0,0);this.changed();return;}
  if(s.tool==='text'||s.tool==='image'){this.place(p,s);this.changed();return;}this.pointer=e.pointerId;this.last=p;this.activeSettings=s;this.stroke(p,p,s,true);
 });listen('pointermove',e=>{if(this.pointer!==e.pointerId)return;e.preventDefault();const p=this.position(e);this.stroke(this.last,p,this.activeSettings);this.last=p;});
 const end=(e,cancel)=>{if(this.pointer!==e.pointerId)return;this.pointer=null;if(cancel){this.restore(this.before);this.undo.pop();this.redo=this.previousRedo;}else this.changed();this.before=null;this.previousRedo=null;};listen('pointerup',e=>end(e,false));listen('pointercancel',e=>end(e,true));listen('lostpointercapture',e=>end(e,true));}
 dispose(){for(const [name,fn] of this.handlers)this.canvas.removeEventListener?.(name,fn);this.handlers=[];this.stamp?.close?.();this.stamp=null;this.undo=[];this.redo=[];}
}

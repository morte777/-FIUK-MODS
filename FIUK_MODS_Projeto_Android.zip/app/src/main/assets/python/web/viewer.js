import {TextureManager} from './textures.js';
// Small offline WebGL renderer. No runtime downloads or engine dependencies.
export const multiply=(a,b)=>{
 const o=new Float32Array(16);
 for(let c=0;c<4;c++)for(let r=0;r<4;r++)for(let k=0;k<4;k++)o[c*4+r]+=a[k*4+r]*b[c*4+k];
 return o;
};
export function identity(){return new Float32Array([1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1]);}
export function transform(n){
 const [x,y,z]=n.rotation.map(v=>v*Math.PI/180),[cx,sx,cy,sy,cz,sz]=[Math.cos(x),Math.sin(x),Math.cos(y),Math.sin(y),Math.cos(z),Math.sin(z)];
 const rx=new Float32Array([1,0,0,0,0,cx,sx,0,0,-sx,cx,0,0,0,0,1]);
 const ry=new Float32Array([cy,0,-sy,0,0,1,0,0,sy,0,cy,0,0,0,0,1]);
 const rz=new Float32Array([cz,sz,0,0,-sz,cz,0,0,0,0,1,0,0,0,0,1]);
 const s=identity();[s[0],s[5],s[10]]=n.scale;
 const m=multiply(multiply(multiply(rz,ry),rx),s);
 [m[12],m[13],m[14]]=n.translation;return m;
}
export const point=(m,p)=>[0,1,2].map(r=>m[r]*p[0]+m[4+r]*p[1]+m[8+r]*p[2]+m[12+r]);
const sub=(a,b)=>a.map((v,i)=>v-b[i]);
const cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];
const norm=a=>{const l=Math.hypot(...a)||1;return a.map(v=>v/l)};
const dot=(a,b)=>a.reduce((n,v,i)=>n+v*b[i],0);
export function decodeBuffer(base64,Type){
 const binary=atob(base64),bytes=new Uint8Array(binary.length);
 for(let i=0;i<binary.length;i++)bytes[i]=binary.charCodeAt(i);
 if(bytes.byteLength%Type.BYTES_PER_ELEMENT)throw Error('Buffer de malha desalinhado.');
 return new Type(bytes.buffer);
}
export function computeNormals(positions,indices){
 const normals=new Float32Array(positions.length);
 for(let i=0;i<indices.length;i+=3){
  const a=indices[i]*3,b=indices[i+1]*3,c=indices[i+2]*3;
  const ab=[positions[b]-positions[a],positions[b+1]-positions[a+1],positions[b+2]-positions[a+2]];
  const ac=[positions[c]-positions[a],positions[c+1]-positions[a+1],positions[c+2]-positions[a+2]];
  const n=cross(ab,ac);for(const j of [a,b,c])for(let k=0;k<3;k++)normals[j+k]+=n[k];
 }
 for(let i=0;i<normals.length;i+=3){const n=norm([normals[i],normals[i+1],normals[i+2]]);normals.set(n,i);}
 return normals;
}
// Invert a 4x4 matrix, including perspective; reject singular transforms.
export function inverse(m){
 const rows=Array.from({length:4},(_,r)=>[...Array.from({length:4},(_,c)=>m[c*4+r]),...Array.from({length:4},(_,c)=>+(r===c))]);
 for(let c=0;c<4;c++){
  let pivot=c;for(let r=c+1;r<4;r++)if(Math.abs(rows[r][c])>Math.abs(rows[pivot][c]))pivot=r;
  if(Math.abs(rows[pivot][c])<1e-12)return null;
  [rows[c],rows[pivot]]=[rows[pivot],rows[c]];const d=rows[c][c];rows[c]=rows[c].map(v=>v/d);
  for(let r=0;r<4;r++)if(r!==c){const f=rows[r][c];rows[r]=rows[r].map((v,i)=>v-f*rows[c][i]);}
 }
 return new Float64Array(Array.from({length:16},(_,i)=>rows[i%4][4+Math.floor(i/4)]));
}
function unproject(m,p){const w=m[3]*p[0]+m[7]*p[1]+m[11]*p[2]+m[15];return point(m,p).map(v=>v/w);}
// Returns the hit fraction on a near-to-far segment, independent of model scale.
export function triangleHit(origin,direction,a,b,c){
 const e1=sub(b,a),e2=sub(c,a),p=cross(direction,e2),det=dot(e1,p);
 if(Math.abs(det)<1e-12)return null;
 const t=sub(origin,a),u=dot(t,p)/det;if(u<0||u>1)return null;
 const q=cross(t,e1),v=dot(direction,q)/det;if(v<0||u+v>1)return null;
 const distance=dot(e2,q)/det;return distance>=0&&distance<=1?distance:null;
}
function boundsHit(o,d,b){
 let lo=0,hi=1;for(let i=0;i<3;i++){
  if(Math.abs(d[i])<1e-12){if(o[i]<b[0][i]||o[i]>b[1][i])return false;continue;}
  let a=(b[0][i]-o[i])/d[i],z=(b[1][i]-o[i])/d[i];if(a>z)[a,z]=[z,a];lo=Math.max(lo,a);hi=Math.min(hi,z);if(lo>hi)return false;
 }return true;
}
function lookAt(eye,target){
 const z=norm(sub(eye,target)),x=norm(cross([0,1,0],z)),y=cross(z,x);
 return new Float32Array([x[0],y[0],z[0],0,x[1],y[1],z[1],0,x[2],y[2],z[2],0,-dot(x,eye),-dot(y,eye),-dot(z,eye),1]);
}
function perspective(aspect,distance){
 const f=1/Math.tan(Math.PI/7),near=Math.max(.01,distance/2000),far=Math.max(1000,distance*50);
 return new Float32Array([f/aspect,0,0,0,0,f,0,0,0,0,(far+near)/(near-far),-1,0,0,2*far*near/(near-far),0]);
}
function normalMatrix(m){
 const a=[m[0],m[1],m[2]],b=[m[4],m[5],m[6]],c=[m[8],m[9],m[10]];
 const x=cross(b,c),y=cross(c,a),z=cross(a,b),d=dot(a,x);
 return new Float32Array([...x,...y,...z].map(v=>Math.abs(d)<1e-10?0:v/d));
}
function corners(bounds){
 const [lo,hi]=bounds;return [[lo[0],lo[1],lo[2]],[hi[0],lo[1],lo[2]],[hi[0],hi[1],lo[2]],[lo[0],hi[1],lo[2]],[lo[0],lo[1],hi[2]],[hi[0],lo[1],hi[2]],[hi[0],hi[1],hi[2]],[lo[0],hi[1],hi[2]]];
}
export class Viewer{
 constructor(canvas){
  this.canvas=canvas;this.gl=canvas.getContext('webgl',{antialias:true,alpha:false});
  if(!this.gl)throw Error('WebGL indisponível. A edição da árvore e do XML continua disponível.');
  const gl=this.gl;
  this.index32=!!gl.getExtension?.('OES_element_index_uint');
  const shader=(type,text)=>{const s=gl.createShader(type);gl.shaderSource(s,text);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))throw Error(gl.getShaderInfoLog(s));return s;};
  this.program=gl.createProgram();
  gl.attachShader(this.program,shader(gl.VERTEX_SHADER,`
attribute vec3 aPosition;attribute vec3 aNormal;attribute vec4 aTangent;
attribute vec2 aUv0;attribute vec2 aUv1;attribute vec2 aUv2;
uniform mat4 uMVP;uniform mat3 uNormal;
varying vec3 vNormal;varying vec4 vTangent;varying vec2 vUv0;varying vec2 vUv1;varying vec2 vUv2;
void main(){gl_Position=uMVP*vec4(aPosition,1.0);vNormal=uNormal*aNormal;
vTangent=vec4(uNormal*aTangent.xyz,aTangent.w);vUv0=aUv0;vUv1=aUv1;vUv2=aUv2;}`));
  gl.attachShader(this.program,shader(gl.FRAGMENT_SHADER,`
precision mediump float;
varying vec3 vNormal;varying vec4 vTangent;varying vec2 vUv0;varying vec2 vUv1;varying vec2 vUv2;
uniform vec4 uSurface;uniform vec3 uColor;uniform vec4 uMode;uniform vec3 uMapFlags;uniform vec4 uMat;uniform vec4 uDetail;
uniform vec4 uPalette[8];uniform sampler2D uDiffuse;uniform sampler2D uNormalMap;uniform sampler2D uSpecular;
uniform sampler2D uDetailDiffuse;uniform sampler2D uDetailSpecular;
vec4 palette(float i){if(i<0.5)return uPalette[0];if(i<1.5)return uPalette[1];if(i<2.5)return uPalette[2];if(i<3.5)return uPalette[3];if(i<4.5)return uPalette[4];if(i<5.5)return uPalette[5];if(i<6.5)return uPalette[6];return uPalette[7];}
void main(){
 if(uMode.x<0.5){gl_FragColor=vec4(uColor,1.0);return;}
 bool vehicle=uMode.y>0.5;
 bool converted=uSurface.y>0.5;
 bool custom=uMode.z>0.5&&vUv0.y<0.0;
 vec4 paint=palette(clamp(floor(vUv0.x),0.0,7.0));
 float materialIndex=custom?floor(max(paint.a,0.0)):max(0.0,floor(vUv0.x)+floor(vUv0.y)*8.0);
 vec3 base=uColor;float alpha=uMat.x;
 if(uMapFlags.x>0.5){vec4 tex=texture2D(uDiffuse,vUv0);base*=pow(tex.rgb,vec3(2.2));alpha*=tex.a;}
 if(alpha<uMode.w)discard;
 vec3 detailSpec=converted?vec3(uSurface.z,1.0,uSurface.w):vec3(0.1,1.0,0.0);
 if(vehicle&&!converted&&uDetail.y>materialIndex&&uDetail.w>0.0){detailSpec=texture2D(uDetailSpecular,vec2((materialIndex+0.5)/uDetail.y,0.5/uDetail.w)).rgb;}
 if(custom)base=paint.rgb;
 if(vehicle){
  if(custom||uMode.z<0.5)base*=detailSpec.g;
  else if(uDetail.x>materialIndex&&uDetail.z>0.0)base=pow(texture2D(uDetailDiffuse,vec2((materialIndex+0.5)/uDetail.x,0.5/uDetail.z)).rgb,vec3(2.2));
 }
 vec3 n=normalize(vNormal+vec3(0.00001));
 if(uMapFlags.y>0.5&&length(vTangent.xyz)>0.01){
  vec2 normalUV=uMat.z>0.5?vUv2:vUv0;
  vec3 detail=texture2D(uNormalMap,normalUV).xyz*2.0-1.0;
  vec3 t=normalize(vTangent.xyz-n*dot(n,vTangent.xyz));vec3 b=cross(n,t)*vTangent.w;
  n=normalize(t*detail.x*uMat.y+b*detail.y*uMat.y+n*detail.z);
 }
 float ao=1.0;float spec=vehicle?detailSpec.r*0.18:0.08;
 if(uMapFlags.z>0.5){vec2 glossUV=uMat.w>0.5?vUv1:vUv0;vec3 data=texture2D(uSpecular,glossUV).rgb;
  // vehicleShader: R is wear, G is AO, B is dirt. R is not gloss.
  if(vehicle)ao=data.g;else{spec=data.r*0.22;ao=mix(0.65,1.0,data.g);}
 }
 if(!vehicle&&uSurface.x>=0.0)spec=uSurface.x;
 float sun=abs(dot(n,normalize(vec3(0.4,0.9,0.5))));
 vec3 shine=vehicle?mix(vec3(1.0),base,detailSpec.b):vec3(1.0);
 vec3 result=base*(0.34+0.66*sun)*ao+shine*(spec*pow(sun,24.0));
 gl_FragColor=vec4(pow(max(result,vec3(0.0)),vec3(1.0/2.2)),alpha);
}`));
  gl.linkProgram(this.program);if(!gl.getProgramParameter(this.program,gl.LINK_STATUS))throw Error(gl.getProgramInfoLog(this.program));
  this.loc={};for(const n of ['aPosition','aNormal','aTangent','aUv0','aUv1','aUv2'])this.loc[n]=gl.getAttribLocation(this.program,n);
  for(const n of ['uMVP','uNormal','uSurface','uColor','uMode','uMapFlags','uMat','uPalette[0]','uDiffuse','uNormalMap','uSpecular','uDetail','uDetailDiffuse','uDetailSpecular'])this.loc[n]=gl.getUniformLocation(this.program,n);
  this.texturesEnabled=true;
  this.textures=new TextureManager(gl,state=>{this.onTextures?.(state);if(this.vp)this.requestDraw();});
  this.yaw=.72;this.pitch=.55;this.distance=20;this.target=[0,1,0];this.meshes={};this.nodes=[];this.selected=null;this.gpu=[];
  const grid=[];for(let i=-30;i<=30;i++){grid.push(-30,0,i,30,0,i,i,0,-30,i,0,30);}
  this.grid=this.buffer(grid);this.axes=[this.buffer([0,.015,0,5,.015,0]),this.buffer([0,0,0,0,5,0]),this.buffer([0,.015,0,0,.015,5])];
  this.outline=this.buffer([]);this.bindTouch();this.draw();
  canvas.addEventListener('webglcontextlost',e=>{e.preventDefault();document.getElementById('status').textContent='A GPU pausou a cena. Recarregue a página; o projeto permanece salvo.'});
 }
 buffer(vertices,normals,uvs=[],tangents=null){
  const gl=this.gl,mesh={count:vertices.length/3,hasUV:!!uvs[0],extra:[]};
  const put=(name,data)=>{const b=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,b);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(data),gl.STATIC_DRAW);mesh[name]=b;};
  put('b',vertices);put('n',normals||new Float32Array(vertices.length));
  if(tangents){put('t',tangents);mesh.extra.push(mesh.t);}
  uvs.slice(0,3).forEach((uv,i)=>{if(uv){put('uv'+i,uv);mesh.extra.push(mesh['uv'+i]);}});
  return mesh;
 }
 disposeGeometry(){for(const m of this.gpu){for(const b of [m.b,m.n,...m.extra])this.gl.deleteBuffer(b);if(m.ib)this.gl.deleteBuffer(m.ib)}this.gpu=[];this.meshes={};}
 setScene(scene,reset=false){
  this.gizmo=null;this.viewFilter=null;this.locked=new Set();this.selectedMany=[];this.disposeGeometry();this.nodes=scene.nodes;this.materials=scene.materials;this.materialDetails=scene.materialDetails||{};this.selected=null;this.lastHit=null;
  for(const [id,data]of Object.entries(scene.meshes)){
   if(data.positionsBase64){
    let positions=decodeBuffer(data.positionsBase64,Float32Array);
    const indices=decodeBuffer(data.indicesBase64,data.indexType==='u32'?Uint32Array:Uint16Array);
    let normals=data.normalsBase64?decodeBuffer(data.normalsBase64,Float32Array):computeNormals(positions,indices);
    if(positions.length!==data.vertexCount*3||normals.length!==positions.length||indices.length!==data.triangleCount*3)throw Error('Contagem de geometria inconsistente.');
    let uvs=(data.uvSetsBase64||[]).slice(0,3).map(s=>s?decodeBuffer(s,Float32Array):null);
    let tangents=data.tangentsBase64?decodeBuffer(data.tangentsBase64,Float32Array):null;
    if(uvs.some(a=>a&&a.length!==data.vertexCount*2)||tangents&&tangents.length!==data.vertexCount*4)throw Error('UVs/tangentes inconsistentes.');
    const pickPositions=positions;
    let indexed=true;
    if(data.indexType==='u32'&&!this.index32){
     const expanded=new Float32Array(indices.length*3),en=new Float32Array(expanded.length);
     for(let i=0;i<indices.length;i++)for(let j=0;j<3;j++){expanded[i*3+j]=positions[indices[i]*3+j];en[i*3+j]=normals[indices[i]*3+j];}
     const expand=(a,size)=>{if(!a)return null;const out=new Float32Array(indices.length*size);for(let i=0;i<indices.length;i++)for(let j=0;j<size;j++)out[i*size+j]=a[indices[i]*size+j];return out;};
     uvs=uvs.map(a=>expand(a,2));tangents=expand(tangents,4);
     positions=expanded;normals=en;indexed=false;
    }
    const mesh=this.buffer(positions,normals,uvs,tangents);mesh.bounds=data.bounds;mesh.subsets=data.subsets;mesh.count=indices.length;mesh.pickPositions=pickPositions;mesh.pickIndices=indices;
    if(indexed){
     mesh.ib=this.gl.createBuffer();mesh.indexType=data.indexType==='u32'?this.gl.UNSIGNED_INT:this.gl.UNSIGNED_SHORT;mesh.indexBytes=data.indexType==='u32'?4:2;
     this.gl.bindBuffer(this.gl.ELEMENT_ARRAY_BUFFER,mesh.ib);this.gl.bufferData(this.gl.ELEMENT_ARRAY_BUFFER,indices,this.gl.STATIC_DRAW);
    }
    this.gpu.push(mesh);this.meshes[id]=mesh;continue;
   }
   const positions=[],normals=[],uvs=[];let lo=[Infinity,Infinity,Infinity],hi=[-Infinity,-Infinity,-Infinity];
   for(const p of data.positions)for(let i=0;i<3;i++){lo[i]=Math.min(lo[i],p[i]);hi[i]=Math.max(hi[i],p[i]);}
   for(let i=0;i<data.indices.length;i+=3){
    const [a,b,c]=data.indices.slice(i,i+3).map(j=>data.positions[j]);const n=norm(cross(sub(b,a),sub(c,a)));
    for(let j=0;j<3;j++){positions.push(...[a,b,c][j]);normals.push(...n);if(data.uvs)uvs.push(...data.uvs[data.indices[i+j]]);}
   }
   const mesh=this.buffer(positions,normals,uvs.length?[uvs]:[]);mesh.bounds=[lo,hi];mesh.pickPositions=new Float32Array(positions);this.gpu.push(mesh);this.meshes[id]=mesh;
  }
  this.updateMatrices();if(reset)this.frame();else this.draw();
  this.textures.setScene(scene);
 }
 updateMatrices(changedIndex){
  const partial=Number.isInteger(changedIndex)&&this.world?.length===this.nodes.length&&this.nativeVisible?.length===this.nodes.length;
  if(!partial){this.world=[];this.visible=[];this.nativeVisible=[];}
  const native=this.nativeVisible,affected=partial?new Set([changedIndex]):null;
  for(const n of this.nodes){
   if(affected&&!affected.has(n.index)&&!affected.has(n.parent))continue;
   affected?.add(n.index);
   const local=transform(n);this.world[n.index]=n.parent===null?local:multiply(this.world[n.parent],local);native[n.index]=n.visibility&&(n.parent===null||native[n.parent]);this.visible[n.index]=native[n.index]&&(!this.viewFilter||this.viewFilter.has(n.index));
  }
 }
 select(index){this.selected=index;this.selectedMany=[];this.draw();}
 selectMany(indices){this.selectedMany=[...indices];this.selected=indices.at(-1)??null;this.draw();}
 setViewFilter(indices){this.viewFilter=indices?new Set(indices):null;this.updateMatrices();this.draw();}
 setLocked(indices){this.locked=new Set(indices);}
 pick(clientX,clientY){
  this.lastHit=null;
  if(!this.vp)return null;
  const rect=this.canvas.getBoundingClientRect();if(!rect.width||!rect.height)return null;
  const x=(clientX-rect.left)/rect.width*2-1,y=1-(clientY-rect.top)/rect.height*2;
  const inv=inverse(this.vp);if(!inv)return null;
  const near=unproject(inv,[x,y,-1]),far=unproject(inv,[x,y,1]);let hit=null,closest=Infinity;
  for(const n of this.nodes){
   const mesh=this.meshes[n.shapeId];if(!mesh||n.nonRenderable||!this.visible[n.index]||this.locked?.has(n.index))continue;
   const local=inverse(this.world[n.index]);if(!local)continue;
   const o=point(local,near),d=sub(point(local,far),o);if(!boundsHit(o,d,mesh.bounds))continue;
   const p=mesh.pickPositions,indices=mesh.pickIndices,count=indices?.length??p.length/3;
   for(let i=0;i<count;i+=3){
    const vertex=j=>{const k=(indices?indices[j]:j)*3;return [p[k],p[k+1],p[k+2]];};
    const t=triangleHit(o,d,vertex(i),vertex(i+1),vertex(i+2));
    if(t!==null&&t<closest){closest=t;hit=n.index;
     let normal=norm(cross(sub(vertex(i+1),vertex(i)),sub(vertex(i+2),vertex(i))));if(dot(normal,d)>0)normal=normal.map(v=>-v);
     this.lastHit={index:n.index,point:o.map((v,k)=>v+d[k]*t),normal};
    }
   }
  }return hit;
 }
 bounds(index){
  const points=[];
  for(const n of this.nodes){
   if(!this.visible[n.index])continue;
   let p=n.index;while(p!==null&&p!==index)p=this.nodes[p].parent;
   if(index!==undefined&&p!==index)continue;
   const mesh=n.nonRenderable?null:this.meshes[n.shapeId];
   if(mesh&&Number.isFinite(mesh.bounds[0][0]))points.push(...corners(mesh.bounds).map(p=>point(this.world[n.index],p)));
  }
  if(!points.length&&index!==undefined)points.push(point(this.world[index],[0,0,0]));
  if(!points.length)return [[-3,0,-3],[3,3,3]];
  const lo=[Infinity,Infinity,Infinity],hi=[-Infinity,-Infinity,-Infinity];
  for(const p of points)for(let i=0;i<3;i++){lo[i]=Math.min(lo[i],p[i]);hi[i]=Math.max(hi[i],p[i]);}
  return [lo,hi];
 }
 frame(index){
  const [lo,hi]=this.bounds(index);this.target=lo.map((v,i)=>(v+hi[i])*.5);
  const aspect=Math.max(1,this.canvas.clientWidth)/Math.max(1,this.canvas.clientHeight);
  const half=Math.min(Math.PI/7,Math.atan(Math.tan(Math.PI/7)*aspect));
  this.distance=Math.max(3,Math.hypot(...sub(hi,lo))*.5/Math.sin(half)*1.15);this.draw();
 }
 drawItem(mesh,model,color,mode,lit=0,range=null,material={}){
  const gl=this.gl;if(!mesh.count)return;
  gl.bindBuffer(gl.ARRAY_BUFFER,mesh.b);gl.enableVertexAttribArray(this.loc.aPosition);gl.vertexAttribPointer(this.loc.aPosition,3,gl.FLOAT,false,0,0);
  gl.bindBuffer(gl.ARRAY_BUFFER,mesh.n);gl.enableVertexAttribArray(this.loc.aNormal);gl.vertexAttribPointer(this.loc.aNormal,3,gl.FLOAT,false,0,0);
  for(const [name,key,size]of [['aTangent','t',4],['aUv0','uv0',2],['aUv1','uv1',2],['aUv2','uv2',2]]){
   const loc=this.loc[name],buffer=mesh[key];
   if(buffer){gl.bindBuffer(gl.ARRAY_BUFFER,buffer);gl.enableVertexAttribArray(loc);gl.vertexAttribPointer(loc,size,gl.FLOAT,false,0,0);}
   else{gl.disableVertexAttribArray(loc);if(size===4)gl.vertexAttrib4f(loc,0,0,0,1);else gl.vertexAttrib2f(loc,0,0);}
  }
  gl.uniformMatrix4fv(this.loc.uMVP,false,multiply(this.vp,model));gl.uniformMatrix3fv(this.loc.uNormal,false,normalMatrix(model));
  const flags=this.textures.bind(material,this.texturesEnabled&&!!lit,mesh.hasUV);
  gl.uniform3fv(this.loc.uColor,lit?(material.baseColor||color):color);
  gl.uniform4fv(this.loc.uMode,[lit,(material.shaderFamily==='convertedFS25'||material.shaderFamily==='vehicle'&&mesh.hasUV)?1:0,material.colorMask&&mesh.hasUV?1:0,material.alphaTesting?0.12:0]);
  gl.uniform3fv(this.loc.uMapFlags,flags);
  const converted=material.shaderFamily==='convertedFS25',surface=material.convertedSurface||[.65,1,.1,0];
  gl.uniform4fv(this.loc.uSurface,[material.specularStrength??-1,converted?1:0,converted?surface[0]:0,converted?surface[2]:0]);
  gl.uniform4fv(this.loc.uMat,[material.opacity??(material.alphaBlending&&!material.maps?.diffuse?.length?0.35:1),1,material.normalThirdUV&&mesh.uv2?1:0,material.secondUV&&mesh.uv1?1:0]);
  const palette=material.paletteRGBA||(material.palette||Array(8).fill(color)).map(c=>[...c,0]);
  gl.uniform4fv(this.loc['uPalette[0]'],palette.flat());
  gl.uniform4fv(this.loc.uDetail,this.textures.bindDetails(material,this.texturesEnabled&&!!lit,mesh.hasUV));
  ['uDiffuse','uNormalMap','uSpecular','uDetailDiffuse','uDetailSpecular'].forEach((n,i)=>gl.uniform1i(this.loc[n],i));
  const start=range?.firstIndex??0,count=range?.numIndices??mesh.count;
  if(mesh.ib){gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,mesh.ib);gl.drawElements(mode,count,mesh.indexType,start*mesh.indexBytes);}
  else gl.drawArrays(mode,start,count);
 }
 draw(){
  const gl=this.gl,ratio=Math.min(window.devicePixelRatio||1,2),w=Math.max(1,Math.floor(this.canvas.clientWidth*ratio)),h=Math.max(1,Math.floor(this.canvas.clientHeight*ratio));
  if(this.canvas.width!==w||this.canvas.height!==h){this.canvas.width=w;this.canvas.height=h;}
  gl.viewport(0,0,w,h);gl.clearColor(.059,.091,.12,1);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);gl.enable(gl.DEPTH_TEST);gl.disable(gl.CULL_FACE);gl.useProgram(this.program);
  const eye=this.target.map((v,i)=>v+this.distance*[Math.sin(this.yaw)*Math.cos(this.pitch),Math.sin(this.pitch),Math.cos(this.yaw)*Math.cos(this.pitch)][i]);
  this.vp=multiply(perspective(w/h,this.distance),lookAt(eye,this.target));
  const id=identity();this.drawItem(this.grid,id,[.16,.23,.28],gl.LINES);
  [[1,.33,.3],[.4,.9,.65],[.35,.65,1]].forEach((c,i)=>this.drawItem(this.axes[i],id,c,gl.LINES));
  const opaque=[],transparent=[];
  for(const n of this.nodes){
   const mesh=this.meshes[n.shapeId];if(!mesh||n.nonRenderable||!this.visible[n.index])continue;
   const materials=(n.materialIds||'').trim().split(/\s+/),subsets=mesh.subsets?.length?mesh.subsets:[null];
   subsets.forEach((range,i)=>{const id=materials[i]??materials[0],mat=this.materialDetails?.[id]||{};
    (mat.alphaBlending?transparent:opaque).push({mesh,model:this.world[n.index],color:this.materials[id]||[.5,.63,.67],range,mat});});
  }
  transparent.sort((a,b)=>{const center=m=>point(m.model,m.mesh.bounds[0].map((v,i)=>(v+m.mesh.bounds[1][i])/2));return Math.hypot(...sub(center(b),eye))-Math.hypot(...sub(center(a),eye));});
  const render=item=>{
   if(item.mat.alphaTesting){gl.enable(gl.POLYGON_OFFSET_FILL);gl.polygonOffset(-1,-1);}
   this.drawItem(item.mesh,item.model,item.color,gl.TRIANGLES,1,item.range,item.mat);
   if(item.mat.alphaTesting)gl.disable(gl.POLYGON_OFFSET_FILL);
  };
  gl.disable(gl.BLEND);gl.depthMask(true);opaque.forEach(render);
  if(transparent.length){gl.enable(gl.BLEND);gl.blendFunc(gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA);gl.depthMask(false);transparent.forEach(render);gl.depthMask(true);gl.disable(gl.BLEND);}
  for(const selected of this.selectedMany?.length?this.selectedMany:this.selected!==null?[this.selected]:[]){
   if(!this.nodes[selected])continue;
   const cs=corners(this.bounds(selected)),edges=[[0,1],[1,2],[2,3],[3,0],[4,5],[5,6],[6,7],[7,4],[0,4],[1,5],[2,6],[3,7]],p=[];
   for(const [a,b]of edges)p.push(...cs[a],...cs[b]);
   gl.bindBuffer(gl.ARRAY_BUFFER,this.outline.b);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(p),gl.DYNAMIC_DRAW);
   gl.bindBuffer(gl.ARRAY_BUFFER,this.outline.n);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(p.length),gl.DYNAMIC_DRAW);this.outline.count=p.length/3;
   gl.disable(gl.DEPTH_TEST);this.drawItem(this.outline,id,[1,.73,.32],gl.LINES);gl.enable(gl.DEPTH_TEST);
  }
  this.drawGizmo();
 }
 requestDraw(){
  if(this._drawScheduled)return;
  if(typeof requestAnimationFrame!=='function'){this.draw();return;}
  this._drawScheduled=true;
  requestAnimationFrame(()=>{this._drawScheduled=false;this.draw();});
 }
 setGizmo(config,redraw=true){this.gizmo=config;if(redraw)this.draw();}
 screenPoint(p){const r=this.canvas.getBoundingClientRect(),w=this.vp[3]*p[0]+this.vp[7]*p[1]+this.vp[11]*p[2]+this.vp[15];if(w<=0)return null;const q=point(this.vp,p);return [r.left+(q[0]/w+1)*r.width/2,r.top+(1-q[1]/w)*r.height/2];}
 gizmoGeometry(){
  const g=this.gizmo,n=this.nodes[g?.index];if(!n||!this.vp||!this.visible[n.index])return [];
  const parent=n.parent===null?identity():this.world[n.parent],origin=point(this.world[n.index],[0,0,0]),length=this.distance*.115;
  const axes=[0,1,2].map(i=>{const v=[parent[i*4],parent[i*4+1],parent[i*4+2]],l=Math.hypot(...v)||1;return {v:v.map(x=>x/l),factor:l};});
  return axes.map((a,i)=>{
   const points=[];
   if(g.mode==='rotation'){const b=axes[(i+1)%3].v,c=axes[(i+2)%3].v;for(let j=0;j<=48;j++){const angle=j/48*Math.PI*2;points.push(origin.map((v,k)=>v+(b[k]*Math.cos(angle)+c[k]*Math.sin(angle))*length*.8));}}
   else{const end=origin.map((v,k)=>v+a.v[k]*length);points.push(origin,end);}
   return {axis:i,points,origin,screen:points.map(p=>this.screenPoint(p)),length,factor:a.factor};
  });
 }
 gizmoHit(x,y){
  let hit=null,best=18;
  for(const h of this.gizmoGeometry())for(let i=1;i<h.screen.length;i++){const a=h.screen[i-1],b=h.screen[i];if(!a||!b)continue;const dx=b[0]-a[0],dy=b[1]-a[1],size=dx*dx+dy*dy;if(size<(this.gizmo.mode==='rotation'?.01:64))continue;const t=Math.max(this.gizmo.mode==='rotation'?0:.25,Math.min(1,((x-a[0])*dx+(y-a[1])*dy)/size)),d=Math.hypot(x-a[0]-dx*t,y-a[1]-dy*t);if(d<best){best=d;hit=h;}}
  return hit;
 }
 drawGizmo(){
  if(!this.gizmo)return;const gl=this.gl;gl.disable(gl.DEPTH_TEST);
  for(const h of this.gizmoGeometry()){
   const p=[];for(let i=1;i<h.points.length;i++)p.push(...h.points[i-1],...h.points[i]);
   if(h.points.length===2){const end=h.points[1],direction=norm(sub(end,h.origin)),side=norm(cross(direction,[.3,.9,.2]));for(const sign of [-1,1])p.push(...end,...end.map((v,k)=>v-direction[k]*h.length*.18+side[k]*h.length*.07*sign));}
   gl.bindBuffer(gl.ARRAY_BUFFER,this.outline.b);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(p),gl.DYNAMIC_DRAW);gl.bindBuffer(gl.ARRAY_BUFFER,this.outline.n);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(p.length),gl.DYNAMIC_DRAW);this.outline.count=p.length/3;this.drawItem(this.outline,identity(),[[1,.25,.24],[.3,1,.57],[.3,.65,1]][h.axis],gl.LINES);
  }gl.enable(gl.DEPTH_TEST);
 }
 bindTouch(){
  const pointers=new Map(),canvas=this.canvas;let gesture=null,tap=null,drag=null;
  const snap=()=>{const p=[...pointers.values()];return p.length>1?{x:(p[0].x+p[1].x)/2,y:(p[0].y+p[1].y)/2,d:Math.hypot(p[0].x-p[1].x,p[0].y-p[1].y),n:p.length}:{...(p[0]||{x:0,y:0}),n:p.length};};
  canvas.addEventListener('pointerdown',e=>{if(drag){this.gizmo?.onChange?.(drag.base);drag=null;}const hit=this.gizmo&&!pointers.size?this.gizmoHit(e.clientX,e.clientY):null;if(hit&&this.gizmo?.onStart?.()!==false){const n=this.nodes[this.gizmo.index];drag={id:e.pointerId,hit,x:e.clientX,y:e.clientY,base:Object.fromEntries(['translation','rotation','scale'].map(k=>[k,[...n[k]]]))};}if(pointers.size)tap=null;else tap={id:e.pointerId,x:e.clientX,y:e.clientY,time:performance.now()};canvas.setPointerCapture(e.pointerId);pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});gesture=snap();});
  canvas.addEventListener('pointermove',e=>{
   if(!pointers.has(e.pointerId))return;
   if(drag?.id===e.pointerId){tap=null;const h=drag.hit,g=this.gizmo,mode=g.mode,values=Object.fromEntries(Object.entries(drag.base).map(([k,v])=>[k,[...v]])),a=h.screen[0],b=h.screen[h.screen.length-1],dx=e.clientX-drag.x,dy=e.clientY-drag.y;let amount;
    if(mode==='rotation'){const center=this.screenPoint(h.origin);let angle=Math.atan2(e.clientY-center[1],e.clientX-center[0])-Math.atan2(drag.y-center[1],drag.x-center[0]);angle=Math.atan2(Math.sin(angle),Math.cos(angle));amount=-angle*180/Math.PI;}else{const vx=b[0]-a[0],vy=b[1]-a[1],length=vx*vx+vy*vy;amount=(dx*vx+dy*vy)/length;if(mode==='translation')amount*=h.length/h.factor;}
    const step=g.snap||0;if(step)amount=Math.round(amount/step)*step;values[mode][h.axis]=mode==='scale'?drag.base[mode][h.axis]*Math.max(.01,1+amount):drag.base[mode][h.axis]+amount;g.onChange?.(values);return;
   }
   if(tap&&Math.hypot(e.clientX-tap.x,e.clientY-tap.y)>8)tap=null;pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});const now=snap();
   if(gesture&&gesture.n===now.n){
    const dx=now.x-gesture.x,dy=now.y-gesture.y;
    if(now.n===1&&!tap){this.yaw-=dx*.008;this.pitch=Math.max(-1.45,Math.min(1.45,this.pitch+dy*.008));}
    else if(now.n>1){const scale=this.distance*.002;this.target[0]-=Math.cos(this.yaw)*dx*scale;this.target[2]+=Math.sin(this.yaw)*dx*scale;this.target[1]+=dy*scale;if(gesture.d>3&&now.d>3)this.distance=Math.max(.1,Math.min(1e6,this.distance*gesture.d/now.d));}
   }
   gesture=now;this.requestDraw();
  });
  for(const event of ['pointerup','pointercancel','lostpointercapture'])canvas.addEventListener(event,e=>{if(drag?.id===e.pointerId){if(event!=='pointerup')this.gizmo?.onChange?.(drag.base);this.gizmo?.onEnd?.();drag=null;tap=null;}if(event==='pointerup'&&tap?.id===e.pointerId&&performance.now()-tap.time<700)this.onPick?.(this.pick(e.clientX,e.clientY));tap=null;pointers.delete(e.pointerId);gesture=snap();});
  canvas.addEventListener('wheel',e=>{e.preventDefault();this.distance=Math.max(.1,Math.min(1e6,this.distance*Math.exp(e.deltaY*.001)));this.requestDraw();},{passive:false});
  new ResizeObserver(()=>this.draw()).observe(canvas);
 }
}

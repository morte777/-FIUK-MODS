// Values are local to the parent, matching the stored I3D attributes.
export const copyTransform=n=>Object.fromEntries(['translation','rotation','scale'].map(k=>[k,[...n[k]]]));
export function adjusted(base,key,axis,amount){
 if(!['translation','rotation','scale'].includes(key)||!Number.isFinite(amount)||![0,1,2,3].includes(axis))throw Error('Ajuste inválido.');
 const out=copyTransform(base),axes=axis===3?[0,1,2]:[axis];
 for(const i of axes){
  const value=key==='scale'?base[key][i]*Math.max(.01,1+amount):base[key][i]+amount;
  if(!Number.isFinite(value)||Math.abs(value)>1e9)throw Error('Valor fora do limite.');
  out[key][i]=Number(value.toFixed(6));
 }return out;
}

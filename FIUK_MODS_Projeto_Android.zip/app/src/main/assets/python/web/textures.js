// AST/GS2D payloads are served locally; original mod assets remain untouched.
const formats=['4x4','5x4','5x5','6x5','6x6','8x5','8x6','8x8','10x5','10x6','10x8','10x10','12x10','12x12'];
export function bytes64(text){const s=atob(text),b=new Uint8Array(s.length);for(let i=0;i<s.length;i++)b[i]=s.charCodeAt(i);return b;}
const pot=x=>x>0&&(x&(x-1))===0;
export class TextureManager{
 constructor(gl,update){
  this.gl=gl;this.update=update;this.generation=0;this.cache=new Map();this.dimensions=new Map();this.errors=[];
  this.astc=gl.getExtension?.('WEBGL_compressed_texture_astc');
  this.aniso=gl.getExtension?.('EXT_texture_filter_anisotropic');
  this.limit=Math.min(2048,gl.getParameter?.(gl.MAX_TEXTURE_SIZE)||2048);
  this.white=this.pixel([255,255,255,255]);this.neutral=this.pixel([128,128,255,255]);this.spec=this.pixel([64,255,0,255]);
 }
 pixel(rgba){const gl=this.gl,t=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,t);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,1,1,0,gl.RGBA,gl.UNSIGNED_BYTE,new Uint8Array(rgba));this.filter(false,false);return t;}
 filter(mips,repeat){
  const gl=this.gl;gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,mips?gl.LINEAR_MIPMAP_LINEAR:gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,repeat?gl.REPEAT:gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,repeat?gl.REPEAT:gl.CLAMP_TO_EDGE);
  if(this.aniso?.TEXTURE_MAX_ANISOTROPY_EXT)gl.texParameterf(gl.TEXTURE_2D,this.aniso.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(4,gl.getParameter(this.aniso.MAX_TEXTURE_MAX_ANISOTROPY_EXT)||1));
 }
 clear(){for(const t of this.cache.values())this.gl.deleteTexture(t);this.cache.clear();this.dimensions.clear();}
 get(path){return path?this.cache.get(path):null;}
 state(){return {loaded:this.paths?.filter(p=>this.cache.has(p)).length||0,total:this.paths?.length||0,errors:this.errors,astc:!!this.astc};}
 setScene(scene){
  const gen=++this.generation;
  if(this.project!==scene.projectId){this.clear();this.project=scene.projectId;}
  this.paths=scene.textureInfo?.resources||[];this.formats=scene.textureInfo?.formats||{};this.pixelPaths=new Set(Object.values(scene.materialDetails||{}).flatMap(m=>[m.maps?.detailDiffuse,m.maps?.detailSpecular]).filter(Boolean));this.errors=[];
  const needed=new Set(this.paths);
  for(const [p,t]of this.cache)if(!needed.has(p)){this.gl.deleteTexture(t);this.cache.delete(p);this.dimensions.delete(p);}
  this.update(this.state());
  const queue=this.paths.filter(p=>!this.cache.has(p));
  const worker=async()=>{while(queue.length&&gen===this.generation){
   const path=queue.shift();
   try{await this.load(path,gen);}catch(e){if(gen===this.generation)this.errors.push(path+': '+e.message);}
   if(gen===this.generation)this.update(this.state());
  }};
  this.pending=Promise.all([worker(),worker()]);return this.pending;
 }
 url(route,path,size){return route+'?file='+encodeURIComponent(path)+'&project='+encodeURIComponent(this.project)+'&size='+size;}
 async response(url){const r=await fetch(url);if(!r.ok){let message='Falha ao carregar textura';try{message=(await r.json()).error||message;}catch{}throw Error(message);}return r;}
 async load(path,gen){
  const gl=this.gl,isAst=this.formats[path]==='astc'||/\.(ast|astc)$/i.test(path);
  if(isAst){
   let t=null;
   try{
    const info=await(await this.response(this.url('/api/texture',path,this.limit))).json();
    if(gen!==this.generation)return;
    t=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,t);
    for(let i=0;i<4&&gl.getError?.();i++){}
    if(info.encoding==='rgba8'){
     gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,false);gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL,false);
     info.levels.forEach((m,i)=>{const bytes=bytes64(m.data);if(bytes.length!==m.width*m.height*4)throw Error('Pixels RGBA8 incompletos');gl.texImage2D(gl.TEXTURE_2D,i,gl.RGBA,m.width,m.height,0,gl.RGBA,gl.UNSIGNED_BYTE,bytes);});
    }else{
     if(!this.astc)throw Error('GPU sem ASTC');
     const index=formats.indexOf(info.blockX+'x'+info.blockY);if(index<0)throw Error('Bloco ASTC nao suportado');
     info.levels.forEach((m,i)=>gl.compressedTexImage2D(gl.TEXTURE_2D,i,0x93B0+index,m.width,m.height,0,bytes64(m.data)));
    }
    const last=info.levels.at(-1),complete=last.width===1&&last.height===1;
    this.filter(complete,pot(info.width)&&pot(info.height));
    if(gl.getError?.())throw Error('GPU recusou a textura '+(info.encoding||'ASTC'));
    this.dimensions.set(path,[info.width,info.height]);this.paletteFilter(path);this.cache.set(path,t);return;
   }catch(e){if(t)gl.deleteTexture(t);if(gen!==this.generation)return;}
  }
  const response=await this.response(this.url('/api/texture-image',path,isAst?Math.min(1024,this.limit):this.limit));
  const blob=await response.blob();let image;
  if(typeof createImageBitmap==='function')image=await createImageBitmap(blob,{premultiplyAlpha:'none',imageOrientation:isAst?'none':'flipY'});
  else image=await new Promise((resolve,reject)=>{const img=new Image(),url=URL.createObjectURL(blob);img.onload=()=>{URL.revokeObjectURL(url);resolve(img)};img.onerror=()=>{URL.revokeObjectURL(url);reject(Error('Imagem invalida'))};img.src=url;});
  if(gen!==this.generation){image.close?.();return;}
  const t=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,t);
  // ASTC already uses the engine's bottom-up orientation; ordinary images do not.
  gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,typeof createImageBitmap==='function'?false:!isAst);gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL,false);
  gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,image);
  const repeat=pot(image.width)&&pot(image.height);if(repeat)gl.generateMipmap(gl.TEXTURE_2D);this.filter(repeat,repeat);
  this.dimensions.set(path,[image.width,image.height]);this.paletteFilter(path);image.close?.();this.cache.set(path,t);
 }
 setCanvas(path,canvas){
  const gl=this.gl,t=this.cache.get(path)||gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,t);gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,true);gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL,false);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,canvas);const repeat=pot(canvas.width)&&pot(canvas.height);if(repeat)gl.generateMipmap(gl.TEXTURE_2D);this.filter(repeat,repeat);this.cache.set(path,t);this.dimensions.set(path,[canvas.width,canvas.height]);return t;
 }
 removeCanvas(path){const t=this.cache.get(path);if(t)this.gl.deleteTexture(t);this.cache.delete(path);this.dimensions.delete(path);}
 paletteFilter(path){
  if(!this.pixelPaths?.has(path))return;
  const gl=this.gl;
  gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.NEAREST);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.NEAREST);
  gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);
 }
 bindDetails(material,enabled,hasUV){
  const gl=this.gl,maps=material?.maps||{},result=[0,0,0,0];
  [maps.detailDiffuse,maps.detailSpecular].forEach((p,i)=>{
   const t=enabled&&hasUV?this.get(p):null;gl.activeTexture(gl.TEXTURE0+3+i);gl.bindTexture(gl.TEXTURE_2D,t||(i?this.spec:this.white));
   if(t){const [w,h]=this.dimensions.get(p)||[0,0];result[i]=w;result[i+2]=h;}
  });return result;
 }
 bind(material,enabled,hasUV){
  const gl=this.gl,maps=material?.maps||{};
  const paths=[maps.diffuse,maps.normal,maps.specular],fallbacks=[this.white,this.neutral,this.spec];
  const flags=paths.map(p=>enabled&&hasUV&&this.get(p)?1:0);
  paths.forEach((p,i)=>{gl.activeTexture(gl.TEXTURE0+i);gl.bindTexture(gl.TEXTURE_2D,flags[i]?this.get(p):fallbacks[i]);});
  return flags;
 }
}

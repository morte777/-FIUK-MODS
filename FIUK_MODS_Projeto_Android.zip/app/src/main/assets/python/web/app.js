import {installTextureConvert} from './texture-convert-ui.js';
import {installOptionalManager} from './optional-manager-ui.js';
import {Viewer} from './viewer.js';
import {installWheels} from './wheels-ui.js';
import {installWorkbench} from './workbench-ui.js';
import {installSelection} from './selection-ui.js';
import {installAnimations} from './animation-ui.js';
import {installCreation} from './creation-ui.js';
import {installTexturePaint} from './texture-paint-ui.js';
import {copyTransform,adjusted} from './editing.js';
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const state={project:null,scene:null,file:null,selected:null,list:'scene',view:'model',busy:false,xmlDirty:false,wheelConfig:0};
let viewer=null,editOriginal=null,sliderBase=null,paintData=null,paintPreview=null,accessoryData=null,accessoryTarget=null;
const transformDrafts=new Map(),collapsedGroups=new Set();let treeScope=null;
let editMode='translation',editAxis=0,wheelTools=null,workbenchTools=null,selectionTools=null,animationTools=null,textureTools=null,optionalManager=null,textureConverter=null,gizmoEnabled=true;
try{viewer=new Viewer($('#canvas'));}catch(e){$('#renderError').hidden=false;$('#renderError').textContent=e.message;}
if(viewer)viewer.onTextures=info=>{
 const el=$('#textureStatus'),failed=info.errors.length;
 el.textContent=info.total?`TEXTURAS ${info.loaded}/${info.total}${failed?' · '+failed+' indisponível(is) · detalhes':''}`:'';
 el.title=info.errors.join('\n');el.classList.toggle('failed',!!failed);el.onclick=failed?()=>window.alert('Algumas texturas nao foram carregadas:\n\n'+info.errors.join('\n')):null;
};
$('#texturesToggle').onclick=()=>{if(viewer){viewer.texturesEnabled=!viewer.texturesEnabled;$('#texturesToggle').textContent=viewer.texturesEnabled?'Texturas ✓':'Texturas —';$('#texturesToggle').setAttribute('aria-pressed',String(viewer.texturesEnabled));viewer.draw();}};
const status=message=>{$('#status').textContent=message;};
async function api(path,body){
 const response=await fetch(path,body===undefined?{}:{method:'POST',headers:{'Content-Type':'application/json','X-Gabriel-Editor':'1'},body:JSON.stringify(body)});
 const result=await response.json();if(!response.ok)throw Error(result.error||'Falha na operação');return result;
}
function baseChanged(base){
 const active=base?.active;
 $('#baseBadge').textContent=active?base.name+' · '+base.files.toLocaleString('pt-BR')+' recursos':base?.error?'Base indisponível':'APK ou pasta data';
 $('#baseBadge').title=base?.path||'';
 $('#baseCurrent').textContent=active?`Base conectada: ${base.name} · ${base.files.toLocaleString('pt-BR')} recursos. Somente leitura.`:base?.error||'Nenhuma base conectada.';
 $('#removeBase').disabled=!base?.path;$('#showBaseVehicles').disabled=!active;$('#baseBrowseVehicles').disabled=!active;
}
async function refreshBases(){
 const result=await api('/api/base');baseChanged(result);
 const select=$('#baseCandidates');select.replaceChildren();
 const first=document.createElement('option');first.value='';first.textContent=result.candidates.length?'Selecione o APK ou ZIP…':'Nenhum APK/ZIP encontrado em Download';select.append(first);
 for(const file of result.candidates){const option=document.createElement('option');option.value=file.path;option.textContent=file.name+(file.size?' · '+(file.size/1024**3>=1?(file.size/1024**3).toFixed(2)+' GB':(file.size/1024**2).toFixed(1)+' MB'):'');select.append(option);}
 if(!$('#basePath').value&&result.path)$('#basePath').value=result.path;
 $('#baseFeedback').textContent=result.candidates.length?'':'Se o APK estiver em Download e não aparecer, libere o acesso do Termux com termux-setup-storage ou cole o caminho abaixo.';
}
$('#showBase').onclick=()=>{if(state.busy)return;$('#baseDialog').showModal();busy('Lendo arquivos disponíveis…',refreshBases);};
$('#closeBase').onclick=()=>$('#baseDialog').close();
$('#refreshBases').onclick=()=>busy('Atualizando lista…',refreshBases);
$('#baseCandidates').onchange=e=>{if(e.target.value)$('#basePath').value=e.target.value;};
$('#baseForm').onsubmit=e=>{e.preventDefault();busy('Conectando a base do jogo…',async()=>{
 if(!dirtyGuard())return;const path=$('#basePath').value.trim();if(!path)throw Error('Selecione o APK na lista ou informe o caminho.');
 $('#baseFeedback').textContent='Lendo o índice da base. O jogo não será extraído…';
 let result;try{result=await api('/api/base',{path});}catch(error){$('#baseFeedback').textContent=error.message;throw error;}
 baseChanged(result);if(state.file)await openScene(state.file);
 $('#baseDialog').close();status('Base conectada. Os recursos encontrados serão carregados na cena.');
});};
$('#removeBase').onclick=()=>busy('Desconectando base…',async()=>{
 if(!dirtyGuard())return;baseChanged(await api('/api/base',{path:null}));$('#basePath').value='';$('#baseFeedback').textContent='Base desconectada. O APK permanece intacto.';
 if(state.file)await openScene(state.file);status('Base desconectada.');
});
let baseVehicleState=null;
function baseVehicleButtons(enabled){$('#baseVehicleOpen').disabled=!enabled;$('#baseVehicleDownload').disabled=!enabled;}
function renderBaseVehicles(){
 const p=baseVehicleState,select=$('#baseVehicleList'),previous=select.value,search=$('#baseVehicleSearch').value.toLowerCase(),models=$('#baseVehicleModels').checked;select.replaceChildren();baseVehicleButtons(false);if(!p)return;
 const rows=p.items.filter(r=>(models||r.kind==='vehicle')&&[r.name,r.brand,r.file].join(' ').toLowerCase().includes(search));
 for(const row of rows){const option=document.createElement('option');option.value=row.file;option.textContent=[row.brand,row.name,row.kind==='model'?'I3D':null].filter(Boolean).join(' · ')+(row.available?'':' · indisponível');option.disabled=!row.available;select.append(option);}
 select.value=rows.some(r=>r.file===previous&&r.available)?previous:rows.find(r=>r.available)?.file||'';p.selected=select.value;p.report=null;
 $('#baseVehicleCount').textContent=rows.length+' resultado(s) · '+p.items.filter(r=>r.kind==='vehicle').length+' veículo(s) com XML na base';
 $('#baseVehicleDetails').textContent=rows.length?'Selecione um item para ver os arquivos.':'Nenhum resultado. Tente outra busca ou marque modelos I3D avulsos. Se os arquivos estiverem apenas em dataS.gar, esta versão não consegue listá-los.';
}
async function loadBaseVehicleDetails(){
 const p=baseVehicleState,file=$('#baseVehicleList').value;baseVehicleButtons(false);if(!p||!file)return;const baseId=p.baseId;p.selected=file;
 const result=await api('/api/base-vehicle-info?file='+encodeURIComponent(file)+'&baseId='+encodeURIComponent(baseId));
 if(baseVehicleState!==p||p.selected!==file)return;p.report=result;$('#baseVehicleDetails').textContent=[result.folder,result.files+' arquivo(s) · '+(result.size/1024/1024).toFixed(1)+' MB',result.kind==='model'?'Modelo I3D avulso. O XML do veículo pode não estar disponível.':result.name,result.note].join('\n');baseVehicleButtons(true);
}
async function showBaseVehicles(refresh=false){
 if(state.busy)return;$('#baseDialog').close();$('#baseVehiclesDialog').showModal();baseVehicleButtons(false);$('#baseVehiclesSource').textContent='Lendo os veículos da base…';
 await busy('Listando veículos da base…',async()=>{
  const result=await api('/api/base-vehicles'+(refresh?'?refresh=1':''));baseVehicleState=result;$('#baseVehiclesSource').textContent=result.baseName;$('#baseVehicleSearch').value='';$('#baseVehicleModels').checked=!result.items.some(r=>r.kind==='vehicle'&&r.available);renderBaseVehicles();await loadBaseVehicleDetails();
 });
}
$('#showBaseVehicles').onclick=()=>showBaseVehicles();$('#baseBrowseVehicles').onclick=()=>showBaseVehicles();$('#refreshBaseVehicles').onclick=()=>showBaseVehicles(true);
$('#closeBaseVehicles').onclick=()=>{if(!state.busy)$('#baseVehiclesDialog').close();};$('#baseVehiclesDialog').addEventListener('cancel',e=>{if(state.busy)e.preventDefault();});
for(const id of ['baseVehicleSearch','baseVehicleModels'])$('#'+id)[id==='baseVehicleSearch'?'oninput':'onchange']=()=>{if(state.busy)return;renderBaseVehicles();busy('Conferindo os arquivos do veículo…',loadBaseVehicleDetails);};
$('#baseVehicleList').onchange=()=>busy('Conferindo os arquivos do veículo…',loadBaseVehicleDetails);
$('#baseVehicleOpen').onclick=()=>busy('Criando a cópia editável do veículo…',async()=>{
 const p=baseVehicleState;if(!p?.report)throw Error('Selecione um veículo disponível.');if(!dirtyGuard())return;
 const result=await api('/api/base-vehicle-open',{file:p.selected,baseId:p.baseId});await startProject(result.project);$('#baseVehiclesDialog').close();status('Cópia da base aberta com '+result.files+' arquivo(s). Edite e use Salvar como mod para gerar o pacote novo.'+(result.missingCount?' Há '+result.missingCount+' referência(s) ausente(s); confira GABRIEL_BASE.txt.':''));
});
$('#baseVehicleDownload').onclick=()=>busy('Preparando o ZIP do veículo da base…',async()=>{
 const p=baseVehicleState;if(!p?.report)throw Error('Selecione um veículo disponível.');const response=await fetch('/api/base-vehicle-export',{method:'POST',headers:{'Content-Type':'application/json','X-Gabriel-Editor':'1'},body:JSON.stringify({file:p.selected,baseId:p.baseId})});
 if(!response.ok){const error=await response.json();throw Error(error.error||'Não foi possível exportar o veículo.');}
 const url=URL.createObjectURL(await response.blob()),a=document.createElement('a');a.href=url;a.download='FS23_Base_'+p.selected.split('/').pop().replace(/\.(xml|i3d)$/i,'').replace(/[^A-Za-z0-9_-]/g,'_')+'.zip';document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),30000);status('ZIP da base preparado para download. Você pode abri-lo pelo botão Abrir mod.');
});
let newModState=null;
function newModVehicleFields(){
 const row=newModState?.vehicles.find(v=>v.file===$('#newModVehicle').value);if(!row)return;$('#newModTitle').value=row.name+' Editado';$('#newModPrice').value=row.price;
}
async function showNewMod(){
 if(state.busy||!exportReady())return;if(!state.project?.project||!state.file){status('Abra o veículo completo primeiro.');return;}
 await busy('Preparando os dados do novo mod…',async()=>{
  const info=await api('/api/new-mod?file='+encodeURIComponent(state.file));newModState=info;const select=$('#newModVehicle');select.replaceChildren();for(const row of info.vehicles){const option=document.createElement('option');option.value=row.file;option.textContent=row.name+' · '+row.file;select.append(option);}select.value=info.vehicles[0].file;
  newModVehicleFields();$('#newModTitle').value=info.title;$('#newModInternal').value=info.internalName;$('#newModAuthor').value=info.author;$('#newModVersion').value=info.version;$('#newModDescription').value=info.description;$('#newModDescVersion').value=info.descVersion;$('#newModIcon').value='';$('#newModDialog').showModal();
 });
}
$('#showNewMod').onclick=showNewMod;$('#newModVehicle').onchange=newModVehicleFields;
$('#closeNewMod').onclick=()=>{if(!state.busy){newModState=null;$('#newModDialog').close();}};$('#newModDialog').addEventListener('cancel',e=>{if(state.busy)e.preventDefault();else newModState=null;});
$('#newModForm').onsubmit=e=>{e.preventDefault();busy('Gerando o pacote do novo mod…',async()=>{
 if(!newModState)throw Error('Abra Salvar como mod primeiro.');if(!exportReady())return;
 const priceText=$('#newModPrice').value.trim(),body={project:newModState.project,revision:newModState.revision,file:newModState.file,vehicle:$('#newModVehicle').value,title:$('#newModTitle').value.trim(),internalName:$('#newModInternal').value.trim(),author:$('#newModAuthor').value.trim(),version:$('#newModVersion').value.trim(),description:$('#newModDescription').value,descVersion:Number($('#newModDescVersion').value),price:priceText?Number(priceText):null};
 if(!/^[A-Za-z][A-Za-z0-9_]{2,79}$/.test(body.internalName))throw Error('Nome do arquivo: use letras, números e _, começando por letra.');
 if(priceText&&(!Number.isFinite(body.price)||body.price<0||body.price>10000000))throw Error('Preço inválido.');
 const image=$('#newModIcon').files?.[0];if(image)body.iconPng=await decalPNG(image);
 const response=await fetch('/api/new-mod-export',{method:'POST',headers:{'Content-Type':'application/json','X-Gabriel-Editor':'1'},body:JSON.stringify(body)});if(!response.ok){const error=await response.json();throw Error(error.error||'Não foi possível gerar o mod.');}
 const url=URL.createObjectURL(await response.blob()),a=document.createElement('a');a.href=url;a.download=body.internalName+'.zip';document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),30000);newModState=null;$('#newModDialog').close();status('Mod novo gerado com modDesc.xml, veículo e edições.'+(response.headers?.get('X-Gabriel-Icon')==='fallback'?' Foi usado um ícone simples.':''));
});};
async function busy(label,fn){
 if(state.busy)return;state.busy=true;$('#busyLabel').textContent=label;$('#busy').hidden=false;
 for(const id of ['textureConvertDialog','optionalManagerDialog','optionalDialog','accessoryDialog','baseVehiclesDialog','newModDialog','wheelDialog','workbenchDialog','removePieceDialog','emptySceneDialog','primitiveDialog','objectExportDialog','texturePaintDialog'])$('#'+id).inert=true;
 try{await fn();return true;}catch(e){status(e.message);window.alert(e.message);return false;}finally{state.busy=false;$('#busy').hidden=true;for(const id of ['textureConvertDialog','optionalManagerDialog','optionalDialog','accessoryDialog','baseVehiclesDialog','newModDialog','wheelDialog','workbenchDialog','removePieceDialog','emptySceneDialog','primitiveDialog','objectExportDialog','texturePaintDialog'])$('#'+id).inert=false;updateDraftBar();}
}
function projectChanged(project){
 state.project=project;window.dispatchEvent?.(new CustomEvent('gabriel-project-profile',{detail:project}));
 const active=!!project.project;$('#projectName').textContent=active?project.name:'Seu novo espaço de criação';
 $('#changeCount').textContent=active?`${project.changes} ARQUIVO(S) ALTERADO(S)`:'OFFLINE';
 $('#undo').disabled=!project.canUndo;$('#redo').disabled=!project.canRedo;$('#export').disabled=!active;$('#i3ds').disabled=!active;
 $('#welcome').hidden=active;$('#showNewMod').disabled=!active;
 const selected=state.file;$('#i3ds').replaceChildren();
 if(active)for(const name of project.i3ds){const option=document.createElement('option');option.value=name;option.textContent=name;$('#i3ds').append(option);}
 if(selected&&project.i3ds?.includes(selected))$('#i3ds').value=selected;
 const fs19=project.compatibility?.game==='FS19';$('#showTextureConvert').disabled=fs19;$('#showTextureConvert').title=fs19?'FS19 mantém texturas DDS; conversão de jogo será uma opção separada.':'';$('#fileStats').textContent=active?`${project.files.length} arquivos · ${fs19?'FS19 · exportação original':'original preservado'}`:'Abra um ZIP para começar';renderTree();
}
async function openScene(file,reset=false){
 if(animationTools?.isActive())animationTools.close();
 snapshotOptionalDraft();resetOptionalPreview();cancelAlignment();
 if(state.file!==file)state.wheelConfig=0;
 if(transformDrafts.size)throw Error('Use Salvar tudo ou Descartar tudo antes de recarregar a cena.');
 const nextScope=state.project.project+':'+file;if(treeScope!==nextScope){collapsedGroups.clear();treeScope=nextScope;}
 editOriginal=null;sliderBase=null;state.file=file;state.selected=null;state.scene=await api('/api/scene?file='+encodeURIComponent(file)+'&wheelConfig='+state.wheelConfig);
 rebindOptionalDraft();$('#i3ds').value=file;if(state.scene.gameBase)baseChanged(state.scene.gameBase);viewer?.setScene(state.scene,reset);if(selectionTools)await selectionTools.sceneChanged();renderSelection();renderTree();
 const count=Object.values(state.scene.meshes).reduce((n,m)=>n+(m.triangleCount??m.indices.length/3),0);
 wheelsChanged();
 $('#meshStats').textContent=`${state.scene.nodes.length} NÓS · ${count.toLocaleString('pt-BR')} TRIÂNGULOS`;
 const warnings=state.scene.warnings;$('#warnings').hidden=!warnings.length;$('#warnings').textContent=warnings.join(' ');
 if(optionalState?.mode==='position')previewOptionalScene();updateOptionalWorkflow();
 try{localStorage.setItem('gabriel:lastFile:'+state.project.project,file);}catch{}
 status('I3D aberto. Selecione uma peça para editar.');
}
function wheelsChanged(){
 const info=state.scene?.wheelInfo;$('#showWheels').disabled=!info;
 $('#wheelBadge').textContent=info?`${info.tiresLoaded}/${info.requested} pneus · ${info.rimsLoaded} aros · ${info.hubsLoaded} cubos`:'Prévia pelo XML do veículo';
 const select=$('#wheelConfig');select.replaceChildren();
 const off=document.createElement('option');off.value='-1';off.textContent='Somente I3D · sem montagem';select.append(off);
 if(!info){$('#wheelReport').textContent='Nenhuma configuração de rodas encontrada.';$('#wheelMissing').textContent='';return;}
 state.wheelConfig=info.selected;
 for(const config of info.configurations){const option=document.createElement('option');option.value=config.index;option.textContent=[config.brand,config.name,config.saveId].filter(Boolean).join(' · ');select.append(option);}
 select.value=String(info.selected);
 $('#wheelReport').textContent=info.selected<0?'Montagem desativada na prévia.':`${info.tiresLoaded} de ${info.requested} pneus montados · ${info.rimsLoaded} aros · ${info.hubsLoaded} cubos. As peças montadas aparecem na árvore.`;
 $('#wheelMissing').textContent=info.missing?.length?'Recursos/etapas indisponíveis:\n'+info.missing.join('\n'):'Recursos da configuração carregados.';
}
function resetPaintPreview(){
 if(!paintPreview)return;const p=paintPreview;state.scene.nodes[p.index].materialIds=p.ids;
 if(p.shared){state.scene.materialDetails[p.id]=p.original;state.scene.materials[p.id]=p.color;}
 else{delete state.scene.materialDetails[p.temporary];delete state.scene.materials[p.temporary];}
 paintPreview=null;viewer?.draw();
}
function closePaint(){resetPaintPreview();paintData=null;$('#paintPanel').hidden=true;renderSelection();}
function paintChoice(){return paintData?.materials.find(m=>m.id===$('#paintMaterial').value);}
function paintChannelChanged(){
 resetPaintPreview();const m=paintChoice(),choice=m?.choices.find(c=>c.key===$('#paintChannel').value);
 $('#paintColor').disabled=!choice;$('#paintHex').disabled=!choice;$('#paintApply').disabled=!choice;
 if(choice){$('#paintColor').value=choice.color;$('#paintHex').value=choice.color;}
 $('#paintNote').textContent=m?.note||'Prévia na cena. Salvar cor grava a pintura no projeto.';
}
function paintMaterialChanged(){
 resetPaintPreview();const material=paintChoice(),select=$('#paintChannel');select.replaceChildren();
 for(const choice of material?.choices||[]){const option=document.createElement('option');option.value=choice.key;option.textContent=choice.label;select.append(option);}
 select.value=material?.choices[0]?.key||'';$('#paintShares').textContent=material?'('+material.shared+' peças)':'';paintChannelChanged();
}
function previewPaint(){
 if(!paintData)return;const hex=$('#paintHex').value;
 if(!/^#[0-9a-f]{6}$/i.test(hex))return;
 resetPaintPreview();const material=paintChoice(),channel=$('#paintChannel').value;
 if(!material?.choices.some(c=>c.key===channel))return;
 const rgb=[1,3,5].map(i=>parseInt(hex.slice(i,i+2),16)/255).map(v=>v<=.04045?v/12.92:((v+.055)/1.055)**2.4);
 const id=material.id,node=state.scene.nodes[paintData.index],original=state.scene.materialDetails[id],color=state.scene.materials[id],copy=JSON.parse(JSON.stringify(original)),shared=$('#paintShared').checked,temporary='_paintPreview';
 paintPreview={id,original,color,index:paintData.index,ids:node.materialIds,temporary,shared};
 if(channel==='base')copy.baseColor=rgb;
 else if(channel==='convertedColor'){copy.convertedColor=[...rgb,copy.convertedColor?.[3]??1];copy.baseColor=rgb.map((v,i)=>v*(copy.diffuseColorFactor?.[i]??1));}
 else{const slot=Number(channel.slice(-1));copy.paletteRGBA[slot]=[...rgb,copy.paletteRGBA[slot][3]];if(copy.palette)copy.palette[slot]=rgb;}
 if(shared){state.scene.materialDetails[id]=copy;state.scene.materials[id]=channel==='base'?rgb:color;}
 else{state.scene.materialDetails[temporary]=copy;state.scene.materials[temporary]=channel==='base'?rgb:color;node.materialIds=node.materialIds.split(/\s+/).map(mid=>mid===id?temporary:mid).join(' ');}
 viewer?.draw();
}
$('#showPaint').onclick=async()=>{
 if(alignMode){status('Termine ou cancele o alinhamento primeiro.');return;}
 if(optionalState){status('Conclua ou feche o opcional antes de pintar.');return;}
 if(state.busy)return;if(!editableNode()?.materialIds){status('Selecione uma peça do I3D principal para pintar.');return;}
 if(paintData)return;
 if(!await saveTransform())return;
 await busy('Lendo os materiais da peça…',async()=>{
  const result=await api('/api/paint?file='+encodeURIComponent(state.file)+'&index='+state.selected);
  if(!result.materials.length)throw Error('Esta peça não possui material para pintar.');
  paintData={...result,file:state.file};$('#paintPiece').textContent='Pintura · '+result.name;$('#paintShared').checked=false;
  const select=$('#paintMaterial');select.replaceChildren();for(const m of result.materials){const option=document.createElement('option');option.value=m.id;option.textContent=m.name;select.append(option);}
  select.value=result.materials.find(m=>m.choices.length)?.id||result.materials[0].id;paintMaterialChanged();
  $('#left').classList.remove('open');$('#inspector').classList.remove('open');$('#paintPanel').hidden=false;viewer?.setGizmo?.(null);$('#touchEditor').hidden=true;requestAnimationFrame(()=>viewer?.draw());
 });
};
$('#paintMaterial').onchange=paintMaterialChanged;$('#paintChannel').onchange=paintChannelChanged;
$('#paintColor').oninput=()=>{$('#paintHex').value=$('#paintColor').value;previewPaint();};
$('#paintHex').oninput=()=>{if(/^#[0-9a-f]{6}$/i.test($('#paintHex').value)){$('#paintColor').value=$('#paintHex').value;previewPaint();}};
$('#paintShared').onchange=previewPaint;$('#paintCancel').onclick=closePaint;
$('#paintPanel').onsubmit=e=>{e.preventDefault();busy('Salvando a pintura…',async()=>{
 if(!paintData)throw Error('Abra a pintura da peça.');
 const data=paintData,materialId=$('#paintMaterial').value,channel=$('#paintChannel').value,color=$('#paintHex').value,shared=$('#paintShared').checked;
 if(!/^#[0-9a-f]{6}$/i.test(color))throw Error('Escolha uma cor válida, como #ff0000.');
 resetPaintPreview();const result=await api('/api/paint',{file:data.file,index:data.index,materialId,channel,color,shared,revision:data.revision});
 closePaint();projectChanged(result.project);await openScene(data.file);state.selected=result.index;viewer?.select(result.index);renderSelection();renderTree();status('Pintura salva. Exporte o ZIP ao terminar.');
});};
function accessoryNodes(){
 const select=$('#accessoryNode'),previous=select.value,search=$('#accessorySearch').value.toLowerCase();select.replaceChildren();
 const first=document.createElement('option');first.value='';first.textContent='Selecione uma peça ou grupo…';select.append(first);
 for(const node of accessoryData?.nodes||[]){
  if(!node.name.toLowerCase().includes(search))continue;let depth=0,parent=node.parent;while(parent!==null){depth++;parent=accessoryData.nodes[parent].parent;}
  const option=document.createElement('option');option.value=String(node.index);option.textContent='· '.repeat(Math.min(depth,10))+node.name+(node.shapeId?' ◇':'');select.append(option);
 }
 select.value=(accessoryData?.nodes||[]).some(n=>String(n.index)===previous&&n.name.toLowerCase().includes(search))?previous:'';$('#accessoryApply').disabled=!select.value;
}
function accessoryChanged(data){
 accessoryData=data;$('#accessorySourceName').textContent='Origem: '+data.source.name;
 const select=$('#accessoryFile');select.replaceChildren();for(const file of data.source.i3ds){const option=document.createElement('option');option.value=file;option.textContent=file;select.append(option);}select.value=data.file;select.disabled=false;accessoryNodes();
}
$('#showAccessory').onclick=async()=>{
 if(optionalState){await beginOptionalImport();return;}
 if(alignMode){status('Termine ou cancele o alinhamento primeiro.');return;}
 if(state.busy||!state.project?.project){status('Abra o mod de destino antes de importar um acessório.');return;}
 if(paintData&&!dirtyGuard())return;
 if(state.selected!==null&&!editableNode()){status('Selecione uma peça do I3D principal como destino.');return;}
 if((state.selected!==null||transformDrafts.size)&&!await saveTransform())return;
 if(state.xmlDirty&&!dirtyGuard())return;
 const parent=state.selected??state.scene?.nodes.find(n=>n.parent===null)?.index;
 if(parent===undefined){status('Abra uma cena com uma peça de destino.');return;}
 const hit=viewer?.lastHit;accessoryTarget={file:state.file,parent,revision:state.project.revision,translation:hit?.index===parent?hit.point.map((v,i)=>v+hit.normal[i]*.01):[0,0,0]};
 $('#accessoryOptionalHint').hidden=true;$('#accessoryTarget').textContent='Destino: '+state.scene.nodes[parent].name;$('#left').classList.remove('open');$('#inspector').classList.remove('open');$('#accessoryDialog').showModal();
 await busy('Lendo a origem do acessório…',async()=>{try{accessoryChanged(await api('/api/accessory-source'));}catch(error){accessoryData=null;$('#accessorySourceName').textContent='Abra o ZIP que contém a peça.';$('#accessoryApply').disabled=true;}});
};
$('#closeAccessory').onclick=closeAccessory;
$('#accessoryDialog').addEventListener('cancel',e=>{e.preventDefault();closeAccessory();});
$('#accessoryDialog').addEventListener('close',()=>{if(!$('#accessoryDialog').open&&optionalState?.mode==='import')resumeOptional();});$('#accessorySearch').oninput=accessoryNodes;
$('#accessoryNode').onchange=()=>{$('#accessoryApply').disabled=!$('#accessoryNode').value;};
$('#accessoryFile').onchange=e=>busy('Abrindo a cena de origem…',async()=>accessoryChanged(await api('/api/accessory-source?file='+encodeURIComponent(e.target.value))));
$('#accessoryZip').onchange=()=>busy('Lendo o ZIP de origem…',async()=>{
 const file=$('#accessoryZip').files[0];if(!file)return;$('#accessoryApply').disabled=true;
 const response=await fetch('/api/accessory-source',{method:'POST',headers:{'X-Gabriel-Editor':'1','X-Filename':encodeURIComponent(file.name)},body:file});
 const result=await response.json();if(!response.ok)throw Error(result.error||'Falha ao abrir a origem.');accessoryChanged(result);$('#accessoryZip').value='';
});
$('#accessoryApply').onclick=()=>busy('Importando a peça e os recursos…',async()=>{
 if(!accessoryTarget||!accessoryData||!$('#accessoryNode').value)throw Error('Selecione uma peça da origem.');
 const result=await api('/api/accessory-import',{...accessoryTarget,sourceFile:accessoryData.file,sourceIndex:Number($('#accessoryNode').value),sourceId:accessoryData.source.id});
 projectChanged(result.project);await openScene(accessoryTarget.file);state.selected=result.index;viewer?.select(result.index);renderSelection();renderTree();
 if(optionalState?.mode==='import'){
  const p=optionalState,c=p.choices[p.active],node=state.scene.nodes[result.index];c.indices.add(result.index);p.imported=true;p.mode='position';setView('model');
  if(/^(Novo acessório|Com acessório|Escolha \d+)$/.test(c.name))c.name=node.name.replace(/^Acessorio /,'').slice(0,80);
  snapshotOptionalDraft();$('#accessoryDialog').close();optionalChoices();optionalAttachment();updateOptionalWorkflow();previewOptionalScene();status('Peça adicionada à escolha '+c.name+'. Ajuste na cena e toque Voltar ao opcional.');return;
 }
 $('#accessoryDialog').close();status('Acessório importado com '+result.meshes+' malha(s). Ajuste posição, rotação e tamanho; depois exporte.');
});
let pieceToolsTarget=null,alignMode=null;
function cancelAlignment(){const active=!!alignMode;alignMode=null;$('#alignBanner').hidden=true;if(active&&state.scene)renderSelection();}
$('#alignCancel').onclick=()=>{cancelAlignment();renderSelection();status('Alinhamento cancelado.');};
async function handleAlignmentPick(index){
 if(state.busy||!alignMode)return;const target=state.scene.nodes[index],hit=viewer?.lastHit;
 if(!target||target.previewOnly||target.previewDriven||!hit||hit.index!==index){status('Toque numa superfície do I3D principal.');return;}
 const source=alignMode;await busy('Alinhando a peça…',async()=>{
  const result=await api('/api/align',{...source,target:index,point:hit.point,normal:hit.normal});cancelAlignment();projectChanged(result.project);await openScene(source.file);state.selected=result.index;viewer?.select(result.index);renderSelection();renderTree();status('Peça alinhada e salva. Desfazer restaura a posição anterior.');
 });
}
function reservedNode(node){return node?.tag==='TransformGroup'&&node.name.startsWith('__GabrielReserva__');}
function pieceGroupCount(){const count=$$('[data-piece-index]').filter(c=>c.checked).length;$('#pieceGroupCount').textContent=count+' peça(s) selecionada(s)';$('#pieceToolApply').disabled=count<2;}
function pieceToolAction(){
 if(!pieceToolsTarget)return;const action=$('#pieceAction').value,node=state.scene.nodes[pieceToolsTarget.index];
 $('#pieceNameRow').hidden=!['duplicate','group','prefab'].includes(action);$('#pieceOffsetRow').hidden=action!=='duplicate';$('#pieceGroupRow').hidden=action!=='group';$('#pieceToolApply').disabled=false;$('#pieceAxisRow').hidden=!['mirror','align'].includes(action);$('#pieceAlignRow').hidden=action!=='align';
 $('#pieceToolName').value=action==='group'?'Grupo de peças':action==='prefab'?node.name.slice(0,80):node.name.slice(0,74)+' cópia';
 const info={mirror:['ESPELHAR','Inverte a escala no eixo local escolhido. Letras e texturas também ficam espelhadas. Use em peças visuais estáticas.'],align:['ESCOLHER SUPERFÍCIE','Fecha o painel para você tocar no destino. Apoia a extremidade da peça na superfície tocada. Escolha o eixo que deve apontar para fora ou desmarque Girar.'],prefab:['BAIXAR CONJUNTO ZIP','Salva a peça ou grupo com seus filhos, malhas e recursos visuais. Para várias peças, agrupe primeiro. Reutilize o ZIP pelo botão + Acessório. Recursos da base continuam dependendo da base.'],duplicate:['DUPLICAR','Cria uma cópia visual com seus filhos. A cópia reutiliza malhas, materiais e texturas; física e funções não são copiadas.'],group:['CRIAR GRUPO','Marque pelo menos duas peças com o mesmo pai. Elas mantêm a posição atual e passam a ser ajustadas juntas pelo novo grupo. Peças usadas pelo XML ou com física são protegidas.'],delete:['EXCLUIR PEÇA E FILHOS','Remove a peça e todos os seus filhos da cena. Mantém uma posição vazia na hierarquia para preservar os índices das outras peças. Peças usadas pelo XML ou com física são protegidas.'],visibility:[node.visibility?'OCULTAR':'MOSTRAR','Altera a visibilidade da peça e de seus filhos na cena e no mod. Geometria, hierarquia e física permanecem.']};
 $('#pieceToolApply').textContent=info[action][0];$('#pieceToolsHint').textContent=info[action][1];
 if(action==='group')pieceGroupCount();
}
async function showPieceTools(){
 if(state.busy||alignMode)return;
 if(paintData){status('Salve ou cancele a pintura antes de abrir as ferramentas.');return;}
 if(!editableNode()){status('Selecione uma peça do I3D principal.');return;}
 if(!await saveTransform())return;
 const node=editableNode();if(!node)return;
 pieceToolsTarget={file:state.file,index:node.index,revision:state.project.revision};$('#pieceToolsTarget').textContent='Selecionada: '+node.name;
 const list=$('#pieceCandidates');list.replaceChildren();
 for(const sibling of state.scene.nodes.filter(n=>n.parent===node.parent&&!n.previewOnly&&!n.previewDriven&&!reservedNode(n))){
  const row=document.createElement('label');row.className='piece-candidate';const check=document.createElement('input');check.type='checkbox';check.dataset.pieceIndex=String(sibling.index);check.checked=sibling.index===node.index;check.onchange=pieceGroupCount;
  const text=document.createElement('span');text.textContent=sibling.name;row.append(check,text);list.append(row);
 }
 $('#pieceAction').value='duplicate';$('#pieceOffset').value='10';$('#pieceAxis').value='0';$('#pieceGap').value='1';$('#pieceOrient').checked=true;pieceToolAction();$('#left').classList.remove('open');$('#inspector').classList.remove('open');$('#pieceToolsDialog').showModal();
}
$('#showPieceTools').onclick=showPieceTools;$('#pieceAction').onchange=pieceToolAction;$('#closePieceTools').onclick=()=>$('#pieceToolsDialog').close();
$('#pieceProperties').onclick=()=>{$('#pieceToolsDialog').close();$('#inspector').classList.add('open');};
$('#pieceToolsForm').onsubmit=e=>{e.preventDefault();busy('Aplicando ferramenta da peça…',async()=>{
 if(!pieceToolsTarget)throw Error('Selecione uma peça.');const target=pieceToolsTarget,action=$('#pieceAction').value;let result;
 if(action==='align'){
  const gap=$('#pieceGap').value.trim(),offset=Number(gap)/1000;if(!gap||!Number.isFinite(offset)||offset<0||offset>1)throw Error('Use um afastamento de 0 a 1000 mm.');
  alignMode={...target,axis:Number($('#pieceAxis').value),offset,orient:$('#pieceOrient').checked};$('#pieceToolsDialog').close();$('#left').classList.remove('open');$('#inspector').classList.remove('open');$('#touchEditor').hidden=true;$('#alignBanner').hidden=false;status('Toque na superfície de destino.');return;
 }else if(action==='prefab'){
  const title=$('#pieceToolName').value.trim();if(!title)throw Error('Informe o nome do conjunto.');const response=await fetch('/api/prefab',{method:'POST',headers:{'Content-Type':'application/json','X-Gabriel-Editor':'1'},body:JSON.stringify({...target,title})});if(!response.ok){const error=await response.json();throw Error(error.error||'Não foi possível salvar o conjunto.');}
  const url=URL.createObjectURL(await response.blob()),a=document.createElement('a');a.href=url;a.download=title.replace(/[^a-z0-9_-]/gi,'_').slice(0,80)+'.zip';document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),30000);$('#pieceToolsDialog').close();status('Conjunto salvo em ZIP. Importe pelo botão + Acessório em outro projeto.');return;
 }else if(action==='mirror')result=await api('/api/mirror',{...target,axis:Number($('#pieceAxis').value)});
 else if(action==='visibility'){
  const project=await api('/api/transform',{file:target.file,index:target.index,changes:{visibility:!state.scene.nodes[target.index].visibility},revision:target.revision});result={project,index:target.index};
 }else{
  const indices=action==='group'?$$('[data-piece-index]').filter(c=>c.checked).map(c=>Number(c.dataset.pieceIndex)):[target.index];
  const body={file:target.file,action,indices,revision:target.revision};
  if(['duplicate','group'].includes(action)){body.name=$('#pieceToolName').value.trim();if(!body.name||body.name.length>80)throw Error('Informe um nome de 1 a 80 caracteres.');}
  if(action==='group'&&indices.length<2)throw Error('Marque pelo menos duas peças com o mesmo pai.');
  if(action==='duplicate'){const text=$('#pieceOffset').value.trim(),offset=Number(text)/100;if(!text||!Number.isFinite(offset)||Math.abs(offset)>100)throw Error('Deslocamento inválido: use até 10.000 cm.');body.offset=[offset,0,0];}
  result=await api('/api/scene-tool',body);
 }
 projectChanged(result.project);await openScene(target.file);state.selected=result.index;viewer?.select(result.index);renderSelection();renderTree();$('#pieceToolsDialog').close();pieceToolsTarget=null;
 status(({mirror:'Peça espelhada no eixo escolhido.',duplicate:'Cópia criada e selecionada. Ajuste a posição para separar as peças.',group:'Grupo criado. Use Mover, Girar ou Tamanho para ajustar as peças juntas.',delete:'Peça e filhos excluídos. Desfazer restaura a seleção removida.',visibility:'Visibilidade salva.'})[action]+' Exporte o ZIP ao terminar.');
});};
// Direct removal uses the existing hierarchy audit and atomic undo history.
let removePieceTarget=null;
function removePieceSummary(){
 if(!removePieceTarget)return;const index=Number($('#removePieceTarget').value),node=state.scene.nodes[index],children=new Set([index]);for(const n of state.scene.nodes)if(children.has(n.parent))children.add(n.index);
 $('#removePieceSummary').textContent='Remover “'+node.name+'”'+(children.size>1?' e '+(children.size-1)+' peça(s) dentro deste grupo.':'.');
}
function closeRemovePiece(){if(state.busy)return;removePieceTarget=null;$('#removePieceDialog').close();}
$('#removePiece').onclick=()=>{
 if(state.busy)return;if(optionalState||alignMode||paintData||workbenchTools?.isDirty()){status('Conclua a edição atual antes de remover uma peça.');return;}
 if(state.xmlDirty){status('Salve o XML antes de remover uma peça.');return;}
 const node=editableNode();if(!node||node.parent===null){status('Selecione uma peça abaixo da raiz do veículo.');return;}
 removePieceTarget={file:state.file,project:state.project.project,revision:state.project.revision};const select=$('#removePieceTarget');select.replaceChildren();let index=node.index;
 while(index!==null){const n=state.scene.nodes[index];if(n.parent===null)break;if(!n.previewOnly&&!n.previewDriven&&!reservedNode(n)){const o=document.createElement('option');o.value=index;o.textContent=(index===node.index?'Peça tocada: ':'Grupo: ')+n.name;select.append(o);}index=n.parent;}
 select.value=String(node.index);removePieceSummary();$('#removePieceDialog').showModal();
};
$('#removePieceTarget').onchange=removePieceSummary;$('#removePieceClose').onclick=closeRemovePiece;$('#removePieceCancel').onclick=closeRemovePiece;
$('#removePieceDialog').addEventListener('cancel',e=>{e.preventDefault();closeRemovePiece();});
$('#removePieceApply').onclick=()=>busy('Removendo a peça…',async()=>{
 const target=removePieceTarget;if(!target||target.project!==state.project.project||target.file!==state.file||target.revision!==state.project.revision)throw Error('O projeto mudou. Selecione a peça novamente.');
 const index=Number($('#removePieceTarget').value),node=state.scene.nodes[index];if(!node||node.parent===null||node.previewOnly||node.previewDriven||reservedNode(node))throw Error('Selecione uma peça do I3D principal.');
 const result=await api('/api/scene-tool',{file:target.file,action:'delete',indices:[index],revision:target.revision});
 editOriginal=null;sliderBase=null;removePieceTarget=null;$('#removePieceDialog').close();projectChanged(result.project);await openScene(target.file);state.selected=null;viewer?.select(null);renderSelection();renderTree();status('Peça removida do projeto. Desfazer recupera a peça; exporte o ZIP para levar ao jogo.');
});
let optionalState=null,optionalPreview=null;
function nodeById(id){return state.scene?.nodes.find(n=>n.nodeId===id&&!n.previewOnly&&!n.previewDriven&&!reservedNode(n));}
function snapshotOptionalDraft(){
 const p=optionalState;if(!p||p.file!==state.file||!p.choices)return;
 for(const c of p.choices){if(c.missing?.length)continue;c.nodeIds=[...c.indices].map(i=>state.scene.nodes[i]?.nodeId);}
}
function rebindOptionalDraft(){
 const p=optionalState;if(!p||p.file!==state.file||!p.choices)return;
 if(p.project!==state.project.project){closeOptional();return;}
 for(const c of p.choices){c.indices=new Set();c.missing=[];for(const id of c.nodeIds||[]){const n=nodeById(id);if(!n)c.missing.push(id);else c.indices.add(n.index);}}
 p.info.revision=state.project.revision;p.index=nodeById(p.seedId)?.index??state.scene.nodes.find(n=>n.parent===null&&!n.previewOnly)?.index;
}
function updateOptionalWorkflow(){
 const p=optionalState,active=p?.mode==='position';$('#optionalWorkflowBar').hidden=!active;
 if(active)$('#optionalWorkflowLabel').textContent=p.choices[p.active].name+' · ajuste a peça e salve';
}
function optionalAdjustPieces(){
 if(!optionalState)return;const p=optionalState,select=$('#optionalAdjustPiece'),previous=select.value;select.replaceChildren();
 for(const i of p.choices[p.active].indices){const n=state.scene.nodes[i];if(!n)continue;const o=document.createElement('option');o.value=n.nodeId;o.textContent=n.name;select.append(o);}
 const choices=p.choices[p.active].indices;select.value=[...choices].some(i=>state.scene.nodes[i]?.nodeId===previous)?previous:state.scene.nodes[[...choices][0]]?.nodeId||'';$('#optionalAdjust').disabled=!select.value;
}
function optionalAttachment(){
 const p=optionalState;if(!p)return;const select=$('#optionalAttach'),chosen=new Set(p.choices.flatMap(c=>[...c.indices]));select.replaceChildren();
 for(const n of state.scene.nodes){
  if(n.previewOnly||n.previewDriven||reservedNode(n)||!['Shape','TransformGroup'].includes(n.tag))continue;
  let ancestor=n.index,blocked=false;while(ancestor!==null){if(chosen.has(ancestor)){blocked=true;break;}ancestor=state.scene.nodes[ancestor].parent;}if(blocked)continue;
  const o=document.createElement('option');o.value=n.nodeId;o.textContent=n.name;select.append(o);
 }
 if(![...select.children].some(o=>o.value===p.parentId))p.parentId=select.children[0]?.value||'';
 select.value=p.parentId;select.disabled=!!p.imported;$('#optionalAttachRow').hidden=false;
}
function suspendOptional(mode){optionalCommit();optionalBack();snapshotOptionalDraft();optionalState.mode=mode;$('#optionalDialog').close();updateOptionalWorkflow();}
async function resumeOptional(){
 const p=optionalState;if(!p||state.busy)return;if(alignMode){status('Termine ou cancele o alinhamento primeiro.');return;}
 if(transformDrafts.size&&!await saveTransform())return;
 await busy('Voltando ao opcional…',async()=>{
  const info=await api('/api/shop-options?file='+encodeURIComponent(p.file)+'&vehicle='+encodeURIComponent(p.info.vehicle));resetOptionalPreview();p.mode='panel';p.info=info;optionalGroups();snapshotOptionalDraft();optionalChoices();optionalAttachment();updateOptionalWorkflow();$('#optionalDialog').showModal();
 });
}
function closeAccessory(){
 if(state.busy)return;const p=optionalState;$('#accessoryDialog').close();if(p?.mode==='import')resumeOptional();
}
async function beginOptionalImport(){
 const p=optionalState;if(!p||state.busy)return;if(alignMode){status('Termine ou cancele o alinhamento primeiro.');return;}
 if(p.mode==='position'&&transformDrafts.size&&!await saveTransform())return;optionalCommit();optionalAttachment();const parent=nodeById(p.parentId);
 if(!parent){status('Selecione o ponto de ligação das novas peças.');return;}
 if(!p.slot&&!p.info.freeSlots.length){status('Não há grupo livre. Selecione um grupo do editor para adicionar escolhas.');return;}
 suspendOptional('import');accessoryTarget={file:p.file,parent:parent.index,revision:state.project.revision,translation:[0,0,0]};
 $('#accessoryOptionalHint').hidden=false;$('#accessoryTarget').textContent='Opcional: '+$('#optionalTitle').value+' · escolha: '+p.choices[p.active].name+' · ligar em '+parent.name;$('#accessoryDialog').showModal();
 await busy('Lendo a origem do opcional…',async()=>{try{accessoryChanged(await api('/api/accessory-source'));}catch(error){accessoryData=null;$('#accessorySourceName').textContent='Abra o ZIP que contém a peça.';$('#accessoryApply').disabled=true;}});
}
async function adjustOptionalPiece(){
 if(state.busy||!optionalState)return;const node=nodeById($('#optionalAdjustPiece').value);if(!node){status('Marque uma peça nesta escolha para ajustar.');return;}
 suspendOptional('position');setView('model');state.selected=node.index;viewer?.select(node.index);renderSelection();renderTree();$('#left').classList.remove('open');$('#inspector').classList.remove('open');previewOptionalScene();status('Ajuste a peça, salve e toque Voltar ao opcional.');
}

function resetOptionalPreview(){
 if(!optionalPreview)return;
 for(const [index,visibility] of optionalPreview)if(state.scene?.nodes[index])state.scene.nodes[index].visibility=visibility;
 optionalPreview=null;$('#optionalPreviewStatus').textContent='';viewer?.updateMatrices();viewer?.draw();
}
function optionalBack(){resetOptionalPreview();$('#optionalSettings').hidden=false;$('#optionalBack').hidden=true;$('#optionalDialog').classList.remove('previewing');}
function closeOptional(){optionalBack();optionalState=null;$('#optionalWorkflowBar').hidden=true;$('#accessoryOptionalHint').hidden=true;$('#optionalDialog').close();if(state.scene)renderSelection();}
function optionalCommit(){if(!optionalState)return;const c=optionalState.choices[optionalState.active];c.name=$('#optionalName').value;c.price=$('#optionalPrice').value;}
function optionalCount(){
 if(!optionalState)return;const p=optionalState;
 $('#optionalCount').textContent=p.choices[p.active].indices.size+' peça(s) nesta escolha · '+p.choices.length+' escolhas no grupo'+(p.choices[p.active].missing?.length?' · há peça removida nesta escolha':'');
 $('#optionalAdd').disabled=p.choices.length>=20;$('#optionalRemoveChoice').disabled=p.choices.length<=2;
 $('#optionalApply').disabled=!p.slot&&!p.info.freeSlots.length;optionalAdjustPieces();
}
function optionalPieces(){
 if(!optionalState)return;const search=$('#optionalSearch').value.toLowerCase(),choice=optionalState.choices[optionalState.active],list=$('#optionalParts');list.replaceChildren();
 for(const node of state.scene.nodes){
  if(node.parent===null||node.previewOnly||node.previewDriven||reservedNode(node)||node.nonRenderable||!['Shape','TransformGroup'].includes(node.tag))continue;
  if(search&&!node.name.toLowerCase().includes(search)&&!choice.indices.has(node.index))continue;
  const row=document.createElement('label');row.className='optional-part';const check=document.createElement('input');check.type='checkbox';check.dataset.optIndex=String(node.index);check.checked=choice.indices.has(node.index);
  check.onchange=()=>{resetOptionalPreview();if(check.checked)choice.indices.add(node.index);else choice.indices.delete(node.index);choice.missing=[];snapshotOptionalDraft();optionalAttachment();optionalCount();};
  const name=document.createElement('span');name.textContent=node.name;row.append(check,name);list.append(row);
 }optionalCount();
}
function optionalChoices(){
 const p=optionalState,select=$('#optionalChoice');select.replaceChildren();p.choices.forEach((c,i)=>{const o=document.createElement('option');o.value=String(i);o.textContent=(i+1)+'. '+c.name;select.append(o);});select.value=String(p.active);
 const c=p.choices[p.active];$('#optionalName').value=c.name;$('#optionalPrice').value=c.price;optionalPieces();snapshotOptionalDraft();
}
function optionalLoadGroup(){
 optionalBack();const p=optionalState,value=$('#optionalGroup').value,group=(p.info.managed||[]).find(g=>g.slot===value&&g.editable);
 p.slot=group?.slot||null;p.active=0;p.choices=group?group.options.map(c=>({...c,price:String(c.price),indices:new Set(c.indices)})):[{name:'Sem acessório',price:'0',indices:new Set()},{name:'Com acessório',price:'100',indices:new Set([p.index])}];
 p.mode='panel';p.imported=false;const seed=state.scene.nodes[p.index];
 if(!group&&p.newFlow){p.active=1;p.choices=[{name:'Original',price:'0',indices:new Set(seed.parent!==null&&!seed.nonRenderable?[seed.index]:[])},{name:'Novo acessório',price:'100',indices:new Set()}];}
 $('#optionalTitle').value=group?.title||(!group&&p.newFlow&&seed.parent===null?'Acessórios':seed.name.replace(/^Acessorio /,'').slice(0,80));$('#optionalDelete').hidden=!group;$('#optionalSearch').value='';optionalChoices();optionalAttachment();
}
function optionalGroups(){
 const info=optionalState.info,select=$('#optionalGroup');select.replaceChildren();
 const add=document.createElement('option');add.value='';add.textContent='＋ Novo grupo';select.append(add);
 for(const g of info.managed||[]){const o=document.createElement('option');o.value=g.slot;o.textContent=g.title+(g.editable?'':' · protegido: '+g.reason);o.disabled=!g.editable;select.append(o);}
 select.value=optionalState.slot||'';$('#optionalSlots').textContent=info.freeSlots.length+' grupo(s) livre(s). Até 20 escolhas por grupo. Selecione um grupo existente para editar ou excluir.';
}
function optionalInfo(info){optionalState.info=info;optionalGroups();$('#optionalGroup').value='';optionalLoadGroup();}
async function showOptionals(createNew=false){
 if(optionalState){await resumeOptional();return;}
 if(state.busy||alignMode)return;if(paintData){status('Salve ou cancele a pintura primeiro.');return;}if(state.xmlDirty){status('Salve o XML antes de criar opcionais.');return;}
 const node=editableNode();if(!state.scene||!state.file){status('Abra um mod com o XML do veículo primeiro.');return;}
 if(!createNew&&(!node||node.parent===null)){status('Selecione uma peça visual ou acessório abaixo da raiz do veículo.');return;}
 if((node||transformDrafts.size)&&!await saveTransform())return;
 await busy('Lendo as configurações da loja…',async()=>{
  const info=await api('/api/shop-options?file='+encodeURIComponent(state.file));const selected=createNew?node:editableNode(),index=selected?.index??state.scene.nodes.find(n=>n.parent===null&&!n.previewOnly)?.index;
  if(index===undefined)throw Error('A cena não possui um ponto de ligação.');
  optionalState={file:state.file,index,info,project:state.project.project,seedId:state.scene.nodes[index].nodeId,newFlow:createNew,mode:'panel',parentId:state.scene.nodes[selected?.parent??index]?.nodeId,imported:false};
  const select=$('#optionalVehicle');select.replaceChildren();for(const filename of info.vehicles){const option=document.createElement('option');option.value=filename;option.textContent=filename;select.append(option);}select.value=info.vehicle;
  optionalInfo(info);
  $('#left').classList.remove('open');$('#inspector').classList.remove('open');$('#optionalDialog').showModal();
 });
}
function previewOptionalScene(){
 if(!optionalState)return;resetOptionalPreview();optionalPreview=new Map();const p=optionalState,choice=p.choices[p.active];
 for(const index of new Set(p.choices.flatMap(c=>[...c.indices]))){const node=state.scene.nodes[index];if(!node)continue;optionalPreview.set(index,node.visibility);node.visibility=choice.indices.has(index);}
 viewer?.updateMatrices();viewer?.draw();
}
function previewOptional(){
 if(!optionalState)return;optionalCommit();const choice=optionalState.choices[optionalState.active];previewOptionalScene();$('#optionalSettings').hidden=true;$('#optionalBack').hidden=false;$('#optionalDialog').classList.add('previewing');$('#optionalPreviewStatus').textContent='Prévia: '+choice.name+' · ainda não salva';
}
$('#addOptional').onclick=()=>showOptionals(true);$('#showOptionals').onclick=()=>showOptionals();$('#optionalImport').onclick=beginOptionalImport;$('#optionalAdjust').onclick=adjustOptionalPiece;$('#optionalResume').onclick=resumeOptional;$('#optionalAttach').onchange=()=>{if(optionalState)optionalState.parentId=$('#optionalAttach').value;};$('#pieceOptional').onclick=()=>{$('#pieceToolsDialog').close();showOptionals();};$('#closeOptional').onclick=()=>{if(state.busy)return;closeOptional();status('Rascunho fechado. Importações e ajustes permanecem no projeto; as escolhas da loja só são gravadas ao salvar o opcional.');};
$('#optionalDialog').addEventListener('close',()=>{if(!$('#optionalDialog').open&&optionalState?.mode==='panel')closeOptional();});
$('#optionalDialog').addEventListener('cancel',e=>{e.preventDefault();if(!state.busy)closeOptional();});
$('#optionalSearch').oninput=optionalPieces;$('#optionalVehicle').onchange=e=>busy('Lendo outro veículo…',async()=>{optionalBack();const info=await api('/api/shop-options?file='+encodeURIComponent(optionalState.file)+'&vehicle='+encodeURIComponent(e.target.value));optionalInfo(info);});
$('#optionalGroup').onchange=optionalLoadGroup;$('#optionalChoice').onchange=()=>{optionalCommit();optionalBack();optionalState.active=Number($('#optionalChoice').value);optionalChoices();};
$('#optionalName').oninput=()=>{optionalCommit();const i=optionalState.active;$('#optionalChoice').children[i].textContent=(i+1)+'. '+$('#optionalName').value;};$('#optionalPrice').oninput=optionalCommit;
$('#optionalAdd').onclick=()=>{if(!optionalState||optionalState.choices.length>=20)return;optionalCommit();optionalBack();optionalState.choices.push({name:'Escolha '+(optionalState.choices.length+1),price:'0',indices:new Set()});optionalState.active=optionalState.choices.length-1;optionalChoices();};
$('#optionalRemoveChoice').onclick=()=>{if(!optionalState||optionalState.choices.length<=2)return;optionalBack();optionalState.choices.splice(optionalState.active,1);optionalState.active=Math.min(optionalState.active,optionalState.choices.length-1);optionalChoices();};
$('#optionalPreview').onclick=previewOptional;$('#optionalBack').onclick=optionalBack;
$('#optionalDelete').onclick=()=>busy('Excluindo o grupo do XML…',async()=>{
 const p=optionalState;if(!p?.slot)throw Error('Selecione um grupo criado no editor.');optionalBack();const result=await api('/api/shop-options-delete',{file:p.file,vehicle:p.info.vehicle,slot:p.slot,revision:p.info.revision});closeOptional();projectChanged(result.project);status('Grupo de opcionais excluído. Desfazer restaura o grupo. Exporte o ZIP ao terminar.');
});
$('#optionalForm').onsubmit=e=>{e.preventDefault();busy('Salvando o opcional no XML…',async()=>{
 if(!optionalState)throw Error('Abra o painel de opcionais.');optionalCommit();const p=optionalState,title=$('#optionalTitle').value.trim();if(p.choices.some(c=>c.missing?.length))throw Error('Uma peça do rascunho foi removida. Confira a lista das escolhas antes de salvar.');if(!title||title.length>80)throw Error('Preencha o título com até 80 caracteres.');
 const options=p.choices.map(c=>{const name=c.name.trim(),price=Number(c.price);if(!name||name.length>80)throw Error('Preencha os nomes com até 80 caracteres.');if(!String(c.price).trim()||!Number.isFinite(price)||price<0||price>10000000)throw Error('Preço inválido. Use de 0 a 10.000.000.');return {name,price,indices:[...c.indices],...(c.saveId?{saveId:c.saveId}:{})};});optionalBack();
 const result=await api('/api/shop-options',{file:p.file,vehicle:p.info.vehicle,slot:p.slot,title,options,revision:p.info.revision});closeOptional();projectChanged(result.project);renderSelection();status('Opcional "'+result.title+'" salvo com '+result.choices.length+' escolhas. Exporte o ZIP para testar na loja.');
});};
let decalPlacement=null;
$('#showDecal').onclick=()=>{
 if(optionalState){status('Conclua ou feche o opcional antes de adicionar plotagem.');return;}
 if(state.busy)return;const node=editableNode();
 if(!node||!node.shapeId){status('Toque na superfície de uma peça do veículo antes de adicionar a plotagem.');return;}
 if(!dirtyGuard())return;
 const hit=viewer?.lastHit,mesh=viewer?.meshes?.[node.shapeId];let point,normal;
 if(hit?.index===node.index){point=hit.point;normal=hit.normal;}
 else{const bounds=mesh?.bounds||[[-.5,-.5,0],[.5,.5,0]];point=bounds[0].map((v,i)=>(v+bounds[1][i])/2);point[2]=bounds[1][2];normal=[0,0,1];}
 const rotation=[-Math.asin(Math.max(-1,Math.min(1,normal[1])))*180/Math.PI,Math.atan2(normal[0],normal[2])*180/Math.PI,0];
 decalPlacement={parent:node.index,translation:point.map((v,i)=>v+normal[i]*.003),rotation};
 $('#decalTarget').textContent='Peça: '+node.name+(hit?.index===node.index?' · ponto tocado na superfície.':' · posição inicial na frente da peça; ajuste após importar.');
 $('#decalMode').value='surface';$('#decalDepth').value='20';$('#decalImage').value='';$('#decalDialog').showModal();
};
$('#curveDecal').onclick=async()=>{
 if(state.busy||!editableNode()?.decalInfo)return;
 if(!await saveTransform())return;
 const node=editableNode(),info=node?.decalInfo;if(!info)return;
 $('#projectTarget').textContent=node.name+' · '+(info.mode==='surface'?'Ajustar a projeção existente.':'Adaptar o adesivo plano às curvas da peça.');
 $('#projectDepth').value=String((info.depth??.2)*100);$('#projectAngle').value=String(info.maxAngle??75);$('#projectOffset').value=String((info.offset??.001)*1000);
 $('#projectDialog').showModal();
};
$('#closeProject').onclick=()=>$('#projectDialog').close();
$('#projectForm').onsubmit=e=>{e.preventDefault();busy('Adaptando a plotagem à lataria…',async()=>{
 if(!editableNode()?.decalInfo)throw Error('Selecione uma plotagem para adaptar.');
 if(transformDrafts.size||state.xmlDirty)throw Error('Salve os ajustes antes de projetar.');
 $('#projectSubmit').disabled=true;$('#projectSubmit').textContent='PROJETANDO…';
 try{const result=await api('/api/decal-project',{file:state.file,index:state.selected,revision:state.project.revision,depth:Number($('#projectDepth').value)/100,maxAngle:Number($('#projectAngle').value),offset:Number($('#projectOffset').value)/1000});
  projectChanged(result.project);await openScene(state.file);state.selected=result.index;viewer?.select(result.index);renderSelection();renderTree();$('#projectDialog').close();
  status('Curvatura aplicada e salva · '+result.projection.triangles+' triângulos. Exporte o ZIP ao terminar.');
 }finally{$('#projectSubmit').disabled=false;$('#projectSubmit').textContent='APLICAR CURVATURA';}
});};
$('#closeDecal').onclick=()=>$('#decalDialog').close();
async function decalPNG(file){
 if(file.size>16*1024*1024)throw Error('Escolha um PNG de até 16 MB.');
 const header=new DataView(await file.slice(0,33).arrayBuffer());
 if(header.byteLength<33||header.getUint32(0)!==0x89504e47||header.getUint32(4)!==0x0d0a1a0a)throw Error('Escolha uma imagem PNG válida.');
 const w=header.getUint32(16),h=header.getUint32(20);if(!w||!h||w*h>32*1024*1024||w>8192||h>8192)throw Error('A imagem deve ter até 8192 px e 32 milhões de pixels.');
 const image=await createImageBitmap(file);
 try{const ratio=Math.min(1,1024/Math.max(image.width,image.height)),canvas=document.createElement('canvas');
  canvas.width=Math.max(1,Math.round(image.width*ratio));canvas.height=Math.max(1,Math.round(image.height*ratio));
  canvas.getContext('2d').drawImage(image,0,0,canvas.width,canvas.height);return canvas.toDataURL('image/png').split(',')[1];
 }finally{image.close?.();}
}
$('#decalForm').onsubmit=e=>{e.preventDefault();busy('Criando a plotagem e a textura AST…',async()=>{
 const file=$('#decalImage').files[0];if(!file||!decalPlacement)throw Error('Escolha o PNG e a peça.');
 if(state.xmlDirty||transformDrafts.size)throw Error('Salve ou cancele as alterações pendentes antes de importar.');
 $('#decalSubmit').disabled=true;$('#decalSubmit').textContent='CRIANDO PLOTAGEM…';
 try{const png=await decalPNG(file),result=await api('/api/decal',{file:state.file,...decalPlacement,png,width:Number($('#decalWidth').value)/100,label:file.name.replace(/\.png$/i,''),revision:state.project.revision,projection:{mode:$('#decalMode').value,depth:Number($('#decalDepth').value)/100}});
 projectChanged(result.project);await openScene(state.file);state.selected=result.index;viewer?.select(result.index);renderSelection();renderTree();
 $('#decalDialog').close();status('Plotagem adicionada e salva. Se ajustar a posição, toque Salvar novamente. Exporte o ZIP ao terminar.');
 }finally{$('#decalSubmit').disabled=false;$('#decalSubmit').textContent='ADICIONAR PLOTAGEM';}
});};
$('#showWheels').onclick=()=>{wheelsChanged();$('#wheelDialog').showModal();};
$('#closeWheels').onclick=()=>$('#wheelDialog').close();
$('#wheelForm').onsubmit=e=>{e.preventDefault();busy('Montando as rodas…',async()=>{
 if(!dirtyGuard())return;state.wheelConfig=Number($('#wheelConfig').value);await openScene(state.file);$('#wheelDialog').close();status('Configuração de prévia atualizada.');
});};
function dirtyGuard(){
 if(textureConverter?.isOpen())textureConverter.close();
 if(optionalManager?.isOpen())optionalManager.close();
 if(textureTools?.isOpen()&&!textureTools.close())return false;
 if(animationTools?.isActive())animationTools.close();
 if(workbenchTools&&!workbenchTools.close())return false;
 if(wheelTools?.isOpen()&&!wheelTools.close())return false;
 if(optionalState){status('Volte ao opcional e salve ou feche o rascunho antes de trocar de arquivo, projeto ou histórico.');return false;}
 cancelAlignment();
 if((state.xmlDirty||transformDrafts.size||paintPreview)&&!window.confirm('Há alterações ainda não salvas. Descartar as alterações pendentes?'))return false;
 if(paintData)closePaint();discardAllTransforms();return true;
}
function selectNode(index,fromTree=false,internal=false){
 if(optionalManager?.isOpen()){status('Feche o gerenciador de opcionais antes de editar peças.');return;}
 if(textureTools?.isOpen()){status('Salve ou cancele a textura antes de selecionar outra peça.');return;}
 if(animationTools?.isActive()){status('Feche a prévia da animação antes de editar.');return;}
 if(workbenchTools?.isDirty()){status('Salve ou cancele a prévia do material.');return;}
 if(alignMode){status('Toque no destino ou cancele o alinhamento.');return;}
 if(optionalState){
  if(optionalState.mode!=='position'){status('Feche o painel de opcionais antes de trocar de peça.');return;}
  const controlled=optionalState.choices[optionalState.active].indices;let i=index;while(i!==null&&i!==undefined&&!controlled.has(i))i=state.scene.nodes[i]?.parent;
  if(i===null||i===undefined){status('Ajuste uma peça desta escolha. Use Voltar ao opcional para trocar de escolha.');return;}
 }
 if(paintData){status('Salve ou cancele a pintura antes de trocar de peça.');return;}
 if(state.busy&&!internal)return;
 if(!internal&&selectionTools?.handlePick(index,fromTree))return;
 if(!fromTree&&selectionTools?.isLocked(index)){status('Peça travada. Selecione pela árvore para destravar.');return;}
 const wheel=state.scene?.nodes[index];if(wheel?.wheelIndex!==undefined){wheelTools?.select(wheel.wheelIndex);return;}
 if(wheelTools?.isOpen()&&!wheelTools.close())return;
 if(index===state.selected)return;
 if(editableNode()){try{const values=readTransformFields();if(!sameTransform(editableNode(),values))updatePreview(values,internal);}catch(e){status(e.message);return;}}
 endSlide();
 state.selected=index;editOriginal=transformDrafts.get(index)||null;
 let parent=state.scene?.nodes[index]?.parent;while(parent!==null&&parent!==undefined){collapsedGroups.delete(groupKey(state.scene.nodes[parent]));parent=state.scene.nodes[parent].parent;}
viewer?.select(index);renderTree();renderSelection();
 if(innerWidth<=760){$('#left').classList.remove('open');if(fromTree)$('#inspector').classList.add('open');else $('#inspector').classList.remove('open');}
}
if(viewer)viewer.onPick=index=>alignMode?handleAlignmentPick(index):selectNode(index);
function editableNode(){const n=state.scene?.nodes[state.selected];return n&&!n.previewOnly&&!n.previewDriven&&!reservedNode(n)&&!animationTools?.isActive()&&!textureTools?.isOpen()&&(!selectionTools||selectionTools.canEdit(n.index))&&!(selectionTools?.isMulti()&&selectionTools.count()>1)?n:null;}
function rememberEdit(internal=false){const n=editableNode();if(!n||(state.busy&&!internal)||alignMode)return null;
 if(state.xmlDirty){status('Salve o XML antes de ajustar a peça.');return null;}
 if(!transformDrafts.has(n.index))transformDrafts.set(n.index,{...copyTransform(n),visibility:n.visibility});editOriginal=transformDrafts.get(n.index);return n;
}
function cancelPreview(){
 const n=state.scene?.nodes[state.selected];if(editOriginal&&n){Object.assign(n,editOriginal);viewer?.updateMatrices();viewer?.draw();}
 if(n)transformDrafts.delete(n.index);editOriginal=null;sliderBase=null;if(state.scene){renderSelection();renderTree();}
}
function updatePreview(values,internal=false){
 const n=rememberEdit(internal);if(!n)return;
 Object.assign(n,values);const original=transformDrafts.get(n.index);if(original&&sameTransform(n,original)){transformDrafts.delete(n.index);editOriginal=null;}viewer?.updateMatrices(n.index);
 for(const input of $$('[data-vector]'))input.value=n[input.dataset.vector][Number(input.dataset.axis)];
 updateTouchEditor(false);
 if(viewer?.requestDraw)viewer.requestDraw();else viewer?.draw();
}
function updateTouchEditor(syncSelection=true){
 updateDraftBar();
 if(syncSelection)selectionTools?.syncSingle(state.selected);
 const gizmoNode=editableNode();viewer?.setGizmo?.(gizmoEnabled&&gizmoNode&&!paintData&&!alignMode&&$('#selectionPanel').hidden?{index:gizmoNode.index,mode:editMode,snap:$('#gizmoSnap').checked?Number($('#editStep').value):0,onStart:()=>!!rememberEdit(),onChange:updatePreview}:null,syncSelection);
 const node=state.scene?.nodes[state.selected],editable=!!editableNode();$('#removePiece').hidden=!editable||node?.parent===null;$('#touchEditor').hidden=!node||!!paintData||!$('#selectionPanel').hidden||!!animationTools?.isActive()||(selectionTools?.isMulti()&&selectionTools.count()>1);
 if(!node)return;
 $('#curveDecal').hidden=!editable||!node.decalInfo;$('#editPiece').textContent=node.name;$('#editReadonly').hidden=editable;$('#editControls').hidden=!editable;
 $('#editSave').disabled=!editable;$('#editSave').textContent=transformDrafts.size?'Salvar tudo':'Salvo ✓';$('#editCancel').disabled=!editOriginal;
 $('#editMode').value=editMode;$('#editAxis').value=String(editAxis);$('#editUniform').hidden=editMode!=='scale';
 const steps=editMode==='translation'?['0.001','0.01','0.1']:editMode==='rotation'?['0.1','1','5']:['0.001','0.01','0.05'];
 const select=$('#editStep');if(select.dataset.mode!==editMode){select.dataset.mode=editMode;select.replaceChildren();
  for(const step of steps){const option=document.createElement('option');option.value=step;option.textContent=editMode==='translation'?`${Number(step)*100} cm`:editMode==='rotation'?`${step}°`:`${Number(step)*100}%`;select.append(option);}select.value=steps[1];}
 $('#editValue').textContent=node[editMode].map((v,i)=>`${['X','Y','Z'][i]} ${Number(v.toFixed(4))}`).join(' · ')+(editMode==='translation'?' m':editMode==='rotation'?'°':'');
 $('#editPending').textContent=transformDrafts.size?transformDrafts.size+' peça(s) pendente(s) · pode selecionar outra peça':'Eixos locais · deslize para ajustar';
}
function nudge(amount){const n=editableNode();if(!n||!rememberEdit())return;updatePreview(adjusted(copyTransform(n),editMode,editAxis,amount*Number($('#editStep').value)));}
$('#editMode').onchange=e=>{endSlide();editMode=e.target.value;if(editAxis===3&&editMode!=='scale')editAxis=0;updateTouchEditor();};
$('#gizmoToggle').onclick=()=>{gizmoEnabled=!gizmoEnabled;$('#gizmoToggle').textContent=gizmoEnabled?'Setas ✓':'Setas —';updateTouchEditor();};$('#gizmoSnap').onchange=updateTouchEditor;
$('#editAxis').onchange=e=>{endSlide();editAxis=Number(e.target.value);updateTouchEditor();};
let editorCollapsed=false,sceneExpanded=false;
$('#editCollapse').onclick=()=>{editorCollapsed=!editorCollapsed;$('#touchEditor').classList.toggle('collapsed',editorCollapsed);$('#editCollapse').textContent=editorCollapsed?'⌃':'⌄';$('#editCollapse').setAttribute('aria-expanded',String(!editorCollapsed));$('#editCollapse').setAttribute('aria-label',editorCollapsed?'Abrir controles':'Recolher painel');requestAnimationFrame(()=>viewer?.draw());};
function expandScene(value){sceneExpanded=value;document.body.classList.toggle('scene-expanded',value);$('#expandScene').textContent=value?'Voltar':'Ampliar';$('#expandScene').setAttribute('aria-pressed',String(value));requestAnimationFrame(()=>viewer?.draw());}
$('#expandScene').onclick=()=>expandScene(!sceneExpanded);
let warningsOpen=false;function toggleWarnings(){warningsOpen=!warningsOpen;$('#warnings').classList.toggle('expanded',warningsOpen);$('#warnings').setAttribute('aria-expanded',String(warningsOpen));}
$('#warnings').onclick=toggleWarnings;$('#warnings').onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();toggleWarnings();}};
window.addEventListener('keydown',e=>{if(e.key==='Escape'&&sceneExpanded)expandScene(false);});
$('#editSlider').oninput=e=>{const n=editableNode();if(!n||!rememberEdit())return;if(!sliderBase)sliderBase=copyTransform(n);updatePreview(adjusted(sliderBase,editMode,editAxis,Number(e.target.value)*Number($('#editStep').value)));};
function endSlide(){sliderBase=null;$('#editSlider').value=0;}
$('#editSlider').onchange=endSlide;$('#editSlider').addEventListener('pointercancel',endSlide);$('#editStep').onchange=endSlide;
$('#editMinus').onclick=()=>nudge(-1);$('#editPlus').onclick=()=>nudge(1);
$('#editCancel').onclick=()=>{cancelPreview();status('Prévia cancelada.');};
$('#editSave').onclick=saveTransform;
$('#editDetails').onclick=showPieceTools;
$('#vectors').oninput=()=>{const values={};for(const key of ['translation','rotation','scale']){
 const inputs=$$(`[data-vector="${key}"]`);if(inputs.some(i=>!i.value.trim()||!i.validity.valid))return;values[key]=inputs.map(i=>Number(i.value));}
 if(Object.values(values).flat().every(Number.isFinite))updatePreview(values);
};
$('#visibility').onchange=()=>updatePreview({visibility:$('#visibility').checked});

async function startProject(result){
 state.file=null;state.xmlDirty=false;$('#xmlText').value='';delete $('#xmlText').dataset.file;$('#saveXml').disabled=true;projectChanged(result);state.view='model';setView('model');
 if(!result.project){state.scene=null;state.selected=null;editOriginal=null;sliderBase=null;transformDrafts.clear();collapsedGroups.clear();treeScope=null;viewer?.setScene({nodes:[],meshes:{},materials:{},materialDetails:{},projectId:null,textureInfo:{resources:[],formats:{}}});selectionTools?.reset();renderSelection();renderTree();wheelsChanged();$('#meshStats').textContent='GRADE · EIXOS · ÓRBITA';$('#warnings').textContent='';$('#warnings').hidden=true;$('#textureStatus').textContent='';$('#inspector').classList.remove('open');$('#left').classList.remove('open');return;}
 let initial=result.i3ds[0];try{const last=localStorage.getItem('gabriel:lastFile:'+result.project);if(result.i3ds.includes(last))initial=last;}catch{}await openScene(initial,true);$('#left').classList.remove('open');
}
function groupKey(node){return node.index+':'+(node.nodeId||'');}
$('#collapseGroups').onclick=()=>{for(const n of state.scene?.nodes||[])if(state.scene.nodes.some(child=>child.parent===n.index))collapsedGroups.add(groupKey(n));renderTree();};
$('#expandGroups').onclick=()=>{collapsedGroups.clear();renderTree();};
function renderTree(){
 $('#treeGroupsToolbar').hidden=state.list!=='scene';
 const tree=$('#tree');tree.replaceChildren();const query=$('#search').value.toLowerCase();
 if(!state.project?.project){const el=document.createElement('div');el.className='empty';el.textContent='O seu projeto começa por aqui. Abra um ZIP de mod ou a cena de exemplo.';tree.append(el);return;}
 if(state.list==='scene'){
  const nodes=state.scene?.nodes||[],hasChildren=new Set(nodes.map(n=>n.parent)),matches=new Set();
  if(query)for(const n of nodes)if(n.name.toLowerCase().includes(query)){let index=n.index;while(index!==null&&index!==undefined&&!matches.has(index)){matches.add(index);index=nodes[index].parent;}}
  for(const node of nodes){
   if(reservedNode(node)||query&&!matches.has(node.index))continue;
   let depth=0,parent=node.parent,hidden=false;while(parent!==null&&parent!==undefined){depth++;if(!query&&collapsedGroups.has(groupKey(nodes[parent])))hidden=true;parent=nodes[parent].parent;}if(hidden)continue;
   const row=document.createElement('div');row.className='piece-tree-row';row.dataset.index=node.index;row.style.paddingLeft=Math.min(depth,12)*12+'px';
   const toggle=document.createElement('button');toggle.type='button';toggle.className='group-toggle';const group=hasChildren.has(node.index),closed=collapsedGroups.has(groupKey(node));toggle.textContent=group?(closed&&!query?'▶':'▼'):'·';toggle.disabled=!group||!!query;toggle.setAttribute('aria-label',(closed?'Expandir ':'Recolher ')+node.name);toggle.setAttribute('aria-expanded',String(!closed||!!query));toggle.onclick=()=>{const key=groupKey(node);if(collapsedGroups.has(key))collapsedGroups.delete(key);else collapsedGroups.add(key);renderTree();};
   const b=document.createElement('button');b.type='button';b.className='piece-tree-label '+(node.index===state.selected?'active ':'')+(selectionTools?.isSelected(node.index)?'multi-selected ':'')+(selectionTools?.isLocked(node.index)?'locked-piece ':'')+(transformDrafts.has(node.index)?'pending-piece':'');
   const icon=document.createElement('span');icon.className='tree-icon';icon.textContent=selectionTools?.isLocked(node.index)?'🔒':group?'▱':node.tag==='Shape'?'◇':'·';
   const label=document.createElement('span');label.textContent=node.name+(transformDrafts.has(node.index)?' •':'');b.append(icon,label);b.title=`${node.tag} · nodeId ${node.nodeId||'—'}`;b.onclick=()=>selectNode(node.index,true);row.append(toggle,b);tree.append(row);
  }
 }else{
  for(const file of state.project.files){
   if(!file.name.toLowerCase().includes(query))continue;
   const b=document.createElement('button');b.className=file.edited?'edited':'';b.textContent=file.name;b.title=file.name;b.style.overflowWrap='anywhere';b.style.whiteSpace='normal';
   b.onclick=()=>busy('Abrindo arquivo…',async()=>{
    if(!dirtyGuard())return;
    if(file.name.toLowerCase().endsWith('.i3d')){await openScene(file.name,true);setView('model');}
    else if(file.name.toLowerCase().endsWith('.xml')){await openText(file.name);setView('xml');}
    else status('Arquivo binário preservado. A edição desta versão aceita I3D e XML.');
    $('#left').classList.remove('open');
   });tree.append(b);
  }
 }
 if(!tree.children.length){const e=document.createElement('div');e.className='empty';e.textContent='Nenhum resultado.';tree.append(e);}
}
function renderSelection(){
 sliderBase=null;$('#editSlider').value=0;
 const node=state.scene?.nodes[state.selected];$('#noSelection').hidden=!!node;$('#properties').hidden=!node;
 updateTouchEditor();if(!node)return;$('#nodeType').textContent=node.tag.toUpperCase();$('#nodeName').textContent=node.name;$('#nodeId').textContent=`nodeId ${node.nodeId||'—'}${node.shapeId?' · shapeId '+node.shapeId:''}`;
 const mats=(node.materialIds||'').trim().split(/\s+/).map(id=>state.scene.materialDetails?.[id]).filter(Boolean);
 $('#materialInfo').textContent=mats.map(m=>m.name+(m.shaderFamily==='vehicle'?' · vehicleShader · '+(m.maps.detailDiffuse?'tabela de cores localizada':'tabela de cores ausente'):m.shader?' · prévia simples':'')).join('\n');
 $('#vectors').replaceChildren();
 for(const [key,label] of [['translation','POSIÇÃO · m'],['rotation','ROTAÇÃO · °'],['scale','ESCALA']]){
  const group=document.createElement('div');group.className='vector';const l=document.createElement('label');l.textContent=label;const row=document.createElement('div');row.className='vector-row';
  node[key].forEach((value,i)=>{const f=document.createElement('div');f.className='value-field';const s=document.createElement('span');s.textContent=['X','Y','Z'][i];const input=document.createElement('input');input.type='number';input.step='any';input.value=value;input.dataset.vector=key;input.dataset.axis=i;input.required=true;input.setAttribute('aria-label',`${label} ${s.textContent}`);f.append(s,input);row.append(f);});
  group.append(l,row);$('#vectors').append(group);
 }
 $('#visibility').checked=node.visibility;
 const readonly=!editableNode();
 $$('[data-vector]').forEach(input=>input.disabled=readonly);$('#visibility').disabled=readonly;$('#applyTransform').disabled=readonly;$('#previewOnlyNote').hidden=!readonly;
}
function setView(view){
 state.view=view;$('#viewport').hidden=view!=='model';$('#xmlView').hidden=view!=='xml';
 $$('[data-view]').forEach(b=>b.classList.toggle('selected',b.dataset.view===view));
 if(view==='model')requestAnimationFrame(()=>viewer?.draw());
}
async function openText(file){
 const result=await api('/api/text?file='+encodeURIComponent(file));$('#xmlText').value=result.text;$('#xmlName').textContent=file;$('#xmlText').dataset.file=file;$('#saveXml').disabled=false;state.xmlDirty=false;state.xmlRevision=state.project.revision;
}
$('#upload').onchange=()=>busy('Importando ZIP. Aguarde…',async()=>{
 const file=$('#upload').files[0];if(!file||!dirtyGuard())return;
 const response=await fetch('/api/import',{method:'POST',headers:{'X-Gabriel-Editor':'1','X-Filename':encodeURIComponent(file.name)},body:file});
 const result=await response.json();if(!response.ok)throw Error(result.error);await startProject(result);$('#upload').value='';
});
for(const id of ['example','exampleHero'])$('#'+id).onclick=()=>busy('Criando projeto de exemplo…',async()=>{if(dirtyGuard())await startProject(await api('/api/example',{}));});
$('#i3ds').onchange=e=>busy('Abrindo I3D…',async()=>{if(dirtyGuard()){await openScene(e.target.value,true);if(state.view==='xml')await openText(state.file);}else $('#i3ds').value=state.file;});
$('#search').oninput=renderTree;
$$('[data-list]').forEach(b=>b.onclick=()=>{state.list=b.dataset.list;$$('[data-list]').forEach(x=>x.classList.toggle('selected',x===b));renderTree();});
$$('[data-view]').forEach(b=>b.onclick=()=>busy('Abrindo editor…',async()=>{if(b.dataset.view==='xml'&&(optionalState||transformDrafts.size||paintData)&&!dirtyGuard())return;if(b.dataset.view==='xml'&&state.file&&!state.xmlDirty)await openText(state.file);setView(b.dataset.view);}));
function sameTransform(a,b){return a.visibility===b.visibility&&['translation','rotation','scale'].every(key=>a[key].every((v,i)=>v===b[key][i]));}
function updateDraftBar(){
 const count=transformDrafts.size;$('#transformDraftBar').hidden=!count;$('#transformDraftCount').textContent=count+' peça(s) com ajustes pendentes';$('#saveAllTransforms').disabled=state.busy;$('#discardAllTransforms').disabled=state.busy;
 const n=state.scene?.nodes[state.selected];$('#selectParent').disabled=!n||n.parent===null||n.parent===undefined;$('#selectParent').title=n&&n.parent!==null&&n.parent!==undefined?'Selecionar grupo: '+state.scene.nodes[n.parent].name:'Selecione uma peça dentro de um grupo';
}
function discardAllTransforms(){
 for(const [index,original]of transformDrafts){const n=state.scene?.nodes[index];if(n)Object.assign(n,copyTransform(original),{visibility:original.visibility});}
 transformDrafts.clear();editOriginal=null;sliderBase=null;if(state.scene){viewer?.updateMatrices();viewer?.requestDraw?.();renderSelection();renderTree();}else updateDraftBar();
}
function readTransformFields(){
 const changes={visibility:$('#visibility').checked};
 for(const key of ['translation','rotation','scale']){
  const inputs=$$(`[data-vector="${key}"]`);if(inputs.length!==3)throw Error('Reabra as propriedades da peça antes de salvar.');
  changes[key]=inputs.map(input=>{const text=String(input.value).trim(),value=Number(text);if(!text||input.validity?.badInput||!Number.isFinite(value)||Math.abs(value)>1e9)throw Error(`Valor inválido em ${key==='translation'?'Posição':key==='rotation'?'Rotação':'Tamanho'} · ${['X','Y','Z'][Number(input.dataset.axis)]}. Informe um número válido.`);return value;});
 }return changes;
}
function saveTransform(){return busy('Salvando os ajustes das peças…',async()=>{
 if(alignMode)throw Error('Termine ou cancele o alinhamento primeiro.');if(state.xmlDirty)throw Error('Salve a edição XML antes de aplicar transformações.');
 const node=editableNode();
 if(node){const values=readTransformFields();if(!sameTransform(node,values))updatePreview(values,true);}
 if(!transformDrafts.size){status('Esta peça já está salva no projeto. Toque Exportar ZIP para baixar o mod.');return;}
 const selected=state.selected,textFile=$('#xmlText').dataset.file;
 const edits=[...transformDrafts.keys()].map(index=>{const n=state.scene.nodes[index];if(!selectionTools?.canEdit(index)&&selectionTools)throw Error('Destrave as peças pendentes antes de salvar.');return {index,changes:{...copyTransform(n),visibility:n.visibility}};});
 const result=await api('/api/transforms',{project:state.project.project,file:state.file,edits,revision:state.project.revision});
 transformDrafts.clear();editOriginal=null;projectChanged(result);await openScene(state.file);state.selected=selected;viewer?.select(selected);renderSelection();renderTree();if(state.view==='xml'&&textFile)await openText(textFile);status(edits.length+' peça(s) salva(s) no projeto. Exporte o ZIP quando terminar.');
});}
$('#saveAllTransforms').onclick=saveTransform;
$('#discardAllTransforms').onclick=()=>{if(!state.busy&&window.confirm('Descartar todos os ajustes de posição, rotação, tamanho e visibilidade ainda não salvos?')){discardAllTransforms();status('Todos os ajustes pendentes foram descartados.');}};
$('#selectParent').onclick=()=>{const parent=state.scene?.nodes[state.selected]?.parent;if(parent!==null&&parent!==undefined)selectNode(parent,true);};
$('#properties').onsubmit=e=>{e.preventDefault();saveTransform();};
$('#xmlText').oninput=()=>{state.xmlDirty=true;};
$('#saveXml').onclick=()=>busy('Validando e salvando XML…',async()=>{
 if(transformDrafts.size)throw Error('Use Salvar tudo ou Descartar tudo antes de salvar o XML.');
 projectChanged(await api('/api/xml',{file:$('#xmlText').dataset.file,text:$('#xmlText').value,revision:state.xmlRevision}));state.xmlDirty=false;state.xmlRevision=state.project.revision;
 if(state.file)await openScene(state.file);status('XML válido e salvo no projeto.');
});
for(const action of ['undo','redo'])$('#'+action).onclick=()=>busy(action==='undo'?'Desfazendo…':'Refazendo…',async()=>{
 if(!dirtyGuard())return;const textFile=$('#xmlText').dataset.file;state.xmlDirty=false;projectChanged(await api('/api/'+action,{}));if(state.file)await openScene(state.file);if(state.view==='xml'&&textFile)await openText(textFile);
});
function exportReady(){if(textureConverter?.isOpen()){status('Feche o conversor de texturas antes de exportar.');return false;}if(optionalManager?.isOpen()){status('Feche o gerenciador de opcionais antes de exportar.');return false;}if(textureTools?.isOpen()){status('Salve ou cancele a textura antes de exportar.');return false;}if(animationTools?.isActive())animationTools.close();if(workbenchTools?.isDirty()){status('Salve ou cancele a prévia do material antes de exportar.');return false;}if(wheelTools?.isOpen()){status('Salve ou feche a edição das rodas antes de exportar.');return false;}if(alignMode){status('Termine ou cancele o alinhamento antes de exportar.');return false;}if(optionalState){status('Salve ou feche os opcionais antes de exportar.');return false;}if(paintData){status('Salve ou cancele a pintura antes de exportar.');return false;}if(transformDrafts.size){status('Use Salvar tudo ou Descartar tudo antes de exportar.');return false;}if(state.xmlDirty){status('Salve o XML antes de exportar.');return false;}return true;}
$('#export').onclick=()=>{if(!exportReady())return;return busy('Conferindo arquivos para exportar…',async()=>{const report=await api('/api/check');const a=document.createElement('a');a.href='/api/export';a.download='';document.body.append(a);a.click();a.remove();status('ZIP preparado para download.'+(report.missing.length||report.invalid.length?' Há '+report.missing.length+' referência(s) ausente(s) e '+report.invalid.length+' XML(s) inválido(s). Veja CONFERIR ARQUIVOS DO MOD.':' Arquivos locais conferidos.'));});};
$('#frame').onclick=()=>viewer?.frame();$('#focusNode').onclick=()=>{if(state.selected!==null)viewer?.frame(state.selected);};
$('#front').onclick=()=>{if(viewer){viewer.yaw=0;viewer.pitch=.08;viewer.draw();}};$('#top').onclick=()=>{if(viewer){viewer.pitch=1.45;viewer.draw();}};
for(const [show,close,target]of [['showLeft','closeLeft','left'],['showInspector','closeInspector','inspector']]){$('#'+show).onclick=()=>$('#'+target).classList.toggle('open');$('#'+close).onclick=()=>$('#'+target).classList.remove('open');}
window.addEventListener('beforeunload',e=>{if(textureTools?.isDirty()||wheelTools?.isDirty()||workbenchTools?.isDirty()||optionalState||state.xmlDirty||transformDrafts.size||paintPreview){e.preventDefault();e.returnValue='';}});
function canChangeSelection(){
 if(state.busy)return false;if(textureTools?.isOpen()){status('Salve ou cancele a textura antes de mudar a seleção.');return false;}if(optionalState||alignMode||paintData||workbenchTools?.isDirty()||transformDrafts.size||state.xmlDirty||wheelTools?.isOpen()){status('Conclua ou cancele a edição atual antes de mudar a seleção.');return false;}
 if(animationTools?.isActive())animationTools.close();return true;
}
selectionTools=installSelection({$,state,api,busy,status,viewer,canChange:canChangeSelection,dirtyGuard,changed:index=>{state.selected=index;renderSelection();renderTree();},projectChanged,openScene});
animationTools=installAnimations({$,state,api,busy,status,viewer,dirtyGuard,onClose:()=>{renderSelection();renderTree();}});
workbenchTools=installWorkbench({$,state,api,busy,status,viewer,editableNode,dirtyGuard,projectChanged,openScene,startProject,selectNode,accessoryChanged});
wheelTools=installWheels({$,state,api,busy,status,viewer,projectChanged,openScene,dirtyGuard,selectNode});
textureTools=installTexturePaint({$,state,api,busy,status,viewer,dirtyGuard,editableNode,projectChanged,openScene,selectNode});
optionalManager=installOptionalManager({$,state,api,busy,status,viewer,projectChanged,openScene,onClosed:()=>{renderSelection();renderTree();},canOpen:()=>{if(!state.file||!state.scene){status('Abra um mod completo com XML do veículo.');return false;}if(optionalState||paintData||alignMode||transformDrafts.size||state.xmlDirty||wheelTools?.isOpen()||textureTools?.isOpen()||workbenchTools?.isDirty()||animationTools?.isActive()){status('Conclua a edição atual e use Salvar tudo ou Descartar tudo antes de gerenciar os opcionais.');return false;}return true;}});
textureConverter=installTextureConvert({$,state,api,busy,status,projectChanged,openScene,canOpen:()=>{if(!state.project?.project){status('Abra um mod primeiro.');return false;}return exportReady();}});
installCreation({$,state,api,busy,status,viewer,dirtyGuard,exportReady,editableNode,startProject,projectChanged,openScene,selectNode});
window.addEventListener('gabriel-converter-project-check',event=>{if(state.busy||!exportReady())event.preventDefault();});
window.addEventListener('gabriel-converter-open',e=>{
 if(state.busy||!dirtyGuard())return;
 busy('Abrindo uma cópia do mod convertido…',async()=>{
  const result=await api('/api/converter/open',{id:e.detail.id});await startProject(result);
  document.querySelector('#converterDialog')?.close();status('Mod convertido aberto em um novo projeto. Confira o relatório de conversão antes de testar no jogo.');
 });
});
busy('Abrindo o editor…',async()=>{try{const job=await api('/api/texture-jobs/status');if(job?.state==='running'){setTimeout(()=>textureConverter.resume(job),0);return;}}catch{}const project=await api('/api/project');projectChanged(project);baseChanged(await api('/api/base'));if(project.project){let initial=project.i3ds[0];try{const last=localStorage.getItem('gabriel:lastFile:'+project.project);if(project.i3ds.includes(last))initial=last;}catch{}await openScene(initial,true);}});

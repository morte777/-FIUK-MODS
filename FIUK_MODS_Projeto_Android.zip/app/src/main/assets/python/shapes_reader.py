"""Read-only FS22 .i3d.shapes geometry, based on I3DShapesTool's format.

Cipher: BrewingCoder/giants-fs-codecs + Donkie/I3DShapesTool (MIT notices bundled).
The FS22 subset layout is deliberately parsed separately from the FS25 codec.
Never writes or converts the original .shapes file.
"""
from array import array
import base64
import math
import struct
import sys
from codecs_vendor import shapes_cipher as cipher

try:
    import numpy as np
except ImportError:
    np = None

def decrypt(data, seed, block=0):
    """Optional vectorized acceleration; identical per-read cipher counters."""
    if np is None or len(data) < 256:
        return cipher.process(data, seed, block)
    padded = data + b'\0' * ((-len(data)) % 64)
    words = np.frombuffer(padded, dtype='<u4').reshape(-1, 16)
    result = np.empty_like(words)
    for begin in range(0, len(words), 4096):
        end = min(begin + 4096, len(words))
        key = np.tile(np.array(cipher.KEY_CONST[seed*16:seed*16+16], dtype=np.uint32), (end-begin, 1))
        counter = np.arange(block+begin, block+end, dtype=np.uint64)
        key[:, 8] = (counter & np.uint64(0xffffffff)).astype(np.uint32)
        key[:, 9] = (counter >> np.uint64(32)).astype(np.uint32)
        k = key.copy()
        def rol(value, shift): return (value << np.uint32(shift)) | (value >> np.uint32(32-shift))
        def shuffle1(a,b,c,d):
            k[:,c] ^= rol(k[:,b]+k[:,a],7)
            k[:,d] ^= rol(k[:,c]+k[:,a],9)
            k[:,b] ^= rol(k[:,c]+k[:,d],13)
            k[:,a] ^= rol(k[:,b]+k[:,d],18)
        def shuffle2(a,b,c,d):
            k[:,c] ^= rol(k[:,b]+k[:,a],7)
            k[:,d] ^= rol(k[:,b]+k[:,c],9)
            k[:,a] ^= rol(k[:,c]+k[:,d],13)
            k[:,b] ^= rol(k[:,d]+k[:,a],18)
        for _ in range(10):
            shuffle1(0,12,4,8);shuffle1(5,1,9,13);shuffle1(10,6,14,2);shuffle1(15,11,3,7)
            shuffle2(3,0,1,2);shuffle2(4,5,6,7);shuffle1(10,9,11,8);shuffle2(14,15,12,13)
        result[begin:end] = words[begin:end] ^ (key+k)
    return result.astype('<u4', copy=False).tobytes()[:len(data)]

class Reader:
    def __init__(self, data): self.data=data;self.pos=0
    def take(self, count):
        if count < 0 or count > len(self.data)-self.pos: raise ValueError('Malha truncada ou tamanho invalido.')
        result=self.data[self.pos:self.pos+count];self.pos+=count;return result
    def u32(self):return struct.unpack('<I', self.take(4))[0]
    def i32(self):return struct.unpack('<i', self.take(4))[0]
    def align(self):self.take((-self.pos)%4)

def numbers(raw, kind):
    values=array(kind);values.frombytes(raw)
    if sys.byteorder!='little':values.byteswap()
    return values

def packed(raw):return base64.b64encode(raw).decode('ascii')

def parse_shape(data, version):
    r=Reader(data)
    name_len=r.i32()
    if name_len < 0 or name_len > 16384:raise ValueError('Nome de malha invalido.')
    name=r.take(name_len).decode('ascii','replace');r.align()
    shape_id=r.u32();bv=struct.unpack('<4f', r.take(16))
    corners,subset_count,vertices,options=[r.u32() for _ in range(4)]
    if corners%3 or corners>6000000 or vertices>2000000 or subset_count>4096:
        raise ValueError('Contagem de malha invalida ou acima do limite de visualizacao.')
    subsets=[];uv_densities=[]
    for _ in range(subset_count):
        first_vertex,num_vertices,first_index,num_indices=[r.u32() for _ in range(4)]
        densities=[None]*4
        if version>=6:
            for uv,bit in enumerate([2,4,8,16]):
                if options&bit:densities[uv]=struct.unpack('<f',r.take(4))[0]
        if any(v is not None and not math.isfinite(v) for v in densities):raise ValueError('Densidade UV invalida: '+name)
        uv_densities.append(densities)
        if first_vertex+num_vertices>vertices or first_index+num_indices>corners or first_index%3 or num_indices%3:
            raise ValueError('Subset fora da malha: '+name)
        subsets.append({'firstVertex':first_vertex,'numVertices':num_vertices,
                        'firstIndex':first_index,'numIndices':num_indices})
    index_type='u32' if vertices>65536 else 'u16'
    indices=r.take(corners*(4 if index_type=='u32' else 2));r.align()
    positions=r.take(vertices*12)
    normals=r.take(vertices*12) if options&1 else None
    tangents=r.take(vertices*16) if options&128 and version>=5 else None
    uvsets=[]
    for bit in [2,4,8,16]:
        uvsets.append(r.take(vertices*8) if options&bit else None)
    colors=r.take(vertices*16) if options&32 else None
    skin=None
    if options&64:
        single=bool(options&256)
        weights=None if single else r.take(vertices*16)
        blend_indices=r.take(vertices*(1 if single else 4))
        skin={'single':single,'indices':packed(blend_indices),
              'weights':packed(weights) if weights else None}
    if options&512:r.take(vertices*4)
    attachments=r.u32()
    if attachments>100000:raise ValueError('Anexos em excesso.')
    for _ in range(attachments):
        flags=r.u32()
        if flags&4:r.take(12)
        r.take(r.i32())
    if r.pos!=len(data):raise ValueError(f'Malha nao consumida por completo: {name} ({r.pos}/{len(data)})')
    if np is not None and vertices>=256:
        pos=np.frombuffer(positions,dtype='<f4').reshape(-1,3)
        idx=np.frombuffer(indices,dtype='<u4' if index_type=='u32' else '<u2')
        if not np.all(np.isfinite(pos)&(np.abs(pos)<1e9)):raise ValueError('Vertices invalidos: '+name)
        if normals and not np.all(np.isfinite(np.frombuffer(normals,dtype='<f4'))):raise ValueError('Normais invalidas: '+name)
        if colors and not np.all(np.isfinite(np.frombuffer(colors,dtype='<f4'))):raise ValueError('Cores de vertices invalidas: '+name)
        if idx.size and int(idx.max())>=vertices:raise ValueError('Indice fora da malha: '+name)
        bounds=[pos.min(axis=0).tolist(),pos.max(axis=0).tolist()]
    else:
        pos=numbers(positions,'f');idx=numbers(indices,'I' if index_type=='u32' else 'H')
        if not all(math.isfinite(f) and abs(f)<1e9 for f in pos):raise ValueError('Vertices invalidos: '+name)
        if normals and not all(math.isfinite(f) for f in numbers(normals,'f')):raise ValueError('Normais invalidas: '+name)
        if colors and not all(math.isfinite(f) for f in numbers(colors,'f')):raise ValueError('Cores de vertices invalidas: '+name)
        if idx and max(idx)>=vertices:raise ValueError('Indice fora da malha: '+name)
        bounds=[[min(pos[i::3]) for i in range(3)],[max(pos[i::3]) for i in range(3)]] if vertices else [[0,0,0],[0,0,0]]
    mesh={'name':name,'vertexCount':vertices,'triangleCount':corners//3,
          'positionsBase64':packed(positions),'normalsBase64':packed(normals) if normals else None,
          'indicesBase64':packed(indices),'indexType':index_type,'subsets':subsets,
          'bounds':bounds,'skin':skin,'uvDensities':uv_densities,'boundingSphere':list(bv) if all(math.isfinite(v) for v in bv) else None,'nativeOptions':options,'nativeAttachments':attachments,
          'tangentsBase64':packed(tangents) if tangents else None,'colorsBase64':packed(colors) if colors else None,
          'uvSetsBase64':[packed(uv) if uv else None for uv in uvsets]}
    return str(shape_id),mesh

def decode(raw):
    if len(raw)<8:raise ValueError('Arquivo .shapes incompleto.')
    version,seed,offset=cipher.read_header(raw)
    if version not in (4,5,6,7):raise ValueError(f'.shapes versao {version}: suporte atual 4 a 7.')
    r=Reader(raw[offset:]);block=0
    def read(count):
        nonlocal block
        data=decrypt(r.take(count),seed,block);block+=(count+63)//64;return data
    def i32():return struct.unpack('<i',read(4))[0]
    count=i32()
    if not 0<=count<=100000:raise ValueError('Contagem de entidades .shapes invalida.')
    meshes={};warnings=[];types={}
    for entity in range(count):
        kind,size=i32(),i32()
        blob=read(size)
        types[kind]=types.get(kind,0)+1
        if kind!=1:continue
        try:
            sid,mesh=parse_shape(blob,version)
            if sid in meshes:raise ValueError('shapeId duplicado no binario.')
            meshes[sid]=mesh
        except (ValueError,struct.error,OverflowError) as e:
            warnings.append(f'Entidade {entity}: {e}')
    if r.pos!=len(r.data):raise ValueError('Bytes adicionais fora das entidades .shapes.')
    return {'version':version,'seed':seed,'entityCount':count,'entityTypes':types,
            'meshes':meshes,'warnings':warnings,'engine':'numpy' if np is not None else 'python'}

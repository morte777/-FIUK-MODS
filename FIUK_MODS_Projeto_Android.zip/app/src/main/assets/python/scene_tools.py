"""Static visual hierarchy tools; leave reserved slots so unrelated paths stay stable."""
import copy,json,math,re,xml.etree.ElementTree as ET
from collections import Counter
from core import I3D,tagname
from decals import spans,append_element
from xml_edit import attributes,fragment,section,next_id,whole_end

ANCHOR='__GabrielReserva__'
VISUAL={'name','translation','rotation','scale','visibility','nodeId','shapeId','materialIds',
        'nonRenderable','clipDistance','castsShadows','receiveShadows','distanceBlending'}
META={'gabrielPlotagem','gabrielEditorGrupo'}

def is_anchor(node):return node['tag']=='TransformGroup' and node['name'].startswith(ANCHOR)

def scene_paths(doc):
    counts={};paths={}
    for n in doc.nodes:
        parent=n['parent'];ordinal=counts.get(parent,0);counts[parent]=ordinal+1
        paths[n['index']]=str(ordinal) if parent is None else paths[parent]+('>' if doc.nodes[parent]['parent'] is None else '|')+str(ordinal)
    return paths

def selection(doc,indices):
    if not isinstance(indices,list) or not 1<=len(indices)<=50 or any(type(i)!=int or not 0<=i<len(doc.nodes) for i in indices):
        raise ValueError('Selecione de 1 a 50 pecas do I3D principal.')
    if len(set(indices))!=len(indices):raise ValueError('Selecao repetida.')
    indices=sorted(indices);chosen=set(indices)
    for i in indices:
        n=doc.nodes[i]
        if n['parent'] is None:raise ValueError('A raiz do veiculo e protegida. Selecione uma peca abaixo dela.')
        if is_anchor(n):raise ValueError('Posicao reservada da hierarquia: selecione uma peca visual.')
        parent=n['parent']
        while parent is not None:
            if parent in chosen:raise ValueError('Selecione o grupo ou seus filhos, sem incluir ambos.')
            parent=doc.nodes[parent]['parent']
    return indices

def context(editor,name,indices,*,allow_functional=False):
    if not isinstance(name,str) or not name.lower().endswith('.i3d'):raise ValueError('Abra um I3D principal.')
    doc=I3D(editor.read(name));indices=selection(doc,indices);_,items=spans(doc.text)
    by_start={e['start']:e for e in items};roots={i:by_start[doc.spans[i][0]] for i in indices}
    selected=[e for e in items if any(root['start']<=e['start']<whole_end(doc,root) for root in roots.values())]
    if len(selected)>3000:raise ValueError('Selecao muito grande. Escolha menos de 3.000 nos.')
    if not allow_functional and any(e['local'] not in ('Shape','TransformGroup') for e in selected):raise ValueError('Ferramenta para pecas visuais estaticas, sem luzes, cameras ou articulacoes.')
    if any(e['attrs'].get('skinBindNodeIds') for e in selected):raise ValueError('Pecas com ossos nao podem ser reorganizadas por esta ferramenta.')
    return doc,items,roots,selected

def audit_move(editor,name,doc,items,roots,selected):
    # All I3D paths outside the selection remain stable through reserved slots.
    # Refuse moving/removing a selected target used by native vehicle XML or I3D.
    ids={e['attrs'].get('nodeId') for e in selected}-{None};counts=Counter(n['nodeId'] for n in doc.nodes)
    if any(counts[nid]!=1 for nid in ids):raise ValueError('nodeId duplicado na selecao. Corrija o I3D antes de reorganizar.')
    selected_starts={e['start'] for e in selected}
    for e in selected:
        extra=set(e['attrs'])-VISUAL
        if extra or e['attrs'].get('nonRenderable') in ('true','1'):
            raise ValueError('A selecao possui fisica, colisoes ou atributos funcionais. Use Ocultar para uma alteracao apenas visual.')
    root=ET.fromstring(doc.text)
    for e in root.iter():
        if tagname(e.tag)=='UserAttribute' and e.get('nodeId') in ids:
            if any(tagname(c.tag)!='Attribute' or c.get('name') not in META for c in e):
                raise ValueError('A peca possui UserAttributes de funcionamento. Sua hierarquia foi preservada.')
    for e in items:
        if e['start'] in selected_starts:continue
        if e['local']=='UserAttribute':continue
        for key,value in e['attrs'].items():
            if key in ('skinBindNodeIds','nodeId','transformId','rootNode','jointNode') and set(value.split())&ids:
                raise ValueError('A peca e referenciada por ossos, animacoes ou dinamica no I3D.')
    paths=scene_paths(doc);selected_paths={paths[n['index']] for n in doc.nodes if doc.spans[n['index']][0] in selected_starts}
    def canonical(value):
        value=value.strip()
        if not re.fullmatch(r'\d+(?:>\d+(?:\|\d+)*)?',value):return None
        if '>' not in value:return str(int(value))
        root,rest=value.split('>');return str(int(root))+'>'+'|'.join(str(int(v)) for v in rest.split('|'))
    total=0
    for entry in editor.summary()['files']:
        path=entry['name']
        if not path.lower().endswith('.xml'):continue
        data=editor.read(path);total+=len(data)
        if total>64*1024*1024:raise ValueError('XMLs grandes demais para conferir referencias. Escolha Ocultar.')
        try:other=I3D(data);_,elements=spans(other.text)
        except (ValueError,ET.ParseError) as error:raise ValueError('Nao foi possivel conferir as referencias de '+path) from error
        for element in elements:
            for key,value in element['attrs'].items():
                # Single numbers can be unrelated counts. Native root references
                # are already protected; descendants always contain the > separator.
                if '>' in value and canonical(value) in selected_paths:
                    raise ValueError('Peca usada em '+path+' ('+key+'). Use Ocultar ou duplique a parte visual para editar.')

def label(value,default):
    if value is None:value=default
    if not isinstance(value,str) or not value.strip() or len(value.strip())>80 or any(ord(c)<32 for c in value):raise ValueError('Informe um nome de 1 a 80 caracteres.')
    return value.strip()

def encoded(doc,raw):return raw.decode('utf-8').encode(doc.encoding,errors='xmlcharrefreplace')

def apply(editor,name,action,indices,revision,title=None,offset=None):
    with editor.lock:
        if revision!=editor.meta()['revision']:raise ValueError('O projeto mudou. Reabra as ferramentas da peca.')
        if action not in ('duplicate','delete','group'):raise ValueError('Ferramenta desconhecida.')
        doc,items,roots,selected=context(editor,name,indices);indices=sorted(roots)
        if action!='group' and len(indices)!=1:raise ValueError('Selecione somente uma peca para esta ferramenta.')
        if action=='group' and (len(indices)<2 or len({doc.nodes[i]['parent'] for i in indices})!=1):raise ValueError('Escolha pelo menos duas pecas que tenham o mesmo pai.')
        if action!='duplicate':audit_move(editor,name,doc,items,roots,selected)
        # Static geometry is shared with the source; no .shapes/texture is rewritten.
        scene=editor.scene(name,include_wheels=False)
        for e in selected:
            mesh=scene['meshes'].get(e['attrs'].get('shapeId'))
            if mesh and mesh.get('skin'):raise ValueError('Malha com deformacao por ossos: use uma peca estatica.')
        parent=doc.nodes[indices[0]]['parent'];new_id=next_id(doc,'nodeId');result_id=None;metadata=[]
        if action=='duplicate':
            node=ET.fromstring(fragment(doc,roots[indices[0]]));idmap={}
            if len({e.get('nodeId') for e in node.iter() if e.get('nodeId')})!=sum(bool(e.get('nodeId')) for e in node.iter()):raise ValueError('nodeId duplicado na origem.')
            for i,e in enumerate(node.iter()):
                if e.get('nodeId'):idmap[e.get('nodeId')]=str(new_id+i)
                attrs={k:v for k,v in e.attrib.items() if k in VISUAL};e.attrib.clear();e.attrib.update(attrs);e.set('nodeId',str(new_id+i))
            node.set('name',label(title,doc.nodes[indices[0]]['name'][:74]+' copia'));result_id=node.get('nodeId')
            offset=[.1,0,0] if offset is None else offset
            # Reuse the transform validator for bounded finite offsets.
            doc.patch(indices[0],{'translation':offset})
            translation=[v+d for v,d in zip(doc.nodes[indices[0]]['translation'],offset)]
            if any(abs(v)>1e9 for v in translation):raise ValueError('Deslocamento fora do limite.')
            node.set('translation',' '.join(format(v,'.10g') for v in translation))
            # Only copy editor-owned metadata. Do not clone executable attributes.
            xmlroot=ET.fromstring(doc.text)
            for ua in xmlroot.iter():
                if tagname(ua.tag)!='UserAttribute' or ua.get('nodeId') not in idmap:continue
                clone=ET.Element('UserAttribute',{'nodeId':idmap[ua.get('nodeId')]})
                for a in ua:
                    if tagname(a.tag)=='Attribute' and a.get('name') in META:clone.append(copy.deepcopy(a))
                if len(clone):metadata.append(ET.tostring(clone,encoding='utf-8'))
            parent_item=next(e for e in items if e['start']==doc.spans[parent][0]);raw=encoded(doc,append_element(doc.utf8,parent_item,ET.tostring(node,encoding='utf-8')))
        else:
            changes=[];new_group=None
            if action=='group':
                result_id=str(new_id);new_id+=1
                center=[sum(doc.nodes[i]['translation'][k] for i in indices)/len(indices) for k in range(3)]
                new_group=ET.Element('TransformGroup',{'name':label(title,'Grupo de pecas'),'nodeId':result_id,'translation':' '.join(format(v,'.10g') for v in center)})
                for i in indices:
                    node=ET.fromstring(fragment(doc,roots[i]));node.set('translation',' '.join(format(v-c,'.10g') for v,c in zip(doc.nodes[i]['translation'],center)));new_group.append(node)
            for i in indices:
                item=roots[i];anchor=ET.Element('TransformGroup',{'name':ANCHOR+str(new_id),'nodeId':str(new_id)})
                changes.append((item['start'],whole_end(doc,item),ET.tostring(anchor,encoding='utf-8')));new_id+=1
            if action=='delete':
                ids={e['attrs'].get('nodeId') for e in selected}-{None}
                for e in items:
                    if e['local']=='UserAttribute' and e['attrs'].get('nodeId') in ids:changes.append((e['start'],whole_end(doc,e),b''))
            raw=doc.utf8
            for start,end,replacement in sorted(changes,reverse=True):raw=raw[:start]+replacement+raw[end:]
            raw=encoded(doc,raw)
            if new_group is not None:
                updated=I3D(raw);_,elements=spans(updated.text);parent_item=next(e for e in elements if e['start']==updated.spans[parent][0])
                raw=encoded(updated,append_element(updated.utf8,parent_item,ET.tostring(new_group,encoding='utf-8')))
        if metadata:raw=section(I3D(raw),'UserAttributes',b''.join(metadata))
        parsed=I3D(raw)
        result_index=next((n['index'] for n in parsed.nodes if n['nodeId']==result_id),None) if result_id else parent
        project=editor.change(name,raw,revision)
        return {'project':project,'index':result_index,'action':action,'count':len(indices)}

"""Isolated diffuse texture editing with PNG source and mipmapped native AST."""
import base64,copy,posixpath,uuid,xml.etree.ElementTree as ET
from core import I3D
from decals import png_pixels,gs2d_rgba,spans
from xml_edit import fragment,section,attributes,next_id
from selection_tools import node_keys,view_state

def options(editor,name,index):
    with editor.lock:
        doc=I3D(editor.read(name))
        if type(index)!=int or not 0<=index<len(doc.nodes):raise ValueError('Selecione uma peca do projeto.')
        node=doc.nodes[index];scene=editor.scene(name,include_wheels=False);mesh=scene['meshes'].get(node['shapeId']);uv=bool(mesh and (mesh.get('uvs') or (mesh.get('uvSetsBase64') or [None])[0]));root=ET.fromstring(doc.text);rows=[]
        for mid in dict.fromkeys(node['materialIds'].split()):
            element=next((e for e in root.findall('Materials/Material') if e.get('materialId')==mid),None)
            if element is None:continue
            material=scene['materialDetails'].get(mid,{});resource=material.get('maps',{}).get('diffuse');source=resource
            # Prefer the editable PNG next to a generated AST, when available.
            if resource and not resource.startswith('base:') and resource.lower().endswith(('.ast','.astc','.dds')):
                png=posixpath.splitext(resource)[0]+'.png';source=editor.archive_index()[0].get(png.casefold(),resource)
            supported=uv and not element.get('customShaderId')
            note='UV automatico nas formas criadas. A imagem segue o UV existente desta peca.' if supported else 'Esta peca nao possui UV de textura.' if not uv else 'Este material usa shader proprio. Use Pintura ou uma peca com material simples para aplicar uma imagem diffuse.'
            rows.append({'id':mid,'name':element.get('name') or 'Material '+mid,'supported':supported,'resource':source,'flipY':bool(source and source.lower().endswith(('.ast','.astc'))),'note':note})
        return {'file':name,'index':index,'name':node['name'],'project':editor.project.name,'revision':editor.meta()['revision'],'materials':rows}

def save(editor,body):
    with editor.lock:
        if not editor.project or body.get('project')!=editor.project.name or body.get('revision')!=editor.meta()['revision']:raise ValueError('O projeto mudou. Reabra o editor de texturas.')
        name=body['file'];index=body['index'];mid=str(body['materialId']);available=options(editor,name,index);choice=next((m for m in available['materials'] if m['id']==mid),None)
        if choice is None or not choice['supported']:raise ValueError(choice['note'] if choice else 'Material nao pertence a peca selecionada.')
        doc=I3D(editor.read(name));keys=node_keys(doc.nodes);locked=set(view_state(editor,name)['locked']);p=index
        while p is not None:
            if keys[p] in locked:raise ValueError('A peca esta travada. Destrave antes de salvar a textura.')
            p=doc.nodes[p]['parent']
        try:png=base64.b64decode(body['png'],validate=True)
        except (ValueError,TypeError):raise ValueError('PNG invalido.')
        w,h,pixels=png_pixels(png);transparent=any(pixels[i]<255 for i in range(3,len(pixels),4));stem='gabriel_texturas/'+uuid.uuid4().hex[:16]+'/pintura'
        from game_compat import texture_assets
        path,assets=texture_assets(editor,posixpath.join(posixpath.dirname(name),stem),png,w,h,pixels);relative=posixpath.relpath(path,posixpath.dirname(name) or '.')
        _,items=spans(doc.text);original=next(e for e in items if e['local']=='Material' and e['attrs'].get('materialId')==mid);material=ET.fromstring(fragment(doc,original));new_mid=str(next_id(doc,'materialId'));fid=str(next_id(doc,'fileId'));material.set('materialId',new_mid);material.set('name',(material.get('name') or 'Material')+' textura');rgba=material.get('diffuseColor','1 1 1 1').split();material.set('diffuseColor','1 1 1 '+(rgba[3] if len(rgba)>3 else '1'))
        texture=material.find('Texture')
        if texture is None:texture=ET.SubElement(material,'Texture')
        texture.set('fileId',fid)
        if transparent:material.set('alphaBlending','true')
        file=ET.Element('File',{'fileId':fid,'filename':relative,'relativePath':'true'});raw=section(doc,'Files',ET.tostring(file,encoding='utf-8'));raw=section(I3D(raw),'Materials',ET.tostring(material,encoding='utf-8'));current=I3D(raw);_,items=spans(current.text);item=next(e for e in items if e['start']==current.spans[index][0]);raw=attributes(current,item,{'materialIds':' '.join(new_mid if m==mid else m for m in current.nodes[index]['materialIds'].split())})
        result=editor.change_many({name:raw,**assets},body['revision']);stem=posixpath.splitext(path)[0];native='dds' if path.lower().endswith('.dds') else 'ast'
        return {'project':result,'index':index,'file':name,'materialId':new_mid,'png':stem+'.png',native:stem+'.'+native,'nativeFormat':native,'width':w,'height':h}

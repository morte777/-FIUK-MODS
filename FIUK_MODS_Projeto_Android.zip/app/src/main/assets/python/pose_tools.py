"""Static visual mirror and surface placement; hierarchy and resources stay intact."""
import copy,math
from scene_tools import context
from surface_decal import rotation,arrays,dot,cross

def mv(a,v):return [sum(x*y for x,y in zip(row,v)) for row in a]
def mm(a,b):return [[sum(a[i][k]*b[k][j] for k in range(3)) for j in range(3)] for i in range(3)]
def transpose(a):return [list(v) for v in zip(*a)]
def unit(v):
    length=math.sqrt(dot(v,v))
    if length<1e-12:raise ValueError('Direcao ou normal sem comprimento.')
    return [x/length for x in v]
def inverse(a):
    cols=transpose(a);cof=[cross(cols[1],cols[2]),cross(cols[2],cols[0]),cross(cols[0],cols[1])];det=dot(cols[0],cof[0])
    if abs(det)<1e-12:raise ValueError('Escala nula ou quase nula impede o alinhamento.')
    return [[v/det for v in row] for row in cof]
def world(nodes):
    out=[]
    for n in nodes:
        r=rotation(n['rotation']);a=[[r[i][j]*n['scale'][j] for j in range(3)] for i in range(3)];t=n['translation'][:]
        if n['parent'] is not None:
            pa,pt=out[n['parent']];t=[x+y for x,y in zip(mv(pa,t),pt)];a=mm(pa,a)
        out.append((a,t))
    return out
def euler(r):
    y=math.asin(max(-1,min(1,-r[2][0])))
    if abs(math.cos(y))>1e-8:x=math.atan2(r[2][1],r[2][2]);z=math.atan2(r[1][0],r[0][0])
    else:x=math.atan2(-r[1][2],r[1][1]);z=0
    return [v*180/math.pi for v in (x,y,z)]
def between(a,b):
    a,b=unit(a),unit(b);c=max(-1,min(1,dot(a,b)));v=cross(a,b)
    if c<-.99999999:
        k=unit(cross(a,min(([1,0,0],[0,1,0],[0,0,1]),key=lambda v:abs(dot(a,v)))))
        return [[2*k[i]*k[j]-(1 if i==j else 0) for j in range(3)] for i in range(3)]
    k=[[0,-v[2],v[1]],[v[2],0,-v[0]],[-v[1],v[0],0]];k2=mm(k,k)
    return [[(1 if i==j else 0)+k[i][j]+k2[i][j]/(1+c) for j in range(3)] for i in range(3)]
def vector(value):
    if not isinstance(value,list) or len(value)!=3 or any(isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) or abs(v)>1e9 for v in value):raise ValueError('Ponto/normal invalido.')
    return value
def _static(editor,name,index):
    doc,items,roots,selected=context(editor,name,[index]);node=doc.nodes[index]
    if node['nonRenderable']:raise ValueError('Selecione uma peca visual.')
    if any(set(e['attrs'])&{'dynamic','compound','collisionMask','joint','rigidBodyType'} for e in selected):raise ValueError('Use uma peca visual estatica, sem fisica.')
    return doc,node

def mirror(editor,name,index,axis,revision):
    with editor.lock:
        if revision!=editor.meta()['revision']:raise ValueError('O projeto mudou. Reabra a ferramenta.')
        if type(axis)!=int or axis not in (0,1,2):raise ValueError('Escolha o eixo X, Y ou Z.')
        doc,node=_static(editor,name,index);scene=editor.scene(name,include_wheels=False)
        descendants={index}
        for n in doc.nodes:
            if n['parent'] in descendants:descendants.add(n['index'])
            if n['index'] in descendants and scene['meshes'].get(n['shapeId'],{}).get('skin'):raise ValueError('Espelhamento requer malhas estaticas, sem ossos.')
        scale=node['scale'][:];scale[axis]*=-1
        return {'project':editor.change(name,doc.patch(index,{'scale':scale}),revision),'index':index}

def align(editor,name,index,target,point,normal,axis,offset,orient,revision):
    with editor.lock:
        if revision!=editor.meta()['revision']:raise ValueError('O projeto mudou. Selecione a superficie novamente.')
        doc,node=_static(editor,name,index)
        if type(target)!=int or not 0<=target<len(doc.nodes):raise ValueError('Toque uma superficie do I3D principal.')
        p=target
        while p is not None:
            if p==index:raise ValueError('Toque outra peca, fora do conjunto que sera alinhado.')
            p=doc.nodes[p]['parent']
        if type(axis)!=int or axis not in (0,1,2) or not isinstance(orient,bool):raise ValueError('Eixo de alinhamento invalido.')
        if isinstance(offset,bool) or not isinstance(offset,(int,float)) or not math.isfinite(offset) or not 0<=offset<=1:raise ValueError('Afastamento deve estar entre 0 e 1 metro.')
        point=vector(point);normal=unit(vector(normal));scene=editor.scene(name,include_wheels=False)
        if not scene['meshes'].get(doc.nodes[target]['shapeId']) or doc.nodes[target]['nonRenderable']:raise ValueError('O destino precisa ter uma malha visual.')
        original=world(doc.nodes);ta,tt=original[target];pa,pt=original[node['parent']];inv_parent=inverse(pa)
        nw=unit(mv(transpose(inverse(ta)),normal));contact=[a+b for a,b in zip(mv(ta,point),tt)];r=rotation(node['rotation'])
        if orient:
            local_normal=unit(mv(inv_parent,nw));direction=[r[k][axis]*(1 if node['scale'][axis]>=0 else -1) for k in range(3)];r=mm(between(direction,local_normal),r)
        rotations=euler(r);nodes=copy.deepcopy(doc.nodes);nodes[index]['rotation']=rotations;nodes[index]['translation']=[0,0,0];posed=world(nodes);origin=posed[index][1]
        selected=set();minimum=None;count=0;visible={}
        for n in nodes:
            if n['index']!=index and n['parent'] not in selected:continue
            selected.add(n['index']);visible[n['index']]=(True if n['index']==index else n['visibility'] and visible[n['parent']])
            mesh=scene['meshes'].get(n['shapeId'])
            if not mesh or n['nonRenderable'] or not visible[n['index']]:continue
            if mesh.get('skin'):raise ValueError('Alinhamento automatico requer malhas estaticas, sem ossos.')
            positions,_,_=arrays(mesh);count+=len(positions)
            if count>1000000:raise ValueError('Selecione um conjunto com menos de um milhao de vertices.')
            a,t=posed[n['index']]
            for v in positions:
                projected=dot(nw,[x+y-z for x,y,z in zip(mv(a,v),t,origin)]);minimum=projected if minimum is None else min(minimum,projected)
        if minimum is None:raise ValueError('A peca selecionada nao tem geometria visual para apoiar.')
        desired=[x+n*(offset-minimum) for x,n in zip(contact,nw)];translation=mv(inv_parent,[a-b for a,b in zip(desired,pt)])
        raw=doc.patch(index,{'translation':translation,'rotation':rotations})
        return {'project':editor.change(name,raw,revision),'index':index}

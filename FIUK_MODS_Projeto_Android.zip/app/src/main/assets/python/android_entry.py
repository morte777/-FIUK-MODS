from pathlib import Path
import server

def start(data_dir):
    return server.start_embedded(data_dir)

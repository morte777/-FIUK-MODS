"""V18 profiles/mipmaps adapted to the editor's transactional ZIP workflow.
Never runs the CLI, deletes a source directly or executes a file from the ZIP.
"""
import io, posixpath, struct
from pathlib import Path
from dds_texture import header as header_2d, level_image, image_module

def rules():
 image_module()  # Load the bundled Pillow before the original V18 imports PIL.
 import fs23_v18
 return fs23_v18

def header(raw,check_payload=True):
 if len(raw)<128 or raw[:4]!=b'DDS ' or struct.unpack_from('<I',raw,4)[0]!=124 or struct.unpack_from('<I',raw,76)[0]!=32:raise ValueError('Cabecalho DDS invalido ou truncado.')
 if raw[84:88]!=b'DX10':return header_2d(raw,check_payload)
 if len(raw)<148:raise ValueError('Cabecalho DDS DX10 truncado.')
 fmt,dimension,misc,layers,_=struct.unpack_from('<5I',raw,128)
 if layers==1:return header_2d(raw,check_payload)
 h,w=struct.unpack_from('<II',raw,12);depth=struct.unpack_from('<I',raw,24)[0];mips=max(1,struct.unpack_from('<I',raw,28)[0]);caps2=struct.unpack_from('<I',raw,112)[0]
 if dimension!=3 or misc&4 or caps2&(0xfe00|0x200000) or depth>1:raise ValueError('Cubemap e volume ainda nao suportados pelo conversor V18.')
 if not 0<w<=4096 or not 0<h<=4096 or mips>max(w,h).bit_length():raise ValueError('Dimensoes ou mipmaps do array invalidos.')
 effect=layers==2 and fmt==10 and mips==1
 if not effect and (layers not in (4,6) or fmt not in (28,29,71,72,77,78,98,99)):raise ValueError('Array DXGI '+str(fmt)+' com '+str(layers)+' camadas ainda nao suportado; DDS preservada.')
 if w*h*layers*(8 if effect else 4)>128*1024*1024:raise ValueError('Array excede 128 MB de pixels decodificados; DDS preservada.')
 unit=8 if effect or fmt in (71,72) else 4 if fmt in (28,29) else 16
 compressed=fmt not in (10,28,29)
 stride=sum(((max(1,w>>i)+3)//4)*((max(1,h>>i)+3)//4)*unit if compressed else max(1,w>>i)*max(1,h>>i)*unit for i in range(mips))
 if check_payload and len(raw)!=148+stride*layers:raise ValueError('Payload do array DDS truncado ou inconsistente.')
 return dict(width=w,height=h,mipmaps=mips,layers=layers,effect=effect,format=('RGBA16F' if effect else 'DXGI '+str(fmt))+' array '+str(layers)+'L',start=148)

def terrain_roles(editor):
 import xml.etree.ElementTree as ET
 result={}
 for owner in editor.archive_index()[0].values():
  if not owner.lower().endswith('.i3d'):continue
  try:doc=ET.fromstring(editor.read(owner))
  except (ET.ParseError,ValueError,OSError):continue
  files={node.get('fileId'):node.get('filename') for node in doc.iter() if node.tag.rsplit('}',1)[-1]=='File'}
  for node in doc.iter():
   if node.tag.rsplit('}',1)[-1]!='Layer':continue
   for attr,role in [('detailMapId','detail'),('normalMapId','normal')]:
    value=files.get(node.get(attr))
    if not value or value.startswith('$'):continue
    value=value.split('?',1)[0].split('#',1)[0]
    if value.lower().endswith('.png'):value=posixpath.splitext(value)[0]+'.dds'
    path=editor.resolve_resource(value,owner)
    if path and path.lower().endswith('.dds'):result[str((Path('/gabriel/mod')/path).resolve())]=role
 return result

def array_images(raw,source):
 """Use our Pillow 11 DXGI aliases, with the same layer stride/orientation as V18."""
 fmt,unit=rules().dds_array_format(source);w,h=source['width'],source['height'];stride=sum(rules().dds_level_size(max(1,w>>i),max(1,h>>i),fmt,unit) for i in range(source['mips']));size=rules().dds_level_size(w,h,fmt,unit);images=[];Image=image_module()
 try:
  for layer in range(source['array_size']):
   head=bytearray(raw[:148]);struct.pack_into('<I',head,28,1);struct.pack_into('<I',head,140,1);off=148+layer*stride;one=bytes(head)+raw[off:off+size]
   with level_image(one,header_2d(one)) as image:images.append(image.transpose(Image.Transpose.FLIP_TOP_BOTTOM))
  return images
 except Exception:
  for image in images:image.close()
  raise

def convert(raw,path,max_size=0,roles=None,quality='medium',preserve_profiles=True,progress=None):
 v18=rules();info=header(raw);source=dict(data=raw,width=info['width'],height=info['height'],mips=info['mipmaps'],fourcc=raw[84:88],header_size=info['start'])
 if info.get('layers'):
  source.update(dxgi=struct.unpack_from('<I',raw,128)[0],resource_dimension=3,array_size=info['layers'])
  if info['effect']:
   ast=v18.convert_fs23_effect_array_dds(raw)
   # Experimental V18 layout: payload equality alone does not prove game compatibility.
   note='Array RGBA16F experimental do V18: DDS preservada para teste no jogo.'
  else:
   images=array_images(raw,source)
   try:
    if max_size and max(images[0].size)>max_size:
     w,h=images[0].size
     while max(w,h)>max_size:w=max(1,w//2);h=max(1,h//2)
     resized=[]
     for image in images:resized.append(v18.resize_preserve_rgba_rgb(image,(w,h)));image.close()
     images=resized;info.update(width=w,height=h)
    ast=v18.make_gs2d_array(raw,images);v18.verify_gs2d_array(ast,info['width'],info['height'],info['layers'])
   finally:
    for image in images:image.close()
   note='Array V18 de '+str(info['layers'])+' camadas; exporta o mip principal, como no script.'
  return ast,dict(width=info['width'],height=info['height'],mipmaps=1,layers=info['layers'],encoding='GS2D array V18',sourceFormat=info['format'],note=note,preserveDDS=info['effect'])
 from astc_native import encode_image
 native=header_2d(raw);level=0
 if max_size and max(native['width'],native['height'])>4096:
  level=next((i for i,(w,h,_,_) in enumerate(native['levels']) if max(w,h)<=4096),0)
 base=level_image(raw,native,level);virtual=Path('/gabriel/mod')/path
 v18.I3D_TERRAIN_LAYER_TEXTURES.clear();v18.I3D_TERRAIN_LAYER_TEXTURES.update(roles or {})
 try:
  settings=v18.choose_settings(virtual,base,source)
  # Respect fixed map/native profiles so every terrain array layer still matches.
  if max_size and (not preserve_profiles or not settings['catalog_match'] and not settings['i3d_terrain_role'] and settings['class'].startswith(('GENERIC','UI_','MAP_PREVIEW','FOLIAGE_GENERIC'))):
   while max(settings['target_width'],settings['target_height'])>max_size:
    settings['target_width']=max(1,settings['target_width']//2);settings['target_height']=max(1,settings['target_height']//2)
   settings['mip_count']=min(settings['mip_count'],v18.full_fs23_mip_count(settings['target_width'],settings['target_height']))
  base,note=v18.repair_terrain_distance_base(virtual,base,settings)
  mips=v18.build_fs23_mips(base,settings)
  try:
   encoded=[]
   for i,m in enumerate(mips):
    if progress:progress(i,len(mips))
    encoded.append(encode_image(m['image'],settings['srgb'],quality))
   if progress:progress(len(mips),len(mips))
  finally:
   for m in mips:m['image'].close()
  w,h=settings['target_width'],settings['target_height'];ast=v18.make_gs2d(raw,w,h,settings['components'],settings['profile'],encoded)
  v18.verify_gs2d_2d(ast,w,h,len(encoded),settings['components'],settings['profile'])
  from ast_texture import decode
  decode(ast)
  return ast,dict(width=w,height=h,mipmaps=len(encoded),encoding='GS2D ASTC 6x6 V18',sourceFormat=info['format'],textureClass=settings['class'],note=note)
 finally:base.close();v18.I3D_TERRAIN_LAYER_TEXTURES.clear()

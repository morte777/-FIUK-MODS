-- Gabriel Mods V1.13. This file belongs to the converted mod.
-- Creates only the generated types below; never edits a native type or dataS.
local definitions = __GM_DEFINITIONS__
local function copy(source)
    local target = {}
    for k, value in pairs(source or {}) do target[k] = value end
    return target
end
local function clone(base, name)
    local target = copy(base)
    target.name = name
    target.parent = base
    target.customEnvironment = ""
    target.specializations = copy(base.specializations)
    target.specializationNames = copy(base.specializationNames)
    target.specializationsByName = copy(base.specializationsByName)
    target.functions = copy(base.functions)
    target.events = copy(base.events)
    target.eventListeners = {}
    for event, listeners in pairs(base.eventListeners or {}) do
        target.eventListeners[event] = copy(listeners)
    end
    target.__fs22CompatAlias = nil
    return target
end
local warned = {}
local function warning(key, message)
    if not warned[key] then
        warned[key] = true
        print("[Gabriel Mods V1.13] " .. message)
    end
end
local function install()
    local manager = g_vehicleTypeManager
    if manager == nil or manager.types == nil then return false end
    local complete = true
    for _, definition in ipairs(definitions) do
        local current = manager.types[definition.name]
        if current == nil or current.__fs22CompatAlias == true then
            local base = manager.types[definition.base]
            if base == nil or base.functions == nil or next(base.functions) == nil then
                complete = false
            elseif (base.specializationsByName or {}).motorized ~= nil
                or (base.specializationsByName or {}).enterable ~= nil
                or (base.specializationsByName or {}).drivable ~= nil then
                warning(definition.name, "base insegura recusada: " .. definition.base)
                complete = false
            else
                local target = clone(base, definition.name)
                local added = {}
                local valid, reason = pcall(function()
                    -- Resolve all candidates before evaluating their prerequisites.
                    for _, specName in ipairs(definition.specs) do
                        if target.specializationsByName[specName] == nil then
                            local spec = g_specializationManager and g_specializationManager:getSpecializationObjectByName(specName)
                            assert(spec ~= nil, "especializacao indisponivel: " .. specName)
                            target.specializations[#target.specializations + 1] = spec
                            target.specializationNames[#target.specializationNames + 1] = specName
                            target.specializationsByName[specName] = spec
                            added[#added + 1] = spec
                        end
                    end
                    for _, spec in ipairs(added) do
                        assert(spec.prerequisitesPresent == nil or spec.prerequisitesPresent(target.specializations), "pre-requisito ausente")
                    end
                    for _, phase in ipairs({"registerEvents", "registerFunctions", "registerOverwrittenFunctions", "registerEventListeners"}) do
                        for _, spec in ipairs(added) do
                            if spec[phase] ~= nil then spec[phase](target) end
                        end
                    end
                end)
                if not valid then
                    -- Keep the implement loadable without inventing engine data.
                    -- Its original XML/specializations remain in modDesc for review.
                    target = clone(base, definition.name)
                    warning(definition.name .. ":specs", "implemento com funcoes adicionais pendentes: " .. tostring(reason))
                end
                target.__gmAttachableType = definition.name
                manager.types[definition.name] = target
                print("[Gabriel Mods V1.13] " .. definition.name .. " -> " .. definition.base .. "; sem motor/cameras artificiais")
            end
        elseif current.__gmAttachableType ~= definition.name then
            -- A correctly registered declarative mod type takes priority.
            local specs = current.specializationsByName or {}
            if specs.motorized ~= nil or specs.drivable ~= nil or specs.enterable ~= nil then
                warning(definition.name .. ":collision", "tipo existente incompativel; nao sobrescrito: " .. definition.name)
                complete = false
            end
        end
    end
    return complete
end
local listener = {}
local shopHooked, loadingHooked = false, false
local function hooks()
    if not shopHooked and ShopConfigScreen ~= nil and ShopConfigScreen.loadCurrentConfiguration ~= nil then
        local previous = ShopConfigScreen.loadCurrentConfiguration
        ShopConfigScreen.loadCurrentConfiguration = function(self, ...)
            install()
            return previous(self, ...)
        end
        shopHooked = true
    end
    if not loadingHooked and VehicleLoadingUtil ~= nil and VehicleLoadingUtil.loadVehicle ~= nil then
        local previous = VehicleLoadingUtil.loadVehicle
        VehicleLoadingUtil.loadVehicle = function(...)
            install()
            return previous(...)
        end
        loadingHooked = true
    end
end
function listener:loadMap()
    hooks()
    install()
end
function listener:update()
    -- Definitions are rebuilt on a later map if the manager has been recreated.
    hooks()
    install()
end
hooks()
if addModEventListener ~= nil then addModEventListener(listener) end

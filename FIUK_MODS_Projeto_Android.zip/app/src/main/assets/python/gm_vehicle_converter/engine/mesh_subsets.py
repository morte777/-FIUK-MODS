"""Validate subset bounds; recover only an unambiguous vertex start offset."""
import struct
from . import shapes_codec as codec
def validate_subsets(data, shape, context, report):
    vertices, corners = shape['vertexCount'], shape['cornerCount']
    b = codec.Blob(data)
    size = b.u32(); b.take(size); b.align(); b.take(20+16)
    start = b.p
    stride = 16 + 4*sum(bool(shape['options'] & bit) for bit in (2,4,8,16))
    plans = []
    for number, subset in enumerate(shape['subsets']):
        first, count = subset['firstIndex'], subset['numIndices']
        label = f'{context}: malha {shape["shapeId"]} ({shape["name"]}), subconjunto {number+1}'
        if first+count > corners or first % 3 or count % 3:
            raise ValueError(label+': intervalo de índices inválido; arquivo preservado.')
        if subset['firstVertex']+subset['numVertices'] <= vertices:
            continue
        if count == 0 or subset['numVertices'] == 0:
            raise ValueError(label+': subconjunto sem triângulos/vértices para reconstruir o intervalo.')
        triangles = shape['triangles'][first//3:(first+count)//3]
        lower = min(min(t) for t in triangles)
        upper = max(max(t) for t in triangles)
        # Preserve count and index/material boundaries. Never trim a triangle,
        # expand a buffer, guess a missing vertex or repair ambiguous metadata.
        if lower < 0 or upper >= vertices or upper-lower+1 != subset['numVertices']:
            raise ValueError(label+': intervalo de vértices não pode ser reconstruído sem ambiguidade.')
        plans.append((number, subset['firstVertex'], lower, upper))
    if not plans: return data
    result = bytearray(data)
    records = []
    for number, old, lower, upper in plans:
        offset = start + number*stride
        struct.pack_into('<I', result, offset, lower)
        records.append({'arquivo':context,'shapeId':shape['shapeId'],'malha':shape['name'],'subconjunto':number+1,'firstVertex_original':old,'firstVertex_corrigido':lower,'numVertices':upper-lower+1,'motivo':'Intervalo exato dos índices válidos reproduz a contagem de vértices original. Apenas firstVertex corrigido.'})
    # Prove the precise byte delta: only the planned firstVertex words changed.
    restored = bytearray(result)
    for number, old, _, _ in plans: struct.pack_into('<I', restored, start+number*stride, old)
    assert bytes(restored) == data
    report.setdefault('subconjuntos_corrigidos', []).extend(records)
    return bytes(result)

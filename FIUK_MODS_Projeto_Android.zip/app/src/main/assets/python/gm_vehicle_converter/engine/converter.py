"""Gabriel Mods: experimental vehicle/implement conversion; no game scripts executed."""
from pathlib import Path, PurePosixPath
import json, math, os, re, shutil, stat, struct, zipfile
import xml.etree.ElementTree as E
from . import shapes_codec as codec
from .lights import port_valtra
from .auto_lights import port_general
from .windows import port_windows
from .node_audit import audit_nodes
from .colors import port_colors,port_rim_colors
from .vehicle_types import port_attachable_types
from .mesh_subsets import validate_subsets
from .load_compat import random_parts,pto_aliases,fs23_optional_resources
try:
 from .fast_cipher import process
 codec.process=process
 FAST=True
except ImportError:
 FAST=False
ASSETS=Path(__file__).resolve().parents[1]/'assets'
XSI='{http://www.w3.org/2001/XMLSchema-instance}noNamespaceSchemaLocation'
E.register_namespace('xsi','http://www.w3.org/2001/XMLSchema-instance')
CATALOG=json.loads((ASSETS/'wheels_catalog.json').read_text())
COMPAT_SHADER=E.parse(ASSETS/'vehicleShaderCompat.xml')
COMPAT_VARIATIONS={e.get('name') for e in COMPAT_SHADER.findall('.//Variation')}
COMPAT_MAPS=(('mArraySpecular','detailArray_specular.png'),('mArrayNormal','detailArray_normal.png'),('mArrayDiffuse','detailArray_diffuse.png'),('mPixelsDiffuse','detailArrayPixels_diffuse.png'),('mPixelsSpecular','detailArrayPixels_specular.png'))
class Unsupported(Exception):pass

def read_xml(p):
 raw=p.read_bytes()
 if b'<!DOCTYPE' in raw.upper() or b'<!ENTITY' in raw.upper():raise ValueError('XML com DTD/entidade não suportado: '+p.name)
 return E.ElementTree(E.fromstring(raw))
def save(t,p):
 E.indent(t,space='  ');t.write(p,encoding='utf-8',xml_declaration=True)
def safe_extract(archive,dst):
 with zipfile.ZipFile(archive) as z:
  infos=z.infolist()
  if len(infos)>60000 or sum(i.file_size for i in infos)>3*1024**3:raise ValueError('ZIP excede 60 mil arquivos ou 3 GB descompactados.')
  seen=set()
  for i in infos:
   path=PurePosixPath(i.filename.replace('\\','/'))
   if path.is_absolute() or '..' in path.parts or ':' in str(path) or '\x00' in str(path):raise ValueError('Caminho inválido no ZIP.')
   if stat.S_ISLNK(i.external_attr>>16):raise ValueError('Links simbólicos não são aceitos.')
   name=str(path)
   if name in seen and not i.is_dir():raise ValueError('Arquivo duplicado no ZIP: '+name)
   seen.add(name)
   out=dst.joinpath(*path.parts)
   if i.is_dir():out.mkdir(parents=True,exist_ok=True);continue
   out.parent.mkdir(parents=True,exist_ok=True)
   with z.open(i) as src,out.open('wb') as dest:shutil.copyfileobj(src,dest,1024*1024)

def upgrade_v5_mesh(data,editor_uv=False):
 # v5 has no subset UV densities. Both v5 and v7 store U,V pairs.
 # Preserve all remaining vertex/skin/attachment bytes, including unknown payloads.
 b=codec.Blob(data);n=b.u32()
 if n>65535:raise Unsupported('Nome de malha v5 excede limite.')
 b.take(n);b.align();b.take(4+16)
 corners=b.u32();subsets=b.u32();vertices=b.u32();options=b.u32();head=b.p
 if subsets>65535 or vertices>5000000 or corners>30000000 or corners%3:raise Unsupported('Contagem v5 excede limites ou é inválida.')
 # Metadata bit 24 occurs in FS19 shadow-focus meshes without extra payload.
 # Preserve it; full consumption and field-by-field validation remain required.
 if options&~(codec.OPT_ALL|0x01000000):raise Unsupported('Flags adicionais de shapes v5 exigem revisão.')
 sh=codec.parse_shape(data,5)
 if not sh['consumed_all']:raise Unsupported('Shapes v5 com dados adicionais não interpretados.')
 counts=[b.take(16) for _ in range(subsets)];indices_start=b.p
 b.take(corners*(4 if vertices>65536 else 2));b.align();vertices_start=b.p
 prefix_size=vertices*(12+(12 if options&1 else 0)+(16 if options&128 else 0))
 uv_start=vertices_start+prefix_size
 # A neutral density is needed by the v7 layout; UV values themselves are exact.
 uv_count=sum(bool(options&bit) for bit in (2,4,8,16))
 result=bytearray(data[:head])
 for counts_entry in counts:result.extend(counts_entry);result.extend(struct.pack('<f',1.)*uv_count)
 # Preserve all vertex payload bytes, including each UV set. The optional
 # editor_uv argument stays accepted for existing callers; no swap is needed.
 result.extend(data[indices_start:]);converted=bytes(result)
 new=codec.parse_shape(converted,7)
 if not new['consumed_all']:raise ValueError('Shapes v5 convertido com dados restantes.')
 if new['uvsets']!=sh['uvsets']:raise ValueError('Mudança inesperada nas coordenadas UV v5.')
 for key in ('shapeId','boundingVolume','cornerCount','vertexCount','options','triangles','positions','normals','tangents','vertexColor','generic','attachments'):
  if sh[key]!=new[key]:raise ValueError('Mudança inesperada no campo v5: '+key)
 return converted

def source_xml_notes(root,report):
 paths=list(root.rglob('*.xml'))+list(root.rglob('*.i3d'));notes=set();references=set()
 for path in paths:
  raw=path.read_bytes()
  if path.suffix=='.xml' and not raw.lstrip(b'\xef\xbb\xbf \t\r\n').startswith(b'<'):
   notes.add(path.resolve());continue
  tree=read_xml(path)
  for e in tree.iter():
   values=[e.get(k) for k in ('file','filename','xmlFilename','externalShapesFile') if e.get(k)]
   if e.tag in ('filename','xmlFilename') and e.text:values.append(e.text.strip())
   for value in values:
    if not value.startswith('$'):
     references.add((path.parent/value).resolve());references.add((root/value).resolve())
 for note in sorted(notes):
  if note in references:raise Unsupported('Arquivo referenciado não é XML válido: '+str(note.relative_to(root.resolve())))
  name=str(note.relative_to(root.resolve()));report.setdefault('anotacoes_xml',[]).append(name)
  report['pendencias'].append('Arquivo de anotação sem estrutura XML, não referenciado, preservado sem processamento: '+name)
 return notes

def convert_shapes(path,report,notify):
 raw=path.read_bytes()
 if len(raw)<4:raise ValueError('Shapes vazio: '+path.name)
 version=raw[0]
 if version==7:return
 if version not in (5,10):raise Unsupported(f'{path.name}: shapes v{version} ainda não suportado; arquivo original preservado na entrada.')
 if len(raw)>256*1024**2:raise Unsupported('Shapes maior que 256 MB: limite da primeira versão para celular.')
 ver,seed,entities=codec.decode_entities(str(path));out=[]
 for number,(kind,data) in enumerate(entities):
  if kind!=1:raise Unsupported(f'{path.name}: entidade tipo {kind} não validada nesta versão.')
  if version==5:
   editor_uv=any(folder in path.parts or (path.parent/folder).is_dir() for folder in ('gabriel_criados','gabriel_plotagens','gabriel_acessorios'))
   converted=upgrade_v5_mesh(data,editor_uv=editor_uv)
   sh=codec.parse_shape(converted,7);vertices=sh['vertexCount'];corners=sh['cornerCount']
  else:
   converted=None
  b=codec.Blob(data);n=b.u32()
  if n>65535:raise ValueError('Nome de malha inválido.')
  if version==10:
   b.take(n);b.align();b.take(4+16);corners=b.u32();subsets=b.u32();vertices=b.u32();options=b.u32();head=b.p
   if subsets>65535 or vertices>5000000 or corners>30000000:raise ValueError('Contagem de geometria inválida.')
   if b.u32()!=0:raise Unsupported('Campo adicional FS25 não reconhecido; conversão interrompida.')
   start=b.p
   b.take(subsets*(16+4*sum(bool(options&bit) for bit in (2,4,8,16))));end=b.p
   for _ in range(subsets):b.take(b.u16())
   b.align()
   converted=data[:head]+data[start:end]+data[b.p:]
  sh=codec.parse_shape(converted,7)
  if not sh['consumed_all']:raise ValueError('A malha contém dados não interpretados: '+sh['name'])
  if not all(0<=i<vertices for tri in sh['triangles'] for i in tri):raise ValueError('Índice de triângulo inválido.')
  converted=validate_subsets(converted,sh,path.name,report)
  out.append((kind,converted));notify(f'Malhas: {path.name} • {number+1}/{len(entities)}')
 data=codec.encode_entities(7,seed,out);temp=path.with_suffix(path.suffix+'.tmp');temp.write_bytes(data)
 v,s,check=codec.decode_entities(str(temp))
 if v!=7 or s!=seed or check!=out:raise ValueError('Verificação de reabertura dos shapes falhou.')
 temp.replace(path);report['malhas']+=len(entities);report['shapes_convertidos']+=1
 if version==5:
  report['shapes_v5_convertidos']=report.get('shapes_v5_convertidos',0)+1
  report.setdefault('ajustes',[]).append(path.name+': shapes v5 → v7; UVs, geometria e demais atributos verificados. Densidade UV usa valor neutro 1; conferir mipmaps da peça no jogo.')

class Adapter:
 def __init__(self,root,report):self.root=root;self.report=report;self.ignored_xml=set();self.shader_formats={};self.shader_definitions={}
 def warn(self,s):
  if s not in self.report['pendencias']:self.report['pendencias'].append(s)
 def material(self,path):
  tree=read_xml(path);r=tree.getroot();files=r.find('Files');materials=r.find('Materials')
  if files is None or materials is None:return
  from .fs19 import material_resources
  material_resources(self.root,path,files,self.report)
  for item in files:
   value=item.get('filename','').replace('\\','/')
   if not value.startswith('$') and '..' in Path(value).parts and Path(value).suffix.lower() in ('.dds','.png') and not (path.parent/value).is_file():
    expected={Path(value).name}
    if Path(value).suffix.lower()=='.png':expected.add(Path(value).stem+'.dds')
    candidates=[p for p in self.root.rglob('*') if p.is_file() and p.name in expected]
    if len(candidates)==1:
     with candidates[0].open('rb') as check:header=check.read(4)
     if header in (b'DDS ',b'\x89PNG'):
      corrected=os.path.relpath(candidates[0],path.parent).replace(os.sep,'/')
      item.set('filename',corrected)
      self.report.setdefault('texturas_referencias_corrigidas',[]).append({'modelo':str(path.relative_to(self.root)),'antes':value,'depois':corrected,'motivo':'Caminho de exportação externo; arquivo de mesmo nome único confirmado dentro do mod.'})
      value=corrected
   if value.startswith('$') or not value.lower().endswith('.png'):continue
   source=path.parent/value;replacement=source.with_suffix('.dds')
   if source.is_file() or source.with_suffix('.ast').is_file() or not replacement.is_file():continue
   with replacement.open('rb') as check:header=check.read(4)
   if header!=b'DDS ':continue
   corrected=value[:-4]+'.dds';item.set('filename',corrected)
   self.report.setdefault('texturas_referencias_corrigidas',[]).append({'modelo':str(path.relative_to(self.root)),'antes':value,'depois':corrected})
   self.warn('Referência PNG ausente corrigida para DDS existente: '+value+' → '+corrected)
  refs={x.get('fileId'):x.get('filename','') for x in files};maximum=max([int(v) for v in refs if v and v.isdigit()]+[0]);changes=0
  prefix=os.path.relpath(self.root,path.parent).replace(os.sep,'/');prefix='' if prefix=='.' else prefix+'/'
  def fid(resource):
   nonlocal maximum
   for i,f in refs.items():
    if f==resource:return i
   maximum+=1;i=str(maximum);refs[i]=resource;E.SubElement(files,'File',fileId=i,filename=resource);return i
  for m in materials:
   shader=refs.get(m.get('customShaderId'),'')
   if not shader:continue
   if Path(shader.replace('\\','/')).name.lower()=='vehicleshadercompat.xml':continue
   if Path(shader.replace('\\','/')).name.lower()!='vehicleshader.xml':
    self.warn('Shader próprio mantido e requer revisão: '+shader);continue
   params={e.get('name'):e.get('value') for e in m.findall('CustomParameter')}
   legacy=False
   if not shader.startswith('$'):
    shaderpath=(path.parent/shader).resolve()
    if shaderpath not in self.shader_formats:
     if shaderpath.is_file():
      shader_tree=read_xml(shaderpath);self.shader_definitions[shaderpath]=shader_tree;parameter_names={e.get('name') for e in shader_tree.findall('Parameters/Parameter')}
      self.shader_formats[shaderpath]='colorMat' in parameter_names and 'lightIds0' not in parameter_names
     else:self.shader_formats[shaderpath]=False
    legacy=self.shader_formats[shaderpath]
   legacy=legacy or self.report.get('origem')=='FS19' or ('colorScale' not in params and (any(k.startswith('colorMat') for k in params) or m.get('customShaderVariation') in ('colorMask','Decal','tirePressureDeformation')))
   # FS25 detailLibrary/custom maps can coexist with the old variation name.
   modern_details=any(m.find("Custommap[@name='"+key+"']") is not None for key in ('detailDiffuse','detailNormal','detailSpecular'))
   modern_details=modern_details or any(refs.get(e.get('fileId'),'').startswith('$data/shared/detailLibrary/') for e in m if e.tag=='Texture')
   if modern_details:legacy=False
   if legacy:
    self.report['materiais_legados_preservados']=self.report.get('materiais_legados_preservados',0)+1
    if not shader.startswith('$') or self.report.get('origem')=='FS19':
     variation=m.get('customShaderVariation')
     if variation and variation not in COMPAT_VARIATIONS:
      self.warn('Variação do shader legado sem equivalente compatível; revisão necessária: '+shader+' / '+variation);continue
     m.set('customShaderId',fid(prefix+'gm_compat/vehicleShaderCompat.xml'))
     for key,filename in COMPAT_MAPS:
      if m.find("Custommap[@name='"+key+"']") is None:E.SubElement(m,'Custommap',name=key,fileId=fid('$data/shared/'+filename))
     source_shader=self.shader_definitions.get((path.parent/shader).resolve()) if not shader.startswith('$') else None
     if source_shader is not None:
      defaults={e.get('index'):[float(v) for v in e.text.split()] for e in COMPAT_SHADER.findall("Parameters/Parameter[@name='colorMat']/Default")}
      for e in source_shader.findall("Parameters/Parameter[@name='colorMat']/Default"):
       key='colorMat'+e.get('index','')
       if [float(v) for v in e.text.split()]!=defaults.get(e.get('index')) and m.find("CustomParameter[@name='"+key+"']") is None:
        E.SubElement(m,'CustomParameter',name=key,value=e.text.strip())
     oldparam=m.find("CustomParameter[@name='scratches_dirt_snow_wetness']")
     if oldparam is not None and m.find("CustomParameter[@name='RDT']") is None:oldparam.set('name','RDT')
     changes+=1
     self.report['shaders_legados_adaptados']=self.report.get('shaders_legados_adaptados',0)+1
    continue # Retain native color masks, light controls, decals and tire deformation.

   name=m.get('name','');lower=name.lower();oldvar=m.get('customShaderVariation','');decal=oldvar=='vmaskUV2' or 'decal' in lower;light=oldvar=='staticLight'
   m.set('customShaderId',fid(prefix+'gm_compat/vehicleShaderCompat.xml'))
   m.set('customShaderVariation','convertedFS25Decal' if decal else 'convertedFS25Light' if light else 'convertedFS25')
   m.set('diffuseColor','1 1 1 1');m.set('specularColor','1 1 1')
   for e in list(m):
    if e.tag in ('Custommap','CustomParameter'):m.remove(e)
    elif e.get('fileId') and refs.get(e.get('fileId'),'').startswith('$'):
     if e.tag=='Texture':e.set('fileId',fid(prefix+'gm_compat/'+('glass.png' if m.get('alphaBlending')=='true' else 'white.png')))
     elif e.tag in ('Normalmap','Glossmap'):m.remove(e)
   if m.find('Texture') is None:E.SubElement(m,'Texture',fileId=fid(prefix+'gm_compat/white.png'))
   if m.find('Glossmap') is None:E.SubElement(m,'Glossmap',fileId=fid(prefix+'gm_compat/neutral_vmask.dds'))
   if decal:m.set('alphaBlending','true')
   color=params.get('colorScale','1 1 1')
   if len(color.split())!=3:raise Unsupported('colorScale não reconhecido em '+name)
   if decal:color='1 1 1'
   if 'rubber' in lower and color=='1 1 1':color='0.015 0.015 0.015'
   smooth=min(.95,max(.08,float(params.get('smoothnessScale','.65'))))
   metal=1 if any(w in lower for w in ('chrome','cromado','chromado','silverscratched')) else .85 if 'castiron' in lower else .05
   if any(w in lower for w in ('rubber','fabric','plastic','glass','lona')):metal=0
   E.SubElement(m,'CustomParameter',name='convertedColor',value=color+' 1')
   E.SubElement(m,'CustomParameter',name='convertedSurface',value=f'{smooth} 1 {metal} 0')
   E.SubElement(m,'CustomParameter',name='RDT',value='0 0 0 0')
   if light:
    emission='1 0.9 0.65' if 'workinglight' in lower or 'clearglass' in lower else '1 0.05 0.01'
    E.SubElement(m,'CustomParameter',name='convertedEmission',value=emission+' 0');E.SubElement(m,'CustomParameter',name='lightControl',value='0')
   for key,filename in COMPAT_MAPS:E.SubElement(m,'Custommap',name=key,fileId=fid('$data/shared/'+filename))
   changes+=1
  if changes:
   folder=self.root/'gm_compat';folder.mkdir(exist_ok=True)
   for name in ('vehicleShaderCompat.xml','white.png','glass.png','neutral_vmask.dds'):
    # Existing FS23 AST was already encoded; do not add its obsolete DDS sibling.
    if self.report.get('destino')=='FS23' and name.endswith('.dds') and (folder/Path(name).with_suffix('.ast')).is_file():continue
    shutil.copyfile(ASSETS/name,folder/name)
   # Drop only unreferenced entries in Files, including obsolete FS25 detailLibrary paths.
   used={e.get('fileId') for m in materials for e in m.iter() if e.get('fileId')}
   used.update(m.get('customShaderId') for m in materials if m.get('customShaderId'))
   # File ids can also be referenced by scene/spline/user-attribute nodes.
   for section in r:
    if section.tag not in ('Files','Materials'):
     for e in section.iter():
      for a,v in e.attrib.items():
       if a.lower().endswith('fileid'):used.add(v)
   for f in list(files):
    if f.get('fileId') not in used:files.remove(f)
   self.report['materiais']+=changes
  # Translate only the known FS25 vehicle collision preset; unknown masks stay pending.
  for node in r.findall('.//*[@collisionFilterGroup]'):
   group=int(node.get('collisionFilterGroup'),0);mask=int(node.get('collisionFilterMask','0'),0)
   if group==0x10004:
    node.set('collisionMask',str(8194|((1<<21) if node.get('dynamic')=='true' else 0)))
   elif node.get('trigger')=='true' and mask==0x40000000:node.set('collisionMask',str(1<<30))
   else:
    continue # May be resolved by vehicle XML mappings later.
   node.attrib.pop('collisionFilterGroup',None);node.attrib.pop('collisionFilterMask',None)
  save(tree,path)
 def wheel(self,path,tree):
  r=tree.getroot()
  # Per-size FS25 mesh paths also occur inside optional/dual configurations.
  for tire in r.findall('.//tire'):
   filename=tire.get('filename','').replace('\\','/')
   if filename.startswith('$data/shared/wheels/tires/') and re.search(r'/\d+_\d+R[^/]+\.i3d$',filename):
    entry=CATALOG.get(filename[:-4]+'.xml')
    if entry:
     if tire is r.find('default/tire'):
      tire.attrib.clear();tire.attrib.update(entry['tire'])
      phys=r.find('default/physics')
      if phys is not None:phys.attrib.update(entry['physics'])
     else:
      # Retain custom offsets, sizing and author options; replace the native
      # model/node selection and deformation values from the exact size entry.
      tire.attrib.update(entry['tire'])
     self.report['pneus']+=1
     self.report.setdefault('pneus_modelos_adaptados',[]).append({'xml':str(path.relative_to(self.root)),'antes':filename,'depois':entry['tire']['filename'],'opcional':tire is not r.find('default/tire')})
    else:self.warn('Pneu sem correspondência no catálogo enviado: '+filename)
   tire.attrib.pop('hasMudMesh',None)
 def audio(self,path,tree):
  if self.report.get('origem')=='FS19':
   from .fs19 import audio,motor_audio
   audio(self.root,path,tree,self.report)
   motor_audio(self.root,path,tree,self.report)
  if self.report.get('destino')!='FS23':return
  absent={'wiper1','wiper2','rainInVehicle','transmissionModern_02','indoorCabinRumble','waterSplash01','switch01','switchTurnlight','hydraulicOpen01','hydraulicOpen03','hydraulicClose01','hydraulicClose02','vibratingImp','attach01','honkFendt511C'}
  for e in tree.iter():
   template=e.get('template')
   if template in absent:
    self.warn('Som pendente em '+str(path.relative_to(self.root))+': template '+template+' ausente no FS23 do log fornecido. Preservado para substituição com recurso nativo.')
   for key in ('file','filename'):
    value=e.get(key,'').replace('\\','/')
    if value=='$data/vehicles/fendt/vario200/sounds/vario200_loop.gls':
     self.warn('MOTOR SEM RECURSO CONFIRMADO: '+value+' não existe no FS23 do log. Não removido nem substituído por caminho presumido. É necessário fornecer um perfil de áudio nativo com seus arquivos.')
 def vehicle(self,path,tree,parents):
  r=tree.getroot();typ=r.get('type')
  random_parts(r,self.report,str(path.relative_to(self.root)))
  if self.report.get('destino')=='FS23':fs23_optional_resources(r,self.report,str(path.relative_to(self.root)))
  if self.report.get('destino')=='FS23':
   suspension=r.find('suspensions')
   if suspension is not None:
    self.report['suspensoes_cabine_removidas']=self.report.get('suspensoes_cabine_removidas',0)+len(suspension)
    r.remove(suspension)
   for camera in r.findall('.//camera'):
    if 'suspensionNodeIndex' in camera.attrib:
     camera.attrib.pop('suspensionNodeIndex')
     self.report['cameras_ajustadas']=self.report.get('cameras_ajustadas',0)+1

  if typ in parents:r.set('type',parents[typ])
  name=r.find('storeData/name')
  if name is not None and len(name):
   text=name.findtext('pt') or name.findtext('br') or name.findtext('en') or next(iter(name)).text or path.stem
   name.clear();name.text=text
  r.set(XSI,'https://validation.gdn.giants-software.com/xml/fs22/vehicle.xsd')
  if r.get('type')=='augerWagon':
   for key,value in [('storeData/functions/function','$l10n_function_augerWagon'),('base/typeDesc','$l10n_typeDesc_augerWagon')]:
    e=r.find(key)
    if e is not None:e.text=value
  for e in r.findall('base/components/component'):e.attrib.pop('inertiaScale',None)
  for e in r.iter():
   for key in ('visibilityActive','visibilityInactive'):
    if e.get(key) in ('True','False'):
     e.set(key,e.get(key).lower());self.report['booleanos_corrigidos']=self.report.get('booleanos_corrigidos',0)+1
   e.attrib.pop('isYesNoOption',None);e.attrib.pop('useFullCapacity',None)
  for conf in r.findall('attachable/inputAttacherJointConfigurations/inputAttacherJointConfiguration'):
   for e in list(conf):
    if e.tag=='support':conf.remove(e);r.find('attachable').append(e)
    if e.tag=='sounds':conf.remove(e);self.warn('Som de engate FS25 removido de '+path.name)
  for tag in ('highPressureWasher','handToolHolders'):
   e=r.find(tag)
   if e is not None:r.remove(e);self.warn('Lavadora portátil FS25 desativada; tanque apenas decorativo.')
  for parent in r.iter():
   for e in list(parent):
    if e.tag=='dependentConfiguration' and e.get('name') in ('designColor','baseColor','rimColor') and r.find(e.get('name')+'Configurations') is None:parent.remove(e)
  for e in r.findall('animations/animation/sound'):
   if e.get('template') in {'woodDoorOpen','fabricCover1','fabricCover2','hydraulicOpen02'}:e_parent=next(p for p in r.iter() if e in list(p));e_parent.remove(e);self.report['sons_removidos']+=1
  if r.find('simpleIC') is not None:self.warn('SimpleIC em '+path.name+': controles não portados; esta versão não inclui suporte móvel para essa extensão. XML preservado para revisão.')
  ported_lights=False
  model=r.findtext('base/filename')
  if model and not model.startswith('$'):
   modelpath=(path.parent/model)
   if not modelpath.exists():modelpath=self.root/model
   if modelpath.exists():
    mt=read_xml(modelpath);scene=mt.find('Scene');mapping={e.get('id'):e.get('node') for e in r.findall('i3dMappings/i3dMapping')}
    def resolve(value):
     value=mapping.get(value,value)
     if not value:return None
     if '>' not in value:value='0>'+value
     a,b=value.split('>',1);node=scene[int(a)]
     if b:
      for i in b.split('|'):node=node[int(i)]
     return node
    for e in r.findall('.//exactFillRootNode'):
     try:
      node=resolve(e.get('node'))
      if node is not None:node.set('collisionMask',str(int(node.get('collisionMask','0'),0)|(1<<30)));node.attrib.pop('collisionFilterGroup',None);node.attrib.pop('collisionFilterMask',None)
     except (ValueError,IndexError,TypeError):self.warn('exactFillRootNode sem mapeamento válido em '+path.name)
    if scene is not None:
     for node in scene:
      if node.get('dynamic')=='true':node.set('collisionMask',str(int(node.get('collisionMask','0'),0)|(1<<21)))
    # Disable only triggers referenced by the removed handheld-holder section.
    original=read_xml(path)
    for e in original.findall('handToolHolders/handToolHolder/trigger'):
     try:
      node=resolve(e.get('node'))
      if node is not None:
       node.set('trigger','false');node.set('collisionMask','0');node.attrib.pop('collisionFilterGroup',None);node.attrib.pop('collisionFilterMask',None)
     except (ValueError,IndexError,TypeError):pass
    audit_nodes(r,mt,str(path.relative_to(self.root)),self.report)
    port_colors(r,mt,modelpath,self.report)
    port_rim_colors(r,path,self.root,ASSETS,self.report)
    port_windows(r,mt,modelpath,self.report,path)
    ported_lights=port_valtra(r,mt,modelpath,self.report)
    if not ported_lights:ported_lights=bool(port_general(r,mt,modelpath,self.report))
    if ported_lights:
     shader=self.root/'gm_compat/vehicleShaderCompat.xml'
     shader.parent.mkdir(exist_ok=True)
     shutil.copyfile(ASSETS/'vehicleShaderCompat.xml',shader)
     self.warn('Luzes adaptadas: testar faróis, trabalho, lanterna, freio, ré, setas e pisca-alerta no jogo; funcionamento ainda não confirmado no FS23.')
    save(mt,modelpath)
  for e in r.findall('lights/staticLightCompounds'):
   self.report.setdefault('grupos_luzes_originais',[]).append({'arquivo':str(path.relative_to(self.root)),'xml':E.tostring(e,encoding='unicode')})
   if not ported_lights:self.warn('Lentes FS25 sem comandos compatíveis em '+path.name+': consultar luzes_pendentes e configuração original no relatório.')
   r.find('lights').remove(e)
  if self.report.get('aros_pendentes'):self.warn('Há aros que exigem revisão; consultar aros_pendentes. Nenhuma ponte no dataS é exportada.')
  if self.report.get('cores_pendentes'):self.warn('Há configurações de cor pendentes; dados originais preservados em cores_pendentes.')
  if self.report.get('vidros_pendentes'):self.warn('Opcionais de vidro exigem revisão; consulte vidros_pendentes no relatório.')
  if self.report.get('luzes_pendentes'):self.warn('Há luzes que exigem revisão; motivos, nós e XML de origem estão em luzes_pendentes no relatório completo.')
 def references(self):
  for path in list(self.root.rglob('*.xml'))+list(self.root.rglob('*.i3d')):
   if path.resolve() in self.ignored_xml:continue
   tree=read_xml(path)
   for e in tree.iter():
    if e.get('collisionFilterGroup') is not None:self.warn('Máscara de colisão FS25 exige revisão em '+path.name+': '+e.get('name','?'))
    refs=[e.get(a) for a in ('filename','file','xmlFilename','externalShapesFile') if e.get(a)]
    if e.tag in ('filename','image','iconFilename') and e.text:refs.append(e.text.strip())
    for resource in refs:
     if resource.startswith('$'):continue
     if self.report.get('destino')=='FS23' and Path(resource).suffix.lower() in ('.dds','.png'):
      native=[(path.parent/resource).with_suffix('.ast'),(self.root/resource).with_suffix('.ast')]
      if any(p.is_file() and p.open('rb').read(4)==b'GS2D' for p in native):continue
     if not any(p.is_file() for p in (path.parent/resource,self.root/resource)):
      self.warn('Referência local ausente: '+str(path.relative_to(self.root))+' → '+resource)

def convert(archive,work,target,progress=lambda p,m:None):
 report={'versao':'1.19','destino':target,'malhas':0,'shapes_convertidos':0,'materiais':0,'pneus':0,'sons_removidos':0,'pendencias':[],'limites':['Teste real no jogo é necessário.','FS23: texturas DDS → ASTC são uma etapa separada nesta versão.','Detalhes e acabamento dos materiais são aproximações; mapas e scripts complexos não foram portados.']}
 progress(3,'Abrindo o ZIP');tree=work/'extraido';tree.mkdir(parents=True);safe_extract(archive,tree)
 descs=list(tree.rglob('modDesc.xml'))
 if len(descs)!=1:raise Unsupported('Selecione um ZIP de um único mod com modDesc.xml.')
 root=descs[0].parent;desc=read_xml(descs[0]);r=desc.getroot()
 original_desc=int(r.get('descVersion','0'));report['origem']='FS19' if 40<=original_desc<=53 else 'FS25' if original_desc>=90 else 'FS22';report['descVersion_origem']=original_desc
 retired_bridge=root/'GABRIEL_MODS_PONTE_AROS.py'
 if retired_bridge.is_file() and b'GM_RIM_COLOR_BRIDGE_V1' in retired_bridge.read_bytes():
  retired_bridge.unlink()
  report.setdefault('ajustes',[]).append('Instalador de ponte da V1.11 retirado do resultado; V1.12 trabalha somente no mod.')
 previous=root/'GABRIEL_MODS_RELATORIO.json'
 if previous.is_file() and previous.stat().st_size<2*1024**2:
  try:
   old=json.loads(previous.read_text(encoding='utf-8'))
   for key in ('luzes_pendentes','grupos_luzes_originais','luzes_adaptadas','luzes_comandos_originais','vidros_pendentes','vidros_comandos_originais','vidros_opcionais'):
    if isinstance(old.get(key),list):report[key]=old[key]
  except (ValueError,UnicodeError,AttributeError):pass
 if r.find('maps') is not None:raise Unsupported('Conversão de mapas não está disponível na V1. A entrada foi preservada.')
 if report['origem']=='FS19':
  from .fs19 import prepare
  prepare(root,r,report,target)
 port_attachable_types(root,r,report)
 adapter=Adapter(root,report);adapter.ignored_xml=source_xml_notes(root,report);parents={}
 for typ in r.findall('vehicleTypes/type'):
  specs=[s.get('name') for s in typ.findall('specialization')]
  for s in list(typ):
   if s.tag=='specialization' and s.get('name') in ('highPressureWasher','handToolHolder'):typ.remove(s)
  if not typ.findall('specialization') and typ.get('parent'):
   parents[typ.get('name')]=typ.get('parent');r.find('vehicleTypes').remove(typ)
 disabled=set(report.get('scripts_cosmeticos_fs19_desativados',[]))
 if any(e.get('filename')!='gm_compat/attachable_types.lua' for e in r.findall('extraSourceFiles/sourceFile')) or any(p.relative_to(root).as_posix() not in disabled|{'gm_compat/attachable_types.lua'} for p in root.rglob('*.lua')):adapter.warn('Scripts Lua presentes: preservados, sem conversão automática; revisão obrigatória.')
 r.set('descVersion','80');r.set(XSI,'https://validation.gdn.giants-software.com/xml/fs22/modDesc.xsd');save(desc,descs[0])
 shapes=list(root.rglob('*.i3d.shapes'))
 for i,path in enumerate(shapes):
  progress(8+int(42*i/max(len(shapes),1)),'Convertendo '+path.name)
  convert_shapes(path,report,lambda msg:progress(8+int(42*i/max(len(shapes),1)),msg))
 i3ds=list(root.rglob('*.i3d'))
 for i,path in enumerate(i3ds):progress(52+int(12*i/max(len(i3ds),1)),'Adaptando materiais: '+path.name);adapter.material(path)
 xmls=list(root.rglob('*.xml'))
 for i,path in enumerate(xmls):
  if 'gm_compat' in path.parts or path.resolve() in adapter.ignored_xml:continue
  progress(66+int(15*i/max(len(xmls),1)),'Adaptando XML: '+path.name)
  t=read_xml(path)
  adapter.audio(path,t)
  if t.getroot().tag=='vehicle':adapter.vehicle(path,t,parents)
  elif t.getroot().tag=='wheel':adapter.wheel(path,t)
  elif t.getroot().tag=='powerTakeOff':
   model=t.getroot().get('filename','')
   if model and not model.startswith('$'):
    pto_model=root/model
    if not pto_model.is_file():pto_model=path.parent/model
    if pto_model.is_file():pto_aliases(t.getroot(),read_xml(pto_model),report,str(path.relative_to(root)))
  elif t.getroot().tag=='handTool':adapter.warn('Ferramenta de mão FS25 requer revisão: '+str(path.relative_to(root)))
  save(t,path)
 if report.get('trepidacoes_desativadas'):adapter.warn('Trepidacoes decorativas com parametros incompletos desativadas para evitar erro ao carregar; XML original salvo no relatorio.')
 if report.get('cardas_indices_corrigidos'):adapter.warn('Indices nomeados do carda convertidos em caminhos numericos conferidos no I3D.')
 if report.get('recursos_visuais_fs23_desativados'):adapter.warn('Conectores/efeitos visuais ausentes na base FS23 do log desativados; detalhes em recursos_visuais_fs23_desativados.')
 if report['materiais']:adapter.warn('Materiais adaptados com superfície aproximada. Conferir cores, transparência, sujeira e luzes.')
 progress(85,'Conferindo referências');adapter.references()
 (root/'GABRIEL_MODS_RELATORIO.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
 (root/'GABRIEL_MODS_LEIA_ME.txt').write_text('Gabriel Mods V1.19\n\nDestino: '+target+'\n\n'+'\n'.join(report['limites'])+'\n\nPENDÊNCIAS\n'+'\n'.join(report['pendencias']),encoding='utf-8')
 progress(90,'Compactando resultado');out=work/'resultado.zip'
 with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for p in root.rglob('*'):
   if p.is_file():z.write(p,p.relative_to(root))
 with zipfile.ZipFile(out) as z:
  if z.testzip() is not None:raise ValueError('Falha ao conferir o ZIP de saída.')
 progress(100,'Concluído • conferir pendências');return out,report

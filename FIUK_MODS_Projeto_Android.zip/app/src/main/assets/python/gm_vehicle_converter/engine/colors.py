"""Port explicit FS25 color targets to native BaseMaterial configuration channels.

Unknown slots remain in the input and are reported. The Lizard profile is guarded
by node paths, shape names and original material IDs from the supplied original.
No geometry is rebuilt, and shared materials are cloned before recoloring.
"""
import copy,re,shutil
import xml.etree.ElementTree as E

CHANNELS=('baseMaterial','designMaterial','designMaterial2','designMaterial3')
PROFILE={
 'baseColorConfigurations': [('0>0|6|8|0|0','mapeado_Planogroup3','72'),('0>0|6|12|0|1|0','defletor','5')],
 'designColorConfigurations': [('0>0|7|0|0|0|0','parachoque_old','46'),('0>0|7|0|0|1|0','parachoque_new','48'),('0>0|6|8|0|3|6','paralama','7'),('0>0|7|6|0','paralama','7')],
 'designColor2Configurations': [('0>0|6|12|0|8|0','faixa1','76')],
 'designColor3Configurations': [('0>0|6|12|0|8|1','faixa2','77')],
 'designColor4Configurations': [('0>0|6|12|0|8|2','faixa3','76')],
}

def port_colors(vehicle,tree,path,report):
 scene=tree.find('Scene');materials=tree.find('Materials')
 if scene is None or materials is None:return 0
 paths={}
 def walk(n,p):
  paths[p]=n
  for i,c in enumerate(n):walk(c,p+('|' if p.split('>')[1] else '')+str(i))
 for i,n in enumerate(scene):walk(n,str(i)+'>')
 mats={m.get('materialId'):m for m in materials}
 nextid=max([int(k) for k in mats]+[0])+1
 groups=[g for g in list(vehicle) if re.fullmatch(r'(baseColor|designColor\d*)Configurations',g.tag) and g.find('material[@materialSlotName]') is not None]
 profile=path.name.lower()=='113frontal.i3d' and all(p in paths and paths[p].get('name')==name and paths[p].get('materialIds')==mid for entries in PROFILE.values() for p,name,mid in entries)
 count=0
 for group in groups:
  try:
   channel=next((c for c in CHANNELS if vehicle.find(c+'Configurations') is None),None)
   if channel is None:raise ValueError('os quatro canais nativos de BaseMaterial já estão ocupados; requer extensão do jogo para outro seletor independente')
   targets=[]
   if profile and group.tag in PROFILE:targets=[(p,paths[p]) for p,_,_ in PROFILE[group.tag]]
   else:
    for binding in group.findall('material'):
     slot=binding.get('materialSlotName')
     candidates=[m for m in materials if slot in (m.get('name'),m.get('materialSlotName'),m.get('slotName'))]
     if len(candidates)!=1:raise ValueError('slot ausente/ambíguo: '+str(slot))
     mid=candidates[0].get('materialId')
     uses=[(p,n) for p,n in paths.items() if n.tag=='Shape' and mid in n.get('materialIds','').replace(',',' ').split()]
     if not uses or any(n.get('materialIds')!=mid for _,n in uses):raise ValueError('slot não usado ou malha com vários materiais: '+slot)
     targets.extend(uses)
   targets=list({p:n for p,n in targets}.items())
   for _,n in targets:
    m=mats[n.get('materialIds')]
    if m.get('customShaderVariation')!='convertedFS25' or m.find("CustomParameter[@name='convertedColor']") is None:raise ValueError('material não usa a cor uniforme compatível')
   options=[e for e in group if e.tag!='material']
   if any(e.get('materialTemplateName') for e in options):raise ValueError('template de acabamento sem equivalente confirmado')
   original=E.tostring(group,encoding='unicode')
   native=copy.deepcopy(group);native.tag=channel+'Configurations'
   for e in list(native):
    if e.tag=='material':native.remove(e)
    else:e.tag=channel+'Configuration'
   base=vehicle.find('baseMaterial')
   if base is None:base=E.SubElement(vehicle,'baseMaterial')
   bindings=[]
   for nodepath,n in targets:
    m=copy.deepcopy(mats[n.get('materialIds')]);mid=str(nextid);nextid+=1
    name='gm_color_'+mid;m.set('materialId',mid);m.set('name',name);materials.append(m);mats[mid]=m;n.set('materialIds',mid)
    entry=E.SubElement(base,'material',name=name,baseNode=nodepath)
    E.SubElement(entry,'shaderParameter',name='convertedColor',value=m.find("CustomParameter[@name='convertedColor']").get('value'))
    E.SubElement(native,'material',name=name,shaderParameter='convertedColor')
    bindings.append({'node':nodepath,'material':name,'materialId':mid})
   vehicle.insert(list(vehicle).index(group),native);vehicle.remove(group)
   report.setdefault('cores_comandos_originais',[]).append({'xml':original,'modelo':path.name})
   report.setdefault('cores_adaptadas',[]).append({'origem':group.tag,'destino':native.tag,'perfil':'Lizard 113 validado por nós' if profile else 'slot explícito','ligacoes':bindings})
   count+=1
  except (ValueError,KeyError,TypeError) as e:
   report.setdefault('cores_pendentes',[]).append({'modelo':path.name,'configuracao':group.tag,'motivo':str(e)})
 return count

def port_rim_colors(vehicle,vehicle_path,root,assets,report):
 from .native_rims import port_native_rims
 return port_native_rims(vehicle,vehicle_path,root,report)

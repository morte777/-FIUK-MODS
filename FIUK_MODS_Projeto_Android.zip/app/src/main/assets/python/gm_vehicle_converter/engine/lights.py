"""Native light XML and an explicit, geometry-checked Valtra A3F lens profile.

No name-based guesses for other vehicles. New overlay meshes retain source vertex
attributes (including skin data); source entities and indexed scene paths survive.
"""
from pathlib import Path
import copy, struct
import xml.etree.ElementTree as E
from . import shapes_codec as codec
PROFILE = (
 # scene name, material subset, role, RGB, light types, half of local X
 ('lente_frontal', 0, 'head', '1 .9 .72', '0 3', None),
 ('luz_sup_cabine', 0, 'work', '1 .94 .82', '2', None),
 ('proximaHS120LightsGlass_static.002', 0, 'tail', '1 .012 .002', '0', None),
 ('proximaHS120LightsGlass_static.002', 1, 'left', '1 .23 .002', '', 'positive'),
 ('proximaHS120LightsGlass_static.002', 1, 'right', '1 .23 .002', '', 'negative'),
 ('proximaHS120Lights01_static.001', 0, 'reverse', '1 .94 .85', '', None),
)
EXPECTED = {'lente_frontal': ('84', '54 24', 2),
 'luz_sup_cabine': ('17', '57', 1),
 'proximaHS120LightsGlass_static.002': ('19', '64 65', 2),
 'proximaHS120Lights01_static.001': ('18', '68 66 67', 3)}


def selected_mesh(data, shape, subset_index, shape_id, name, side=None, selected_triangles=None):
 """Single-subset v7 mesh; unchanged vertex tail except a small normal offset."""
 sub=shape['subsets'][subset_index]
 triangles=selected_triangles if selected_triangles is not None else shape['triangles'][sub['firstIndex']//3:(sub['firstIndex']+sub['numIndices'])//3]
 if side:
  xs=[shape['positions'][i][0] for tri in triangles for i in tri]
  mid=(min(xs)+max(xs))/2
  # Require disjoint lens clusters; never cut triangles across the center.
  if any(min(shape['positions'][i][0] for i in t)<mid<max(shape['positions'][i][0] for i in t) for t in triangles):
   raise ValueError('Lentes de seta atravessam a divisão lateral; perfil recusado.')
  triangles=[t for t in triangles if (sum(shape['positions'][i][0] for i in t)/3>mid)==(side=='positive')]
 if not triangles:raise ValueError('Subconjunto de luz vazio.')
 b=codec.Blob(data);b.take(b.u32());b.align();b.take(4+16+16)
 b.take(shape['numSubsets']*(16+4*len(sub['densities'])))
 b.take(shape['cornerCount']*(4 if shape['vertexCount']>65536 else 2));b.align()
 tail=bytearray(data[b.p:])
 # Overlay sits 0.25 mm above the original lens, avoiding coplanar flicker.
 if shape['normals']:
  for i,(p,n) in enumerate(zip(shape['positions'],shape['normals'])):
   struct.pack_into('<3f',tail,i*12,*(p[j]+n[j]*.00025 for j in range(3)))
 w=codec.BlobWriter();encoded=name.encode('ascii');w.u32(len(encoded));w.raw(encoded);w.align();w.u32(shape_id)
 for f in shape['boundingVolume']:w.f32(f)
 w.u32(len(triangles)*3);w.u32(1);w.u32(shape['vertexCount']);w.u32(shape['options'])
 for n in (0,shape['vertexCount'],0,len(triangles)*3):w.u32(n)
 for f in sub['densities']:w.f32(f)
 for tri in triangles:
  for i in tri:(w.u32 if shape['vertexCount']>65536 else w.u16)(i)
 w.align();w.raw(tail)
 result=bytes(w.buf);check=codec.parse_shape(result,7)
 if not check['consumed_all'] or check['triangles']!=triangles:raise ValueError('Falha ao validar malha de luz.')
 return result


def port_valtra(vehicle, model_tree, model_path, report):
 """Return true only for the known A3F geometry, or an already applied profile."""
 mappings=vehicle.find('i3dMappings');lights=vehicle.find('lights')
 if mappings is None or lights is None:return False
 if mappings.find("i3dMapping[@id='gm_light_head']") is not None:
  report['perfil_luzes']='Valtra A3F (já aplicado)';report['luzes']=6;return True
 scene=model_tree.find('Scene');materials=model_tree.find('Materials');shapes=model_tree.find('Shapes')
 if scene is None or materials is None or shapes is None:return False
 nodes={n.get('name'):n for n in scene.iter('Shape') if n.get('name') in EXPECTED}
 if set(nodes)!=set(EXPECTED):return False
 for name,(sid,mids,_) in EXPECTED.items():
  node=nodes[name]
  if node.get('shapeId')!=sid or ' '.join(node.get('materialIds','').replace(',',' ').split())!=mids:return False
 shape_path=model_path.parent/shapes.get('externalShapesFile','')
 if not shape_path.is_file():return False
 version,seed,entities=codec.decode_entities(str(shape_path))
 if version!=7:return False
 parsed={};raw={}
 for kind,data in entities:
  if kind!=1:continue
  b=codec.Blob(data);b.take(b.u32());b.align();sid=str(b.u32())
  raw[sid]=data
 for name,(sid,_,num_subsets) in EXPECTED.items():
  if sid not in raw:return False
  sh=codec.parse_shape(raw[sid],7)
  if not sh['consumed_all'] or sh['numSubsets']!=num_subsets:return False
  parsed[name]=sh
 # The converted shader is required; don't bind arbitrary native/custom shaders.
 by_material={m.get('materialId'):m for m in materials}
 used_mids={nodes[name].get('materialIds').replace(',',' ').split()[subset] for name,subset,*_ in PROFILE}
 if any(by_material[mid].get('customShaderVariation')!='convertedFS25Light' for mid in used_mids):return False
 next_shape=max(int(i) for i in raw)+1
 next_node=max(int(n.get('nodeId','0')) for n in scene.iter())+1
 next_material=max(int(m.get('materialId','0')) for m in materials)+1
 paths={}
 def walk(n,p):
  paths[id(n)]=p
  for i,c in enumerate(n):walk(c,p+('|' if '>' in p and p.split('>')[1] else '')+str(i))
 for i,n in enumerate(scene):walk(n,str(i)+'>')
 additions=[];new_materials=[];new_nodes=[];new_mappings=[];bindings=[]
 for index,(name,subset,role,color,types,side) in enumerate(PROFILE):
  parent=nodes[name];sh=parsed[name];sid=next_shape+index;mid=next_material+index;nid=next_node+index
  overlay=selected_mesh(raw[str(sh['shapeId'])],sh,subset,sid,'gm_light_'+role,side)
  additions.append((1,overlay))
  material=copy.deepcopy(by_material[parent.get('materialIds').replace(',',' ').split()[subset]])
  material.set('name','gm_light_'+role);material.set('materialId',str(mid))
  def parameter(key,value):
   p=material.find("CustomParameter[@name='"+key+"']")
   if p is None:p=E.SubElement(material,'CustomParameter',name=key)
   p.set('value',value)
  parameter('convertedEmission',color+' 0');parameter('lightControl','0')
  # Only indicators blink. Head, tail, work and reverse lamps remain steady.
  parameter('blinkOffset','0 0 '+('1' if role in ('left','right') else '0')+' 0')
  new_materials.append(material)
  node=E.Element('Shape',name='gm_light_'+role,shapeId=str(sid),nodeId=str(nid),materialIds=str(mid),visibility='false',castsShadows='false',receiveShadows='false')
  # Appending leaves every existing indexed node unchanged, including children.
  child_index=len(parent)+sum(1 for p,_ in new_nodes if p is parent)
  path=paths[id(parent)]+('|' if paths[id(parent)].split('>')[1] else '')+str(child_index)
  new_nodes.append((parent,node));new_mappings.append(E.Element('i3dMapping',id='gm_light_'+role,node=path))
  key='gm_light_'+role
  attributes={'node':key,'shaderNode':key,'intensity':'2' if role in ('head','work','reverse') else '1','toggleVisibility':'true'}
  if role in ('head','work','tail'):
   bindings.append(('defaultLights','defaultLight',dict(attributes,lightTypes=types)))
   if role=='tail':bindings.append(('brakeLights','brakeLight',dict(attributes)))
  else:bindings.append(('turnLights' if role in ('left','right') else 'reverseLights',{'left':'turnLightLeft','right':'turnLightRight','reverse':'reverseLight'}[role],attributes))
 # Validate the encrypted result before committing any XML changes.
 encoded=codec.encode_entities(7,seed,entities+additions)
 temp=shape_path.with_suffix(shape_path.suffix+'.lights.tmp');temp.write_bytes(encoded)
 try:
  v,s,check=codec.decode_entities(str(temp))
  if v!=7 or s!=seed or check!=entities+additions:raise ValueError('Falha ao reabrir shapes com luzes.')
  temp.replace(shape_path)
 finally:
  if temp.exists():temp.unlink()
 for material in new_materials:materials.append(material)
 for parent,node in new_nodes:parent.append(node)
 for mapping in new_mappings:mappings.append(mapping)
 for section,tag,attributes in bindings:
  group=lights.find(section)
  if group is None:group=E.SubElement(lights,section)
  E.SubElement(group,tag,attributes)
 report['luzes']=6;report['perfil_luzes']='Valtra A3F'
 report.setdefault('ajustes',[]).append('Valtra A3F: 6 lentes adaptadas: farol frontal, trabalho dianteiro, lanterna/freio, ré e setas traseiras independentes. As luzes compartilhadas e os feixes originais foram preservados.')
 return True

"""Conservative FS23 adaptation of declared, non-drivable attachable harvesters."""
from pathlib import Path
import hashlib, json, re
import xml.etree.ElementTree as E

BASES = {'attachableCombineWithoutCutter': 'attachableCombineExtended',
         'attachableCombineExtended': 'attachableCombineExtended',
         'attachableCombine': 'attachableCombine'}
DRIVABLE = {'motorized', 'enterable', 'drivable', 'aiDrivable'}
EXTRAS = {'vineDetector', 'vineCutter', 'trailer', 'fruitPreparer', 'cutter',
          'fillUnit', 'fillVolume', 'dischargeable', 'turnOnVehicle', 'pipe',
          'workArea', 'workParticles', 'testAreas', 'groundReference'}
SCRIPT = 'gm_compat/attachable_types.lua'

def port_attachable_types(root, desc, report):
    if report.get('destino') != 'FS23': return 0
    types = desc.find('vehicleTypes')
    declared = {t.get('name'): t for t in desc.findall('vehicleTypes/type')}
    def resolve(name, seen=None):
        seen = set() if seen is None else seen
        if name in seen: return None
        if name in BASES: return BASES[name], []
        seen.add(name)
        t = declared.get(name)
        if t is None or t.get('className', 'Vehicle') != 'Vehicle': return None
        if t.get('filename') and not t.get('filename').replace('\\', '/').endswith('/vehicles/Vehicle.lua'): return None
        parent = resolve(t.get('parent'), seen)
        if parent is None: return None
        extras = list(dict.fromkeys(parent[1] + [s.get('name') for s in t.findall('specialization')]))
        if any(s not in EXTRAS for s in extras): return None
        return parent[0], extras
    manifest = root/'gm_compat/attachable_types.json'
    definitions = {}
    if manifest.is_file():
        previous = json.loads(manifest.read_text())
        for d in previous:
            if (re.fullmatch(r'gmAC_[0-9a-f]{16}', d.get('name', ''))
                and d.get('base') in set(BASES.values())
                and set(d.get('specs', [])) <= EXTRAS):
                definitions[d['name']] = d
    count = 0
    for path in sorted(root.rglob('*.xml')):
        if 'gm_compat' in path.relative_to(root).parts: continue
        try: tree = E.parse(path)
        except E.ParseError: continue
        v = tree.getroot()
        if v.tag != 'vehicle': continue
        original = v.get('type')
        if original in definitions: continue
        resolution = resolve(original)
        if resolution is None:
            if original in declared and v.find('combine') is not None and v.find('attachable') is not None:
                reason = 'Colheitadeira rebocada com herança/especialização não validada; tipo preservado e abertura no jogo exige revisão.'
                report.setdefault('tipos_pendentes', []).append({'arquivo':str(path.relative_to(root)), 'tipo':original, 'motivo':reason})
                report.setdefault('pendencias', []).append(str(path.relative_to(root))+': '+reason)
            continue
        base, extras = resolution
        if original == base and not extras: continue
        # A declared attachable parent is necessary, but insufficient alone.
        # Preserve genuine motorized and enterable machines and ambiguous XMLs.
        if v.find('combine') is None or not (v.findall('attachable/inputAttacherJoints/inputAttacherJoint') or v.findall('attachable/inputAttacherJointConfigurations/inputAttacherJointConfiguration/inputAttacherJoint')):
            report.setdefault('tipos_pendentes', []).append({'arquivo':str(path.relative_to(root)), 'tipo':original, 'motivo':'Tipo rebocado declarado sem combine/engate confirmados; preservado.'})
            continue
        if any(v.find(tag) is not None for tag in DRIVABLE):
            report.setdefault('tipos_pendentes', []).append({'arquivo':str(path.relative_to(root)), 'tipo':original, 'motivo':'XML possui motor/direção/cabine; classificação automática recusada.'})
            continue
        if extras:
            signature = json.dumps([base, extras], separators=(',', ':'))
            alias = 'gmAC_' + hashlib.sha256(signature.encode()).hexdigest()[:16]
            definitions[alias] = {'name':alias, 'base':base, 'specs':extras}
            if types is None: types = E.SubElement(desc, 'vehicleTypes')
            if alias not in declared:
                t = E.SubElement(types, 'type', name=alias, parent=base, className='Vehicle', filename='$dataS/scripts/vehicles/Vehicle.lua')
                for name in extras: E.SubElement(t, 'specialization', name=name)
                declared[alias] = t
            v.set('type', alias)
        else:
            v.set('type', base)
        for definition in declared.values():
            if definition.get('parent') == 'attachableCombineWithoutCutter':
                definition.set('parent', 'attachableCombineExtended')
        E.indent(tree, space='  '); tree.write(path, encoding='utf-8', xml_declaration=True)
        report.setdefault('tipos_rebocados_adaptados', []).append({'arquivo':str(path.relative_to(root)), 'tipo_original':original, 'tipo_saida':v.get('type'), 'base_nativa':base, 'especializacoes_preservadas':extras, 'altera_dataS':False})
        if v.find("vineCutter[@fruitType='COFFEE']") is not None:
            report.setdefault('pendencias', []).append('Café COFFEE preservado em '+str(path.relative_to(root))+': exige mapa com fillType, cultura e sistema de colheita compatíveis. Não foi substituído por outra cultura.')
        count += 1
    if definitions:
        data = [definitions[k] for k in sorted(definitions)]
        manifest.parent.mkdir(parents=True, exist_ok=True)
        manifest.write_text(json.dumps(data, ensure_ascii=False, indent=2))
        # JSON string literals for the restricted identifier set are valid Lua.
        entries = ['{name='+json.dumps(d['name'])+',base='+json.dumps(d['base'])+',specs={'+','.join(json.dumps(s) for s in d['specs'])+'}}' for d in data]
        template = (Path(__file__).resolve().parents[1]/'assets/attachable_types.lua').read_text()
        (root/SCRIPT).write_text(template.replace('__GM_DEFINITIONS__', '{'+','.join(entries)+'}'))
        sources = desc.find('extraSourceFiles')
        if sources is None: sources = E.SubElement(desc, 'extraSourceFiles')
        if not any(s.get('filename') == SCRIPT for s in sources): E.SubElement(sources, 'sourceFile', filename=SCRIPT)
    return count

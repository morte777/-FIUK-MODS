"""Port texture-only glass options to native ConfigurationUtil node/refNode swaps.

Uses explicit material slot identity, plus a checked fallback for the uploaded A3F
whose converted I3D no longer contains the original vidros_mat slot metadata.
Geometry and original materials are shared unchanged; hidden references provide
replacement materials when the selected configuration is applied during loading.
"""
import copy,os,re
import xml.etree.ElementTree as E

def port_windows(vehicle,tree,path,report,vehicle_path=None):
 scene=tree.find('Scene');materials=tree.find('Materials');files=tree.find('Files')
 if scene is None or materials is None or files is None or not len(scene):return 0
 mats={m.get('materialId'):m for m in materials};paths={};nodes=[]
 def walk(n,p):
  paths[id(n)]=p
  if n.tag=='Shape':nodes.append(n)
  for i,c in enumerate(n):walk(c,p+('|' if p.split('>')[1] else '')+str(i))
 for i,n in enumerate(scene):walk(n,str(i)+'>')
 next_node=max([int(n.get('nodeId','0')) for n in scene.iter()]+[0])+1
 next_mat=max([int(m.get('materialId','0')) for m in materials]+[0])+1
 next_file=max([int(f.get('fileId','0')) for f in files]+[0])+1
 references={f.get('filename'):f.get('fileId') for f in files}
 def fid(name):
  nonlocal next_file
  if name not in references:
   references[name]=str(next_file);E.SubElement(files,'File',filename=name,fileId=str(next_file));next_file+=1
  return references[name]
 def pending(group,reason):
  report.setdefault('vidros_pendentes',[]).append({'modelo':path.name,'configuracao':group.tag,'motivo':reason})
 handled=set();count=0
 for group in list(vehicle):
  if not re.fullmatch(r'design\d*Configurations',group.tag):continue
  options=list(group)
  edits=[m for option in options for m in option.findall('material') if m.get('materialSlotName')]
  if not edits:continue
  try:
   if any(option.tag!=group.tag[:-1] for option in options):raise ValueError('estrutura de configuração de vidro não suportada')
   slots={m.get('materialSlotName') for m in edits}
   if len(slots)!=1:raise ValueError('múltiplos slots na mesma configuração exigem revisão')
   slot=next(iter(slots))
   if slot in handled:raise ValueError('o mesmo material é alterado por mais de uma configuração')
   candidates=[m for m in materials if slot in (m.get('name'),m.get('materialSlotName'),m.get('slotName'))]
   profile=False
   if not candidates and slot=='vidros_mat' and path.name.lower()=='valtraa3f.i3d':
    candidates=[m for m in materials if m.get('materialId')=='70' and m.get('name')=='VIDRO_CABINE_glassClear03_mat']
    ids={n.get('shapeId') for n in nodes if n.get('materialIds')=='70'}
    if ids!={'45','99','100','101','102','103'}:candidates=[]
    profile=bool(candidates)
   if len(candidates)!=1:raise ValueError('slot de material não localizado de forma inequívoca: '+slot)
   base=candidates[0];mid=base.get('materialId')
   if base.get('alphaBlending')!='true':raise ValueError('material do slot não está configurado como vidro transparente')
   uses=[n for n in nodes if mid in n.get('materialIds','').replace(',',' ').split()]
   if not uses:raise ValueError('slot não utilizado por nenhuma malha')
   if any(n.get('materialIds','').replace(',',' ').split()!=[mid] for n in uses):raise ValueError('vidro compartilha malha com outros materiais; troca nativa do índice zero exige revisão')
   if not 2<=len(options)<=16:raise ValueError('quantidade de opções não suportada')
   plans=[]
   for option in options:
    changes=option.findall('material')
    if len(changes)>1 or any(c.get('materialSlotName')!=slot for c in changes):raise ValueError('opção mistura alterações de material')
    texture=None
    if changes:
     change=changes[0]
     if set(change.attrib)!={'materialSlotName'} or len(change)!=1 or change[0].tag!='textures' or set(change[0].attrib)!={'diffuse'}:raise ValueError('somente troca de textura diffuse está suportada para vidros')
     texture=change[0].get('diffuse','').replace('\\','/')
     if not texture or texture.startswith(('$','/')) or '..' in texture.split('/') or ':' in texture:raise ValueError('textura de vidro externa/relativa não suportada')
     texture_path=(vehicle_path.parent if vehicle_path is not None else path.parent)/texture
     if not texture_path.is_file():raise ValueError('textura local ausente: '+texture)
     texture=os.path.relpath(texture_path,path.parent).replace(os.sep,'/')
    plans.append((option,texture))
   original=E.tostring(group,encoding='unicode')
   # Append to the component; all existing scene indices and moving nodes survive.
   parent=scene[0];holder_path='0>'+str(len(parent))
   holder=E.SubElement(parent,'TransformGroup',name='gm_window_palette_'+str(next_node),nodeId=str(next_node),visibility='false');next_node+=1
   target=paths[id(uses[0])];entries=[]
   for i,(option,texture) in enumerate(plans):
    material=copy.deepcopy(base);material.set('materialId',str(next_mat));material.set('name','gm_window_'+str(next_mat));next_mat+=1
    if texture:
     tex=material.find('Texture')
     if tex is None:tex=E.SubElement(material,'Texture')
     tex.set('fileId',fid(texture))
    materials.append(material)
    # References are hidden, nonphysical shapes sharing the existing glass mesh.
    E.SubElement(holder,'Shape',name='gm_window_reference_'+str(i),nodeId=str(next_node),shapeId=uses[0].get('shapeId'),materialIds=material.get('materialId'),visibility='false',castsShadows='false',receiveShadows='false');next_node+=1
    for old in option.findall('material'):option.remove(old)
    E.SubElement(option,'material',node=target,refNode=holder_path+'|'+str(i))
    if profile:option.set('name','Normal' if not texture else 'Médio' if 'medio' in texture.lower() else 'Escuro' if 'escuro' in texture.lower() else option.get('name','Vidro'))
    entries.append({'opcao':i+1,'textura':texture or 'original','materialId':material.get('materialId')})
   handled.add(slot);count+=1
   report.setdefault('vidros_comandos_originais',[]).append({'modelo':path.name,'xml':original})
   report.setdefault('vidros_opcionais',[]).append({'modelo':path.name,'configuracao':group.tag,'slot':slot,'malhas':len(uses),'opcoes':entries,'perfil':'Valtra A3F' if profile else 'slot explícito'})
   report.setdefault('ajustes',[]).append(f'{path.name}: {len(options)} opções de vidro ligadas a {len(uses)} malhas por troca nativa de material. Conferir transparência na loja e no jogo.')
  except (ValueError,TypeError,IndexError) as e:pending(group,str(e))
 return count

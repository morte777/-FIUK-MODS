"""Adapt local converted rims to the game's native colorMask shader.

Only UV0's integer tile is changed: x selects colorMat0, negative y enables
painting. Fractions are preserved except at a tile's exact upper boundary,
which moves by one float32 step. Geometry and all other attributes stay intact.
The entire file is planned/validated before any material or mesh is changed.
"""
import math,os,struct
import re
from pathlib import Path
import xml.etree.ElementTree as E
from . import shapes_codec as codec
NATIVE_SHADER='$data/shaders/vehicleShader.xml'
UPPER_U=struct.unpack('<f',struct.pack('<I',0x3f7fffff))[0]
NEGATIVE_EDGE=-(1-UPPER_U)

def paint_uv0(raw):
 sh=codec.parse_shape(raw,7)
 if not sh['consumed_all']:raise ValueError('malha com dados adicionais não interpretados')
 uv=sh['uvsets'][0]
 if not uv:raise ValueError('malha sem UV0')
 if any(not math.isfinite(v) for pair in uv for v in pair):raise ValueError('UV não finita')
 umin=min(u for u,v in uv);umax=max(u for u,v in uv);vmax=max(v for u,v in uv)
 tile=math.floor(umin)
 if umax>tile+1 or umax-umin>1:raise ValueError('UV horizontal ocupa vários tiles; precisa de conversão específica')
 vshift=max(1,math.ceil(vmax))
 b=codec.Blob(raw);name=b.u32();b.take(name);b.align();b.take(4+16)
 corners=b.u32();subsets=b.u32();vertices=b.u32();options=b.u32()
 uv_count=sum(bool(options&bit) for bit in (2,4,8,16))
 b.take(subsets*(16+4*uv_count));b.take(corners*(4 if vertices>65536 else 2));b.align()
 b.take(vertices*(12+(12 if options&1 else 0)+(16 if options&128 else 0)))
 offset=b.p;out=bytearray(raw)
 for i,(u,v) in enumerate(uv):
  newu=u-tile;newv=v-vshift
  if newu>=1:newu=UPPER_U
  if newv>=0:newv=NEGATIVE_EDGE
  struct.pack_into('<ff',out,offset+8*i,newu,newv)
 result=bytes(out);new=codec.parse_shape(result,7)
 for key in ('positions','normals','tangents','triangles','subsets','options','vertexColor','generic','attachments','shapeId','boundingVolume'):
  if sh[key]!=new[key]:raise ValueError('atributo fora de UV0 foi alterado: '+key)
 if result[:offset]!=raw[:offset] or result[offset+vertices*8:]!=raw[offset+vertices*8:]:raise ValueError('bytes fora de UV0 alterados')
 if not new['consumed_all'] or any(not(0<=u<1 and v<0) for u,v in new['uvsets'][0]):raise ValueError('UV pintável inválida')
 return result,{'shapeId':sh['shapeId'],'vertices':vertices,'tile_u':tile,'deslocamento_v':vshift}

def port_native_rims(vehicle,vehicle_path,root,report):
 models={};count=0
 for wheel in vehicle.findall('.//wheel')+vehicle.findall('.//additionalWheel'):
  filename=wheel.get('filename','')
  if not filename or filename.startswith('$'):continue
  wp=vehicle_path.parent/filename
  if not wp.is_file():wp=root/filename
  if not wp.is_file():continue
  wt=E.parse(wp)
  for tag in ('innerRim','outerRim','additional'):
   for part in wt.findall('.//'+tag):
    name=part.get('filename','')
    if not name or name.startswith('$'):continue
    p=wp.parent/name
    if not p.is_file():p=root/name
    if p.is_file():
     selected=models.setdefault(p.resolve(),set())
     indices=[part.get(key) for key in ('nodeLeft','nodeRight','node') if part.get(key)]
     selected.update(indices or [None])
 for path in sorted(models):
  try:
   tree=E.parse(path);materials=tree.find('Materials');files=tree.find('Files');scene=tree.find('Scene')
   if materials is None or files is None or scene is None:continue
   # A single I3D may contain both tire and rims. Only the rim subtrees
   # selected by wheel XML may receive palette UVs or native rim materials.
   allowed=set()
   for index in models[path]:
    if index is None:allowed.update(scene.iter());continue
    value=index.replace('>','|').rstrip('|')
    if not re.fullmatch(r'\d+(?:\|\d+)*',value):raise ValueError('indice de aro sem caminho numerico: '+str(index))
    node=scene
    for component in value.split('|'):node=node[int(component)]
    allowed.update(node.iter())
   rim_mids={mid for node in allowed if node.tag=='Shape' for mid in node.get('materialIds','').split()}
   refs={f.get('fileId'):f.get('filename','') for f in files}
   targets=[m for m in materials if m.get('materialId') in rim_mids and m.get('customShaderVariation') in ('convertedFS25','convertedFS25Rim') and Path(refs.get(m.get('customShaderId'),'')).name=='vehicleShaderCompat.xml' and m.find("CustomParameter[@name='convertedColor']") is not None and m.get('alphaBlending')!='true']
   if not targets:continue
   mids={m.get('materialId') for m in targets};shapes=set()
   if any(set(n.get('materialIds','').split())&mids for n in scene.iter('Shape') if n not in allowed):raise ValueError('material de aro compartilhado com malha fora da selecao; requer separacao antes de adaptar')
   for node in scene.iter('Shape'):
    if node not in allowed:continue
    ids=set(node.get('materialIds','').replace(',',' ').split())
    if ids&mids:
     if ids-mids:raise ValueError('malha mistura materiais pintáveis e materiais não convertidos')
     shapes.add(int(node.get('shapeId')))
   if not shapes:raise ValueError('materiais de aro sem malha vinculada')
   if any(int(n.get('shapeId','-1')) in shapes for n in scene.iter('Shape') if n not in allowed):raise ValueError('malha do aro compartilhada fora da selecao; adaptacao recusada para preservar o pneu')
   ext=tree.find('Shapes');filename=ext.get('externalShapesFile','') if ext is not None else ''
   if not filename or filename.startswith('$'):raise ValueError('arquivo de malhas local não localizado')
   meshpath=path.parent/filename
   version,seed,entities=codec.decode_entities(meshpath)
   if version!=7:raise ValueError('a adaptação dos aros exige shapes v7 já convertido')
   plans=[];encoded=[];seen=set()
   for kind,data in entities:
    if kind==1:
     sh=codec.parse_shape(data,7)
     if sh['shapeId'] in shapes:
      data,info=paint_uv0(data);plans.append(info);seen.add(sh['shapeId'])
    encoded.append((kind,data))
   if seen!=shapes:raise ValueError('uma malha de aro não foi localizada no arquivo shapes')
   packed=codec.encode_entities(version,seed,encoded)
   shaderid=next((i for i,name in refs.items() if name==NATIVE_SHADER),None)
   if shaderid is None:
    shaderid=str(max([int(i) for i in refs]+[0])+1);E.SubElement(files,'File',fileId=shaderid,filename=NATIVE_SHADER)
   for m in targets:
    color=m.find("CustomParameter[@name='colorMat0']")
    value=color.get('value') if color is not None else m.find("CustomParameter[@name='convertedColor']").get('value')
    m.set('customShaderId',shaderid);m.set('customShaderVariation','colorMask')
    for p in list(m.findall('CustomParameter')):
     if p.get('name') in ('convertedColor','convertedSurface','convertedEmission','colorMat0'):m.remove(p)
    E.SubElement(m,'CustomParameter',name='colorMat0',value=value)
   # Verification occurred before mutations. Replace the local mesh and model.
   E.indent(tree,space='  ');xml=E.tostring(tree.getroot(),encoding='utf-8',xml_declaration=True)
   meshpath.write_bytes(packed);path.write_bytes(xml)
   count+=len(targets)
   report.setdefault('aros_nativos',[]).append({'modelo':str(path.relative_to(root.resolve())),'materiais':len(targets),'shader':NATIVE_SHADER,'variacao':'colorMask','malhas_uv':plans,'precisa_alterar_dataS':False})
  except (ValueError,KeyError,TypeError,IndexError,OSError,E.ParseError) as e:
   report.setdefault('aros_pendentes',[]).append({'modelo':str(path.relative_to(root.resolve())),'motivo':str(e)})
 return count

import numpy as np
from .shapes_cipher import KEY_CONST,process as reference

def process(data,seed,block_index=0):
 n=(len(data)+63)//64
 if not n:return b''
 base=np.tile(np.array(KEY_CONST[seed*16:seed*16+16],dtype=np.uint32),(n,1)).T.copy()
 c=np.arange(block_index,block_index+n,dtype=np.uint64)
 base[8]=c.astype(np.uint32);base[9]=(c>>32).astype(np.uint32)
 k=base.copy()
 def rol(v,b):return (v<<b)|(v>>(32-b))
 def s1(a,b,c,d):
  k[c]^=rol(k[b]+k[a],7);k[d]^=rol(k[c]+k[a],9);k[b]^=rol(k[c]+k[d],13);k[a]^=rol(k[b]+k[d],18)
 def s2(a,b,c,d):
  k[c]^=rol(k[b]+k[a],7);k[d]^=rol(k[b]+k[c],9);k[a]^=rol(k[c]+k[d],13);k[b]^=rol(k[d]+k[a],18)
 for _ in range(10):
  s1(0,12,4,8);s1(5,1,9,13);s1(10,6,14,2);s1(15,11,3,7)
  s2(3,0,1,2);s2(4,5,6,7);s1(10,9,11,8);s2(14,15,12,13)
 stream=(k+base).T.copy().astype('<u4').tobytes()[:len(data)]
 return np.bitwise_xor(np.frombuffer(data,dtype=np.uint8),np.frombuffer(stream,dtype=np.uint8)).tobytes()

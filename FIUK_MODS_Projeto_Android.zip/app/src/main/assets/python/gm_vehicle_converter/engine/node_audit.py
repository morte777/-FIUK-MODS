"""Read-only audit of explicit vehicle node references against the main I3D scene."""
NODE_KEYS={'node','shaderNode','linkNode','driveNode','rotNode','rotationNode','referenceNode','triggerNode','triggerPoint'}

def audit_nodes(vehicle,model,filename,report):
 scene=model.find('Scene')
 if scene is None:return
 mappings={e.get('id'):e.get('node') for e in vehicle.findall('i3dMappings/i3dMapping')}
 def resolve(value,alias=True):
  value=mappings.get(value,value) if alias else value
  if not value:raise ValueError()
  if '>' not in value:value='0>'+value
  a,b=value.split('>',1)
  if int(a)<0:raise ValueError()
  node=scene[int(a)]
  for i in b.split('|'):
   if i:
    if int(i)<0:raise ValueError()
    node=node[int(i)]
  return node
 issues=[]
 for element in vehicle.iter():
  for key,value in element.attrib.items():
   if key not in NODE_KEYS:continue
   try:resolve(value,element.tag!='i3dMapping')
   except (ValueError,TypeError,IndexError,KeyError):
    item={'elemento':element.tag,'atributo':key,'valor':value}
    if element.tag=='i3dMapping':item['id']=element.get('id')
    if item not in issues:issues.append(item)
 if issues:
  report.setdefault('nos_pendentes',{})[filename]=issues
  text=f'{filename}: {len(issues)} referências distintas de nós inválidas já existentes na configuração; parte pode ser mapeamento sem uso. Conferir nos_pendentes no relatório.'
  if text not in report['pendencias']:report['pendencias'].append(text)

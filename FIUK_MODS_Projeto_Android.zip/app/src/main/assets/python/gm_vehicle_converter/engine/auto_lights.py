"""FS25 static lights -> native FS22 XML, selected by explicit XML and UV2 slots.

Reference: GIANTS vehicleConversion_fs25_v1_0_0, page 10 (8 columns, 2 rows),
StaticLight / StaticLightCompound scripting documentation. No guessed node names.
Unsupported/mixed triangles are recorded rather than activating the entire mesh.
"""
import copy, math
import xml.etree.ElementTree as E
from . import shapes_codec as codec
from .lights import selected_mesh

# Native target roles, lightTypes, relative emission, RGB.
MAX_LIGHT_BYTES=96*1024**2
MAX_LENSES=256
WHITE='1 .92 .78';RED='1 .015 .003';AMBER='1 .24 .002'
SLOTS={1:('default','0',1,WHITE),2:('default','0 3',1,WHITE),
 3:('default','3',1.4,WHITE),7:('left','',1,AMBER),8:('right','',1,AMBER),
 9:('default','0',1,RED),10:('brake','',1,RED),11:('tailbrake','0',1,RED),
 12:('reverse','',1,WHITE),13:('default','2',1,WHITE),14:('default','1',1,WHITE)}
FUNCTIONS={name:i+1 for i,name in enumerate(('defaultlight','defaultlightandhighbeam','highbeam','bottomlight','toplight','daytimerunninglight','turnlightleft','turnlightright','backlight','brakelight','backandbrakelight','reverselight','worklightfront','worklightback','worklightadditional1','worklightadditional2'))}
FUNCTIONS.update(default=1,defaultandhighbeam=2,back=9,brake=10,backandbrake=11,reverse=12,worklightadditional=15)
SECTIONS={'default':('defaultLights','defaultLight'),'brake':('brakeLights','brakeLight'),
 'reverse':('reverseLights','reverseLight'),'left':('turnLights','turnLightLeft'),'right':('turnLights','turnLightRight')}
DIRECT=tuple(SECTIONS.values())
EXTRA=('enableDirection','inputAttacherJointIndex')

def norm(value):return ''.join(c.lower() for c in value if c.isalnum())
def finite(value,default):
 n=float(value if value is not None else default)
 if not math.isfinite(n) or n<0 or n>10000:raise ValueError('intensidade/escala inválida')
 return n

def uv_slot(uv):
 u,v=uv
 if not math.isfinite(u) or not math.isfinite(v):raise ValueError('UV2 não finito')
 if u<0:return 0 # Official non-emissive sector, including negative U near zero.
 if u>=8 or v<0 or v>=2:return -1
 return int(math.floor(u))+8*int(math.floor(v))+1

def split_triangles(shape,subset):
 """Triangles must belong wholly to one UV2 sector; do not clip/reassign faces."""
 uv=shape['uvsets'][1]
 if uv is None:raise ValueError('UV2 ausente: não é possível separar as funções')
 sub=shape['subsets'][subset];groups={};mixed=0
 for tri in shape['triangles'][sub['firstIndex']//3:(sub['firstIndex']+sub['numIndices'])//3]:
  coords=[uv[i] for i in tri]
  if any(not all(math.isfinite(v) for v in pair) for pair in coords):mixed+=1;continue
  center=tuple(sum(pair[j] for pair in coords)/3 for j in (0,1))
  slot=uv_slot(center)
  if slot==0:
   if max(p[0] for p in coords)>1e-5:mixed+=1
   continue
  if slot<0:mixed+=1;continue
  col=(slot-1)%8;row=(slot-1)//8
  if not all(col-1e-5<=u<=col+1+1e-5 and row-1e-5<=v<=row+1+1e-5 for u,v in coords):mixed+=1;continue
  groups.setdefault(slot,[]).append(tri)
 return groups,mixed

class LightPort:
 def __init__(self,vehicle,tree,path,report):
  self.vehicle=vehicle;self.tree=tree;self.path=path;self.report=report
  self.scene=tree.find('Scene');self.materials=tree.find('Materials');self.lights=vehicle.find('lights')
  self.mapping=vehicle.find('i3dMappings')
  self.map={e.get('id'):e.get('node') for e in vehicle.findall('i3dMappings/i3dMapping')}
  self.paths={};self.nodes={};self.by_material={m.get('materialId'):m for m in self.materials} if self.materials is not None else {}
  self.entities=None;self.meshes={};self.parsed={};self.additions=[];self.added_bytes=0;self.count=0;self.touched=set();self.cache={}
  self.pending=report.setdefault('luzes_pendentes',[]);self.details=report.setdefault('luzes_adaptadas',[])
  def walk(node,path):
   self.paths[id(node)]=path;self.nodes[path]=node
   for i,c in enumerate(node):walk(c,path+('|' if path.split('>')[1] else '')+str(i))
  if self.scene is not None:
   for i,node in enumerate(self.scene):walk(node,str(i)+'>')
  self.next_node=max([int(n.get('nodeId','0')) for n in self.scene.iter()]+[0])+1 if self.scene is not None else 1
  self.next_material=max([int(n.get('materialId','0')) for n in self.by_material.values()]+[0])+1
 def warn(self,node,reason,source=None):
  item={'modelo':self.path.name,'node':node or '?','motivo':reason}
  if source is not None:item['xml_original']=E.tostring(source,encoding='unicode')
  if item not in self.pending:self.pending.append(item)
 def resolve(self,value):
  path=self.map.get(value,value)
  if not path:raise ValueError('referência de nó ausente')
  if '>' not in path:path='0>'+path
  try:return self.nodes[path]
  except KeyError:raise ValueError('nó não localizado: '+str(value)) from None
 def load(self):
  if self.entities is not None:return
  shapes=self.tree.find('Shapes');ref=shapes.get('externalShapesFile','') if shapes is not None else ''
  if not ref or ref.startswith('$'):raise ValueError('arquivo shapes local indisponível')
  self.shape_path=self.path.parent/ref
  if self.shape_path.stat().st_size>256*1024**2:raise ValueError('shapes excede o limite de 256 MB para luzes')
  version,self.seed,self.entities=codec.decode_entities(str(self.shape_path))
  if version!=7:raise ValueError('luzes exigem shapes v7 após a conversão')
  for kind,data in self.entities:
   if kind==1:
    b=codec.Blob(data);b.take(b.u32());b.align();sid=b.u32();self.meshes[sid]=data
  self.next_shape=max(self.meshes,default=0)+1
 def shape(self,node):
  self.load();sid=int(node.get('shapeId'))
  if sid not in self.parsed:
   data=self.meshes[sid];b=codec.Blob(data);b.take(b.u32());b.align();b.take(4+16+8)
   if b.u32()>500000:raise ValueError('lente com mais de 500 mil vértices')
   sh=codec.parse_shape(data,7)
   if not sh['consumed_all']:raise ValueError('malha de lente com dados não interpretados')
   if sh['options']&codec.OPT_SKIN or sh['attachments']:raise ValueError('lente com skin/attachments exige revisão')
   self.parsed[sid]=sh
  return self.parsed[sid]
 def subsets(self,node):
  for i,mid in enumerate(node.get('materialIds','').replace(',',' ').split()):
   mat=self.by_material.get(mid)
   if mat is not None and mat.get('customShaderVariation')=='convertedFS25Light':yield i,mat
 def bind(self,key,role,types,intensity,extra):
  roles=('default','brake') if role=='tailbrake' else (role,)
  for role in roles:
   section,tag=SECTIONS[role];group=self.lights.find(section)
   if group is None:group=E.SubElement(self.lights,section)
   attrs=dict(extra,node=key,shaderNode=key,intensity=f'{intensity:g}',toggleVisibility='true')
   if role=='default':attrs['lightTypes']=types
   if not any(e.attrib==attrs for e in group.findall(tag)):E.SubElement(group,tag,attrs)
 def overlay(self,node,subset,material,triangles,slot,role,types,intensity,color,blink,extra):
  # Identical steady tail/brake selections share a node and native doubled charge.
  signature=(id(node),subset,tuple(triangles),blink,tuple(sorted(extra.items())),color,intensity)
  if signature in self.cache:
   key=self.cache[signature];self.bind(key,role,types,intensity,extra);return key
  if self.count>=MAX_LENSES:raise ValueError('limite de 256 lentes por veículo atingido')
  sh=self.shape(node);number=self.next_node;key='gm_auto_light_'+str(number)
  data=selected_mesh(self.meshes[sh['shapeId']],sh,subset,self.next_shape,key,selected_triangles=triangles)
  if self.added_bytes+len(data)>MAX_LIGHT_BYTES:raise ValueError('limite de 96 MB de novas malhas de luz atingido')
  self.added_bytes+=len(data);self.additions.append((1,data));self.next_shape+=1
  mat=copy.deepcopy(material);mat.set('name',key);mat.set('materialId',str(self.next_material))
  def parameter(name,value):
   p=mat.find("CustomParameter[@name='"+name+"']")
   if p is None:p=E.SubElement(mat,'CustomParameter',name=name)
   p.set('value',value)
  parameter('convertedEmission',color+' 0');parameter('lightControl','0');parameter('blinkOffset','0 0 '+('1' if blink else '0')+' 0')
  self.materials.append(mat)
  overlay=E.Element('Shape',name=key,nodeId=str(number),shapeId=str(self.next_shape-1),materialIds=str(self.next_material),visibility='false',castsShadows='false',receiveShadows='false')
  if node.get('clipDistance'):overlay.set('clipDistance',node.get('clipDistance'))
  path=self.paths[id(node)]+('|' if self.paths[id(node)].split('>')[1] else '')+str(len(node));node.append(overlay)
  self.next_node+=1;self.next_material+=1
  if self.mapping is None:self.mapping=E.SubElement(self.vehicle,'i3dMappings')
  self.mapping.append(E.Element('i3dMapping',id=key,node=path))
  self.cache[signature]=key;self.touched.add(id(node));self.count+=1
  self.bind(key,role,types,intensity,extra)
  self.details.append({'modelo':self.path.name,'origem':self.paths[id(node)],'material':material.get('name'),'uvSlotIndex':slot,'funcao':role,'lightTypes':types,'intensidade':intensity,'node':key})
  return key
 def compound(self,compound):
  mapping={i:[(i,1.,0,None)] for i in range(1,17)}
  overrides={}
  for fn in compound.findall('function'):
   try:
    function=FUNCTIONS.get(norm(fn.get('name','')))
    slot=int(fn.get('uvSlotIndex',function or 0))
    if slot not in range(1,17):raise ValueError('uvSlotIndex fora de 1–16')
    overrides.setdefault(slot,[])
    if function is None:raise ValueError('função não reconhecida: '+str(fn.get('name')))
    offset=int(fn.get('uvOffset','0'))
    if offset!=0:raise ValueError('troca dinâmica de cor por uvOffset exige revisão')
    light_type=norm(fn.get('lightType',''))
    if light_type not in ('','static','blinking'):raise ValueError('tipo de pisca personalizado não suportado')
    overrides[slot].append((function,finite(fn.get('intensityScale'),1),offset,light_type or None))
   except (ValueError,TypeError) as e:self.warn(fn.get('name'),str(e),fn)
  mapping.update(overrides)
  for entry in compound.findall('node'):
   label=entry.get('node')
   try:
    node=self.resolve(label)
    if node.tag!='Shape':raise ValueError('staticLightCompound exige nó Shape')
    if entry.get('isTopLight')=='true' or entry.get('isBottomLight')=='true':raise ValueError('seleção top/bottom requer regra do veículo')
    sh=self.shape(node);subsets=list(self.subsets(node))
    if not subsets:raise ValueError('shader da lente sem adaptação compatível')
    intensity=finite(entry.get('intensity'),5);extra={k:entry.get(k) for k in EXTRA if entry.get(k) is not None}
    bitmask=int(entry.get('lightTypeBitMask',compound.get('lightTypeBitMask','20480')),0)
    for subset,mat in subsets:
     groups,mixed=split_triangles(sh,subset)
     if mixed:self.warn(label,f'{mixed} triângulos atravessam setores UV2 ou ficam fora do atlas; preservados apagados',entry)
     for slot,triangles in groups.items():
      functions=mapping[slot]
      if not functions:self.warn(label,f'setor UV {slot} sem função compatível',entry);continue
      roles=[SLOTS[f][0] for f,*_ in functions if f in SLOTS]
      if any(r in ('left','right') for r in roles) and len(set(roles))>1:
       self.warn(label,f'setor {slot} combina seta com outra função; prioridade de pisca exige revisão',entry);continue
      for function,scale,offset,light_type in functions:
       if function not in SLOTS:
        self.warn(label,f'função do setor {function} (top/bottom, DRL ou trabalho adicional) exige revisão',entry);continue
       role,types,gain,color=SLOTS[function]
       mode=(bitmask>>(2*(slot-1)))&3 if slot<=12 else 0
       blink=light_type=='blinking' if light_type else mode in (1,2) or role in ('left','right')
       if mode==3: self.warn(label,f'máscara de pisca inválida no setor {slot}',entry);continue
       if mode==2 or entry.get('useSliderTurnLights',compound.get('useSliderTurnLights'))=='true':self.warn(label,'pisca sequencial aproximado por pisca comum',entry)
       self.overlay(node,subset,mat,triangles,slot,role,types,intensity*gain*scale,color,blink,extra)
   except (ValueError,KeyError,TypeError,OSError,IndexError,EOFError) as e:self.warn(label,str(e),entry)
 def direct(self,group,entry,role):
  if entry.get('shaderNode','').startswith(('gm_auto_light_','gm_light_')) or entry.get('node','').startswith(('gm_auto_light_','gm_light_')):return
  label=entry.get('shaderNode') or entry.get('node');recognized=False
  try:
   root=self.resolve(label);targets=[n for n in root.iter('Shape') if not n.get('name','').startswith(('gm_auto_light_','gm_light_'))]
   subsets=[(n,i,m) for n in targets for i,m in self.subsets(n)]
   if not subsets:
    if entry.get('uvSlotIndex') is not None:self.warn(label,'uvSlotIndex em shader próprio/nativo não adaptado',entry)
    return
   recognized=True
   types=entry.get('lightTypes','');extra={k:entry.get(k) for k in EXTRA+('excludedLightTypes',) if entry.get(k) is not None}
   if role=='default' and (not types or any(not s.isdigit() or int(s)>30 for s in types.split())):raise ValueError('lightTypes ausentes, negativos ou fora de 0–30')
   if entry.get('isTopLight')=='true' or entry.get('isBottomLight')=='true':raise ValueError('seleção top/bottom exige revisão')
   slot=int(entry.get('uvSlotIndex','0'))
   if slot<0 or slot>16:raise ValueError('uvSlotIndex fora de 1–16')
   intensity=finite(entry.get('intensity'),5)
   for node,subset,mat in subsets:
    sh=self.shape(node);sub=sh['subsets'][subset]
    if sh['uvsets'][1] is not None:
     groups,mixed=split_triangles(sh,subset)
     if mixed:self.warn(label,f'{mixed} triângulos com setores UV2 ambíguos',entry)
     triangles=groups.get(slot,[]) if slot else [t for ts in groups.values() for t in ts]
    elif slot:raise ValueError('uvSlotIndex definido, mas UV2 ausente')
    else:triangles=sh['triangles'][sub['firstIndex']//3:(sub['firstIndex']+sub['numIndices'])//3]
    if not triangles:self.warn(label,'nenhum triângulo emissivo para o setor solicitado',entry);continue
    color=AMBER if role in ('left','right') else RED if role=='brake' or (role=='default' and slot in (9,10,11)) else WHITE
    # Material color is explicit source data; use its chromatic tint if available.
    cp=mat.find("CustomParameter[@name='convertedColor']")
    if cp is not None:
     rgb=[float(v) for v in cp.get('value','').split()[:3]]
     if len(rgb)==3 and all(math.isfinite(v) and v>=0 for v in rgb) and max(rgb)>0 and max(rgb)-min(rgb)>.08:color=' '.join(f'{v/max(rgb):g}' for v in rgb)
    self.overlay(node,subset,mat,triangles,slot or None,role,types,intensity,color,role in ('left','right'),extra)
  except (ValueError,KeyError,TypeError,OSError,IndexError,EOFError) as e:self.warn(label,str(e),entry)
  finally:
   if recognized:
    self.report.setdefault('luzes_comandos_originais',[]).append({'modelo':self.path.name,'xml':E.tostring(entry,encoding='unicode')})
    group.remove(entry)
 def run(self):
  if self.scene is None or self.materials is None or self.lights is None:return 0
  existing=[m for m in self.vehicle.findall('i3dMappings/i3dMapping') if m.get('id','').startswith('gm_auto_light_')]
  # Snapshot direct commands before creating additional native bindings.
  entries=[(self.lights.find(section),e,role) for role,(section,tag) in SECTIONS.items() for e in self.lights.findall(section+'/'+tag)]
  for group,entry,role in entries:self.direct(group,entry,role)
  for compound in self.lights.findall('staticLightCompounds/staticLightCompound'):self.compound(compound)
  for path,node in self.nodes.items():
   if node.tag=='Shape' and not node.get('name','').startswith(('gm_auto_light_','gm_light_')) and list(self.subsets(node)) and id(node) not in self.touched and not any(c.get('name','').startswith(('gm_auto_light_','gm_light_')) for c in node):
    try:
     sh=self.shape(node)
     if sh['uvsets'][1] is not None and all(not split_triangles(sh,i)[0] and not split_triangles(sh,i)[1] for i,_ in self.subsets(node)):continue
    except (ValueError,KeyError,TypeError,OSError,IndexError,EOFError):pass
    self.warn(path,'lente sem comando XML compatível; função não deduzida pelo nome/cor')
  if self.additions:
   temp=self.shape_path.with_suffix(self.shape_path.suffix+'.auto.tmp')
   try:
    temp.write_bytes(codec.encode_entities(7,self.seed,self.entities+self.additions));v,s,check=codec.decode_entities(str(temp))
    if v!=7 or s!=self.seed or check!=self.entities+self.additions:raise ValueError('verificação de shapes com luzes falhou')
    temp.replace(self.shape_path)
   finally:
    if temp.exists():temp.unlink()
  total=self.count+len(existing)
  self.report['luzes']=self.report.get('luzes',0)+total
  if total:self.report.setdefault('ajustes',[]).append(f'{self.path.name}: {total} lentes com comandos nativos; leitura geral por XML e UV2. Conferir brilho e acabamento no jogo.')
  if self.count:self.report.setdefault('pendencias',[]).append('Lentes gerais: cores e emissão aproximadas por função/material; detalhes do mapa emissivo FS25 e pisca sequencial podem exigir ajuste visual.')
  return total

def port_general(vehicle,tree,path,report):return LightPort(vehicle,tree,path,report).run()

"""Verified FS19 vehicle adjustments. Never executes the mod's Lua scripts."""
from pathlib import Path
import xml.etree.ElementTree as E

def prepare(root,desc,report,target):
 from .converter import read_xml
 root=root.resolve();disabled=[];extra=desc.find('extraSourceFiles')
 version=desc.find('version')
 if version is not None and version.text and all(v.isdigit() for v in version.text.strip().split('.')) and 1<=len(version.text.strip().split('.'))<4:
  old=version.text;version.text='.'.join(version.text.strip().split('.')+['0']*(4-len(version.text.strip().split('.'))));report['versao_mod_normalizada']={'antes':old,'depois':version.text}
 if extra is not None:
  for entry in list(extra):
   name=entry.get('filename','');path=(root/name).resolve()
   if root not in path.parents or not path.is_file() or path.stat().st_size>1024*1024:continue
   raw=path.read_bytes();base=path.name.casefold()
   known=(base=='categorizer.lua' and b'Categorizer' in raw and b'g_storeManager:addCategory' in raw) or (base=='changemodtitle.lua' and b'ChangeModTitle' in raw and b'Utils.appendedFunction' in raw)
   if known:
    extra.remove(entry);disabled.append(name)
  if not list(extra):desc.remove(extra)
 if disabled:report['scripts_cosmeticos_fs19_desativados']=disabled
 custom={e.get('name','').casefold() for e in desc.findall('newcategory')}
 if any(Path(n).name.casefold()=='categorizer.lua' for n in disabled):
  for e in list(desc.findall('newcategory')):desc.remove(e)
 if any(Path(n).name.casefold()=='changemodtitle.lua' for n in disabled):
  for e in list(desc.findall('changeModTitle')):desc.remove(e)
 for path in root.rglob('*.xml'):
  if path.name.casefold()=='moddesc.xml':continue
  raw=path.read_bytes()
  if not raw.lstrip(b'\xef\xbb\xbf \r\n\t').startswith(b'<'):continue
  tree=read_xml(path);vehicle=tree.getroot()
  if vehicle.tag!='vehicle':continue
  changed=False;category=vehicle.find('storeData/category')
  if category is not None and (category.text or '').strip().casefold() in custom:
   if vehicle.get('type')=='tractor':
    try:hp=float(vehicle.findtext('storeData/specs/power') or 150)
    except ValueError:hp=150
    old=category.text;category.text='tractorsS' if hp<150 else 'tractorsM' if hp<=300 else 'tractorsL';changed=True
    report.setdefault('categorias_fs19_adaptadas',[]).append({'xml':str(path.relative_to(root)),'antes':old,'depois':category.text})
   else:report['pendencias'].append('Categoria personalizada FS19 requer escolha de categoria nativa: '+str(path.relative_to(root)))
  if target=='FS23':
   manual=vehicle.find('realManualTransmission')
   if manual is not None:
    report.setdefault('extensoes_fs19_desativadas',[]).append({'xml':str(path.relative_to(root)),'secao':'realManualTransmission','original':E.tostring(manual,encoding='unicode')})
    vehicle.remove(manual);changed=True
  if changed:E.indent(tree,space='  ');tree.write(path,encoding='utf-8',xml_declaration=True)

def material_resources(root,path,files,report):
 """Replace known absent FS19 resources; report every visual approximation."""
 if report.get('origem')!='FS19' or report.get('destino')!='FS23':return 0
 import os
 # These exact resources failed in the target FS23 game log. Do not guess
 # replacements for arbitrary base-game paths or transplant unrelated UV maps.
 neutral={
  '$data/shared/assets/backHitch_normal.png':'$data/shared/default_normal.png',
  '$data/shared/assets/backHitch_specular.png':'$data/shared/default_specular.png',
  '$data/shared/connectionHoses/hosesPipes_specular.png':'$data/shared/default_specular.png',
  '$data/vehicles/stoll/stollFrontLoaderFZ/stollFrontLoaderFZ_normal.dds':'$data/shared/default_normal.png',
  '$data/vehicles/stoll/stollFrontLoaderFZ/stollFrontLoaderFZ_specular.dds':'$data/shared/default_specular.png',
 }
 tires={
  '$data/shared/wheels/mitas/SFT/SFT_normal.png':'firestone_normal',
  '$data/shared/wheels/mitas/SFT/SFT_specular.png':'firestone_specullar',
 }
 changed=0
 for item in files:
  old=item.get('filename','').replace('\\','/');new=neutral.get(old)
  reason='Mapa neutro da base FS23; o relevo/acabamento externo original não está disponível.'
  if old in tires:
   stem=tires[old]
   local=next((path.parent/(stem+ext) for ext in ('.ast','.dds','.png') if (path.parent/(stem+ext)).is_file()),None)
   if local is None:continue
   new=os.path.relpath(local.with_suffix('.png') if local.suffix=='.ast' else local,path.parent).replace(os.sep,'/')
   reason='Reutiliza o mapa de pneu local; o detalhe superficial Mitas é aproximado.'
  if new is None:continue
  item.set('filename',new);changed+=1
  report.setdefault('recursos_fs19_substituidos',[]).append({'modelo':str(path.relative_to(root)),'antes':old,'depois':new,'motivo':reason})
 return changed

def audio(root,path,tree,report):
 """Correct .wav references only when the same local .ogg is confirmed present."""
 for e in tree.iter():
  for attr in ('file','filename'):
   value=e.get(attr,'').replace('\\','/')
   if value.startswith('$') or not value.lower().endswith('.wav'):continue
   candidates=[path.parent/value,root/value]
   if any(p.is_file() for p in candidates):continue
   replacement=next((p.with_suffix('.ogg') for p in candidates if p.with_suffix('.ogg').is_file()),None)
   if replacement is None or not replacement.resolve().is_relative_to(root.resolve()):continue
   with replacement.open('rb') as f:magic=f.read(4)
   if magic!=b'OggS':continue
   e.set(attr,value[:-4]+'.ogg');report.setdefault('audio_fs19_referencias_corrigidas',[]).append({'xml':str(path.relative_to(root)),'antes':value,'depois':e.get(attr)})

def motor_audio(root,path,tree,report):
 """Migrate the known five-sample legacy tractor profile without template guesses.

 Original sound definitions and OGG bytes remain in the mod. The generated
 FS22/23 sounds.motorized.sounds section uses explicit parameters, not names
 of templates which may not exist in the target base.
 """
 if report.get('destino')!='FS23' or tree.getroot().tag!='vehicle':return
 from .converter import read_xml,save
 import os,copy
 path=path.resolve()
 vehicle=tree.getroot();old=vehicle.find('motorized/sounds')
 if old is None or not old.get('externalSoundFile'):return
 source_name=old.get('externalSoundFile').replace('\\','/')
 source=(path.parent/source_name).resolve();root=root.resolve()
 if source_name.startswith(('$','/')) or not source.is_relative_to(root) or not source.is_file():return
 if len(old) or set(old.attrib)!={'externalSoundFile'}:return
 base=vehicle.find('base')
 if base is None or base.find('sounds') is not None:return
 legacy=read_xml(source).getroot()
 if legacy.tag!='sounds' or legacy.find('motorized') is not None:return
 templates={
  'SMALL_TRACTOR_MOTOR_START':('motorStart',None),
  'SMALL_TRACTOR_MOTOR_STOP':('motorStop',None),
  'SMALL_TRACTOR_MOTOR_IDLE':('motor',[(0,1),(.2,.8),(.55,.15),(1,0)]),
  'SMALL_TRACTOR_MOTOR_OFFLOAD_RUN':('motor',[(0,0),(.15,.1),(.5,.7),(1,1)]),
  'SMALL_TRACTOR_MOTOR_ONLOAD_RUN':('motor',[(0,0),(.25,0),(.65,.5),(1,.8)]),
 }
 selected=[];found=set()
 for sample in legacy:
  template=sample.get('template');profile=templates.get(template)
  if profile is None:continue
  value=sample.get('file','').replace('\\','/')
  candidates=[path.parent/value,source.parent/value,root/value]
  if value.lower().endswith('.wav'):candidates += [p.with_suffix('.ogg') for p in candidates]
  local=next((p.resolve() for p in candidates if p.is_file() and p.resolve().is_relative_to(root)),None)
  if value.startswith(('$','/')) or local is None:continue
  with local.open('rb') as f:magic=f.read(4)
  if magic!=b'OggS':continue
  if template in found:return # Ambiguous profile: do not collapse extra variants.
  found.add(template);selected.append((sample,template,profile,local))
 if found!=set(templates):return # Keep custom/incomplete profiles unchanged.
 output=source.with_name(source.stem+'_fs23.xml')
 if output.exists():
  report['pendencias'].append('Áudio FS19 não alterado: o arquivo de destino já existe: '+str(output.relative_to(root)));return
 generated=E.Element('sounds');motorized=E.SubElement(generated,'motorized');sounds=E.SubElement(motorized,'sounds')
 for sample,template,(tag,curve),local in selected:
  e=copy.deepcopy(sample);e.tag=tag;e.attrib.pop('template',None);e.attrib.pop('parent',None)
  e.set('file',os.path.relpath(local,path.parent).replace(os.sep,'/'))
  e.set('loops','0' if tag=='motor' else '1');e.set('innerRadius','5');e.set('outerRadius','80')
  for child in list(e):
   if child.tag in ('volume','pitch'):e.remove(child)
  volume=E.SubElement(e,'volume',indoor='0.65' if tag=='motor' else '0.7',outdoor='0.85' if tag=='motor' else '1')
  pitch=E.SubElement(e,'pitch',indoor='1',outdoor='1')
  if curve:
   for value,factor in curve:E.SubElement(volume,'modifier',type='MOTOR_RPM',value=str(value),modifiedValue=str(factor))
   for value,factor in ((0,.85),(1,1.25)):E.SubElement(pitch,'modifier',type='MOTOR_RPM',value=str(value),modifiedValue=str(factor))
  sounds.append(e)
 save(E.ElementTree(generated),output)
 E.SubElement(base,'sounds',filename=os.path.relpath(output,path.parent).replace(os.sep,'/'))
 vehicle.find('motorized').remove(old)
 skipped=[e.get('template',e.tag) for e in legacy if e.get('template') not in templates]
 report.setdefault('audio_fs19_perfis_adaptados',[]).append({'veiculo':str(path.relative_to(root)),'original_preservado':str(source.relative_to(root)),'perfil':str(output.relative_to(root)),'amostras':5,'curvas':'Mistura aproximada por RPM; partida e parada sem loop.','extras_sem_amostra_local':skipped})
 if skipped:report['pendencias'].append('Perfil de motor FS19 adaptado com cinco OGG locais; sons auxiliares do perfil antigo continuam no original, sem recurso local confirmado: '+', '.join(skipped))

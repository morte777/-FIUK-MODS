"""Repair structurally unsafe load-time XML; never execute or modify game scripts."""
import math,re,xml.etree.ElementTree as E

PAIRS=('rotMean','rotVariance','rotTimeMean','rotTimeVariance','pauseMean','pauseVariance')
def pair(value):
 try:
  out=[float(v) for v in value.split()]
  return out if len(out)==2 and all(math.isfinite(v) for v in out) else None
 except (ValueError,AttributeError):return None

def random_parts(root,report,filename):
 section=root.find('randomlyMovingParts')
 if section is None:return
 for part in list(section):
  if part.tag!='randomlyMovingPart':continue
  values={key:pair(part.get(key)) for key in PAIRS}
  valid=part.get('rotAxis') in ('1','2','3') and all(v is not None for v in values.values())
  if valid:
   valid=all(values['rotTimeMean'][i]-abs(values['rotTimeVariance'][i])/2>0 and values['pauseMean'][i]-abs(values['pauseVariance'][i])/2>=0 for i in range(2))
  if not valid:
   report.setdefault('trepidacoes_desativadas',[]).append({'arquivo':filename,'motivo':'Parametros incompletos/invalidos: rotMax e speedScale nao substituem rotMean, rotTimeMean e pauseMean no carregador FS22/FS23. Somente o movimento decorativo foi desativado.','xml':E.tostring(part,encoding='unicode')})
   section.remove(part)
 if not len(section):root.remove(section)

def pto_aliases(root,model,report,filename):
 """PTO loader passes its I3D root alone, with no named i3dMappings table."""
 scene=model.find('Scene')
 if scene is None:raise ValueError('Carda sem Scene: '+filename)
 mapping={e.get('id'):e.get('node') for e in root.findall('i3dMappings/i3dMapping')}
 edits=[]
 for item in root.iter():
  if item.tag=='i3dMapping':continue
  for key in ('node','referenceNode'):
   alias=item.get(key)
   if alias not in mapping:continue
   path=mapping[alias]
   if not re.fullmatch(r'\d+>(?:\d+(?:\|\d+)*)?',path or ''):raise ValueError('Mapeamento de carda invalido: '+str(alias))
   first,tail=path.split('>',1);numeric=first+('|' + tail if tail else '')
   current=scene
   try:
    for value in numeric.split('|'):current=list(current)[int(value)]
   except (IndexError,ValueError):raise ValueError('No do carda nao existe: '+alias+' em '+filename)
   edits.append((item,key,alias,numeric))
 for item,key,alias,numeric in edits:
  item.set(key,numeric);report.setdefault('cardas_indices_corrigidos',[]).append({'arquivo':filename,'atributo':key,'antes':alias,'depois':numeric})

def fs23_optional_resources(root,report,filename):
 """Only exact unavailable cosmetic resources evidenced in the supplied FS23 log.
 No guessed replacement filename and no change to sowing/fill/work-area logic.
 """
 missing_connectors='$data/shared/connectionHoses/connectors.i3d'
 parts=root.find('dynamicallyLoadedParts')
 removed=0
 if parts is not None:
  for part in list(parts):
   if part.get('filename','').replace('\\','/')==missing_connectors:
    report.setdefault('recursos_visuais_fs23_desativados',[]).append({'arquivo':filename,'motivo':'Conector ausente no FS23 confirmado na log da Summer.','xml':E.tostring(part,encoding='unicode')});parts.remove(part);removed+=1
# Preserve the existing static hose geometry; only the dynamic declarations go.
 hoses=root.find('connectionHoses')
 if removed and hoses is not None:
  report.setdefault('mangueiras_fs23_pendentes',[]).append({'arquivo':filename,'motivo':'Catalogo de mangueiras ausente na log FS23: declaracoes preservadas para revisao, sem inventar substitutos.','xml':E.tostring(hoses,encoding='unicode')})
 for effect in root.findall('workParticles/effect'):
  for node in list(effect):
   if node.tag!='effectNode':continue
   motion=node.find('motionPathEffect')
   if motion is not None and motion.get('textureFilename','').replace('\\','/')=='$data/vehicles/kinze/planter4900/discEffect01Array.dds':
    report.setdefault('recursos_visuais_fs23_desativados',[]).append({'arquivo':filename,'motivo':'Array de efeito Kinze inexistente no FS23 confirmado pela log. Particula de poeira e areas de plantio preservadas.','xml':E.tostring(node,encoding='unicode')});effect.remove(node)

"""Offline DDS 2D decoding and lossless GS2D RGBA8 export with mipmaps.
DDS is decoded only on request; opening a mod never changes its textures.
"""
import base64,ctypes,hashlib,io,math,platform,struct,sys,zlib
from pathlib import Path

DXGI={70:('BC1',8),73:('BC2',16),76:('BC3',16),79:('BC4',8),82:('BC5',16),97:('BC7',16),28:('RGBA8',4),29:('RGBA8 sRGB',4),71:('BC1',8),72:('BC1 sRGB',8),74:('BC2',16),75:('BC2 sRGB',16),77:('BC3',16),78:('BC3 sRGB',16),80:('BC4',8),83:('BC5',16),84:('BC5S',16),87:('BGRA8',4),88:('BGRX8',4),91:('BGRA8 sRGB',4),98:('BC7',16),99:('BC7 sRGB',16)}
FOURCC={b'DXT1':('BC1',8),b'DXT3':('BC2',16),b'DXT5':('BC3',16),b'ATI1':('BC4',8),b'BC4U':('BC4',8),b'ATI2':('BC5',16),b'BC5U':('BC5',16),b'BC5S':('BC5S',16)}

def image_module():
 try:
  from PIL import Image
  return Image
 except ImportError:
  abi={'aarch64':'arm64_v8a','arm64':'arm64_v8a','x86_64':'x86_64','AMD64':'x86_64'}.get(platform.machine())
  folder=Path(__file__).parent/'codecs_vendor/pillow_android'/str(abi)
  if not folder.is_dir():raise ValueError('Decodificador DDS nao disponivel nesta arquitetura.')
  for path in folder.rglob('libjpeg_chaquopy.so'):ctypes.CDLL(str(path),mode=ctypes.RTLD_GLOBAL)
  sys.path.insert(0,str(folder))
  from PIL import Image
  return Image

def header(raw,check_payload=True):
 if len(raw)<128 or raw[:4]!=b'DDS ' or struct.unpack_from('<I',raw,4)[0]!=124 or struct.unpack_from('<I',raw,76)[0]!=32:raise ValueError('Cabecalho DDS invalido ou truncado.')
 flags,h,w,pitch,depth,count=struct.unpack_from('<6I',raw,8);pf=struct.unpack_from('<I',raw,80)[0];four=raw[84:88];bits=struct.unpack_from('<I',raw,88)[0];caps2=struct.unpack_from('<I',raw,112)[0]
 if not 1<=w<=16384 or not 1<=h<=16384:raise ValueError('Dimensoes DDS invalidas.')
 if depth>1 or caps2&(0xfe00|0x200000):raise ValueError('DDS array, cubemap ou volume: mantenha o original; esta ferramenta converte texturas 2D individuais.')
 count=max(count,1)
 if count>1+int(math.log2(max(w,h))):raise ValueError('Quantidade de mipmaps DDS invalida.')
 start=128;compressed=False
 if pf&4:
  if four==b'DX10':
   if len(raw)<148:raise ValueError('Cabecalho DDS DX10 truncado.')
   fmt,dimension,misc,layers,_=struct.unpack_from('<5I',raw,128)
   if dimension!=3 or layers!=1 or misc&4:raise ValueError('DDS array, cubemap ou volume nao e convertido como textura 2D.')
   if fmt not in DXGI:raise ValueError('Formato DDS DX10 nao suportado: '+str(fmt))
   label,unit=DXGI[fmt];compressed=label.startswith('BC');start=148
  elif four in FOURCC:label,unit=FOURCC[four];compressed=True
  else:raise ValueError('Compressao DDS nao suportada: '+repr(four))
 else:
  if not pf&0x40 or bits not in (24,32):raise ValueError('DDS sem compressao exige RGB ou RGBA de 24/32 bits.')
  label='RGBA8' if bits==32 else 'RGB8';unit=bits//8
  if flags&8 and pitch not in (0,w*unit):raise ValueError('DDS RGB com espacamento de linhas especial nao suportado.')
 levels=[];offset=start
 for i in range(count):
  a,b=max(1,w>>i),max(1,h>>i);size=((a+3)//4)*((b+3)//4)*unit if compressed else a*b*unit
  levels.append((a,b,offset,size));offset+=size
 if check_payload and len(raw)<offset:raise ValueError('Pixels ou mipmaps DDS truncados.')
 return dict(width=w,height=h,format=label,mipmaps=count,start=start,levels=levels,compressed=compressed,unit=unit,expectedBytes=offset)

def level_image(raw,info,level=0):
 Image=image_module();w,h,offset,size=info['levels'][level]
 if w*h>4096*4096:raise ValueError('O nivel DDS excede 4096 x 4096 pixels. Use uma fonte com mipmaps menores ou reduza a imagem fora do editor.')
 head=bytearray(raw[:info['start']]);struct.pack_into('<II',head,12,h,w);struct.pack_into('<I',head,20,size if info['compressed'] else w*info['unit']);struct.pack_into('<I',head,28,1)
 # Normalize DX10 aliases which Pillow 11 does not expose, without changing
 # any compressed payload bits. BGRA masks are described in a legacy header.
 if raw[84:88]==b'DX10':
  fmt=struct.unpack_from('<I',raw,128)[0]
  legacy={70:b'DXT1',71:b'DXT1',72:b'DXT1',73:b'DXT3',74:b'DXT3',75:b'DXT3',76:b'DXT5',77:b'DXT5',78:b'DXT5',79:b'ATI1',80:b'ATI1',82:b'ATI2',83:b'ATI2'}
  if fmt in legacy:head=head[:128];head[84:88]=legacy[fmt]
  elif fmt in (87,88,91):
   head=head[:128];struct.pack_into('<I',head,80,0x40|(1 if fmt!=88 else 0));head[84:88]=b'\0'*4;struct.pack_into('<5I',head,88,32,0xff0000,0xff00,0xff,0xff000000 if fmt!=88 else 0)
 # Pillow decodes a single DDS level. Keep the channel values (including alpha)
 # and do not apply ICC/sRGB conversions or infer/repack normal-map channels.
 try:
  with Image.open(io.BytesIO(bytes(head)+raw[offset:offset+size]),formats=['DDS']) as image:return image.convert('RGBA')
 except (OSError,ValueError,NotImplementedError) as error:raise ValueError('DDS nao pode ser decodificado: '+str(error))

def preview_png(raw,limit=2048):
 info=header(raw);limit=max(32,min(2048,int(limit)));i=next((i for i,(w,h,_,_)in enumerate(info['levels']) if max(w,h)<=limit),None)
 image=level_image(raw,info,i if i is not None else 0)
 try:
  if max(image.size)>limit:image.thumbnail((limit,limit),image_module().Resampling.BOX)
  out=io.BytesIO();image.save(out,format='PNG');return out.getvalue()
 finally:image.close()

def gs2d_levels(levels):
 """RGBA rows supplied in top-down image order, packed in GIANTS bottom-up order."""
 w,h,_=levels[0];count=len(levels);chunks=[];md5=hashlib.md5();flipped=[]
 for a,b,pixels in levels:
  if len(pixels)!=a*b*4:raise ValueError('Pixels RGBA incompletos.')
  rows=b''.join(pixels[y*a*4:(y+1)*a*4] for y in range(b-1,-1,-1));flipped.append(rows);md5.update(rows)
 data=list(reversed(flipped)) if count<=4 else [b''.join(flipped[3:]),flipped[2],flipped[1],flipped[0]]
 for raw in data:
  compressed=zlib.compress(raw,6);chunks.append(compressed if len(compressed)<len(raw) else raw)
 sizes=[len(c) for c in chunks]+[0]*(4-len(chunks));payload=b''.join(c+b'\0'*((-len(c))%16) for c in chunks)
 return struct.pack('<4s12I16s3I',b'GS2D',6,len(payload),w,h,1,((count-1)<<16)|4,1,4,*sizes,hashlib.md5(payload).digest(),5,1,1)+payload

def convert(raw,max_size=0):
 info=header(raw);max_size=int(max_size)
 if max_size not in (0,256,512,1024,2048,4096):raise ValueError('Resolucao invalida.')
 start=next((i for i,(w,h,_,_)in enumerate(info['levels']) if max(w,h)<=max_size),None) if max_size else 0
 start=start if start is not None else 0;levels=[];Image=image_module()
 for i in range(start,len(info['levels'])):
  image=level_image(raw,info,i)
  try:
   if i==start and max_size and max(image.size)>max_size:
    image.thumbnail((max_size,max_size),Image.Resampling.BOX)
   w,h=image.size
   if w&(w-1) or h&(h-1):raise ValueError('Para AST com mipmaps, a largura e a altura precisam ser potencias de 2.')
   levels.append((w,h,image.tobytes()))
   if i==start and (w,h)!=tuple(info['levels'][i][:2]):break
  finally:image.close()
 # Preserve all source mip pixels. Generate only missing levels, channel-wise:
 # alpha can carry material data, so never premultiply or recolor these maps.
 import numpy as np
 w,h,pixels=levels[-1]
 while w>1 or h>1:
  nw,nh=max(1,w//2),max(1,h//2);array=np.frombuffer(pixels,dtype=np.uint8).reshape(h,w,4).astype(np.uint16)
  ys=[slice(0,None,2),slice(1,None,2)] if h>1 else [slice(None)];xs=[slice(0,None,2),slice(1,None,2)] if w>1 else [slice(None)]
  samples=[array[y,x] for y in ys for x in xs];result=sum(samples);pixels=((result+len(samples)//2)//len(samples)).astype(np.uint8).tobytes();w,h=nw,nh;levels.append((w,h,pixels))
 return gs2d_levels(levels),dict(width=levels[0][0],height=levels[0][1],mipmaps=len(levels),encoding='GS2D RGBA8',sourceFormat=info['format'])

"""Editor-only locks and atomic operations on a normalized multi-selection."""
import copy,json,math,xml.etree.ElementTree as ET
from core import I3D,atomic,jsonbytes,tagname
from scene_tools import context,audit_move,ANCHOR,encoded
from decals import spans
from xml_edit import whole_end,next_id,fragment,section,attributes

def view_state(editor,model):
    if model not in editor.archive_index()[0].values():raise ValueError('Modelo nao encontrado no projeto.')
    path=editor.project/'editor_view.json'
    data=json.loads(path.read_text()) if path.exists() else {}
    return {'project':editor.project.name,'file':model,'locked':data.get(model,{}).get('locked',[])}

def save_view(editor,body):
    with editor.lock:
        if not editor.project or body.get('project')!=editor.project.name:raise ValueError('O projeto mudou. Reabra a cena.')
        current=view_state(editor,body['file']);locked=body.get('locked')
        if not isinstance(locked,list) or len(locked)>2000 or any(not isinstance(k,str) or not 1<=len(k)<=300 for k in locked):raise ValueError('Lista de travas invalida.')
        path=editor.project/'editor_view.json';data=json.loads(path.read_text()) if path.exists() else {}
        data[body['file']]={'locked':list(dict.fromkeys(locked))};atomic(path,jsonbytes(data))
        return {**current,'locked':data[body['file']]['locked']}

def normalize(nodes,indices):
    if not isinstance(indices,list) or not 1<=len(indices)<=50 or any(type(i)!=int or not 0<=i<len(nodes) for i in indices):raise ValueError('Selecione de 1 a 50 pecas.')
    selected=set(indices);out=[]
    for index in sorted(selected):
        parent=nodes[index]['parent']
        while parent is not None and parent not in selected:parent=nodes[parent]['parent']
        if parent is None:out.append(index)
    return out

def node_keys(nodes):
    from collections import Counter
    counts=Counter(n['nodeId'] for n in nodes if n.get('nodeId'));ordinal={};paths=[];keys=[]
    for n in nodes:
        i=ordinal.get(n['parent'],0);ordinal[n['parent']]=i+1
        paths.append(str(i) if n['parent'] is None else paths[n['parent']]+'|'+str(i))
        keys.append('id:'+n['nodeId'] if n.get('nodeId') and counts[n['nodeId']]==1 else 'path:'+paths[-1])
    return keys

def apply(editor,body):
    with editor.lock:
        if not editor.project or body.get('project')!=editor.project.name or body.get('revision')!=editor.meta()['revision']:raise ValueError('O projeto mudou. Selecione as pecas novamente.')
        name=body['file'];original=I3D(editor.read(name));indices=normalize(original.nodes,body.get('indices'))
        doc,items,roots,selected=context(editor,name,indices)
        keys=node_keys(doc.nodes);locked=set(view_state(editor,name)['locked']);affected=set()
        for n in doc.nodes:
            if n['index'] in indices or n['parent'] in affected:affected.add(n['index'])
        for i in affected:
            cursor=i
            while cursor is not None:
                if keys[cursor] in locked:raise ValueError('A selecao contem pecas travadas. Destrave antes de editar.')
                cursor=doc.nodes[cursor]['parent']
        action=body.get('action');raw=editor.read(name)
        if action=='move':
            from pose_tools import world,inverse,mv
            delta=body.get('delta')
            if not isinstance(delta,list) or len(delta)!=3 or any(type(v) not in (int,float) or not math.isfinite(v) or abs(v)>100 for v in delta):raise ValueError('Deslocamento entre -100 e 100 metros por eixo.')
            matrices=world(doc.nodes)
            for index in indices:
                node=doc.nodes[index];local=mv(inverse(matrices[node['parent']][0]),delta);translation=[a+b for a,b in zip(node['translation'],local)]
                raw=I3D(raw).patch(index,{'translation':translation})
        elif action=='visibility':
            if type(body.get('visible'))!=bool:raise ValueError('Visibilidade invalida.')
            for index in indices:raw=I3D(raw).patch(index,{'visibility':body['visible']})
        elif action=='delete':
            audit_move(editor,name,doc,items,roots,selected);changes=[];serial=next_id(doc,'nodeId');ids={e['attrs'].get('nodeId') for e in selected}-{None}
            for index,item in roots.items():
                placeholder=ET.Element('TransformGroup',{'name':ANCHOR+str(serial),'nodeId':str(serial)});serial+=1;changes.append((item['start'],whole_end(doc,item),ET.tostring(placeholder,encoding='utf-8')))
            for item in items:
                if item['local']=='UserAttribute' and item['attrs'].get('nodeId') in ids:changes.append((item['start'],whole_end(doc,item),b''))
            raw=doc.utf8
            for a,b,replacement in sorted(changes,reverse=True):raw=raw[:a]+replacement+raw[b:]
            raw=encoded(doc,raw)
        elif action=='paint':raw=paint(editor,name,doc,indices,body.get('channel'),body.get('color'))
        else:raise ValueError('Operacao de selecao desconhecida.')
        I3D(raw);project=editor.change(name,raw,body['revision'])
        return {'project':project,'count':len(indices),'action':action}

def paint(editor,name,doc,indices,channel,color):
    from painting import linear_color,used_slots
    rgb=linear_color(color);scene=editor.scene(name,include_wheels=False);included=set();targets=[];material_ids=set()
    for node in scene['nodes']:
        if node['index'] not in indices and node['parent'] not in included:continue
        included.add(node['index'])
        if node['nonRenderable'] or not node.get('shapeId'):continue
        mids=node['materialIds'].split()
        for slot,mid in enumerate(mids):
            m=scene['materialDetails'].get(mid,{})
            allowed=['convertedColor'] if m.get('shaderFamily')=='convertedFS25' else ['base'] if m.get('shaderFamily')!='vehicle' else ['colorMat'+str(i) for i in used_slots(scene['meshes'].get(node['shapeId']),slot)] if m.get('colorMask') else []
            if channel not in allowed:raise ValueError('O canal de cor nao existe em todas as pecas. Selecione pelo mesmo material ou escolha outro canal.')
            material_ids.add(mid)
        if mids:targets.append(node['index'])
    if not targets:raise ValueError('Selecione pecas com materiais visuais.')
    raw=editor.read(name);mapping={};serial=next_id(doc,'materialId');_,items=spans(doc.text)
    for mid in sorted(material_ids):
        item=next(e for e in items if e['local']=='Material' and e['attrs'].get('materialId')==mid);m=ET.fromstring(fragment(doc,item));new=str(serial);serial+=1;mapping[mid]=new;m.set('materialId',new);m.set('name',(m.get('name') or 'Material')+' selecao')
        if channel=='base':
            values=m.get('diffuseColor','1 1 1 1').split();alpha=values[3] if len(values)>3 else '1';m.set('diffuseColor',' '.join([*(format(v,'.9g') for v in rgb),alpha]))
        else:
            p=next((c for c in m if tagname(c.tag)=='CustomParameter' and c.get('name')==channel),None)
            if p is None:p=ET.SubElement(m,'CustomParameter',{'name':channel});fourth=scene['materialDetails'][mid]['convertedColor'][3] if channel=='convertedColor' else scene['materialDetails'][mid]['paletteRGBA'][int(channel[-1])][3]
            else:
                values=p.get('value','').split();fourth=float(values[3]) if len(values)>3 else 0
            p.set('value',' '.join(format(v,'.9g') for v in rgb+[fourth]))
        raw=section(I3D(raw),'Materials',ET.tostring(m,encoding='utf-8'))
    for index in targets:
        current=I3D(raw);_,items=spans(current.text);item=next(e for e in items if e['start']==current.spans[index][0]);raw=attributes(current,item,{'materialIds':' '.join(mapping.get(mid,mid) for mid in current.nodes[index]['materialIds'].split())})
    return raw

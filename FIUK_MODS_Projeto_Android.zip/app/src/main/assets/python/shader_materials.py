"""Preview metadata adapted from the user's FS23 vehicleShader.xml.

Reads numeric defaults, resource paths and known feature flags only. Does not
execute shader code. The medium-profile material lookup is reproduced in WebGL.
"""
import math,posixpath,re,xml.etree.ElementTree as ET

DEFAULT_PALETTE=[[.8,.55,.05,1],[1,.1,.1,1],[.1,1,.1,1],[.1,.1,1,1],[1,1,.1,1],[.05,.05,.05,1],[1,.1,1,1],[.1,1,1,1]]
CONVERTED_VARIATIONS={'convertedfs25','convertedfs25decal','convertedfs25light','convertedfs25rim'}
CONVERTED_DEFAULTS={'convertedColor':[1,1,1,1],'convertedSurface':[.65,1,.1,0]}

def supported(material):
    shader=material.get('shader','')
    return posixpath.basename(shader.replace('\\','/')).casefold() in ('vehicleshader.xml','vehicleshadercompat.xml') or bool(shader and material.get('variation','').casefold() in CONVERTED_VARIATIONS and 'convertedColor' in material.get('customParameters',{}))

DEFAULT_TEXTURES={'detailDiffuse':'../shared/detailArrayPixels_diffuse.png','detailSpecular':'../shared/detailArrayPixels_specular.png'}

def floats(value,size):
    try:
        out=[float(v) for v in value.split()[:size]]
        return out if len(out)==size and all(math.isfinite(v) for v in out) else None
    except (ValueError,AttributeError):return None

def descriptor(raw=None):
    result={'palette':[p[:] for p in DEFAULT_PALETTE],'textures':dict(DEFAULT_TEXTURES),'variations':{},'convertedDefaults':{k:v[:] for k,v in CONVERTED_DEFAULTS.items()}}
    if raw is None:return result
    if len(raw)>4*1024*1024 or re.search(br'<!\s*(?:DOCTYPE|ENTITY)',raw,re.I):raise ValueError('Shader XML invalido.')
    root=ET.fromstring(raw)
    if root.tag!='CustomShader':raise ValueError('Esperado CustomShader XML.')
    for parameter in root.findall('./Parameters/Parameter'):
        if parameter.get('name') in CONVERTED_DEFAULTS:
            default=floats(parameter.get('defaultValue'),4)
            if default:result['convertedDefaults'][parameter.get('name')]=default
        if parameter.get('name')=='colorMat':
            default=floats(parameter.get('defaultValue'),4)
            if default:result['palette']=[default[:] for _ in range(8)]
            for child in parameter.findall('Default'):
                try:index=int(child.get('index'))
                except (ValueError,TypeError):continue
                color=floats(child.text,4)
                if color and 0<=index<8:result['palette'][index]=color
    for texture in root.findall('./Textures/Texture'):
        role={'mPixelsDiffuse':'detailDiffuse','mPixelsSpecular':'detailSpecular'}.get(texture.get('name'))
        if role and texture.get('defaultFilename'):result['textures'][role]=texture.get('defaultFilename')
    for variation in root.findall('./Variations/Variation'):
        flags=set(re.findall(r'#\s*define\s+(\w+)',variation.text or ''))
        if 'colorMask' in variation.get('groups','').split():flags.add('COLOR_MASK')
        for uv in variation.findall('./UvUsages/UvUsage'):
            if uv.get('textureName')=='glossMap' and uv.get('uvType')=='uv1':flags.add('SPECULAR_SECONDUV')
            if uv.get('textureName')=='normalMap' and uv.get('uvType')=='uv2':flags.add('NORMAL_THIRDUV')
        result['variations'][variation.get('name','').casefold()]=flags
    return result

def apply(material,profile,shader_path):
    variation=material.get('variation','');low=variation.casefold()
    flags=profile['variations'].get(low)
    if flags is None:
        # Supported variations in the supplied source. Unknown flags are ignored.
        flags=set()
        if 'colormask' in low or low.startswith(('staticlight','tirepressuredeformation')):flags.add('COLOR_MASK')
        if 'seconduv' in low or low.startswith('decal'):flags.add('SPECULAR_SECONDUV')
        if 'normalthirduv' in low:flags.add('NORMAL_THIRDUV')
    if low in CONVERTED_VARIATIONS or 'CONVERTED_FS25' in flags:
        # Compatibility shader multiplies diffuse RGB by convertedColor and uses
        # a uniform surface. Its UVs are texture coordinates, never palette IDs.
        params=material.get('customParameters',{})
        values={key:floats(' '.join(params.get(key,[])),4) or profile.get('convertedDefaults',CONVERTED_DEFAULTS)[key][:] for key in CONVERTED_DEFAULTS}
        factor=material.get('diffuseColorFactor',material.get('baseColor',[1,1,1]))[:]
        material.update({'shaderFamily':'convertedFS25','colorMask':False,
            'secondUV':'SPECULAR_SECONDUV' in flags or low=='convertedfs25decal',
            'normalThirdUV':'NORMAL_THIRDUV' in flags,'diffuseColorFactor':factor,
            'baseColor':[a*b for a,b in zip(factor,values['convertedColor'][:3])],**values})
        material['maps'].pop('detailDiffuse',None);material['maps'].pop('detailSpecular',None)
        return material
    material['shaderFamily']='vehicle'
    material['colorMask']='COLOR_MASK' in flags
    material['secondUV']='SPECULAR_SECONDUV' in flags
    material['normalThirdUV']='NORMAL_THIRDUV' in flags
    params=material.get('customParameters',{})
    palette=[]
    for i,default in enumerate(profile['palette']):
        supplied=floats(' '.join(params.get('colorMat'+str(i),[])),4)
        palette.append(supplied or default[:])
    material['paletteRGBA']=palette;material['palette']=[p[:3] for p in palette]
    custom=material.get('customMaps',{})
    for role,filename in profile['textures'].items():
        key='mPixelsDiffuse' if role=='detailDiffuse' else 'mPixelsSpecular'
        if custom.get(key):material['maps'][role]=custom[key];continue
        material['maps'][role]=posixpath.normpath(posixpath.join(posixpath.dirname(shader_path),filename))
    return material

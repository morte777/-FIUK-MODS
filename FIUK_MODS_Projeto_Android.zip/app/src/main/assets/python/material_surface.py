"""Material opacity and basic specular strength, without altering shader palettes."""
import copy,math,xml.etree.ElementTree as ET
from core import I3D
from painting import options
from decals import spans
from xml_edit import fragment,replace,section,attributes,next_id

def info(editor,name,index):
    available=options(editor,name,index);doc=I3D(editor.read(name));root=ET.fromstring(doc.text)
    for row in available['materials']:
        m=next(m for m in root.findall('Materials/Material') if m.get('materialId')==row['id'])
        rgba=m.get('diffuseColor','1 1 1 1').split();opacity=float(rgba[3]) if len(rgba)>3 else 1
        row.update({'opacity':opacity,'blending':m.get('alphaBlending') in ('true','1'),'gloss':sum(float(v) for v in m.get('specularColor','.08 .08 .08').split()[:3])/3,'glossSupported':not m.get('customShaderId')})
    return available
def save(editor,body):
    with editor.lock:
        if body.get('project')!=editor.project.name or body['revision']!=editor.meta()['revision']:raise ValueError('O projeto mudou. Reabra os materiais.')
        available=info(editor,body['file'],body['index']);mid=str(body['materialId']);row=next((r for r in available['materials'] if r['id']==mid),None)
        if row is None:raise ValueError('Material nao pertence a peca selecionada.')
        opacity=body['opacity'];gloss=body.get('gloss')
        if type(opacity) not in (int,float) or not math.isfinite(opacity) or not 0<=opacity<=1:raise ValueError('Opacidade entre 0 e 1.')
        if gloss is not None and (not row['glossSupported'] or type(gloss) not in (int,float) or not math.isfinite(gloss) or not 0<=gloss<=1):raise ValueError('Brilho indisponivel neste shader ou fora de 0 a 1.')
        if type(body.get('shared'))!=bool:raise ValueError('Escolha o alcance do material.')
        doc=I3D(editor.read(body['file']));_,elements=spans(doc.text);item=next(e for e in elements if e['local']=='Material' and e['attrs'].get('materialId')==mid);m=ET.fromstring(fragment(doc,item));rgba=m.get('diffuseColor','1 1 1 1').split()[:3];m.set('diffuseColor',' '.join(rgba+[format(opacity,'.9g')]));m.set('alphaBlending','true' if body.get('blending') or opacity<1 else 'false')
        if gloss is not None:m.set('specularColor',' '.join([format(gloss,'.9g')]*3))
        if body['shared']:raw=replace(doc,item,ET.tostring(m,encoding='utf-8'))
        else:
            new=str(next_id(doc,'materialId'));m.set('materialId',new);m.set('name',(m.get('name') or 'Material')+' editado');raw=section(doc,'Materials',ET.tostring(m,encoding='utf-8'));patched=I3D(raw);_,items=spans(patched.text);node=next(e for e in items if e['start']==patched.spans[body['index']][0]);raw=attributes(patched,node,{'materialIds':' '.join(new if v==mid else v for v in patched.nodes[body['index']]['materialIds'].split())})
        return {'project':editor.change(body['file'],raw,body['revision']),'index':body['index']}

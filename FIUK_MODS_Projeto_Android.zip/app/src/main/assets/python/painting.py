"""Paint diffuse materials or the actual colorMask palette slots used by a shape."""
import base64,copy,math,re,struct,xml.etree.ElementTree as ET
from core import I3D,tagname
from decals import spans,append_element
from xml_edit import attributes,fragment,replace,section,next_id

def linear_color(hex_color):
    if not isinstance(hex_color,str) or not re.fullmatch(r'#[0-9a-fA-F]{6}',hex_color):raise ValueError('Escolha uma cor no formato #RRGGBB.')
    srgb=[int(hex_color[i:i+2],16)/255 for i in (1,3,5)]
    return [v/12.92 if v<=.04045 else ((v+.055)/1.055)**2.4 for v in srgb]
def hex_color(values):
    values=[max(0,min(1,float(v))) for v in values[:3]]
    srgb=[12.92*v if v<=.0031308 else 1.055*v**(1/2.4)-.055 for v in values]
    return '#'+''.join(f'{max(0,min(255,round(v*255))):02x}' for v in srgb)
def floats(raw):
    data=base64.b64decode(raw);return struct.unpack('<'+'f'*(len(data)//4),data)
def used_slots(mesh,slot):
    if not mesh:return []
    if mesh.get('uvSetsBase64'):
        uv=floats(mesh['uvSetsBase64'][0]) if mesh['uvSetsBase64'][0] else []
        data=base64.b64decode(mesh['indicesBase64']);code='I' if mesh['indexType']=='u32' else 'H';indices=struct.unpack('<'+code*(len(data)//struct.calcsize(code)),data)
    else:uv=[v for row in mesh.get('uvs',[]) for v in row];indices=mesh.get('indices',[])
    subsets=mesh.get('subsets') or []
    if subsets:
        if slot>=len(subsets):return []
        subset=subsets[slot];indices=indices[subset['firstIndex']:subset['firstIndex']+subset['numIndices']]
    result=set()
    for index in indices:
        if index*2+1<len(uv) and uv[index*2+1]<0:result.add(max(0,min(7,math.floor(uv[index*2]))))
    return sorted(result)
def options(editor,name,index):
    doc=I3D(editor.read(name));scene=editor.scene(name,include_wheels=False)
    if not isinstance(index,int) or not 0<=index<len(doc.nodes):raise ValueError('Selecione uma peca do I3D principal.')
    node=scene['nodes'][index];ids=node['materialIds'].split();out=[]
    for mid in dict.fromkeys(ids):
        material=scene['materialDetails'].get(mid)
        if not material:continue
        choices=[];note=''
        if material.get('shaderFamily')=='convertedFS25':
            choices=[{'key':'convertedColor','label':'Cor convertida FS25','color':hex_color(material['convertedColor'][:3])}]
            note='Cor do shader convertido, preservando a textura e o acabamento.'
        elif material.get('shaderFamily')=='vehicle':
            slots=set()
            if material.get('colorMask'):
                for slot,m in enumerate(ids):
                    if m==mid:slots.update(used_slots(scene['meshes'].get(node['shapeId']),slot))
            for slot in sorted(slots):choices.append({'key':'colorMat'+str(slot),'label':'Cor '+str(slot+1),'color':hex_color(material['paletteRGBA'][slot][:3])})
            if not choices:note='Este trecho usa cores da tabela do shader, sem canal colorMask editavel. Escolha outra peca/material.'
        else:
            choices=[{'key':'base','label':'Cor base','color':hex_color(material.get('baseColor',[1,1,1]))}]
            note='A cor base multiplica a textura; desenhos e detalhes permanecem.'
        out.append({'id':mid,'name':material.get('name') or 'Material '+mid,'choices':choices,'note':note,'shared':sum(mid in n['materialIds'].split() for n in doc.nodes)})
    return {'index':index,'name':node['name'],'materials':out,'revision':editor.meta()['revision']}

def paint(editor,name,index,material_id,channel,color,shared,revision):
    with editor.lock:
        if revision!=editor.meta()['revision']:raise ValueError('Projeto mudou. Reabra a pintura.')
        if not isinstance(shared,bool):raise ValueError('Opcao de material compartilhado invalida.')
        rgb=linear_color(color);available=options(editor,name,index)
        material=next((m for m in available['materials'] if m['id']==str(material_id)),None)
        if not material or channel not in [c['key'] for c in material['choices']]:raise ValueError('Este canal de cor nao esta disponivel na peca selecionada.')
        doc=I3D(editor.read(name));raw,elements=spans(doc.text)
        item=next(e for e in elements if e['local']=='Material' and e['attrs'].get('materialId')==str(material_id))
        original=ET.fromstring(fragment(doc,item));modified=copy.deepcopy(original)
        def numbers(text,default):
            try:
                v=[float(x) for x in text.split()]
                return v if all(math.isfinite(x) for x in v) else default
            except (ValueError,AttributeError):return default
        if channel=='base':
            old=numbers(modified.get('diffuseColor'),[1,1,1,1]);alpha=old[3] if len(old)>3 else 1
            modified.set('diffuseColor',' '.join(format(v,'.9g') for v in rgb+[alpha]))
        else:
            child=next((e for e in modified if tagname(e.tag)=='CustomParameter' and e.get('name')==channel),None)
            if child is None:
                child=ET.SubElement(modified,'CustomParameter',{'name':channel})
                profile=editor.scene(name,include_wheels=False)['materialDetails'][str(material_id)]
                old=profile['convertedColor'] if channel=='convertedColor' else profile['paletteRGBA'][int(channel[-1])]
            else:old=numbers(child.get('value'),[1,1,1,0])
            fourth=old[3] if len(old)>3 else 0
            child.set('value',' '.join(format(v,'.9g') for v in rgb+[fourth]))
        target_id=str(material_id)
        if shared:raw=replace(doc,item,ET.tostring(modified,encoding='utf-8'))
        else:
            target_id=str(next_id(doc,'materialId'));modified.set('materialId',target_id);modified.set('name',(modified.get('name') or 'Material')+' pintado')
            raw=section(doc,'Materials',ET.tostring(modified,encoding='utf-8'));patched=I3D(raw)
            _,updated=spans(patched.text);node_item=next(e for e in updated if e['start']==patched.spans[index][0])
            ids=patched.nodes[index]['materialIds'].split();ids=[target_id if mid==str(material_id) else mid for mid in ids]
            raw=attributes(patched,node_item,{'materialIds':' '.join(ids)})
        result=editor.change(name,raw,revision)
        return {'project':result,'index':index,'materialId':target_id}

"""Small span edits; unrelated XML bytes and encoding remain intact."""
import re
from xml.sax.saxutils import quoteattr
from decals import spans,append_element

def whole_end(document,item):
    return item['openEnd'] if item['empty'] else document.utf8.index(b'>',item['close'])+1

def fragment(document,item):return document.utf8[item['start']:whole_end(document,item)]
def replace(document,item,content):
    raw=document.utf8
    return (raw[:item['start']]+content+raw[whole_end(document,item):]).decode().encode(document.encoding,errors='xmlcharrefreplace')
def attributes(document,item,values):
    raw=document.utf8;tag=raw[item['start']:item['openEnd']].decode()
    for key,value in values.items():
        match=next((m for m in re.finditer(r'([\w:.-]+)(\s*=\s*)([\"\'])(.*?)\3',tag,re.S) if m.group(1)==key),None)
        if match:tag=tag[:match.start()]+key+match.group(2)+quoteattr(str(value))+tag[match.end():]
        else:
            at=tag.rfind('/>')
            if at<0:at=tag.rfind('>')
            tag=tag[:at]+' '+key+'='+quoteattr(str(value))+tag[at:]
    return (raw[:item['start']]+tag.encode()+raw[item['openEnd']:]).decode().encode(document.encoding,errors='xmlcharrefreplace')
def section(document,name,child):
    raw,elements=spans(document.text);item=next((e for e in elements if e['depth']==1 and e['local']==name),None)
    if item:raw=append_element(raw,item,child)
    else:
        order=['Files','Materials','Shapes','Dynamics','Scene','Animation','UserAttributes'];rank=order.index(name)
        after=next((e for e in elements if e['depth']==1 and e['local'] in order and order.index(e['local'])>rank),None)
        at=after['start'] if after else elements[0]['close'];raw=raw[:at]+f'<{name}>'.encode()+child+f'</{name}>'.encode()+raw[at:]
    return raw.decode().encode(document.encoding,errors='xmlcharrefreplace')
def next_id(document,attribute):
    _,elements=spans(document.text)
    return max([int(e['attrs'][attribute]) for e in elements if e['attrs'].get(attribute,'').isdigit()]+[0])+1

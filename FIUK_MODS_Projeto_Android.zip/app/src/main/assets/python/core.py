"""Gabriel Mods Editor: portable project and I3D editing core. Python stdlib only."""
import hashlib
import gzip
import json
import math
import os
import posixpath
from pathlib import Path, PurePosixPath
import re
import shutil
import threading
import uuid
import xml.etree.ElementTree as ET
from xml.parsers import expat
from xml.sax.saxutils import escape
import zipfile

MAX_XML = 32 * 1024 * 1024
TRANSFORMS = {'translation', 'rotation', 'scale', 'visibility'}

def atomic(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_bytes(data)
    os.replace(tmp, path)

def jsonbytes(value):
    return json.dumps(value, ensure_ascii=False, allow_nan=False).encode('utf-8')

def tagname(name):
    return name.rsplit('}', 1)[-1].rsplit(':', 1)[-1]

def vector(text, default):
    if text is None:
        return list(default)
    values = [float(v) for v in text.split()]
    if len(values) != 3 or not all(math.isfinite(v) for v in values):
        raise ValueError('Vetor deve ter tres numeros finitos.')
    return values

class I3D:
    """Patch only the selected start-tag; preserve all other XML text."""
    def __init__(self, raw):
        if len(raw) > MAX_XML:
            raise ValueError('XML maior que 32 MB nesta primeira versao.')
        if raw.startswith(b'\xff\xfe') or raw.startswith(b'\xfe\xff'):
            self.encoding = 'utf-16'
        elif raw.startswith(b'\xef\xbb\xbf'):
            self.encoding = 'utf-8-sig'
        else:
            m = re.search(br'<\?xml[^>]*encoding=[\"\']([^\"\']+)', raw[:250])
            self.encoding = m.group(1).decode('ascii') if m else 'utf-8'
        self.text = raw.decode(self.encoding)
        if re.search(r'<!\s*(DOCTYPE|ENTITY)\b', self.text, re.I):
            raise ValueError('XML com DTD/entidades nao e aceito pelo editor.')
        self.utf8 = self.text.encode('utf-8')
        self.nodes = []
        self.spans = {}
        stack = []
        scene_depth = None
        parser = expat.ParserCreate('UTF-8')
        def start(name, attrs):
            nonlocal scene_depth
            name = tagname(name)
            if name == 'Scene' and scene_depth is None:
                scene_depth = len(stack)
            parent = next((s[1] for s in reversed(stack) if s[1] is not None), None)
            index = None
            if scene_depth is not None and len(stack) > scene_depth:
                index = len(self.nodes)
                offset = parser.CurrentByteIndex
                end, quote = offset, None
                while end < len(self.utf8):
                    char = self.utf8[end]
                    if quote:
                        if char == quote: quote = None
                    elif char in (34, 39): quote = char
                    elif char == 62: break
                    end += 1
                self.spans[index] = (offset, end + 1)
                self.nodes.append({'index': index, 'parent': parent, 'tag': name,
                    'name': attrs.get('name', name), 'nodeId': attrs.get('nodeId'),
                    'shapeId': attrs.get('shapeId'), 'materialIds': attrs.get('materialIds', ''),
                    'nonRenderable': attrs.get('nonRenderable', 'false') in ('true','1'),
                    'skinBindNodeIds': attrs.get('skinBindNodeIds', '').split(),
                    'translation': vector(attrs.get('translation'), [0, 0, 0]),
                    'rotation': vector(attrs.get('rotation'), [0, 0, 0]),
                    'scale': vector(attrs.get('scale'), [1, 1, 1]),
                    'visibility': attrs.get('visibility', 'true') not in ('false','0')})
            stack.append((name, index))
        def end(name):
            nonlocal scene_depth
            stack.pop()
            if tagname(name) == 'Scene' and len(stack) == scene_depth:
                scene_depth = None
        parser.StartElementHandler = start
        parser.EndElementHandler = end
        parser.Parse(self.utf8, True)

    def patch(self, index, changes):
        if index not in self.spans: raise ValueError('Peca nao encontrada.')
        if not changes or set(changes) - TRANSFORMS:
            raise ValueError('Propriedades de transformacao invalidas.')
        a, b = self.spans[index]
        tag = self.utf8[a:b].decode('utf-8')
        for key, value in changes.items():
            if key == 'visibility':
                if not isinstance(value, bool): raise ValueError('Visibilidade invalida.')
                value = 'true' if value else 'false'
            else:
                if not isinstance(value, list) or len(value) != 3:
                    raise ValueError('Informe X, Y e Z.')
                if any(isinstance(v, bool) or not isinstance(v, (int, float)) or
                       not math.isfinite(v) or abs(v) > 1e9 for v in value):
                    raise ValueError('Valor de transformacao invalido.')
                value = ' '.join(format(v, '.10g') for v in value)
            # Tokenize whole attributes: a quoted value may itself contain
            # text such as translation='...', which is not an attribute.
            pattern = r'([\w:.-]+)(\s*=\s*)([\"\'])(.*?)\3'
            escaped = escape(value, {'"': '&quot;'})
            match = next((m for m in re.finditer(pattern, tag, re.S) if m.group(1) == key), None)
            if match:
                quote_char = match.group(3)
                encoded = escape(value, {quote_char: '&quot;' if quote_char == '"' else '&apos;'})
                replacement = key + match.group(2) + quote_char + encoded + quote_char
                tag = tag[:match.start()] + replacement + tag[match.end():]
            else:
                at = tag.rfind('/>')
                if at < 0: at = tag.rfind('>')
                tag = tag[:at] + ' ' + key + '="' + escaped + '"' + tag[at:]
        modified = (self.utf8[:a] + tag.encode('utf-8') + self.utf8[b:]).decode('utf-8').encode(self.encoding)
        I3D(modified)
        return modified

    def scene(self, external_warning=True):
        root = ET.fromstring(self.text)
        meshes, materials, details, warnings = {}, {}, {}, []
        files={e.get('fileId'):e.get('filename','') for e in root.iter() if tagname(e.tag)=='File'}
        external = []
        for element in root.iter():
            name = tagname(element.tag)
            if name == 'Shapes' and element.get('externalShapesFile'):
                external.append(element.get('externalShapesFile'))
            if name == 'Material':
                color = element.get('diffuseColor', '.48 .62 .65 1').split()
                try:
                    color = [max(0, min(1, float(v))) for v in color[:3]]
                    if len(color) != 3: raise ValueError()
                except ValueError: color = [.48, .62, .65]
                materials[element.get('materialId', '')] = color
                params={p.get('name'):p.get('value','').split() for p in element if tagname(p.tag)=='CustomParameter'}
                palette=[]
                for i in range(8):
                    try:
                        entry=[float(v) for v in params.get('colorMat'+str(i),[])[:3]]
                        if len(entry)!=3 or not all(math.isfinite(v) for v in entry):raise ValueError()
                    except ValueError:entry=color[:]
                    palette.append(entry)
                maps={}
                for child in element:
                    role={'Texture':'diffuse','Normalmap':'normal','Glossmap':'specular'}.get(tagname(child.tag))
                    if role:maps[role]=files.get(child.get('fileId'),'')
                variation=element.get('customShaderVariation','')
                details[element.get('materialId','')]={'name':element.get('name',''),'variation':variation,
                    'maps':maps,'palette':palette,'shader':files.get(element.get('customShaderId'),''),
                    'customParameters':params,'customMaps':{p.get('name'):files.get(p.get('fileId'),'') for p in element if tagname(p.tag)=='Custommap'},'colorMask':'colormask' in variation.lower(),
                    'alphaBlending':element.get('alphaBlending') in ('true','1'),
                    'alphaTesting':element.get('alphaTesting') in ('true','1') or 'decal' in variation.lower()}
                detail=details[element.get('materialId','')]
                try:detail['baseColor']=vector(' '.join(element.get('diffuseColor','1 1 1').split()[:3]),[1,1,1])
                except ValueError:detail['baseColor']=color
                try:
                    alpha=float(element.get('diffuseColor','1 1 1 1').split()[3])
                    if math.isfinite(alpha):detail['opacity']=max(0,min(1,alpha))
                    spec=element.get('specularColor')
                    if spec:detail['specularStrength']=sum(vector(spec,[.08,.08,.08]))/3
                except (ValueError,IndexError):pass
                detail['normalThirdUV']='normalthirduv' in variation.lower()
                detail['secondUV']='seconduv' in variation.lower()
            if name == 'IndexedTriangleSet':
                vertices = next((v for v in element if tagname(v.tag) == 'Vertices'), None)
                triangles = next((v for v in element if tagname(v.tag) == 'Triangles'), None)
                if vertices is None or triangles is None: continue
                if len(vertices) > 100000 or len(triangles) > 200000:
                    warnings.append('Malha inline grande demais para a previa inicial: ' + element.get('name', ''))
                    continue
                positions = [vector(v.get('p'), [0, 0, 0]) for v in vertices]
                indices = []
                for triangle in triangles:
                    ids = [int(i) for i in triangle.get('vi', '').split()]
                    if len(ids) != 3 or any(i < 0 or i >= len(positions) for i in ids):
                        raise ValueError('Indices invalidos na malha ' + element.get('name', ''))
                    indices.extend(ids)
                uvs=[]
                for vertex in vertices:
                    try:
                        uv=[float(v) for v in vertex.get('t0','0 0').split()]
                        if len(uv)!=2 or not all(math.isfinite(v) for v in uv):raise ValueError()
                    except ValueError:uv=[0,0]
                    uvs.append(uv)
                meshes[element.get('shapeId', '')] = {'positions': positions, 'indices': indices,'uvs':uvs}
        if external and external_warning:
            warnings.append('Malhas externas .i3d.shapes: abra pelo projeto para resolver o arquivo binario.')
        if not meshes and external_warning:
            warnings.append('Nenhuma malha inline renderizavel. A grade e os eixos continuam disponiveis.')
        return {'nodes': self.nodes, 'meshes': meshes, 'materials': materials,
                'materialDetails':details,'warnings': warnings, 'externalShapes': external}

class Editor:
    def __init__(self, directory):
        self.directory = Path(directory)
        self.directory.mkdir(parents=True, exist_ok=True)
        self.lock = threading.RLock()
        self.project = None
        self.base=None;self.base_error=None;self.base_path=None
        config=self.directory/'game_base.json'
        if config.exists():
            try:
                self.base_path=json.loads(config.read_text())['path']
                from game_base import GameBase
                self.base=GameBase(self.base_path) if self.base_path else None
            except (ValueError,OSError,KeyError,zipfile.BadZipFile) as e:self.base_error=str(e)
        state = self.directory / 'last.json'
        if state.exists():
            try:
                identifier = json.loads(state.read_text())['project']
                if re.fullmatch(r'[0-9a-f]{32}', identifier):
                    self.project = self.directory / identifier
                    self.meta()
            except (ValueError, OSError, KeyError): self.project = None

    def base_status(self,include_candidates=False):
        from game_base import candidates
        result=self.base.status() if self.base else {'active':False,'path':self.base_path,'name':None,'files':0,'error':self.base_error}
        if include_candidates:result['candidates']=candidates()
        return result

    def set_base(self,source):
        from game_base import GameBase
        with self.lock:
            new=GameBase(source) if source else None
            path=str(new.path) if new else None
            try:atomic(self.directory/'game_base.json',jsonbytes({'path':path}))
            except Exception:
                if new:new.close()
                raise
            if self.base:self.base.close()
            self.base=new;self.base_path=path;self.base_error=None
            return self.base_status()

    def read_resource(self,name,limit=MAX_XML,head=False):
        if name.startswith('base:'):
            if not self.base:raise ValueError('Carregue a base do jogo para ler este recurso.')
            return self.base.read(name,limit,head)
        if not head:return self.read(name,limit)
        m=self.meta()
        if name in m.get('deleted',[]):raise KeyError(name)
        if name in m['overrides']:
            with (self.project/'blobs'/m['overrides'][name]).open('rb') as f:return f.read(limit)
        with zipfile.ZipFile(self.project/'original.zip') as z:
            with z.open(name) as f:return f.read(limit)

    def meta(self):
        if not self.project: raise ValueError('Abra um mod ZIP primeiro.')
        return json.loads((self.project / 'project.json').read_text('utf-8'))

    def write_meta(self, meta): atomic(self.project / 'project.json', jsonbytes(meta))

    def import_zip(self, source, name, *, consume_source=False):
        with self.lock:
            with zipfile.ZipFile(source) as z:
                seen, size = set(), 0
                if len(z.infolist()) > 100000: raise ValueError('ZIP possui arquivos demais.')
                for info in z.infolist():
                    path = PurePosixPath(info.filename.replace('\\', '/'))
                    if path.is_absolute() or '..' in path.parts or '\x00' in info.filename:
                        raise ValueError('Caminho invalido dentro do ZIP.')
                    if info.filename in seen: raise ValueError('ZIP possui nomes duplicados.')
                    seen.add(info.filename)
                    if info.flag_bits & 1: raise ValueError('ZIP com senha nao e suportado.')
                    size += info.file_size
                if size > 8 * 1024**3: raise ValueError('Conteudo maior que 8 GB nesta base.')
                if not any(n.lower().endswith('.i3d') for n in seen):
                    raise ValueError('O ZIP nao possui nenhum arquivo I3D.')
            project = self.directory / uuid.uuid4().hex
            project.mkdir()
            try:
                # HTTP uploads already live on this filesystem; adopt only that
                # disposable temporary file. User-owned ZIPs keep copy semantics.
                if consume_source:os.replace(source, project / 'original.zip')
                else:shutil.copyfile(source, project / 'original.zip')
            except Exception:
                shutil.rmtree(project,ignore_errors=True)
                raise
            previous = self.project
            self.project = project
            try:
                self.write_meta({'name': Path(name).name, 'overrides': {}, 'undo': [], 'redo': [], 'revision': 0})
                atomic(self.directory / 'last.json', jsonbytes({'project': project.name}))
            except Exception:
                self.project = previous
                raise
            return self.summary()

    def summary(self):
        if not self.project: return {'project': None}
        m = self.meta();deleted=set(m.get('deleted',[]))
        with zipfile.ZipFile(self.project / 'original.zip') as z:
            files = [{'name': i.filename, 'size': i.file_size,
                      'edited': i.filename in m['overrides']} for i in z.infolist() if not i.is_dir() and i.filename not in deleted]
        known={i['name'] for i in files}
        files.extend({'name':name,'size':(self.project/'blobs'/digest).stat().st_size,'edited':True}
                     for name,digest in m['overrides'].items() if name not in known and name not in deleted)
        from game_compat import profile,ordered_models
        return {'project': self.project.name, 'name': m['name'], 'files': files,'compatibility':profile(self),
                'i3ds': ordered_models(self,[i['name'] for i in files if i['name'].lower().endswith('.i3d')]),
                'changes': len(set(m['overrides'])|deleted), 'revision': m['revision'],
                'canUndo': bool(m['undo']), 'canRedo': bool(m['redo'])}

    def read(self, name, limit=MAX_XML):
        m = self.meta()
        if name in m.get('deleted',[]):raise KeyError(name)
        if name in m['overrides']: return (self.project / 'blobs' / m['overrides'][name]).read_bytes()
        with zipfile.ZipFile(self.project / 'original.zip') as z:
            info = z.getinfo(name)
            if info.file_size > limit: raise ValueError('Arquivo acima do limite de leitura.')
            return z.read(name)

    def resolve_resource(self,reference,owner='',basename_fallback=False):
        """Resolve relative resources in their own mod/base namespace."""
        if not reference or reference=='-':return None
        from game_base import variants
        ref=reference.replace('\\','/')
        if ref.startswith('base:'):
            if self.base and ref.startswith('base:'+self.base.id+'/'):
                key=ref.split('/',1)[1]
                return ref if key.casefold() in self.base.entries else None
            return None
        if ref.startswith('$'):
            if self.base:
                found=self.base.resolve(ref)
                if found:return found
        elif owner.startswith('base:'):
            prefix,path=owner.split('/',1)
            path=posixpath.normpath(posixpath.join(posixpath.dirname(path),ref))
            if self.base:return self.base.resolve(path)
            return None
        else:
            path=posixpath.normpath(posixpath.join(posixpath.dirname(owner),ref))
            if path.startswith('../') or path.startswith('/'):return None
            # Vehicle/sound XMLs use paths from the mod root. I3Ds also need
            # their traditional owner-relative lookup, which stays first.
            for refpath in dict.fromkeys((path,posixpath.normpath(ref))):
                if refpath.startswith(('../','/')):continue
                for candidate in variants(refpath):
                    if candidate.casefold() in self.archive_index()[0]:return self.archive_index()[0][candidate.casefold()]
            if self.base:
                found=self.base.resolve(path)
                if found:return found
        if basename_fallback:
            for candidate in variants(ref):
                matches=self.archive_index()[1].get(posixpath.basename(candidate).casefold(),[])
                if len(matches)==1:return matches[0]
        return None

    def archive_index(self):
        if not self.project:return {},{}
        stamp=(self.project,self.meta()['revision'])
        if getattr(self,'_indexed_project',None)!=stamp:
            with zipfile.ZipFile(self.project/'original.zip') as z:names=[n for n in z.namelist() if not n.endswith('/')]
            meta=self.meta();deleted=set(meta.get('deleted',[]));names=[n for n in dict.fromkeys(names+list(meta['overrides'])) if n not in deleted]
            lookup={n.casefold():n for n in names};bases={}
            for n in names:bases.setdefault(posixpath.basename(n).casefold(),[]).append(n)
            self._resource_index=(lookup,bases);self._indexed_project=stamp
        return self._resource_index

    def scene(self, name, wheel_config=0, include_wheels=True):
        """Resolve binary geometry without changing I3D or original archive."""
        with self.lock:
            document=I3D(self.read_resource(name))
            scene=document.scene(external_warning=False)
            decoded=[]
            for reference in scene['externalShapes']:
                path=self.resolve_resource(reference,name)
                if not path:
                    scene['warnings'].append('Malha fora do mod/base disponivel: '+reference)
                    continue
                try:
                    raw=self.read_resource(path,256*1024*1024)
                    digest=hashlib.sha256(raw).hexdigest()
                    cache=self.project/'cache'/('shapes_v5_'+digest+'.json.gz')
                    geometry=None
                    if cache.exists():
                        try:
                            geometry=json.loads(gzip.decompress(cache.read_bytes()))
                        except (ValueError,OSError,EOFError):
                            cache.unlink(missing_ok=True)
                    if geometry is None:
                        from shapes_reader import decode
                        geometry=decode(raw)
                        atomic(cache,gzip.compress(jsonbytes(geometry),compresslevel=1))
                    scene['meshes'].update(geometry['meshes'])
                    decoded.append({k:geometry[k] for k in ('version','entityCount','engine')})
                    scene['warnings'].extend(geometry['warnings'])
                except (ValueError,KeyError,OSError,EOFError,ImportError) as error:
                    scene['warnings'].append('Nao foi possivel ler '+reference+': '+str(error))
            missing=sorted({n['shapeId'] for n in scene['nodes'] if n['shapeId'] and not n['nonRenderable'] and n['shapeId'] not in scene['meshes']})
            if missing:scene['warnings'].append(f'{len(missing)} shapeIds sem geometria disponivel.')
            if not scene['meshes']:scene['warnings'].append('Nenhuma geometria disponivel para esta cena.')
            if any(m.get('skin') for m in scene['meshes'].values()):
                scene['warnings'].append('Deformacoes por ossos ainda nao sao aplicadas. Use Animacoes para ver movimentos definidos no XML.')
            scene['geometryInfo']={'sources':decoded,'missingShapeIds':missing,
                'mainNodeCount':len(scene['nodes']),'meshCount':len(scene['meshes']),
                'triangleCount':sum(m.get('triangleCount',len(m.get('indices',[]))//3) for m in scene['meshes'].values())}
            self.resolve_materials(scene,name)
            from surface_decal import annotate
            annotate(scene,document)
            if include_wheels and not name.startswith('base:'):
                from wheel_preview import assemble
                assemble(self,scene,name,wheel_config)
            return scene

    def resolve_materials(self,scene,name):
        missing=set();resources=set()
        def resolve(reference):return self.resolve_resource(reference,name,basename_fallback=True)
        shader_profiles={}
        from shader_materials import descriptor,apply,supported
        for mid,material in scene.get('materialDetails',{}).items():
            shader=material.get('shader','')
            if supported(material):
                if shader not in shader_profiles:
                    resource=resolve(shader)
                    try:profile=descriptor(self.read_resource(resource,4*1024*1024)) if resource else descriptor()
                    except (ValueError,OSError,KeyError,ET.ParseError):profile=descriptor()
                    shader_profiles[shader]=profile
                apply(material,shader_profiles[shader],shader)
                if material.get('shaderFamily')=='convertedFS25':scene['materials'][mid]=material['baseColor'][:]
            material['sourceMaps']=dict(material['maps'])
            for role,reference in list(material['maps'].items()):
                found=resolve(reference) if reference else None
                material['maps'][role]=found
                if found:resources.add(found)
                elif reference:missing.add(reference)
        formats={}
        for resource in sorted(resources):
            try:
                head=self.read_resource(resource,16,head=True)
                formats[resource]='astc' if head[:4] in (b'GS2D',b'\x13\xab\xa1\x5c') else 'dds' if head[:4]==b'DDS ' else 'image'
            except (ValueError,OSError,KeyError):formats[resource]='unknown'
        from_base=sum(p.startswith('base:') for p in resources)
        scene['textureInfo']={'resources':sorted(resources),'missing':sorted(missing),'formats':formats,'fromBase':from_base,
            'materialTables':sorted({m['maps'].get('detailDiffuse') for m in scene.get('materialDetails',{}).values() if m['maps'].get('detailDiffuse')})}
        if any(m.get('shaderFamily')=='vehicle' and not m['maps'].get('detailDiffuse') for m in scene.get('materialDetails',{}).values()):
            scene['warnings'].append('Tabela de cores vehicleShader nao encontrada. Alguns materiais continuam com cor basica; conecte uma base que contenha detailArrayPixels_diffuse.')
        scene['gameBase']=self.base_status()
        if scene['gameBase'].get('error'):scene['warnings'].append(scene['gameBase']['error'])
        scene['projectId']=self.project.name
        if missing:scene['warnings'].append(f'{len(missing)} texturas referenciadas nao foram encontradas no mod nem na base selecionada.')

    def texture(self,name,max_size=2048):
        from ast_texture import preview
        return preview(self.read_resource(name,128*1024*1024),max_size)

    def texture_png(self,name,max_size=1024):
        """Local fallback, used only if the GPU cannot accept ASTC."""
        from ast_texture import decode,astc_file,png_rgba
        import shutil,subprocess,tempfile,struct,zlib
        raw=self.read_resource(name,128*1024*1024)
        digest=hashlib.sha256(raw).hexdigest()
        texture=decode(raw);levels=texture['levels']
        limit=max(32,min(2048,int(max_size)))
        first=next((i for i,(w,h,data) in enumerate(levels) if max(w,h)<=limit),len(levels)-1)
        w,h,data=levels[first];path=self.project/'cache'/f'png_{digest}_{first}.png'
        if path.exists():return path.read_bytes()
        if texture.get('encoding')=='rgba8':
            result=png_rgba(w,h,data);atomic(path,result);return result
        result=None
        try:
            import texture2ddecoder
            bgra=texture2ddecoder.decode_astc(data,w,h,texture['blockX'],texture['blockY'])
            rgba=bytearray(len(bgra));rgba[0::4]=bgra[2::4];rgba[1::4]=bgra[1::4];rgba[2::4]=bgra[0::4];rgba[3::4]=bgra[3::4]
            result=png_rgba(w,h,rgba)
        except ImportError:
            tool=next((shutil.which(n) for n in ['astcenc','astcenc-neon','astcenc-sse4.1','astcenc-avx2'] if shutil.which(n)),None)
            if not tool:raise ValueError('GPU sem ASTC: instale/use astcenc no Termux para a previa de texturas.')
            with tempfile.TemporaryDirectory(dir=self.project) as directory:
                source=Path(directory)/'preview.astc';dest=Path(directory)/'preview.png'
                source.write_bytes(astc_file(w,h,texture['blockX'],texture['blockY'],data))
                run=subprocess.run([tool,'-dl',str(source),str(dest),'-silent'],capture_output=True,timeout=60)
                if run.returncode or not dest.exists():raise ValueError('astcenc nao conseguiu decodificar a textura.')
                result=dest.read_bytes()
        atomic(path,result)
        return result

    def texture_image(self,name,max_size=1024):
        raw=self.read_resource(name,128*1024*1024)
        if raw.startswith(b'\x89PNG\r\n\x1a\n'):return raw,'image/png'
        if raw.startswith(b'\xff\xd8'):return raw,'image/jpeg'
        if raw.startswith(b'DDS '):
            from dds_texture import preview_png
            digest=hashlib.sha256(raw).hexdigest();limit=max(32,min(2048,int(max_size)));path=self.project/'cache'/f'dds_{digest}_{limit}.png'
            if path.exists():return path.read_bytes(),'image/png'
            png=preview_png(raw,limit);atomic(path,png);return png,'image/png'
        return self.texture_png(name,max_size),'image/png'

    def blob(self, raw):
        digest = hashlib.sha256(raw).hexdigest()
        path = self.project / 'blobs' / digest
        if not path.exists(): atomic(path, raw)
        return digest

    def change(self, name, raw, revision):
        return self.change_many({name:raw},revision)

    def change_many(self, files, revision, delete=None):
        if revision!=self.meta()['revision']:raise ValueError('Projeto mudou. Reabra o arquivo antes de aplicar.')
        return self.commit_blobs({name:self.blob(raw) for name,raw in files.items()},revision,delete)

    def commit_blobs(self, staged, revision, delete=None):
        """Atomically publish staged blobs and removals; staging is memory bounded."""
        m=self.meta()
        if revision!=m['revision']:raise ValueError('Projeto mudou. Reabra o arquivo antes de aplicar.')
        if delete is None:delete=[]
        if not isinstance(delete,list) or any(not isinstance(n,str) for n in delete):raise ValueError('Lista de exclusao invalida.')
        before_deleted=set(m.get('deleted',[]));after_deleted=(before_deleted|set(delete))-set(staged)
        changes=[]
        for name in list(staged)+delete:
            path=PurePosixPath(name)
            if path.is_absolute() or '..' in path.parts or '\\' in name or not name:raise ValueError('Caminho de arquivo invalido.')
        current=set(self.archive_index()[0].values())
        if any(name not in current for name in delete):raise ValueError('Arquivo a excluir nao pertence ao projeto.')
        for name,digest in staged.items():
            if not isinstance(digest,str) or not re.fullmatch('[0-9a-f]{64}',digest) or not (self.project/'blobs'/digest).is_file():raise ValueError('Arquivo preparado invalido.')
            if name in before_deleted:
                if name in m['overrides']:old=m['overrides'][name]
                else:
                    with zipfile.ZipFile(self.project/'original.zip') as original:
                        try:old=self.blob(original.read(name))
                        except KeyError:old=None
            else:
                try:before=self.read(name,max(MAX_XML,(self.project/'blobs'/digest).stat().st_size))
                except KeyError:before=None
                old=self.blob(before) if before is not None else None
            if old==digest:continue
            changes.append({'file':name,'before':old,'after':digest})
        if not changes and before_deleted==after_deleted:return self.summary()
        with zipfile.ZipFile(self.project/'original.zip') as z:
            original=set(z.namelist())
            for change in changes:
                name=change['file'];m['overrides'][name]=change['after']
                if name in original and hashlib.sha256(z.read(name)).hexdigest()==change['after']:m['overrides'].pop(name,None)
        operation={'files':changes}
        if before_deleted!=after_deleted:operation.update(deletedBefore=sorted(before_deleted),deletedAfter=sorted(after_deleted))
        if after_deleted:m['deleted']=sorted(after_deleted)
        else:m.pop('deleted',None)
        m['undo']=(m['undo']+[operation])[-50:];m['redo']=[];m['revision']+=1
        self.write_meta(m);return self.summary()

    def add_decal(self,name,parent,png,width,translation,rotation,revision,label='Adesivo',projection=None):
        from decals import png_pixels,gs2d_rgba,add_xml
        from surface_decal import flat_mesh,project,store_info
        with self.lock:
            if revision!=self.meta()['revision']:raise ValueError('Projeto mudou. Reabra antes de importar.')
            doc=I3D(self.read(name))
            if not name.lower().endswith('.i3d') or not isinstance(parent,int) or not 0<=parent<len(doc.nodes):raise ValueError('Selecione uma peca do I3D principal.')
            if not isinstance(width,(float,int)) or isinstance(width,bool) or not math.isfinite(width) or not .01<=width<=20:raise ValueError('Largura entre 0,01 e 20 metros.')
            # Reuse transform validation, including vector size, finiteness and bounds.
            doc.patch(parent,{'translation':translation,'rotation':rotation})
            w,h,pixels=png_pixels(png)
            height=width*h/w
            root=posixpath.dirname(name);token=uuid.uuid4().hex[:12]
            from game_compat import texture_assets
            stem='gabriel_plotagens/adesivo_'+token
            texture,assets=texture_assets(self,posixpath.join(root,stem),png,w,h,pixels)
            relative=posixpath.relpath(texture,root or '.')
            geometry=self.scene(name,include_wheels=False)
            used=[int(k) for k in geometry['meshes'] if k.isdigit()]
            if projection is not None and not isinstance(projection,dict):raise ValueError('Parametros da projecao invalidos.')
            projection=projection or {'mode':'flat'}
            mode=projection.get('mode','surface')
            if mode not in ('flat','surface'):raise ValueError('Tipo de projecao invalido.')
            stats={};mesh=flat_mesh(width,height)
            if mode=='surface':
                receiver=geometry['nodes'][parent]
                if receiver.get('decalInfo'):raise ValueError('Selecione a lataria, em vez de outra plotagem, para projetar.')
                source=geometry['meshes'].get(receiver['shapeId'])
                if not source:raise ValueError('A peca selecionada precisa ter uma malha disponivel.')
                mesh,stats=project(source,width,height,translation,rotation,depth=projection.get('depth',.2),max_angle=projection.get('maxAngle',75),offset=projection.get('offset',.001))
            references=geometry['externalShapes']
            if len(references)>1:raise ValueError('Esta cena possui varias fontes de malha. Plotagem suporta uma fonte binaria por I3D nesta versao.')
            binary_path=self.resolve_resource(references[0],name) if references else None
            if references and not binary_path:raise ValueError('O arquivo .shapes do modelo precisa estar disponivel para adicionar a plotagem.')
            raw,nid=add_xml(doc,parent,relative,width,height,translation,rotation,str(label),used,binary=bool(binary_path),mesh=mesh)
            parsed=I3D(raw);index=next(n['index'] for n in parsed.nodes if n['nodeId']==nid)
            raw=store_info(parsed,nid,{'width':width,'height':height,'mode':mode,**stats})
            files={name:raw,**assets}
            if binary_path:
                shape_id=parsed.nodes[index]['shapeId']
                self._decal_binary_files(files,name,binary_path,shape_id,mesh,token)
            result=self.change_many(files,revision)
            return {'project':result,'index':index,'width':width,'height':height,'projection':{'mode':mode,**stats}}

    def _decal_binary_files(self,files,name,binary_path,shape_id,mesh,token):
        from decals import append_binary_mesh,replace_external
        binary=append_binary_mesh(self.read_resource(binary_path,256*1024*1024),shape_id,mesh)
        if binary_path.startswith('base:'):
            reference='gabriel_plotagens/malhas_'+token+'.i3d.shapes'
            files[name]=replace_external(I3D(files[name]),reference)
            files[posixpath.join(posixpath.dirname(name),reference)]=binary
        else:files[binary_path]=binary

    def project_decal(self,name,index,revision,depth=.2,max_angle=75,offset=.001):
        from decals import spans,append_inline_mesh
        from surface_decal import project,patch_attribute,store_info
        with self.lock:
            if revision!=self.meta()['revision']:raise ValueError('Projeto mudou. Reabra a cena antes de projetar.')
            doc=I3D(self.read(name));scene=self.scene(name,include_wheels=False)
            if not isinstance(index,int) or not 0<=index<len(doc.nodes):raise ValueError('Selecione uma plotagem do I3D principal.')
            node=scene['nodes'][index];info=node.get('decalInfo')
            if not info or node['parent'] is None:raise ValueError('Selecione uma plotagem criada por este editor.')
            receiver=scene['nodes'][node['parent']];source=scene['meshes'].get(receiver.get('shapeId'))
            if not source or receiver.get('decalInfo'):raise ValueError('A plotagem precisa estar ligada diretamente a uma peca da lataria.')
            mesh,stats=project(source,info['width'],info['height'],node['translation'],node['rotation'],node['scale'],depth,max_angle,offset)
            _,elements=spans(doc.text)
            used=[int(k) for k in scene['meshes'] if k.isdigit()]+[int(e['attrs']['shapeId']) for e in elements if e['attrs'].get('shapeId','').isdigit()]
            shape_id=str(max(used+[0])+1)
            span=next(e for e in elements if e['start']==doc.spans[index][0])
            raw=patch_attribute(doc,span,'shapeId',shape_id)
            references=scene['externalShapes']
            if len(references)>1:raise ValueError('Esta projecao aceita uma fonte de malha por I3D.')
            binary_path=self.resolve_resource(references[0],name) if references else None
            if references and not binary_path:raise ValueError('O arquivo .shapes precisa estar disponivel.')
            if not binary_path:raw=append_inline_mesh(I3D(raw),shape_id,mesh)
            raw=store_info(I3D(raw),node['nodeId'],{'width':info['width'],'height':info['height'],'mode':'surface',**stats})
            files={name:raw}
            if binary_path:self._decal_binary_files(files,name,binary_path,shape_id,mesh,uuid.uuid4().hex[:12])
            result=self.change_many(files,revision)
            return {'project':result,'index':index,'projection':{'mode':'surface',**stats}}

    def paint_options(self,name,index):
        from painting import options
        return options(self,name,index)

    def paint_material(self,name,index,material_id,channel,color,shared,revision):
        from painting import paint
        return paint(self,name,index,material_id,channel,color,shared,revision)

    def accessory_source(self,name=None):
        from accessories import inspect
        return inspect(self,name)

    def load_accessory_source(self,path,name,*,consume_source=False):
        from accessories import load_source
        return load_source(self,path,name,consume_source=consume_source)

    def import_accessory(self,target,parent,source,index,revision,translation=None,source_id=None,allow_functional=False):
        from accessories import import_part
        return import_part(self,target,parent,source,index,revision,translation,source_id,allow_functional=allow_functional)

    def new_mod_options(self,model):
        from new_mod import options
        return options(self,model)

    def export_new_mod(self,body):
        from new_mod import export
        return export(self,body)

    def base_vehicles(self,refresh=False):
        from base_vehicles import inventory
        return inventory(self,refresh)

    def base_vehicle_info(self,filename,base_id):
        from base_vehicles import describe
        return describe(self,filename,base_id)

    def open_base_vehicle(self,filename,base_id):
        from base_vehicles import open_copy
        return open_copy(self,filename,base_id)

    def export_base_vehicle(self,filename,base_id):
        from base_vehicles import build
        return build(self,filename,base_id)

    def save_shop_options(self,name,vehicle,title,options,revision,slot=None):
        from shop_options import save
        return save(self,name,vehicle,title,options,revision,slot)

    def remove_shop_options(self,name,vehicle,slot,revision):
        from shop_options import remove
        return remove(self,name,vehicle,slot,revision)

    def export_prefab(self,name,index,title,revision,allow_functional=False):
        from prefabs import export
        return export(self,name,index,title,revision,allow_functional=allow_functional)

    def mirror_piece(self,name,index,axis,revision):
        from pose_tools import mirror
        return mirror(self,name,index,axis,revision)

    def align_piece(self,name,index,target,point,normal,axis,offset,orient,revision):
        from pose_tools import align
        return align(self,name,index,target,point,normal,axis,offset,orient,revision)

    def shop_options(self,name,vehicle=None):
        from shop_options import inspect
        return inspect(self,name,vehicle)

    def create_shop_option(self,name,vehicle,off_indices,on_indices,title,off_name,on_name,off_price,on_price,revision,slot=None):
        from shop_options import create
        return create(self,name,vehicle,off_indices,on_indices,title,off_name,on_name,off_price,on_price,revision,slot)

    def scene_tool(self,name,action,indices,revision,title=None,offset=None):
        from scene_tools import apply
        return apply(self,name,action,indices,revision,title,offset)

    def transform(self, name, index, changes, revision):
        with self.lock:
            if not name.lower().endswith('.i3d'): raise ValueError('Selecione um I3D.')
            return self.change(name, I3D(self.read(name)).patch(index, changes), revision)

    def transform_many(self, body):
        """Commit all local previews as one validated history operation."""
        with self.lock:
            if not self.project or body.get('project')!=self.project.name or body.get('revision')!=self.meta()['revision']:
                raise ValueError('O projeto mudou. As previas foram mantidas; reabra o projeto antes de salvar.')
            name=body.get('file','');edits=body.get('edits')
            if not isinstance(name,str) or not name.lower().endswith('.i3d') or name not in self.archive_index()[0].values():raise ValueError('Selecione um I3D do projeto.')
            if not isinstance(edits,list) or not 1<=len(edits)<=1000:raise ValueError('Informe de 1 a 1000 pecas para salvar.')
            doc=I3D(self.read(name));seen=set()
            from selection_tools import node_keys,view_state
            keys=node_keys(doc.nodes);locked=set(view_state(self,name)['locked'])
            blocked=set()
            for n in doc.nodes:
                if keys[n['index']] in locked or n['parent'] in blocked:blocked.add(n['index'])
            for index in list(blocked):
                parent=doc.nodes[index]['parent']
                while parent is not None:blocked.add(parent);parent=doc.nodes[parent]['parent']
            raw=self.read(name)
            for edit in edits:
                if not isinstance(edit,dict):raise ValueError('Edicao de peca invalida.')
                index=edit.get('index')
                if type(index)!=int or not 0<=index<len(doc.nodes) or index in seen:raise ValueError('Peca invalida ou repetida.')
                if index in blocked or doc.nodes[index]['name'].startswith('__GabrielReserva__'):raise ValueError('A selecao contem pecas travadas ou removidas.')
                seen.add(index)
                raw=I3D(raw).patch(index,edit.get('changes'))
            return self.change(name,raw,body['revision'])

    def save_xml(self, name, text, revision):
        with self.lock:
            if not name.lower().endswith(('.i3d', '.xml')): raise ValueError('Selecione XML ou I3D.')
            I3D(self.read(name))
            # Text editor uses UTF-8 and updates its encoding declaration.
            text = re.sub(r'(<\?xml[^>]*encoding\s*=\s*[\"\'])[^\"\']+', r'\g<1>utf-8', text, count=1)
            raw = text.encode('utf-8')
            I3D(raw)
            return self.change(name, raw, revision)

    def history(self, redo=False):
        with self.lock:
            m = self.meta()
            source, target = ('redo', 'undo') if redo else ('undo', 'redo')
            if m[source]:
                op = m[source].pop()
                with zipfile.ZipFile(self.project/'original.zip') as z:
                    for change in op.get('files',[op]):
                        name=change['file'];digest=change['after' if redo else 'before']
                        if digest is None:m['overrides'].pop(name,None)
                        elif name in z.namelist() and digest==hashlib.sha256(z.read(name)).hexdigest():m['overrides'].pop(name,None)
                        else:m['overrides'][name]=digest
                if 'deletedBefore' in op:
                    removed=op['deletedAfter' if redo else 'deletedBefore']
                    if removed:m['deleted']=removed
                    else:m.pop('deleted',None)
                m[target].append(op)
                m['revision'] += 1
                self.write_meta(m)
            return self.summary()

    def export(self,progress=None):
        with self.lock:
            from decals import generated_texture,repair_generated_texture
            m = self.meta();deleted=set(m.get('deleted',[]))
            dest = self.project / 'export.zip'
            repairs={}
            with zipfile.ZipFile(self.project/'original.zip') as src:
                candidates={info.filename for info in src.infolist() if info.file_size<=8*1024*1024 and generated_texture(info.filename)}
                candidates.update(name for name in m['overrides'] if generated_texture(name))
                for name in candidates-deleted:
                    raw=self.read(name);fixed=repair_generated_texture(raw)
                    if fixed!=raw:repairs[name]=fixed
            if not m['overrides'] and not repairs and not deleted:
                shutil.copyfile(self.project / 'original.zip', dest)
                return dest
            with zipfile.ZipFile(self.project / 'original.zip') as src, zipfile.ZipFile(dest, 'w', allowZip64=True) as out:
                out.comment = src.comment
                for export_number,info in enumerate(src.infolist()):
                    if progress:progress(export_number,len(src.infolist()),info.filename)
                    if info.filename in deleted:continue
                    override = m['overrides'].get(info.filename)
                    if info.filename in repairs:
                        out.writestr(info,repairs[info.filename])
                    elif override:
                        with open(self.project / 'blobs' / override, 'rb') as f, out.open(info, 'w', force_zip64=True) as g:
                            shutil.copyfileobj(f, g, 1024 * 1024)
                    else:
                        with src.open(info) as f, out.open(info, 'w', force_zip64=True) as g:
                            shutil.copyfileobj(f, g, 1024 * 1024)
                original=set(src.namelist())
                for name,digest in m['overrides'].items():
                    if name not in original and name not in deleted:
                        if name in repairs:out.writestr(name,repairs[name],compress_type=zipfile.ZIP_DEFLATED)
                        else:out.write(self.project/'blobs'/digest,name,compress_type=zipfile.ZIP_DEFLATED)
            return dest

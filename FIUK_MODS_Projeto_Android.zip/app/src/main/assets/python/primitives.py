"""Small portable static meshes with explicit normals and automatic UVs."""
import math,posixpath,tempfile,os,zipfile,xml.etree.ElementTree as ET
from pathlib import Path
from core import I3D
from game_compat import profile
from native_assets import empty_shapes,append_meshes,inline_mesh
from decals import spans,append_element
from xml_edit import next_id,section,attributes,whole_end
from scene_tools import label
from painting import linear_color

def scalar(value,name,lo,hi):
    if type(value) not in (int,float) or not math.isfinite(value) or not lo<=value<=hi:raise ValueError(name+' fora do limite permitido.')
    return float(value)

class Mesh:
    def __init__(self):self.data={'positions':[],'normals':[],'uvs':[],'indices':[]}
    def vertex(self,p,n,uv):
        length=math.sqrt(sum(v*v for v in n));n=[v/length for v in n]
        i=len(self.data['positions']);self.data['positions'].append(p);self.data['normals'].append(n);self.data['uvs'].append(uv);return i
    def tri(self,a,b,c):
        p=self.data['positions'];u=[x-y for x,y in zip(p[b],p[a])];v=[x-y for x,y in zip(p[c],p[a])];cross=[u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]]
        if sum(x*x for x in cross)<1e-24:return
        normal=[sum(self.data['normals'][i][k] for i in (a,b,c)) for k in range(3)]
        self.data['indices'].extend((a,b,c) if sum(x*y for x,y in zip(cross,normal))>=0 else (a,c,b))
    def quad(self,points,normal):
        ids=[self.vertex(p,normal,uv) for p,uv in zip(points,([0,0],[1,0],[1,1],[0,1]))];self.tri(*ids[:3]);self.tri(ids[0],ids[2],ids[3])

def generate(body):
    kind=body.get('kind');allowed=('box','bar','plane','sphere','cylinder','cone','tube','bentTube')
    if kind not in allowed:raise ValueError('Escolha uma forma basica.')
    size=body.get('size')
    if not isinstance(size,list) or len(size)!=3:raise ValueError('Informe largura, altura e profundidade.')
    x,y,z=[scalar(v,'Medida',.001,100) for v in size];segments=body.get('segments',24)
    if type(segments)!=int or not 6<=segments<=64:raise ValueError('Segmentos: de 6 a 64.')
    m=Mesh()
    if kind in ('box','bar'):
        a,b,c=x/2,y/2,z/2
        for p,n in [([[-a,-b,c],[a,-b,c],[a,b,c],[-a,b,c]],[0,0,1]),([[a,-b,-c],[-a,-b,-c],[-a,b,-c],[a,b,-c]],[0,0,-1]),([[a,-b,c],[a,-b,-c],[a,b,-c],[a,b,c]],[1,0,0]),([[-a,-b,-c],[-a,-b,c],[-a,b,c],[-a,b,-c]],[-1,0,0]),([[-a,b,c],[a,b,c],[a,b,-c],[-a,b,-c]],[0,1,0]),([[-a,-b,-c],[a,-b,-c],[a,-b,c],[-a,-b,c]],[0,-1,0])]:m.quad(p,n)
    elif kind=='plane':
        points=[[-x/2,-y/2,0],[x/2,-y/2,0],[x/2,y/2,0],[-x/2,y/2,0]];m.quad(points,[0,0,1]);m.quad(points,[0,0,-1])
    elif kind=='sphere':
        rings=max(4,segments//2);grid=[]
        for j in range(rings+1):
            theta=math.pi*j/rings;row=[]
            for i in range(segments+1):
                phi=2*math.pi*i/segments;p=[x/2*math.sin(theta)*math.cos(phi),y/2*math.cos(theta),z/2*math.sin(theta)*math.sin(phi)];n=[p[0]/(x*x),p[1]/(y*y),p[2]/(z*z)];row.append(m.vertex(p,n,[i/segments,1-j/rings]))
            grid.append(row)
        for j in range(rings):
            for i in range(segments):m.tri(grid[j][i],grid[j+1][i],grid[j+1][i+1]);m.tri(grid[j][i],grid[j+1][i+1],grid[j][i+1])
    elif kind in ('cylinder','cone'):
        grid=[]
        for j in (0,1):
            row=[]
            for i in range(segments+1):
                a=2*math.pi*i/segments;f=0 if kind=='cone' and j else 1;p=[math.cos(a)*x/2*f,(j-.5)*y,math.sin(a)*z/2*f];n=[math.cos(a)/(x/2),1/y if kind=='cone' else 0,math.sin(a)/(z/2)];row.append(m.vertex(p,n,[i/segments,j]))
            grid.append(row)
        for i in range(segments):m.tri(grid[0][i],grid[1][i],grid[1][i+1]);m.tri(grid[0][i],grid[1][i+1],grid[0][i+1])
        for j in ((0,) if kind=='cone' else (0,1)):
            n=[0,-1 if j==0 else 1,0];center=m.vertex([0,(j-.5)*y,0],n,[.5,.5]);row=[]
            for i in range(segments+1):
                a=2*math.pi*i/segments;row.append(m.vertex([math.cos(a)*x/2,(j-.5)*y,math.sin(a)*z/2],n,[(math.cos(a)+1)/2,(math.sin(a)+1)/2]))
            for i in range(segments):m.tri(center,row[i],row[i+1])
    else:
        wall=scalar(body.get('wall',min(x,z)*.1),'Espessura',.0001,min(x,z)*.49);rx,rz=x/2,z/2
        curved=kind=='bentTube';radius=scalar(body.get('bendRadius',.2),'Raio da curva',.001,100) if curved else 0
        angle=math.radians(scalar(body.get('bendAngle',90),'Angulo da curva',5,270)) if curved else 0
        if curved and radius<=rz:raise ValueError('O raio da curva deve ser maior que o raio do tubo.')
        rings=max(4,math.ceil(segments*angle/(2*math.pi))) if curved else 1
        def frame(t):
            if not curved:return [0,(t-.5)*y,0],[0,1,0],[0,0,1]
            a=(t-.5)*angle;return [0,radius*math.sin(a),radius*(1-math.cos(a))],[0,math.cos(a),math.sin(a)],[0,-math.sin(a),math.cos(a)]
        for inner in (False,True):
            a,b=(rx-wall,rz-wall) if inner else (rx,rz);grid=[]
            for j in range(rings+1):
                t=j/rings;center,tangent,side=frame(t);row=[]
                for i in range(segments+1):
                    theta=2*math.pi*i/segments;c,s=math.cos(theta),math.sin(theta);p=[center[k]+(a*c if k==0 else 0)+side[k]*b*s for k in range(3)];n=[(c/a if k==0 else 0)+side[k]*s/b for k in range(3)];n=[v*(-1 if inner else 1) for v in n];row.append(m.vertex(p,n,[i/segments,t]))
                grid.append(row)
            for j in range(rings):
                for i in range(segments):m.tri(grid[j][i],grid[j+1][i],grid[j+1][i+1]);m.tri(grid[j][i],grid[j+1][i+1],grid[j][i+1])
        for j in (0,1):
            center,tangent,side=frame(j);n=[v*(-1 if j==0 else 1) for v in tangent];outer=[];inner=[]
            for i in range(segments+1):
                a=2*math.pi*i/segments;c,s=math.cos(a),math.sin(a)
                for row,px,pz in ((outer,rx,rz),(inner,rx-wall,rz-wall)):
                    row.append(m.vertex([center[k]+(px*c if k==0 else 0)+side[k]*pz*s for k in range(3)],n,[.5+px*c/x,.5+pz*s/z]))
            for i in range(segments):m.tri(outer[i],inner[i],inner[i+1]);m.tri(outer[i],inner[i+1],outer[i+1])
    mesh=m.data
    # Streaming density in UV units per metre, based on triangle areas.
    world=uv=0
    for i in range(0,len(mesh['indices']),3):
        a,b,c=mesh['indices'][i:i+3];p,q,r=[mesh['positions'][j] for j in (a,b,c)];u=[q[k]-p[k] for k in range(3)];v=[r[k]-p[k] for k in range(3)];cross=[u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]];world+=math.sqrt(sum(c*c for c in cross))/2
        a,b,c=[mesh['uvs'][j] for j in (a,b,c)];uv+=abs((b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0]))/2
    mesh['uvDensities']=[[math.sqrt(uv/world) if world else 0,None,None,None]]
    return mesh

def new_project(editor,title):
    with editor.lock:
        title=label(title,'Meu acessorio');root=ET.Element('i3D',{'name':title,'version':'1.6'});ET.SubElement(root,'Files');ET.SubElement(root,'Materials');ET.SubElement(root,'Shapes',{'externalShapesFile':'acessorio.i3d.shapes'});scene=ET.SubElement(root,'Scene');outer=ET.SubElement(scene,'TransformGroup',{'name':'Cena','nodeId':'1'});ET.SubElement(outer,'TransformGroup',{'name':title,'nodeId':'2'})
        fd,path=tempfile.mkstemp(prefix='cena_vazia_',suffix='.zip',dir=editor.directory);os.close(fd);path=Path(path)
        try:
            with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:z.writestr('acessorio.i3d',ET.tostring(root,encoding='utf-8',xml_declaration=True));z.writestr('acessorio.i3d.shapes',empty_shapes())
            return editor.import_zip(path,title+'.zip')
        finally:path.unlink(missing_ok=True)

def create(editor,body):
    import uuid
    from selection_tools import node_keys,view_state
    with editor.lock:
        if not editor.project or body.get('project')!=editor.project.name or body.get('revision')!=editor.meta()['revision']:raise ValueError('O projeto mudou. Reabra Criar forma.')
        name=body['file'];doc=I3D(editor.read(name));parent=body.get('parent')
        if type(parent)!=int or not 0<=parent<len(doc.nodes):raise ValueError('Selecione um ponto de montagem do projeto.')
        keys=node_keys(doc.nodes);locked=set(view_state(editor,name)['locked']);p=parent
        while p is not None:
            if keys[p] in locked:raise ValueError('O grupo de destino esta travado.')
            p=doc.nodes[p]['parent']
        translation=body.get('translation',[0,0,0]);doc.patch(parent,{'translation':translation});title=label(body.get('name'),'Nova peca');rgb=linear_color(body.get('color','#b4bfc7'));mesh=generate(body);scene=editor.scene(name,include_wheels=False)
        shape_id=max([int(n['shapeId']) for n in doc.nodes if (n.get('shapeId') or '').isdigit()]+[int(i) for i in scene['meshes'] if i.isdigit()]+[0])+1;mid=str(next_id(doc,'materialId'));nid=str(next_id(doc,'nodeId'));pending={};raw=editor.read(name)
        if len(scene['externalShapes'])>1:raise ValueError('Modelo com varias tabelas externas: crie a peca numa cena independente.')
        if scene['externalShapes']:
            ref=scene['externalShapes'][0];resource=editor.resolve_resource(ref,name)
            if not resource:raise ValueError('Arquivo .shapes nao encontrado no projeto/base.')
            binary=append_meshes(editor.read_resource(resource,256*1024*1024),[(str(shape_id),mesh)])
            if not resource.startswith('base:'):destination=resource
            else:
                relative='gabriel_criados/'+uuid.uuid4().hex[:12]+'/geometria.i3d.shapes';destination=posixpath.join(posixpath.dirname(name),relative);_,items=spans(doc.text);item=next(e for e in items if e['local']=='Shapes' and e['attrs'].get('externalShapesFile'));raw=attributes(doc,item,{'externalShapesFile':relative})
        else:
            root=ET.fromstring(doc.text);existing=[(e.get('shapeId'),inline_mesh(e)) for e in root.iter() if e.tag=='IndexedTriangleSet'];binary=append_meshes(empty_shapes(profile(editor)['shapeVersion']),existing+[(str(shape_id),mesh)]);relative='gabriel_criados/'+uuid.uuid4().hex[:12]+'/geometria.i3d.shapes';destination=posixpath.join(posixpath.dirname(name),relative)
            _,items=spans(doc.text);data=doc.utf8
            for item in reversed([e for e in items if e['local']=='IndexedTriangleSet']):data=data[:item['start']]+data[whole_end(doc,item):]
            raw=data.decode().encode(doc.encoding);current=I3D(raw);_,items=spans(current.text);section_item=next((e for e in items if e['local']=='Shapes' and e['depth']==1),None)
            if section_item:raw=attributes(current,section_item,{'externalShapesFile':relative})
            else:
                raw=section(current,'Shapes',b'');current=I3D(raw);_,items=spans(current.text);raw=attributes(current,next(e for e in items if e['local']=='Shapes' and e['depth']==1),{'externalShapesFile':relative})
        material=ET.Element('Material',{'name':title,'materialId':mid,'diffuseColor':' '.join(format(v,'.9g') for v in rgb+[1]),'specularColor':'.08 .08 .08'});raw=section(I3D(raw),'Materials',ET.tostring(material,encoding='utf-8'));current=I3D(raw);_,items=spans(current.text);target=next(e for e in items if e['start']==current.spans[parent][0]);node=ET.Element('Shape',{'name':title,'nodeId':nid,'shapeId':str(shape_id),'materialIds':mid,'translation':' '.join(format(v,'.9g') for v in translation),'castsShadows':'true','receiveShadows':'true'});raw=append_element(current.utf8,target,ET.tostring(node,encoding='utf-8')).decode().encode(current.encoding)
        pending[name]=raw;pending[destination]=binary;result=editor.change_many(pending,body['revision']);parsed=I3D(raw);index=next(n['index'] for n in parsed.nodes if n['nodeId']==nid)
        return {'project':result,'index':index,'file':name,'triangles':len(mesh['indices'])//3}

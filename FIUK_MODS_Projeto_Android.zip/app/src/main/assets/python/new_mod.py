"""Export the working vehicle as a new mod; original project/history stay intact."""
import base64,copy,os,posixpath,re,shutil,tempfile,zipfile,xml.etree.ElementTree as ET
from pathlib import Path
from core import I3D,tagname
from shop_options import vehicles,money
from decals import spans,append_element,png_pixels,gs2d_rgba
from xml_edit import whole_end
from ast_texture import png_rgba
from xml.sax.saxutils import quoteattr,escape,unescape

DEFAULT_DESC_VERSION=77  # Matches the user's working Fendt descriptor.

def text(value,label,limit=120):
    if not isinstance(value,str) or not value.strip() or len(value.strip())>limit or any(ord(c)<32 for c in value):raise ValueError('Informe '+label+' com ate '+str(limit)+' caracteres.')
    return value.strip()
def slug(value):
    if not isinstance(value,str) or not re.fullmatch(r'[A-Za-z][A-Za-z0-9_]{2,79}',value):raise ValueError('Nome do arquivo: use de 3 a 80 letras, numeros e _, comecando por letra.')
    return value

def localized(element,fallback=''):
    if element is None:return fallback
    for language in ('br','pt','en','de'):
        value=element.findtext(language)
        if value and value.strip():return value.strip()
    return (element.text or '').strip() or fallback

def descriptor(editor,vehicle):
    matches=[f['name'] for f in editor.summary()['files'] if posixpath.basename(f['name']).casefold()=='moddesc.xml']
    choices=sorted(matches,key=lambda n:(n.casefold()!='moddesc.xml',-len(posixpath.dirname(n)) if vehicle.startswith(posixpath.dirname(n)+'/') else 0,n))
    if not choices:return None,None
    name=choices[0];root=ET.fromstring(I3D(editor.read(name)).text)
    if tagname(root.tag)!='modDesc':raise ValueError('O descritor existente nao e um modDesc valido.')
    return name,root

def options(editor,model):
    with editor.lock:
        if not editor.project:raise ValueError('Abra um projeto primeiro.')
        if not isinstance(model,str) or not model.lower().endswith('.i3d') or model.startswith('base:'):raise ValueError('Abra o modelo do projeto primeiro.')
        matches=vehicles(editor,model)
        if not matches:raise ValueError('Para criar um mod novo, abra o veiculo com seu XML completo. Um I3D avulso nao define motor, rodas e componentes.')
        rows=[]
        for name,doc,root in matches:
            title=localized(root.find('storeData/name'),Path(model).stem)
            if title.startswith('$'):title=Path(model).stem
            rows.append({'file':name,'name':title,'price':root.findtext('storeData/price') or '',
                         'image':root.findtext('storeData/image') or ''})
        dname,desc=descriptor(editor,matches[0][0]);title=localized(desc.find('title')) if desc is not None else ''
        from game_compat import profile
        native_game=profile(editor)['game'];title=(title or rows[0]['name'])+' Editado';internal=('FS19_' if native_game=='FS19' else 'FS23_')+re.sub('[^A-Za-z0-9_]','_',Path(model).stem)+'_Editado';internal=internal[:80]
        return {'file':model,'vehicles':rows,'title':title[:120],'internalName':internal,
                'author':(desc.findtext('author') or 'Gabriel Mods') if desc is not None else 'Gabriel Mods',
                'version':(desc.findtext('version') or '1.0.0.0') if desc is not None else '1.0.0.0',
                'description':localized(desc.find('description')) if desc is not None else 'Veiculo editado no Gabriel Mods Editor.',
                'descVersion':int(desc.get('descVersion',DEFAULT_DESC_VERSION)) if desc is not None else (44 if native_game=='FS19' else DEFAULT_DESC_VERSION),
                'project':editor.project.name,'revision':editor.meta()['revision'],'hasDescriptor':dname is not None}

def patch_store(doc,values):
    """Update only storeData fields; preserve physics, optional paths and XML encoding."""
    data,elements=spans(doc.text);store=next((e for e in elements if e['depth']==1 and e['local']=='storeData'),None)
    if store is None:raise ValueError('O XML precisa de storeData para criar um item da loja.')
    patches=[];add=[]
    for key,value in values.items():
        item=next((e for e in elements if e['depth']==2 and e['local']==key and store['start']<e['start']<store['close']),None)
        node=ET.Element(key);node.text=value;raw=ET.tostring(node,encoding='utf-8')
        if item:patches.append((item['start'],whole_end(doc,item),raw))
        else:add.append(raw)
    for a,b,replacement in sorted(patches,reverse=True):data=data[:a]+replacement+data[b:]
    if add:
        current=I3D(data.decode().encode(doc.encoding,errors='xmlcharrefreplace'));_,items=spans(current.text);store=next(e for e in items if e['depth']==1 and e['local']=='storeData');data=append_element(current.utf8,store,b''.join(add))
    return data.decode().encode(doc.encoding,errors='xmlcharrefreplace')

def runtime_paths(editor,vehicle,raw):
    """Rebase local vehicle/config resources to the FS23 mod root.

    Never rewrite I3D resource tables: their textures/shapes are owner-relative.
    Follow local XML dependencies so sound clips and wheel models are rebased too.
    Span edits preserve encoding, comments, physics, and node indices.
    """
    from base_vehicles import ATTR
    from game_base import variants
    lookup=editor.archive_index()[0];result={};pending=[(vehicle,raw)]
    while pending:
        owner,source=pending.pop()
        if owner in result:continue
        doc=I3D(source);data,elements=spans(doc.text);patches=[]
        result[owner]=source
        def link(value):
            ref=value.strip().replace('\\','/')
            if not ref or ref.startswith(('$','/')) or ':' in ref:return value
            found=None
            for path in dict.fromkeys((posixpath.normpath(ref),posixpath.normpath(posixpath.join(posixpath.dirname(owner),ref)))):
                if path.startswith(('../','/')):continue
                found=next((lookup[c.casefold()] for c in variants(path) if c.casefold() in lookup),None)
                if found:break
            if not found:return value
            if found.lower().endswith('.xml') and found not in result:
                pending.append((found,editor.read(found)))
            if found.lower().endswith(('.ast','.astc')) and ref.lower().endswith(('.png','.dds')):
                found=posixpath.splitext(found)[0]+'.png'
            return found
        for item in elements:
            tag=data[item['start']:item['openEnd']].decode();parts=[];start=0
            for match in ATTR.finditer(tag):
                if match.group(1) not in ('filename','file','imageFilename'):continue
                value=item['attrs'].get(match.group(1));new=link(value) if value is not None else value
                if new!=value:
                    parts.extend([tag[start:match.start()],match.group(1)+match.group(2)+quoteattr(new)]);start=match.end()
            if parts:
                parts.append(tag[start:]);patches.append((item['start'],item['openEnd'],''.join(parts).encode()))
            if not item['empty'] and item['local'] in ('filename','image'):
                segment=data[item['openEnd']:item['close']].decode()
                if '<' not in segment and segment.strip():
                    value=unescape(segment.strip());new=link(value)
                    if new!=value:
                        left=segment[:len(segment)-len(segment.lstrip())];right=segment[len(segment.rstrip()):]
                        patches.append((item['openEnd'],item['close'],(left+escape(new)+right).encode()))
        for a,b,replacement in sorted(patches,reverse=True):data=data[:a]+replacement+data[b:]
        result[owner]=data.decode().encode(doc.encoding,errors='xmlcharrefreplace')
    return result

def fallback_icon():
    size=128;pixels=bytearray(bytes([15,26,35,255])*(size*size))
    # Small editor mark; a real store image or uploaded PNG is preferred.
    for y in range(22,106):
        for x in range(22,106):
            if x<36 or y<36 or y>=92 or (x>=78 and y>=62) or (y>=62 and y<76 and x>=60):
                at=(y*size+x)*4;pixels[at:at+4]=bytes([110,237,176,255])
    return png_rgba(size,size,pixels)

def icon(editor,vehicle_root,vehicle,custom):
    if custom is not None:
        if not isinstance(custom,str):raise ValueError('Icone PNG invalido.')
        try:raw=base64.b64decode(custom,validate=True)
        except Exception as e:raise ValueError('Icone PNG invalido.') from e
        w,h,pixels=png_pixels(raw);return raw,gs2d_rgba(w,h,pixels),'uploaded'
    ref=vehicle_root.findtext('storeData/image');resource=editor.resolve_resource(ref,vehicle) if ref else None
    if resource:
        try:
            raw,mime=editor.texture_image(resource,512)
            if mime!='image/png':raise ValueError('Imagem nao e PNG.')
            w,h,pixels=png_pixels(raw);return raw,gs2d_rgba(w,h,pixels),'store'
        except (ValueError,RuntimeError,OSError,ImportError):pass
    raw=fallback_icon();w,h,pixels=png_pixels(raw);return raw,gs2d_rgba(w,h,pixels),'fallback'

def make_descriptor(editor,source,old_name,vehicle,title,author,version,description,desc_version,icon_name):
    root=copy.deepcopy(source) if source is not None else ET.Element('modDesc')
    root.set('descVersion',str(desc_version));old_author=root.findtext('author') or ''
    # Existing script, specialization, brand and l10n registrations survive.
    if old_name and posixpath.dirname(old_name):
        for element in root.iter():
            for attr in ('filename','image'):
                ref=element.get(attr)
                if not ref or ref.startswith('$'):continue
                found=editor.resolve_resource(ref,old_name)
                if found and not found.startswith('base:'):
                    if posixpath.splitext(found)[1].lower() in ('.ast','.astc') and posixpath.splitext(ref)[1].lower() in ('.png','.dds'):found=posixpath.splitext(found)[0]+'.png'
                    element.set(attr,found)
    def field(name,value):
        element=root.find(name)
        if element is None:element=ET.SubElement(root,name)
        element.clear();element.text=value;return element
    field('author',author);field('version',version);field('iconFilename',icon_name)
    for key,value in (('title',title),('description',description)):
        element=root.find(key)
        if element is None:element=ET.SubElement(root,key)
        languages=[c.tag for c in element] or ['en','br'];element.clear()
        for language in dict.fromkeys(languages+['en','br']):ET.SubElement(element,language).text=value
    items=root.find('storeItems')
    if items is None:items=ET.SubElement(root,'storeItems')
    items.clear();ET.SubElement(items,'storeItem',{'rootNode':'vehicle','xmlFilename':vehicle})
    if root.find('multiplayer') is None:ET.SubElement(root,'multiplayer',{'supported':'false'})
    if old_author and old_author!=author:
        element=root.find('contributors')
        if element is None:element=ET.SubElement(root,'contributors')
        previous=(element.text or '').strip();element.text=(previous+'; ' if previous else '')+'Autor do pacote de origem: '+old_author
    return ET.tostring(root,encoding='utf-8',xml_declaration=True)

def export(editor,body):
    with editor.lock:
        if not editor.project:raise ValueError('Abra um projeto primeiro.')
        if body.get('project')!=editor.project.name or body.get('revision')!=editor.meta()['revision']:raise ValueError('O projeto mudou. Reabra Salvar como mod.')
        model=body.get('file');matches=vehicles(editor,model);chosen=next((v for v in matches if v[0]==body.get('vehicle')),None)
        if chosen is None:raise ValueError('Escolha o XML completo associado ao modelo aberto.')
        vehicle,doc,root=chosen
        if root.find('storeData') is None:raise ValueError('O XML precisa de storeData para criar um item da loja.')
        internal=slug(body.get('internalName'));title=text(body.get('title'),'o nome do mod');author=text(body.get('author'),'o autor');version=body.get('version')
        if not isinstance(version,str) or not re.fullmatch(r'\d{1,5}(?:\.\d{1,5}){3}',version):raise ValueError('Versao do mod: use quatro numeros, como 1.0.0.0.')
        description=body.get('description')
        if not isinstance(description,str) or len(description)>4000 or '\0' in description:raise ValueError('Descricao invalida: limite de 4.000 caracteres.')
        from game_compat import profile
        native_game=profile(editor)['game'];desc_version=body.get('descVersion',44 if native_game=='FS19' else DEFAULT_DESC_VERSION)
        if type(desc_version)!=int or not 1<=desc_version<=9999:raise ValueError('Versao do descritor invalida.')
        old_name,old_desc=descriptor(editor,vehicle);known=set(editor.archive_index()[0]);prefix='gabriel_mod/'+internal;number=1
        while (prefix+'/icon.png').casefold() in known or (prefix+'/icon.ast').casefold() in known:prefix='gabriel_mod/'+internal+'_'+str(number);number+=1
        png,ast,icon_source=icon(editor,root,vehicle,body.get('iconPng'))
        from game_compat import texture_assets
        w,h,pixels=png_pixels(png);icon_name,icon_files=texture_assets(editor,prefix+'/icon',png,w,h,pixels)
        fields={'name':title,'image':icon_name}
        if body.get('price') is not None:fields['price']=money(body['price'])
        vehicle_raw=patch_store(doc,fields);desc=make_descriptor(editor,old_desc,old_name,vehicle,title,author,version,description,desc_version,icon_name)
        report=['GABRIEL MODS EDITOR - MOD NOVO','Nome do arquivo: '+internal+'.zip','Veiculo: '+vehicle,'Modelo: '+model,'DescVersion: '+str(desc_version),'Origem do icone: '+icon_source,
                'Inclui os arquivos locais e as edicoes atuais do projeto.','Malhas, texturas do modelo, opcionais e configuracoes do veiculo sao preservados.',
                'Recursos nativos $data/$shared/$dataS continuam dependendo do jogo.',('Edicao mantida no formato FS19; nenhuma conversao para FS22/FS23 foi aplicada.' if native_game=='FS19' else 'O carregamento no FS23 depende do carregador de mods usado na sua instalacao.'),'Pacote gerado localmente; confira icone, loja e funcionamento no jogo.']
        extra={**runtime_paths(editor,vehicle,vehicle_raw),'modDesc.xml':desc,**icon_files,'GABRIEL_MOD.txt':'\n'.join(report).encode()}
        source=editor.export();fd,path=tempfile.mkstemp(prefix='mod_novo_',suffix='.zip',dir=editor.directory);os.close(fd);path=Path(path)
        try:
            with zipfile.ZipFile(source) as original,zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=3) as out:
                names=original.namelist();folded=[n.casefold() for n in names if not n.endswith('/')]
                if len(folded)!=len(set(folded)):raise ValueError('O projeto tem caminhos duplicados que diferem apenas por maiusculas.')
                out.writestr('modDesc.xml',extra.pop('modDesc.xml'))
                for name in list(dict.fromkeys([model]+names)):
                    if name.endswith('/') or name.casefold()=='moddesc.xml':continue
                    if name in extra:out.writestr(name,extra.pop(name));continue
                    with original.open(name) as src,out.open(name,'w') as dst:shutil.copyfileobj(src,dst,1024*1024)
                for name,raw in extra.items():out.writestr(name,raw)
            return path,{'name':internal+'.zip','vehicle':vehicle,'file':model,'iconSource':icon_source,'descVersion':desc_version}
        except Exception:path.unlink(missing_ok=True);raise

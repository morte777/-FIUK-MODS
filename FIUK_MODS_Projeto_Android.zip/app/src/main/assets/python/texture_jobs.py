"""Asynchronous texture jobs. Status never acquires the editor's conversion lock."""
import copy, os, threading, time, uuid
from pathlib import Path
from texture_convert import apply

class Cancelled(Exception):pass

class TextureJobs:
 def __init__(self,editor):
  self.editor=editor;self.lock=threading.RLock();self.rows={};self.active=None
  from android_notifications import notify
  self.notify=notify
 def _view(self,row):
  return {**{k:copy.deepcopy(v) for k,v in row.items() if not k.startswith('_')},'canCancel':row['state']=='running' and not row['_committed']}
 def get(self,identifier=None):
  with self.lock:
   if not identifier:identifier=self.active or next(reversed(self.rows),None)
   if identifier not in self.rows: return None if identifier is None else self._missing()
   row=self._view(self.rows[identifier]);row['elapsed']=round(time.monotonic()-self.rows[identifier]['_started'],1) if row['state']=='running' else row['elapsed'];return row
 def _missing(self):raise ValueError('Conversao nao encontrada.')
 def start(self,body):
  if not isinstance(body,dict):raise ValueError('Requisicao invalida.')
  with self.lock:
   if self.active:raise ValueError('Ja existe uma conversao de texturas em andamento.')
   # Avoid blocking the HTTP/UI thread if another editor operation is busy.
   if not self.editor.lock.acquire(blocking=False):raise ValueError('O editor esta ocupado. Aguarde a operacao atual.')
   try:
    if not self.editor.project or body.get('project')!=self.editor.project.name or body.get('revision')!=self.editor.meta()['revision']:raise ValueError('O projeto mudou. Reabra o conversor.')
   finally:self.editor.lock.release()
   identifier=uuid.uuid4().hex;now=time.monotonic()
   row=dict(id=identifier,state='running',phase='scan',percent=0,done=0,total=0,mip=0,mips=0,file='',elapsed=0,error='',_started=now,_cancel=threading.Event(),_committed=False,_body=copy.deepcopy(body))
   self.rows[identifier]=row;self.active=identifier
   threading.Thread(target=self._run,args=(identifier,),daemon=True,name='TexturasASTC').start()
   return self._view(row)
 def cancel(self,identifier):
  with self.lock:
   row=self.rows.get(identifier)
   if not row:raise ValueError('Conversao nao encontrada.')
   if row['state']=='running' and not row['_committed']:row['_cancel'].set()
   return self._view(row)
 def _push(self,row):
  if self.notify:
   try:self.notify(self._view(row))
   except Exception:pass  # Notification permissions never abort a conversion.
 def _run(self,identifier):
  row=self.rows[identifier]
  def progress(**fields):
   with self.lock:
    if row['_cancel'].is_set() and not row['_committed']:raise Cancelled('Conversao cancelada antes de salvar; projeto preservado.')
    if fields.get('phase')=='commit':row['_committed']=True
    row.update(fields);row['percent']=max(row.get('_percent',0),min(99,row['percent']));row['_percent']=row['percent'];row['elapsed']=round(time.monotonic()-row['_started'],1);self._push(row)
  try:
   progress(phase='scan',percent=0)
   with self.editor.lock:
    result=apply(self.editor,row['_body'],progress=progress)
    with self.lock:row['result']=result
    progress(phase='export',percent=93,file='Preparando ZIP…')
    export=self.editor.export(progress=lambda current,total,name:progress(phase='export',percent=93+int(6*current/max(1,total)),file=name))
    folder=self.editor.directory.parent/'texturas_exportadas';folder.mkdir(exist_ok=True);output=folder/(identifier+'.zip');os.replace(export,output)
    name=Path(result['project']['name']).stem+'_FS23_AST.zip'
   with self.lock:row.update(state='done',phase='done',percent=100,file='',result=result,outputName=name,_output=str(output))
  except Cancelled as error:
   with self.lock:row.update(state='cancelled',phase='cancelled',error=str(error))
  except Exception as error:
   with self.lock:row.update(state='error',phase='error',error=str(error) or type(error).__name__)
  finally:
   with self.lock:row['elapsed']=round(time.monotonic()-row['_started'],1);self.active=None;self._push(row)
 def output(self,identifier):
  with self.lock:
   row=self.rows.get(identifier)
   if not row or row['state']!='done':raise ValueError('O ZIP ainda nao esta pronto.')
   return Path(row['_output']),row['outputName']

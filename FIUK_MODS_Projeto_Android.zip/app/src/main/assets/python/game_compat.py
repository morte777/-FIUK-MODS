"""Detect native editing output; never converts a mod's game or shape version."""
import posixpath,struct,xml.etree.ElementTree as ET
from xml.parsers.expat import ExpatError

def profile(editor):
 if not editor.project:return {'game':'default','nativeTexture':'ast','shapeVersion':7}
 key=(str(editor.project),editor.meta()['revision']);cached=getattr(editor,'_game_profile_cache',None)
 if cached and cached[0]==key:return dict(cached[1])
 names=editor.archive_index()[0];descriptor=next(iter(sorted((n for n in names.values() if posixpath.basename(n).casefold()=='moddesc.xml'),key=lambda n:(n.count('/'),n.casefold()))),None)
 result={'game':'default','nativeTexture':'ast','shapeVersion':7}
 if descriptor:
  try:
   from core import I3D
   root=ET.fromstring(I3D(editor.read(descriptor)).text);version=int(root.get('descVersion','0'))
   if 40<=version<=53:result={'game':'FS19','nativeTexture':'dds','shapeVersion':5,'descVersion':version}
   # A newer descriptor deliberately remains a newer project, even with v5 imports.
  except (ValueError,OSError,LookupError,ET.ParseError,ExpatError):pass
 else:
  for name in names.values():
   if name.lower().endswith('.i3d.shapes'):
    try:
     version=struct.unpack('<H',editor.read_resource(name,4,head=True)[:2])[0]
     if version==5:result={'game':'FS19','nativeTexture':'dds','shapeVersion':5}
     break
    except (ValueError,OSError,KeyError,struct.error):continue
 editor._game_profile_cache=(key,dict(result));return result

def ordered_models(editor,models):
 """Open the store vehicle rather than the first wheel in an FS19 archive."""
 if profile(editor)['game']!='FS19':return models
 from core import I3D
 preferred=[];names=editor.archive_index()[0]
 descriptors=sorted((n for n in names.values() if posixpath.basename(n).casefold()=='moddesc.xml'),key=lambda n:n.count('/'))
 for name in descriptors:
  try:
   desc=ET.fromstring(I3D(editor.read(name)).text)
   for item in desc.findall('storeItems/storeItem'):
    vehicle=editor.resolve_resource(item.get('xmlFilename',''),name)
    if not vehicle:continue
    xml=ET.fromstring(I3D(editor.read_resource(vehicle)).text);reference=xml.findtext('base/filename') or xml.findtext('filename')
    model=editor.resolve_resource(reference,vehicle)
    if model in models and model not in preferred:preferred.append(model)
  except (ValueError,OSError,LookupError,ET.ParseError,ExpatError):continue
 return preferred+sorted((m for m in models if m not in preferred),key=lambda n:(n.count('/'),n.casefold()))

def dds_rgba(w,h,pixels):
 """Legacy RGBA8 DDS with full mip chain, top-down rows and premultiplied alpha filtering.
 No DX10 header, AST container, external encoder or format conversion of original assets.
 """
 from decals import power_of_two_rgba
 w,h,pixels=power_of_two_rgba(w,h,pixels);levels=[];width,height=w,h
 while True:
  levels.append(pixels)
  if width==height==1:break
  nw,nh=max(1,width//2),max(1,height//2);out=bytearray(nw*nh*4)
  for y in range(nh):
   for x in range(nw):
    sample=[(yy*width+xx)*4 for yy in range(y*height//nh,(y+1)*height//nh) for xx in range(x*width//nw,(x+1)*width//nw)];alpha=sum(pixels[i+3] for i in sample);j=(y*nw+x)*4
    for c in range(3):out[j+c]=round(sum(pixels[i+c]*pixels[i+3] for i in sample)/alpha) if alpha else 0
    out[j+3]=round(alpha/len(sample))
  pixels=bytes(out);width,height=nw,nh
 header=bytearray(128);header[:4]=b'DDS ';struct.pack_into('<7I',header,4,124,0x2100f,h,w,w*4,0,len(levels));struct.pack_into('<8I',header,76,32,0x41,0,32,0xff,0xff00,0xff0000,0xff000000);struct.pack_into('<I',header,108,0x401008)
 return bytes(header)+b''.join(levels)

def texture_assets(editor,stem,png,w,h,pixels):
 """Return native I3D filename plus generated files; PNG stays an editable source."""
 if profile(editor)['game']=='FS19':return stem+'.dds',{stem+'.png':png,stem+'.dds':dds_rgba(w,h,pixels)}
 from decals import gs2d_rgba
 return stem+'.png',{stem+'.png':png,stem+'.ast':gs2d_rgba(w,h,pixels)}

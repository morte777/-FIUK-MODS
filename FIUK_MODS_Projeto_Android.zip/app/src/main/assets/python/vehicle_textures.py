"""Prepare FS23 texture output in an isolated editor; never mutates the user's project."""
import json
from pathlib import Path
from core import Editor
from texture_convert import apply

def prepare(source,work,report,options,progress,notification_id=None):
 editor=Editor(Path(work)/'editor_texturas');editor.import_zip(source,'Resultado_FS23.zip')
 def tick(**row):
  percent=65+int(row.get('percent',0)*.28)
  progress(percent,'Texturas '+str(row.get('done',0))+'/'+str(row.get('total',0))+' · '+row.get('file',''))
  if notification_id:
   from android_notifications import notify
   notify({**row,'id':notification_id,'state':'running','percent':percent,'phase':'encode','elapsed':0,'error':''})
 result=apply(editor,dict(project=editor.project.name,revision=0,all=True,encoding='astc-v18',deleteDDS=True,replaceExisting=True,forceDelete=True,maxSize=options['maxSize'],quality=options['quality'],preserveProfiles=True),progress=tick)
 # These exact PNG resources are shipped by our compatibility shader.
 from decals import png_pixels,gs2d_rgba
 files={};names=editor.archive_index()[0]
 for png in ('gm_compat/white.png','gm_compat/glass.png'):
  if png.casefold() in names:
   w,h,pixels=png_pixels(editor.read(png));files[png[:-4]+'.ast']=gs2d_rgba(w,h,pixels)
 report['texturas_fs23']={'convertidas':len(result['converted']),'dds_removidas':len(result['deletedDDS']),'dds_mantidas':result['keptDDS'],'nao_convertidas':result['skipped'],'resolucao_maxima':options['maxSize'],'qualidade':options['quality'],'referencias_atualizadas':result['references'],'bytes_ast':sum(r['astBytes'] for r in result['converted'])}
 report['limites']=[s for s in report['limites'] if not s.startswith('FS23: texturas DDS')]
 resolved=[s for s in report['pendencias'] if s.startswith('Referência PNG ausente corrigida para DDS existente:')]
 report.setdefault('ajustes',[]).extend(resolved);report['pendencias']=[s for s in report['pendencias'] if s not in resolved]
 for row in result['skipped']:report['pendencias'].append('Textura DDS preservada sem conversao: '+row['file']+' · '+row['reason'])
 for row in result['keptDDS']:report['pendencias'].append('DDS convertida e preservada: '+row['file']+' · '+row['reason'])
 files['GABRIEL_MODS_RELATORIO.json']=json.dumps(report,ensure_ascii=False,indent=2).encode()
 files['GABRIEL_MODS_LEIA_ME.txt']=('Gabriel Mods V1.19\nDestino FS23\nOrigem '+report.get('origem','?')+'\nTexturas preparadas: '+str(len(result['converted']))+'\n\n'+'\n'.join(report['limites'])+'\n\nPENDENCIAS\n'+'\n'.join(report['pendencias'])).encode()
 editor.change_many(files,editor.meta()['revision']);progress(94,'Compactando ZIP com texturas FS23')
 def packing(n,total,name):
  percent=94+int(5*n/max(1,total));progress(percent,'Compactando · '+name)
  if notification_id:
   from android_notifications import notify
   notify({'id':notification_id,'state':'running','phase':'export','percent':percent,'done':len(result['converted']),'total':len(result['converted'])+len(result['skipped']),'file':name,'elapsed':0,'error':''})
 output=editor.export(progress=packing)
 return output

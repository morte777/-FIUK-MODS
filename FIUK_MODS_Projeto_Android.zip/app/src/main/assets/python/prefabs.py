"""Export the selected static subtree as a reusable accessory ZIP."""
import tempfile,zipfile,xml.etree.ElementTree as ET
from pathlib import Path
from core import Editor
from native_assets import empty_shapes
from codecs_vendor import shapes_cipher
from scene_tools import context,label

def export(editor,name,index,title,revision,allow_functional=False):
    with editor.lock:
        if revision!=editor.meta()['revision']:raise ValueError('O projeto mudou. Reabra a ferramenta.')
        context(editor,name,[index],allow_functional=allow_functional);title=label(title,'Meu conjunto');scene=editor.scene(name,include_wheels=False);version=7
        for ref in scene['externalShapes']:
            resource=editor.resolve_resource(ref,name)
            if resource:version=shapes_cipher.read_header(editor.read_resource(resource,256*1024*1024))[0];break
        root=ET.Element('i3D',{'name':title,'version':'1.6'});ET.SubElement(root,'Files');ET.SubElement(root,'Materials');ET.SubElement(root,'Shapes',{'externalShapesFile':'conjunto.i3d.shapes'});s=ET.SubElement(root,'Scene');ET.SubElement(s,'TransformGroup',{'name':title,'nodeId':'1'})
        with tempfile.TemporaryDirectory(prefix='prefab_',dir=editor.directory) as directory:
            directory=Path(directory);seed=directory/'blank.zip'
            with zipfile.ZipFile(seed,'w') as z:
                z.writestr('conjunto.i3d',ET.tostring(root,encoding='utf-8',xml_declaration=True));z.writestr('conjunto.i3d.shapes',shapes_cipher.write_header(version,42)+empty_shapes()[4:])
            new=Editor(directory/'package');new.import_zip(seed,'Conjunto.zip');new.base=editor.base;new.base_path=editor.base_path
            info=new.load_accessory_source(editor.export(),'Origem.zip');new.import_accessory('conjunto.i3d',0,name,index,0,[0,0,0],info['source']['id'],allow_functional=allow_functional)
            result=new.export().read_bytes()
        return result

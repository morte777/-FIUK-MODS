"""Offline Arm astc-encoder memory API. APK includes both supported Android ABIs."""
import ctypes, os, platform, sys
from pathlib import Path

_codec = None
def codec():
 global _codec
 if _codec is None:
  abi={'aarch64':'arm64_v8a','arm64':'arm64_v8a','x86_64':'x86_64','AMD64':'x86_64'}.get(platform.machine())
  # Host override exists solely for development; no host ELF is shipped.
  path=Path(os.environ['GABRIEL_ASTC_TEST_LIBRARY']) if sys.platform!='android' and 'ANDROID_ROOT' not in os.environ and os.environ.get('GABRIEL_ASTC_TEST_LIBRARY') else Path(__file__).parent/'codecs_vendor/astcenc'/str(abi)/'libgabriel_astc.so'
  try:lib=ctypes.CDLL(str(path))
  except OSError as error:raise ValueError('Encoder ASTC offline indisponivel nesta arquitetura: '+str(error)) from error
  lib.gm_astc.argtypes=[ctypes.c_int,ctypes.c_int,ctypes.c_float,ctypes.c_uint,ctypes.c_uint,ctypes.c_void_p,ctypes.c_void_p,ctypes.c_size_t];lib.gm_astc.restype=ctypes.c_int
  _codec=lib
 return _codec

def transform(w,h,rgba=None,blocks=None,srgb=False,quality='medium'):
 if quality not in ('fast','medium'):raise ValueError('Qualidade ASTC invalida.')
 if type(w)!=int or type(h)!=int or not 0<w<=4096 or not 0<h<=4096:raise ValueError('ASTC aceita imagens ate 4096 x 4096 nesta versao.')
 size=((w+5)//6)*((h+5)//6)*16;decoding=blocks is not None
 if decoding:
  if len(blocks)!=size:raise ValueError('Blocos ASTC incompletos.')
  image=ctypes.create_string_buffer(w*h*4);encoded=ctypes.create_string_buffer(blocks,size)
 else:
  if rgba is None or len(rgba)!=w*h*4:raise ValueError('Pixels RGBA incompletos.')
  image=ctypes.create_string_buffer(rgba,len(rgba));encoded=ctypes.create_string_buffer(size)
 error=codec().gm_astc(int(decoding),int(srgb),10.0 if quality=='fast' else 60.0,w,h,image,encoded,size)
 if error:raise ValueError('Falha no encoder ASTC: '+str(error))
 return image.raw if decoding else encoded.raw

def encode_image(image,srgb=False,quality='medium'):
 from dds_texture import image_module
 Image=image_module()
 # Same row orientation as V18's astcenc -yflip.
 with image.convert('RGBA') as rgba, rgba.transpose(Image.Transpose.FLIP_TOP_BOTTOM) as flipped:
  return transform(*flipped.size,rgba=flipped.tobytes(),srgb=srgb,quality=quality)

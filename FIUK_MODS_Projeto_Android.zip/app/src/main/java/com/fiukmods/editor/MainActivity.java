package com.fiukmods.editor;

import android.app.*;
import android.os.*;
import android.content.*;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.provider.MediaStore;
import android.webkit.*;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.util.*;
import android.util.Base64;
import com.chaquo.python.*;

public class MainActivity extends Activity {
    WebView web;
    ValueCallback<Uri[]> fileCallback;
    Uri exportUri;
    OutputStream exportStream;
    String exportName="mod.zip";
    static final int PICK_FILE=4101, PICK_BASE=4102;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(0xff111827);
        Python.start(new AndroidPlatform(this));
        File data=new File(getFilesDir(),"projetos"); data.mkdirs();
        File root=new File(getFilesDir(),"editor"); root.mkdirs();
        try { copyAssets("python",root); } catch(Exception e) { showError(e); return; }
        try { Python.getInstance().getModule("sys").getAttr("path").callAttr("insert",0,root.getAbsolutePath()); } catch(Exception ignored) {}
        try { Python.getInstance().getModule("android_entry").callAttr("start",data.getAbsolutePath()); }
        catch(Exception e) { showError(e); return; }

        web=new WebView(this);
        web.setBackgroundColor(0xff10151f);
        WebSettings st=web.getSettings(); st.setJavaScriptEnabled(true); st.setDomStorageEnabled(true);
        st.setAllowFileAccess(false); st.setAllowContentAccess(true);
        web.addJavascriptInterface(new Bridge(),"GabrielAndroid");
        web.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if(fileCallback!=null) fileCallback.onReceiveValue(null);
                fileCallback=cb;
                Intent i=p.createIntent(); startActivityForResult(i,PICK_FILE); return true;
            }
        });
        web.setWebViewClient(new WebViewClient());
        setContentView(web);
        web.postDelayed(()->web.loadUrl("http://127.0.0.1:8766/"),900);
    }
    void copyAssets(String path, File dest) throws IOException {
        String[] children=getAssets().list(path);
        if(children==null || children.length==0) {
            dest.getParentFile().mkdirs();
            try(InputStream in=getAssets().open(path); OutputStream out=new FileOutputStream(dest)) {
                byte[] b=new byte[65536]; int n; while((n=in.read(b))>0) out.write(b,0,n);
            } return;
        }
        dest.mkdirs();
        for(String child:children) copyAssets(path+"/"+child,new File(dest,child));
    }
    void showError(Exception e) {
        new AlertDialog.Builder(this).setTitle("FIUK MODS").setMessage(e.toString()).setPositiveButton("OK",null).show();
    }
    @Override protected void onActivityResult(int req,int res,Intent data) {
        super.onActivityResult(req,res,data);
        if(req==PICK_FILE && fileCallback!=null) {
            Uri[] result=(res==RESULT_OK && data!=null && data.getData()!=null)?new Uri[]{data.getData()}:null;
            fileCallback.onReceiveValue(result); fileCallback=null;
        }
        if(req==PICK_BASE && res==RESULT_OK && data!=null && data.getData()!=null) {
            try {
                Uri u=data.getData(); File target=new File(getFilesDir(),"game-base-"+System.currentTimeMillis()+".apk");
                try(InputStream in=getContentResolver().openInputStream(u); OutputStream out=new FileOutputStream(target)) {
                    byte[] b=new byte[1024*1024]; int n; while((n=in.read(b))>0)out.write(b,0,n);
                }
                String path=target.getAbsolutePath();
                web.evaluateJavascript("window.dispatchEvent(new CustomEvent('gabriel-base-selected',{detail:"+JSONObjectQuote(path)+"}))",null);
            } catch(Exception e){showError(e);}
        }
    }
    String JSONObjectQuote(String s) { return "\""+s.replace("\\","\\\\").replace("\"","\\\"")+"\""; }
    class Bridge {
        @JavascriptInterface public void chooseBase() {
            runOnUiThread(()->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,PICK_BASE);});
        }
        @JavascriptInterface public void showTools() {
            runOnUiThread(()->new AlertDialog.Builder(MainActivity.this).setTitle("FIUK MODS")
                .setItems(new String[]{"Sobre o editor","Abrir base do jogo"},(d,w)->{if(w==1)chooseBase();else new AlertDialog.Builder(MainActivity.this).setMessage("FIUK MODS — Editor de veículos e mods.").setPositiveButton("OK",null).show();}).show());
        }
        @JavascriptInterface public synchronized String beginExport(String name,String mime) {
            try {
                exportName=name; ContentValues v=new ContentValues();v.put(MediaStore.Downloads.DISPLAY_NAME,name);v.put(MediaStore.Downloads.MIME_TYPE,mime);v.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/FIUK MODS");v.put(MediaStore.Downloads.IS_PENDING,1);
                exportUri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);
                if(exportUri==null)return null; exportStream=getContentResolver().openOutputStream(exportUri);return "ok";
            } catch(Exception e){return null;}
        }
        @JavascriptInterface public synchronized boolean appendExport(String id,String b64) {
            try { if(exportStream==null)return false; exportStream.write(Base64.decode(b64,Base64.DEFAULT));return true; }catch(Exception e){return false;}
        }
        @JavascriptInterface public synchronized void finishExport(String id) {
            try {if(exportStream!=null)exportStream.close();exportStream=null;if(exportUri!=null){ContentValues v=new ContentValues();v.put(MediaStore.Downloads.IS_PENDING,0);getContentResolver().update(exportUri,v,null,null);}}catch(Exception ignored){}
            exportUri=null;runOnUiThread(()->Toast.makeText(MainActivity.this,"Arquivo salvo em Downloads/FIUK MODS",Toast.LENGTH_LONG).show());
        }
        @JavascriptInterface public synchronized void abortExport(String id) {
            try{if(exportStream!=null)exportStream.close();if(exportUri!=null)getContentResolver().delete(exportUri,null,null);}catch(Exception ignored){}
            exportStream=null;exportUri=null;
        }
        @JavascriptInterface public void download(String url,String name) {
            web.post(()->web.evaluateJavascript("(async()=>{let r=await fetch("+JSONObjectQuote(url)+");let b=await r.arrayBuffer();let a=new Uint8Array(b),s='';for(let i=0;i<a.length;i+=32768)s+=String.fromCharCode(...a.subarray(i,i+32768));return btoa(s)})()", value->{
                try {String b64=value==null?"":value.replaceAll("^\"|\"$",""); if(b64.isEmpty()||b64.equals("null"))return;
                    beginExport(name,"application/zip");
                    for(int i=0;i<b64.length();i+=65536)appendExport("ok",b64.substring(i,Math.min(i+65536,b64.length())));
                    finishExport("ok");
                }catch(Exception e){showError(e);}
            }));
        }
    }
    @Override public void onBackPressed(){if(web!=null && web.canGoBack())web.goBack();else super.onBackPressed();}
}

# Gabriel Mods Editor — base nova

O objetivo e editar mods FS22 no Android e entregar um APK no fim do projeto.
A versao 0.20 e uma base executavel no Termux, com interface local por toque.
Ela foi escrita sem aproveitar o codigo do editor anterior.

## Partes

| Arquivo | Responsabilidade |
| --- | --- |
| `core.py` | Projetos, ZIP, leitura I3D, alteracoes de atributos, XML e historico |
| `shapes_reader.py` | Leitor binario FS22, aceleracao opcional e buffers compactos |
| `codecs_vendor/` | Cipher MIT e avisos de licencas de terceiros |
| `game_base.py` | Indice e leitura local de recursos do APK/ZIP ou pasta, somente leitura |
| `wheel_preview.py` | Configuracoes e montagem estatica de rodas, aros, pesos e cubos |
| `shader_materials.py` | Metadados e regras do vehicleShader, paleta RGBA e tabelas externas |
| `ast_texture.py` | Leitura GS2D v6/ASTC e selecao de mipmap para previa |
| `web/textures.js` | Upload ASTC, fallback de imagem, cache e diagnosticos |
| `server.py` | Transporte HTTP local; nao contem a logica de edicao |
| `web/app.js` | Interface, selecao, formularios e fluxo de trabalho |
| `web/viewer.js` | WebGL, matrizes de hierarquia e camera touch |
| `web/style.css` | Interface escura, responsiva, sem fontes ou recursos externos |
| `examples/mod_exemplo.zip` | Cena inline para verificar importacao, renderizacao e exportacao |
| `tests/` | Testes automatizados do nucleo e transporte |

## Contrato do projeto

O original fica em `projetos/<id>/original.zip`. Alteracoes ficam em blobs
identificados por SHA-256, com revisoes e historico em `project.json`.
Nenhuma alteracao regrava automaticamente o ZIP importado pelo usuario.
Na exportacao, cada entrada original e mantida; somente o conteudo dos arquivos
editados e substituido. O ZIP pode ser recomprimido, mas os bytes dos arquivos
nao editados permanecem iguais. Sem alteracoes, exporta uma copia exata do ZIP.

Transformacoes usam indices internos de nos, sem assumir nodeIds exclusivos.
O documento e validado com Expat; somente o trecho do atributo selecionado e
alterado no texto original. O editor XML e explicito: um arquivo editado como
texto e salvo em UTF-8 e tem sua declaracao de codificacao atualizada.

## Contrato de visualizacao

`GET /api/scene?file=<caminho>` retorna `nodes`, `meshes`, `materials`,
`warnings` e `externalShapes`. O leitor binario alimenta `meshes` com posicoes/normais/tangentes/UVs Float32 e indices
UInt16/UInt32 em base64, mais contagens, bounds e subsets. A camera e a edicao
de transformacoes continuam iguais. A geometria decodificada fica em cache
por SHA-256 do binario; alteracoes de transformacao nao invalidam a malha.
Malhas nao decodificadas nao sao substituidas por um modelo ficticio.

A hierarquia segue o documento I3D. A visualizacao desenha triangulos inline
e binarios com iluminacao simples. Malhas binarias usam normais originais,
indices, UVs e materiais por subset. ASTC vai diretamente a GPU; em aparelhos
sem suporte, astcenc ou texture2ddecoder podem produzir uma previa PNG local.
O shader de previa aproxima colorMask (colorMat0..7 nas faixas UV negativas),
normal/specular, decalques e transparencia; nao executa os shaders GIANTS.
Ainda faltam skinning e reproducao completa dos materiais do jogo. Formas nonRenderable nao sao desenhadas; seus filhos continuam validos.
A camera enquadra considerando a proporcao da tela, inclusive em retrato.

Referencia primaria do formato: [GIANTS I3D Format](https://gdn.giants-software.com/documentation_i3d.php).

## Caminho para o APK

1. Base atual: importacao/exportacao, arvore, transformacoes, XML e cena inline.
2. Leitor binario `.i3d.shapes`: leitura estatica implementada e validada no
   Fendt900 enviado, com consumo completo das 251 entidades e indices/bounds
   validados. Proximo trabalho: skinning e mais exemplares de mods. A escrita
   do binario fica fora desta fase.
3. Texturas AST/GS2D e materiais por subset implementados. DDS nativo e shaders
   completos ficam para outra etapa. Recursos externos ausentes sao diagnosticados.
4. Gizmos de transformacao, selecao pelo toque no modelo e ferramentas de anexos.
5. Integracao Android: seletor e exportacao pelo sistema, armazenamento privado,
   WebView com os assets locais e integracao do nucleo Python no aplicativo.
   O adaptador Android substitui a inicializacao manual pelo Termux.
6. Compilar e testar o APK em aparelho real, verificando GPU, memoria, retomada
   de projetos e exportacao. Nenhum APK foi compilado nesta entrega.

Nao e suficiente colocar uma pagina num WebView e chamar de editor completo.
O leitor de malhas e os testes em mods reais precisam preceder a entrega final.

## Verificar

```bash
python -m unittest discover -s tests -v
```

O nucleo e o servidor usam a biblioteca padrao Python; NumPy e opcional para
acelerar o cipher, sem mudar o resultado. A interface e
o renderizador nao consultam CDNs. O desenvolvimento Android final precisara
definir e fixar as dependencias de compilacao e integracao Python.

## Fontes e licencas do leitor

- https://github.com/BrewingCoder/giants-fs-codecs — commit ba8db595802620a43aa3e212f1413da52c59bc72.
- https://github.com/Donkie/I3DShapesTool — commit 1a2ecf3125d6754d9100c342419003bf048dbec5.

O cipher Python e sua tabela original estao incluidos sob MIT, com avisos em
`codecs_vendor`. O parser FS22 segue o layout de I3DShape/I3DShapeSubset da
fonte primaria; o parser FS25 possui subsets diferentes e nao e usado aqui.
O arquivo .shapes do usuario e lido, nunca convertido ou regravado.

## Texturas e preservacao

O manifesto `materialDetails` diferencia diffuse, normal e specular.
A resolucao de referencias procura AST ao lado do arquivo DDS/PNG esperado,
sem alterar o XML. `textureInfo` lista recursos resolvidos e ausentes.
`/api/texture` entrega mipmaps ASTC e `/api/texture-image` entrega a previa PNG
ou a imagem original. Ambos exigem a identidade do projeto para evitar respostas
de uma importacao anterior. O frontend descarta carregamentos de cenas antigas.
O cache de texturas e separado dos arquivos editados e do ZIP de exportacao.

GS2D v6: cabecalho de 80 bytes, chunks alinhados em 16 bytes, dados ASTC 6x6
crus ou comprimidos com zlib. Ate quatro mips usam chunks do menor para o maior;
acima disso, o primeiro chunk agrupa mips 3 em diante e os demais guardam 2,1,0.
Essa interpretacao foi verificada com os 24 AST do mod e o conversor fornecido.
O decoder nao aceita outros tipos de contêiner GS2D nem arrays/cubemaps.

Referencias de API:
- https://registry.khronos.org/webgl/extensions/WEBGL_compressed_texture_astc/
- https://github.com/ARM-software/astc-encoder/blob/main/Docs/FileFormat.md

Testes adicionais: `node tests/test_viewer.mjs` e `node tests/test_textures.mjs`.
O teste do Fendt e opcional: defina GABRIEL_TEST_MOD com o caminho do ZIP.

## Base do jogo

`GET /api/base` lista a base conectada e candidatos APK/ZIP em Download.
`POST /api/base {path}` seleciona um arquivo local ou pasta; path null desconecta.
A selecao e explicita, mantida em `game_base.json` ao lado dos projetos.
Nao ha upload/copia do APK; ZipFile indexa o diretorio central, inclusive ZIP64,
e abre somente os recursos solicitados. Arquivos em assets/data e assets/shared
sao mapeados para caminhos data/ e shared/. Pastas data extraidas tambem funcionam.

Os recursos externos recebem identificadores `base:<sessao>/<caminho>`,
separados do ZIP do mod. Trocar a base invalida suas URLs e limpa o cache GPU
desses recursos. Mover/substituir o APK exige reconectar; o original nao e alterado.
A exportacao e o historico continuam operando somente sobre o ZIP do mod.
Cabecalhos identificam AST/ASTC mesmo em arquivos chamados .png.
A base fornece texturas, I3Ds e .shapes para a montagem de rodas da v07.
Outros tipos de subI3D ainda nao sao instanciados automaticamente.
O leitor nao abre GAR, classes.dex ou bibliotecas nativas do APK.

## Materiais vehicleShader — v0.5

A referencia foi o vehicleShader(1).xml de 72625 bytes enviado pelo usuario.
Parameters/colorMat, Textures/mPixelsDiffuse e mPixelsSpecular, Variations e
START_FS/POST_DIFFUSE_COLOR_FS/POST_GLOSS_COLOR_FS fundamentam a adaptacao.
O XML completo proprietario nao e incluido no pacote. O descritor interpreta
defaults numericos, caminhos e flags conhecidas do XML presente no mod/APK;
nenhum codigo recebido e executado. Ausencia do XML usa a referencia enviada.

O perfil medio usa lookup 2D na primeira linha, pelo centro do texel com
filtragem nearest. UV.y negativo usa colorMat.rgb e colorMat.a como indice.
UV.y positivo usa floor(UV.x) + floor(UV.y)*8. O shader WebGL preserva os indices
e a separacao sRGB (diffuse) / linear (specular). Mascaras vehicleShader sao
R=desgaste, G=AO e B=sujeira; brilho/metalness pertencem a tabela specular.
A previa permanece limpa, sem animar RDT ou efeitos de neve.

staticLight inclui colorMask no shader original. secondUV e Decal escolhem UV1
para glossMap, preservando UV0 para diffuse; normalThirdUV escolhe UV2.
As tabelas sao lidas sob demanda da base; nao entram na exportacao do mod.
A verificacao GPU usa tabelas controladas, pois as tabelas reais do APK ficaram
no aparelho do usuario. O shader Vulkan .sharc nao e executado em WebGL.

## GS2D RGBA8 — v0.6

As tabelas reais enviadas tem dimensoes 50x1, quatro componentes e formato 5.
O header de 80 bytes e o alinhamento de 16 bytes sao os mesmos do GS2D ASTC,
mas cada mip contem width*height*4 bytes RGBA8 em vez de blocos ASTC.
A diffuse possui chunk cru de 200 bytes (arquivo 288 bytes); a specular possui
chunk zlib de 166 bytes, expandindo para 200 (arquivo 256 bytes).
A resposta de textura indica encoding=rgba8 e o frontend usa texImage2D com
RGBA/UNSIGNED_BYTE, inclusive em GPUs sem a extensao ASTC. Nao troca canais
nem reordena a tabela. O fallback PNG tambem usa esses pixels diretamente.
O formato 34 continua no caminho ASTC anterior. Outros formatos sao recusados
com informacao do cabecalho, sem presumir que todo GS2D seja ASTC.
Os arquivos originais do usuario nao acompanham o pacote do editor.
Para repetir os testes reais, defina GABRIEL_TEST_TEXTURES para a pasta que
contem detailArrayPixels_diffuse.ast e detailArrayPixels_specular.ast.

## Montagem de rodas — v0.7

`scene()` monta a primeira configuracao por padrao. A API aceita wheelConfig
(zero-based); -1 desativa a montagem. Chamadas internas usam include_wheels=False
para carregar assets, impedindo montagem recursiva. O leitor identifica o XML
pelo base/filename, resolve heranca e usa os mappings do veiculo para linkNode,
driveNode ou repr. yOffset e objectChange alteram somente a cena em memoria.

Assets sao carregados uma vez por cena, selecionados por indice de subtree e
mesclados com IDs separados para malhas/materiais. Um root desanexado conserva
seus transforms locais, sem acumular os ancestrais do arquivo de origem.
Pecas criadas levam previewOnly; nos com overrides levam previewDriven.
A interface permite consulta/foco, bloqueando sua gravacao no I3D principal.
Os indices originais do I3D principal permanecem estaveis.

O cache shapes_v4 preserva cores Float32 dos vertices. Aros RIM sao deformados
em copia da geometria, usando polegadas/metros e os pesos RGB do shader enviado.
Subsets distintos usam seus intervalos de vertices. Outros aros normalizados
usam a escala definida pelo XML. Pneus mantem a geometria original do asset.
RIM_DUAL/HUB_DUAL complexos e additionalWheel ainda exigem adaptacao especifica.
A montagem informa recursos ausentes e nao introduz malhas ficticias.

Referencia primaria de carga, overrides, escala e selecao dos nos:
https://gdn.giants-software.com/documentation_scripting_fs22.php?category=48&class=580&version=script
Schema oficial: https://validation.gdn.giants-software.com/fs22/wheel.html
O algoritmo de smart rim segue getRimPos do vehicleShader.xml enviado pelo usuario.

Validacao: Fendt real (36 configuracoes e 4 cubos locais), testes de heranca,
namespace, yOffset, lados, escala e cor; API com controle de nos gerados; exportacao
sem contaminacao da base. Uma base controlada montou 4 pneus, 8 aros e 4 cubos
para conferir a composicao em OpenGL. Os modelos reais dos pneus/aros do APK
ficaram no aparelho do usuario e precisam de verificacao nele.

## Edicao por toque — v0.8

O Viewer retem as posicoes/indices na CPU por malha, compartilhadas entre
instancias. No toque, inverte view/projection e a matriz mundial de cada no,
filtra pelos limites e testa o segmento near/far contra os triangulos. Compara
as fracoes do mesmo segmento entre instancias, inclusive escalas espelhadas.
Nos ocultos, nonRenderable e transformacoes singulares nao interceptam o toque.
O caminho de indices uint sem extensao GPU usa a mesma geometria para selecao.
A transparencia de pixels nao faz parte do picking nesta versao.

Tap de ate 700ms e deslocamento maximo de 8px seleciona. Arrasto e multitouch
cancelam o candidato a tap; pointercancel nao seleciona. A caixa ja existente
identifica a selecao. A arvore continua permitindo selecionar grupos ou pecas
ocultas/atras de vidro.

web/editing.js faz ajustes locais sobre copias dos vetores. A interface guarda
um snapshot anterior a primeira alteracao, atualiza os valores numericos e as
matrizes sem recarregar geometria, e so envia POST transform quando SALVAR e
acionado. Cancelar restaura todos os vetores e visibilidade. Escala e multiplicativa,
preserva sinal e limita o fator positivo minimo a 0.01. A barra aplica deslocamento
relativo ao inicio daquele gesto e retorna ao centro ao terminar; +/- faz um passo.

O backend e o historico existentes fazem a gravacao atomica por revisao. Apos
salvar a cena e reconstruida, incluindo os vinculos das rodas. Gerados e pontos
previewDriven nao podem ser editados pelo painel. Troca de selecao/contexto
consulta a existencia de previa pendente; exportacao e bloqueada ate salvar ou
cancelar. XML nao salvo bloqueia novos ajustes. Nenhuma textura ou malha e
reescrita para aplicar transformacoes.

Verificacao: test_viewer.mjs cobre ray picking por triangulos, profundidade,
hierarquia, reflexao, partes ocultas e gestos. test_editing.mjs cobre valores e
snapshots. test_touch_editor.mjs executa os eventos do app real com DOM/transporte
simulados: selecao, slider, cancelar, guardar descarte, salvar, partes geradas e
exportacao pendente. Estes testes nao substituem a verificacao de toque/WebGL
no celular. A v0.10 acrescenta plotagem com imagem.

## Correcao de inicializacao — v0.8.1
O servidor inclui /editing.js na lista publica explicita. Sua ausencia na v08
causava HTTP 404 no import estatico e impedia a execucao do app inteiro.
O teste de transporte percorre recursivamente os imports iniciados no script
module do HTML, exige HTTP 200 e MIME JavaScript, e confirma que core.py segue
indisponivel por HTTP. Os testes anteriores de eventos com DOM simulado nao
cobriam o carregamento real de modulos pelo servidor.

## Espaco de trabalho — v0.9
sceneSurface contem canvas, ferramentas e indicadores. O painel touchEditor
ocupa uma linha flex separada abaixo dessa superficie, sem posicionamento
absoluto e sem altura maxima que recorte os botoes. Salvar/cancelar ficam na
barra persistente da peca. Recolher so oculta editBody, preservando a previa.
O modo scene-expanded fixa viewport a janela e mantem o botao Voltar visivel.
O ResizeObserver do canvas recalcula a projecao e o picking na area efetiva.
Menus nativos reduzem a altura dos controles de modo/eixo/precisao.

## Plotagem persistente — v0.10

decals.py decodifica PNG RGB/RGBA 8 bits, valida CRC, dimensoes, inflate limitado
e filtros de linha. O navegador prepara uma imagem normalizada em canvas,
limitada a 1024 px. O escritor GS2D v6 usa formato 5 RGBA8, perfil 4 como nos
arquivos de tabela enviados, chunks alinhados a 16 bytes e zlib somente quando
reduz o tamanho. As linhas sao invertidas para a orientacao nativa da textura.
Mipmaps usam media ponderada por alfa para evitar bordas de cor transparente.
O PNG normalizado acompanha o AST no ZIP. Nao depende de encoder externo.

O picking registra ponto e normal locais do triangulo atingido. A interface
orienta o plano +Z nessa normal e adiciona 0.003 unidades de afastamento. A
largura e dada em metros na API e em cm no formulario. O Shape e acrescentado
como ultimo filho da peca escolhida, sem deslocar caminhos de irmaos existentes.
Novos IDs consideram as referencias XML e as malhas binarias existentes.

Para uma fonte .shapes v4-v7, append_binary_quad retem todos os registros
cifrados existentes e apenas incrementa o contador e anexa uma entidade de tipo
1. A entidade tem quatro vertices, UV0, normais, dois triangulos e um subset.
O estado do cifrador avanca por cada leitura/registro como no leitor vendorizado.
Nao reinterpreta nem reserializa entidades opacas/curvas/ossos existentes.
Se o .shapes vier da base, materializa uma copia no mod e muda a referencia
somente no start-tag Shapes; nunca altera o APK. Cenas sem arquivo binario
recebem IndexedTriangleSet inline, conforme a estrutura I3D documentada em
https://gdn.giants-software.com/documentation_i3d.php . O XML e editado por spans:
comentarios, atributos desconhecidos e codificacao existente sao preservados.

change_many agrupa o I3D, as duas texturas e a malha binaria numa revisao e numa
entrada do historico. O formato anterior de historico com uma unica chave file
continua aceito. before=null representa arquivo novo, removido do overlay no
undo. summary, archive_index e export incluem os nomes novos; o indice de
recursos e invalidado por projeto/revisao. Sem alteracoes o export volta a ser
copia exata do ZIP original. Arquivos da base nunca entram sem necessidade;
a excecao explicita desta operacao e a copia da fonte de malha quando o I3D
principal ja a referencia fora do mod.

Testes incluem AST RGBA8/mips/orientacao/alfa, PNG invalido, revisao atomica,
IDs/caminhos relativos, exportacao, historico legado e em lote, retomada apos
reinicio, fonte binaria na base, preservacao byte a byte de entidades originais
nas versoes 4-7 e Fendt real. Testes de eventos cobrem formulario e normal/ponto
do toque; transporte HTTP cobre criacao/export/undo/redo. Nao ha teste executado
no motor FS23: o carregamento nativo do novo material/geometria precisa ser
conferido no aparelho. O recurso cria um plano, nao uma projecao sobre curvas.

## Gravacao de valores fracionarios — v0.10.1
O formulario de propriedades usa novalidate e step=any. O botao compacto
chama a mesma funcao saveTransform usada por submit. A funcao verifica todos
os eixos (vazio, badInput, finitude e limite 1e9) antes de chamar a API, para
que campos em um inspector escondido nao bloqueiem silenciosamente submit.
A precisao da barra e independente da validade dos valores numericos.
O estado sem alteracoes mostra Salvo e confirma por status; ajustes mostram
Salvar. O teste de eventos modela o bloqueio por stepMismatch antes de submit,
reproduziu a falha com a coordenada 2.003 m e cobre rotacao/escala fracionarias,
repeticao sem escrita e erro explicito para campo vazio.

## Projecao sobre a lataria — v0.11

surface_decal.py transforma vertices da malha receptora para o espaco do projetor,
com rotacao ZYX e escala nao uniforme/espelhada. Recorta cada triangulo contra
seis planos de uma caixa orientada. A espessura e dada nas unidades da peca pai,
independente da escala Z do adesivo. Filtra por inclinacao real da face em relacao
a normal do projetor, sem distorcao pela escala. O offset e aplicado na normal
interpolada em coordenadas da peca e depois convertido ao espaco do adesivo.

A semente usa a menor distancia geometrica da origem aos poligonos recortados,
na metrica fisica da peca, nao ao centroide. Seleciona somente a orientacao da
semente e faz flood fill por posicoes compartilhadas (incluindo vertices duplicados
por seams de UV/normais). Mantem somente o trecho conectado mais proximo. Nao
faz ponte entre vaos nem projeta em nos filhos/pecas diferentes. UV e projetado
por XY sem esticar o trecho recortado para preencher a imagem. Winding/normais
consideram escalas negativas. Nao subdivide superficies lisas artificialmente:
a forma acompanha os triangulos da lataria, com recortes nos limites da caixa.

Os escritores inline e binario agora recebem malhas genericas com bounds reais.
O escritor binario mantem todos os registros existentes e anexa a nova entidade.
I3D UserAttributes guarda gabrielPlotagem (JSON de dimensoes/modo/parametros).
A anotacao decalInfo no payload da cena permite reconhecer e reprojetar adesivos;
a v10 sem metadados e reconhecida pela textura gerada e bounds do plano.
POST /api/decal aceita projection opcional; sem ela conserva o modo plano anterior.
POST /api/decal-project cria uma nova shapeId para o mesmo no/material/textura,
com I3D + binario numa operacao de historico. Falha de projecao nao grava nada.
Fontes binarias do APK sao copiadas para o mod, com referencia atualizada; o APK
fica intacto. Animacao por ossos continua sendo apenas previa estatica.

A interface tem modo curvo na importacao, profundidade e botao Curvar nas plotagens
existentes. Curvar salva ajustes validos pendentes antes de abrir o dialogo.
O dialogo controla profundidade, inclinacao e afastamento. Depois de transformar
uma malha ja projetada, o usuario reaplica Curvar para recalcular o encaixe.
As transformacoes nao disparam uma projecao pesada a cada evento do dedo.

Testes: curva, UV/offset/normais, faces traseiras, ilhas desconectadas, vaos,
profundidade e angulo, espelhamento e escala Z, parametros invalidos/atomicidade,
malhas inline/binarias, plotagem v10, repeticao sem duplicar metadados,
undo/redo e exportacao. O capo real do Fendt produz malha nao plana com mais de
dois triangulos, preservando os bytes de entidades existentes. Transporte e
interface cobrem a importacao e reprojecao com limites. Sem execucao do FS23.


## Pintura e acessorios — v0.12

`painting.py` identifica os materiais da peca e os slots colorMask negativos
presentes nos indices/subsets da malha. Converte o seletor sRGB para RGB linear,
preserva o quarto componente do colorMat e o alpha do diffuseColor. Por padrao,
clona o material e troca seus IDs somente no no selecionado; o modo compartilhado
edita o material existente. Parametros, texturas e variacoes permanecem.
A previa do navegador e reversivel e nao grava ate SALVAR COR.

`accessories.py` mantem um Editor separado em accessory_source dentro do projeto.
A origem e validada por ID, e a revisao do destino e conferida antes da importacao.
A subarvore deve conter somente Shape/TransformGroup estaticos, sem skin.
IDs de nos, materiais, arquivos e shapes sao remapeados; o grupo e acrescentado
como ultimo filho para preservar caminhos de indices anteriores. O selecionado e
centralizado e tornado visivel; os filhos preservam suas visibilidades.
Atributos de fisica e funcoes do veiculo nao sao transferidos.

`native_assets.py` serializa novas malhas estaticas e preserva os registros
criptografados existentes. UV0-3, indices, subsets, normais, tangentes e cores
sao copiados. Geometria inline basica pode ser convertida para native v7.
`xml_edit.py` insere secoes e altera atributos preservando o XML fora dos trechos
editados. Acessorios locais usam namespace exclusivo; somente recursos referenciados
(e auxiliares do diretorio local de shader) sao copiados. Referencias $data continuam
externas. Nao ha conversao automatica de DDS/shaders FS22 para FS23.

I3D, geometria e recursos novos entram em uma unica change_many. Desfazer/Refazer
restaura/remova todos juntos, incluindo arquivos que nao existiam antes.
A origem nao participa da exportacao do destino. Os testes verificam transporte
HTTP, eventos da interface com DOM simulado, preservacao binaria, exportacao,
historico e um acessorio real do Fendt. Nao substituem teste WebGL no Android ou
validacao dentro do jogo.


## Ferramentas de pecas — v0.13

`scene_tools.py` implementa /api/scene-tool para duplicate, group e delete.
Todas as operacoes conferem revisao, selecao, hierarquia e limites antes de
uma gravacao atomica do I3D. Nenhum .shapes ou recurso e reescrito.
A duplicacao recebe nodeIds novos, compartilha shapeIds/materialIds e filtra
atributos para a lista visual. Somente metadados de plotagem/grupo do editor
sao copiados; scripts/onCreate e dinamica nao sao duplicados.

Agrupamento aceita irmaos sem relacao ancestral entre si. Cria um TG com
rotacao zero, escala um e translacao na media das origens locais. Subtrai
essa media das translacoes dos filhos, mantendo suas rotacoes e escalas,
inclusive escalas negativas/nao uniformes. Nos movidos mantem seus nodeIds.

Excluir troca uma subarvore por um TG vazio. Agrupar troca cada subarvore
movida por um TG vazio e acrescenta o grupo no fim dos filhos. Reservas com
prefixo __GabrielReserva__ sao omitidas na arvore da interface e protegidas.
Isso conserva os caminhos hierarquicos dos nos FORA da selecao. Caminhos
dos nos movidos/removidos mudam: por isso a auditoria recusa referencias
em XMLs do projeto, skin, dinamica, animacao e UserAttributes funcionais.
A raiz e protegida. Nao ha reescrita automatica de XMLs ou Lua.
O scanner de XML pode gerar bloqueios conservadores em arquivos de outro
veiculo que tenham o mesmo caminho. Referencias Lua nao sao analisadas.

Ocultar/Mostrar usa /api/transform existente e nao afeta fisica ou hierarquia.
Os tres pontos do painel compacto abrem as ferramentas; Ajustes continua
acessivel dentro do dialogo. Agrupamento usa checkboxes de irmaos; nao altera
a selecao do visualizador antes de confirmar. Todos os formularios validam
valores explicitamente, evitando bloqueio silencioso por step numerico.

Testes novos cobrem IDs/metadados, conservacao de caminhos externos, pose,
negativos na escala, guardas de referencias, falhas atomicas, exportacao,
Desfazer/Refazer/reabertura, HTTP e eventos reais do modulo com DOM simulado.
O CBT real foi usado para agrupar, duplicar e excluir plotagens, seguido de
restauracao exata do ZIP original via historico. Nao houve teste dentro do jogo.


## Preservacao binaria de acessorios — v0.14

O leitor descartava as densidades UV apos le-las. O serializador escrevia 1
para todos os canais, independentemente da origem. No par real Valtra/Fendt,
a bandeira e a termica tinham densidade 0 na origem e 1 no arquivo exportado;
os buffers e os bytes das texturas continuavam identicos. Isso prova a perda
de metadados, mas o teste visual no jogo continua necessario para confirmar
a relacao com a pixelacao relatada.

parse_shape retorna uvDensities (por subset, quatro canais, None se ausente),
boundingSphere, nativeOptions e nativeAttachments. Cache shapes_v5 substitui
v4; caches antigos nao sao reutilizados. Valores finitos de densidade, incluindo
zero, sao preservados. Dados antigos sem densidade usam zero na conversao.

extract_records le somente os registros selecionados das fontes .shapes.
append_meshes aceita native_records: quando a versao coincide, reatribui
somente o uint32 shapeId no payload original e o criptografa para a semente e
contador do destino. Mantem nome, esfera, flags, atributos, densidades e anexos.
Os registros criptografados preexistentes no destino continuam intactos.
A conversao entre versoes usa os canais conhecidos, preserva esfera/densidades
e recusa flags adicionais/anexos que nao consegue representar.

patch_uv_densities permite reparar metadados conhecidos sem mudar o tamanho
do payload/counters; recriptografa apenas a entidade afetada. No Fendt real,
reparar 252 e 253 alterou quatro bytes do .shapes e nenhum outro arquivo.
Testes verificam a textura AST identica, os buffers identicos, densidades
zero/nao triviais, UVs esparsos, subsets, anexos, conservacao do payload exceto
ID, conversao protegida, invalidacao do cache antigo, historico e exportacao.
O importador permanece incorporado ao I3D principal; I3D proprio no runtime
FS23 e uma pendencia separada.


## Opcionais nativos — v0.15

shop_options.py expoe inspect/create via GET/POST /api/shop-options. Descobre
XMLs vehicle com base/filename resolvido para o I3D principal. Nao adivinha
associacoes por nome e nao resolve parentFile sem base/filename direto.
O usuario escolhe explicitamente o XML quando ha variacoes compartilhando I3D.

Limita a criacao a design e design2..design8, registrados na log real FS23
fornecida pelo usuario. Secoes existentes e grupos referidos em configurationSets
ficam reservados. Seleciona o primeiro grupo livre; nao renumera nem altera grupos.
Cria duas opcoes nativas com nome, preco, saveId unico e objectChange para cada
no selecionado. visibilityActive depende da opcao, visibilityInactive e o inverso.
Os nomes/valores sao escapados pelo XML serializer; o restante do documento,
comentarios e codificacao sao preservados por insercao por spans.

scene_paths calcula caminhos da hierarquia incluindo reservas. A selecao protege
raizes, sobreposicao pai/filho, duplicados, slots cheios e indices invalidos.
Detecta conflitos de visibilidade via objectChange em caminhos diretos ou aliases
i3dMappings, inclusive ancestrais/descendentes da selecao. Nao reescreve funcoes.
A gravacao altera somente o XML escolhido, com revisao/historico atomicos. I3D,
malhas, recursos e outros XMLs permanecem byte-identicos. O novo XML passa a ser
considerado pela protecao de referencias das ferramentas de exclusao/agrupamento.

A interface tem listas exclusivas Sem/Com (ou Original/Novo), nomes, precos e
busca. A previa usa um snapshot das visibilidades e nao grava; ao fechar/cancelar
ou confirmar, restaura os valores originais. No modo de previa, o dialogo compacto
fica na parte inferior com fundo transparente; AJUSTAR retorna aos campos.
Os valores sao validados explicitamente, sem bloqueio silencioso de step do form.

Testes verificam descoberta, slots, path canonico, aliases, conflitos, substituicao
visual de pecas, nomes Unicode/escape, precos, XMLs compartilhados, revisoes,
historico/reabertura, preservacao binaria, HTTP e fluxo da interface com DOM simulado.
O caso real do Fendt cria design7 para a bandeira, confere que apenas fendt900.xml
muda e compara Desfazer byte a byte. Validacao visual no jogo continua pendente.
Formato ObjectChangeUtil documentado pela GIANTS:
https://gdn.giants-software.com/documentation_scripting_fs22.php?category=60&class=634&version=script

## Ferramentas e opcionais — v0.16

`shop_options.save/remove` reconhece grupos proprios por saveId e estrutura
nativa estrita, mantendo identidades das escolhas preservadas. De 2 a 20
escolhas, ate 50 nos controlados, nomes distintos e pelo menos dois conjuntos
visuais diferentes. Uma peca pode participar de mais de uma escolha. Grupos
nativos, configurationSets e controles extras sao protegidos. Edicao/substituicao
e exclusao preservam spans do restante do XML, encoding e historico.

`pose_tools` calcula transformacoes Rz*Ry*Rx, normais pela inversa transposta,
orientacao em espaco do pai e apoio pelo menor produto escalar dos vertices
visiveis ao longo da normal mundial. Escala negativa e pais nao uniformes sao
considerados. Espelhamento altera apenas sinal da escala local. Sem regravar
geometria; revisao e uma mutacao atomica do I3D.

`prefabs.export` cria temporariamente um destino vazio da mesma versao nativa,
reutiliza o importador de acessorios para extrair somente o ramo e recursos
visuais necessarios e devolve um ZIP reutilizavel sem mutar o projeto fonte.
Referencias da base ficam externas; nao e um mod funcional independente.

Rotas novas POST: /api/shop-options-delete, /api/mirror, /api/align,
/api/prefab (resposta application/zip). /api/shop-options aceita options[];
o corpo de duas escolhas da v15 continua compativel. A interface preserva
previews de visibilidade, revisao capturada e origem do alinhamento entre toques.

## Criacao guiada de opcionais — v0.17

Adicionar opcional inicia sem selecao obrigatoria, com Original e uma escolha
nova. A peca selecionada, quando abaixo da raiz, compoe Original. O ponto de
ligacao inicial e seu pai; o seletor exclui ramos controlados pelo opcional
para que uma alternativa nao fique filha de outra oculta.

O rascunho tem tres estados na interface: panel, import, position. Reutiliza
as rotas nativas de importacao, transformacao e shop-options; importacoes e
ajustes sao etapas reais do historico, enquanto o rascunho de escolhas fica
na memoria da pagina ate o save do XML. Fechar importacao sem adicionar nada
retorna ao rascunho. Fechar o rascunho nao remove as pecas ja importadas.

Cada escolha mantem indices da cena e um snapshot de nodeIds. Antes de
recarregar o I3D, captura identidades e restaura a previa; depois remapeia por
nodeId, incluindo a peca Original, porque insercoes alteram o preorder dos nos.
Referencias removidas bloqueiam save ate a lista ser revista. A revisao e
atualizada apos mutacoes autorizadas e o painel volta a inspecionar o XML ao
retomar, preservando titulo, precos e escolhas. Preview nao escreve arquivos.

A barra Voltar ao opcional preserva o acesso ao rascunho durante posicionamento;
a selecao de edicao fica no ramo da escolha atual. Alinhamento pode captar outra
superficie sem perder a origem. Trocas de arquivo, XML, base, projeto e historico
ficam bloqueadas enquanto o rascunho estiver aberto, assim como a exportacao.
Os paineis ficam inert durante operacoes pendentes para evitar fechar ou editar
um rascunho que esta recebendo uma importacao. Nenhuma rota nova e necessaria.

## Veiculos da base — v0.18

`base_vehicles.inventory` indexa XMLs <vehicle> em data/vehicles, resolve seu
base/filename e registra I3Ds sem associacao em uma lista separada de modelos.
O catalogo e cacheado por instancia GameBase, com copia dos resultados e refresh
explicito. A instancia/id da base e conferida em cada consulta ou acao.

`build` copia a pasta selecionada e garante o I3D principal e externalShapesFile.
Mantem caminhos canonicos data/vehicles/... no ZIP e o I3D principal na primeira
posicao. A reescrita por spans abrange atributos e texto simples que resolvam a
arquivos: locais viram relativos; recursos compartilhados continuam $data/$shared.
AST substituindo DDS usa referencia PNG. Bytes de .shapes, AST e outros binarios
sao copiados sem conversao, com stream de 1 MB. Encoding e comentarios dos XMLs
validos sao mantidos; auxiliares nao parseaveis ficam intactos e entram no relatorio.

GameBase.copy_to verifica identidade, limites, caminho e tamanho ao copiar.
O limite e 1 GB/20.000 arquivos por pacote, 256 MB por arquivo e 32 MB por XML.
Temp ZIPs sao apagados apos download/importacao e em falhas de montagem. Abertura
chama import_zip somente apos o pacote completo estar pronto. Nenhuma escrita
na base, APK ou GAR. Projetos normais continuam sem copiar recursos da base.

GET /api/base-vehicles e /api/base-vehicle-info listam/estimam. POST
/api/base-vehicle-open cria um projeto; /api/base-vehicle-export transmite ZIP
sem mudar o projeto. Ambos exigem baseId atual. A interface exibe tamanho,
pesquisa, distingue modelos avulsos e respeita o guard de rascunhos/edicoes para
abrir outra copia. Download e leitura sem troca de projeto.

## Pacote de mod novo — v0.19

`new_mod.options` exige XML <vehicle> associado por base/filename ao I3D local.
Retorna metadados e preco, usando o descritor existente ou descVersion 77 do
Fendt de referencia. Nao sintetiza rodas, motor ou fisica para I3Ds avulsos.

`new_mod.export` verifica projeto/revisao, valida metadados e cria ZIP temporario.
O descritor conserva scripts, tipos de veiculo, marcas, especializacoes e l10n
do descritor fonte. Reescreve metadados e storeItems para um XML selecionado.
Descritores em subpastas tem referencias locais de scripts/marcas reposicionadas
para a raiz; os descritores fontes locais permanecem recursos do projeto.

O XML do veiculo sofre apenas edicoes por spans em storeData/name, image e
price opcional. Demais bytes, componentes e opcionais permanecem. Um namespace
livre gabriel_mod/<nome>/ guarda icon.png e icon.ast. Usa PNG enviado, imagem da
loja decodificada ou icone simples de fallback, explicitado no relatorio/header.
AST do icone e RGBA8 GS2D com mipmaps; geometria/texturas do modelo sao copiadas.

GET /api/new-mod oferece o painel; POST /api/new-mod-export transmite ZIP e
remove o temporario. A geracao nao modifica projeto/revisao/historico nem a base.
O painel e inert durante operacoes e compartilha os guards de exportacao.
O carregamento efetivo no FS23 depende do carregador instalado pelo usuario;
montagem estrutural nao equivale a instalacao ou validacao em jogo.

## Correcao visual — v0.20

`.piece-tools-entry.primary` especifica texto escuro para evitar que a regra
verde de `.piece-tools-entry` esconda os rotulos no fundo verde de `.primary`.
O painel lateral tem rolagem externa, controles sem encolhimento e lista de
pecas com minimo de 140 px e maximo de 38dvh. Nao altera exportacao ou arquivos
dos projetos.


## Caminhos do carregador FS23 — v0.21
A log real do MF3670 confirmou que filename no XML do veiculo e sons parte da raiz do mod. new_mod.runtime_paths rebaseia recursos locais e dependencias XML com edicoes por spans. Referencias nativas $data/$shared e recursos relativos do I3D sao preservados. O resolver do editor aceita tambem caminhos da raiz.


## Ferramentas e rodas — v0.22
wheel_edit edita a configuracao efetiva no XML, isola herancas e grava objectChange
para o ponto repr da roda. Ajustes de tamanho criam I3D local com escala aplicada
no no do pneu; tire#scale nao e lido pelo carregador FS22. Malhas externas sao
copiadas byte a byte e texturas/shaders da base continuam nativos. Escrita atomica
multiarquivo com revisao, Desfazer/Refazer e fontes preservadas.
wheel_preview associa os nos gerados ao indice da roda e monta additionalWheel.
O deslocamento usa a largura dos aros, o intervalo e o lado da roda.
Referencia do formato: https://gdn.giants-software.com/documentation_scripting_fs22.php?category=48&class=580&version=script
workbench gerencia projetos locais e conjuntos reutilizaveis, valida arquivos e
alinha caixas visuais no espaco global. material_surface isola materiais para
opacidade e specularColor basico; paletas dos shaders sao preservadas.
Viewer oferece manipuladores por toque; testes Node cobrem hit, arraste, snap,
cancelamento e camera. Os testes de eventos usam a interface real com DOM mock,
e nao substituem testes de GPU no celular.


## Selecao e animacoes — v0.24
selection_tools normaliza raizes, converte deslocamento global para cada pai e
aplica movimentos, visibilidade, pintura isolada e exclusao em uma unica escrita
com historico. Exclusao reutiliza a auditoria funcional e reserva os indices.
editor_view.json guarda somente travas por projeto/modelo, fora do ZIP exportado.
Identidades usam nodeId unico ou caminho estrutural; nos montados nao interferem
na identidade dos nos reais. Travas tambem sao verificadas nas operacoes em lote.
Viewer separa a visibilidade nativa do filtro de isolamento e da trava de picking,
e suporta contornos multiplos. Isolar um filho preserva as matrizes dos ancestrais.
animation_preview le partes do XML associado e resolve caminhos/i3dMappings;
animation-ui amostra segmentos lineares de transformacao e visibilidade a partir
de uma pose original imutavel. A previa nao escreve arquivos. Fechar, trocar de
modelo ou exportar restaura a pose e cancela callbacks pendentes por token.
Sons, ossos, shaders, scripts e fisica continuam fora do escopo da previa.


## Criacao e texturas — v0.25
primitives gera formas estaticas com normais, UV0 e densidade de streaming.
Novos registros sao anexados a tabela nativa sem recodificar as malhas existentes.
A cena independente e um novo projeto; a base conectada e o projeto anterior
permanecem preservados. Formas em I3D inline convertem somente dados suportados.
texture_paint valida UV e material simples, clona o material da peca e grava
PNG + GS2D RGBA8 mipmapped junto do I3D em uma unica operacao de historico.
Materiais com customShaderId nao sao substituidos. Travas e revisoes sao verificadas.
canvas-paint implementa desenho 2D, preenchimento contiguo, texto, carimbos e
historico limitado a oito estados. texture-paint-ui usa uma textura GPU temporaria
e um material isolado para previa; cancelar restaura o material original.
creation-ui coordena cena vazia, medidas em cm e exportacao do grupo escolhido.
A exportacao reutiliza prefabs e copia o PNG editavel junto do AST referenciado.
Testes cobrem geometria, normais, UV, orientacao PNG/AST, isolamento, historico,
reimportacao do ZIP, rotas HTTP e eventos da interface com DOM/canvas simulado.
Validacao automatica nao substitui a verificacao de GPU e jogo no celular.


## Texturas em potencias de dois — v0.26
O gerador GS2D normaliza cada eixo para a proxima potencia de dois, ate 1024,
antes de montar a cadeia completa de mipmaps. Interpolacao bilinear ponderada
por alpha evita contaminar bordas com RGB de pixels transparentes. O bitmap
inteiro ocupa o mesmo UV; a geometria da plotagem continua baseada no PNG original.
Exportar detecta ASTs RGBA8 antigos nas pastas gabriel_plotagens/gabriel_texturas
e normaliza somente os bytes do ZIP final, inclusive sem overrides no projeto.
A deteccao nao altera ASTC, formatos desconhecidos ou outros caminhos. PNGs,
revisao, undo/redo e os arquivos fonte permanecem preservados.
